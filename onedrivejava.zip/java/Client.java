import java.net.URI;

import static sun.security.jgss.GSSUtil.login;

public class Client {
    public static final String ITEM_ID_PREFIX = "/me/drive/items/";
    private RequestTool requestTool;
    private AuthHelper authHelper;


    /**
     * Construct with auto login.
     *
     * @param clientId     Client id that MS gave to programmer for identify programmer's applications.
     * @param scope        Array of scopes that client requires.
     * @param redirectURL  Redirect URL that programmer already set in Application setting. It must matches with set
     *                     one!
     * @param clientSecret Client secret key that MS gave to programmer.
     *
     * @throws UnsupportedOperationException If the user default browser is not found, or it fails to be launched, or
     *                                       the default handler application failed to be launched, or the current
     *                                       platform does not support the {@link java.awt.Desktop.Action#BROWSE}
     *                                       action.
     * @throws RuntimeException              if login is unsuccessful.
     */
    public Client( String clientId,   String[] scope,
                    String redirectURL,   String clientSecret) {
        this(clientId, scope, redirectURL, clientSecret, true);
    }


    /**
     * @param clientId     Client id that MS gave to programmer for identify programmer's applications.
     * @param scope        Array of scopes that client requires.
     * @param redirectURL  Redirect URL that programmer already set in Application setting. It must matches with set
     *                     one!
     * @param clientSecret Client secret key that MS gave to programmer.
     * @param withLogin    if {@code true} construct with login.
     *
     * @throws UnsupportedOperationException If the user default browser is not found, or it fails to be launched, or
     *                                       the default handler application failed to be launched, or the current
     *                                       platform does not support the {@link java.awt.Desktop.Action#BROWSE}
     *                                       action.
     * @throws RuntimeException              if login is unsuccessful.
     */
    public Client( String clientId,  String[] scope,  String redirectURL,
                   String clientSecret, boolean withLogin) {
        requestTool = new RequestTool(this);

        this.authHelper = new AuthHelper(scope, clientId, clientSecret, redirectURL, this.requestTool);

        if (withLogin) authHelper.login();
    }


}
