import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;

import java.io.IOException;

class RequestTool {
    private JsonFactory jsonFactory;

    public RequestTool(Client client) {
    }
    public AuthenticationInfo parseAuthAndHandle(SyncResponse response, int expectedCode) throws Exception {
        try {
            JsonParser parser = jsonFactory.createParser(response.getContent());
            parser.nextToken();

            if (response.getCode() == expectedCode) {
                return AuthenticationInfo.deserialize(parser, true);
            }
            else {
                System.out.println("Occured Error");
                System.exit(0);
            }
        }
        catch (IOException e) {
            // FIXME: custom exception
            throw new RuntimeException("DEV: Unrecognizable json response.", e);
        }
        return null;
    }

}
