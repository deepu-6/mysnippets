import java.net.URL;
import java.nio.Buffer;
import java.util.List;
import java.util.Map;

public class SyncResponse {
     protected final URL url;
     protected final int code;
     protected final String message;
     protected final Map<String, List<String>> header;
     protected final byte[] contentBuf;
    protected String contentString;

    public SyncResponse(URL url, int code, String message,
                        Map<String, List<String>> header, byte[] contentBuf) {
        this.url = url;
        this.code = code;
        this.message = message;
        this.header = header;
        this.contentBuf = contentBuf;
    }
    
    public byte[] getContent() {
        return getContent(true);
    }

    public byte[] getContent(boolean autoRelease) {
        byte[] array = contentBuf;
        if (autoRelease) release();
        return array;
    }
    
    public int getCode() {
        return code;
    }
    public void release() {
//        contentBuf.release();
    }
}
