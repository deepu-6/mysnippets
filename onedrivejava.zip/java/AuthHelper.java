import static java.net.HttpURLConnection.HTTP_OK;


public class AuthHelper {
    private static final String AUTH_URL = "https://login.microsoftonline.com/common/oauth2/v2.0";
    public static final String CONTENT_TYPE = "content-type";
    public static final String APPLICATION_X_WWW_FORM_URLENCODED = "application/x-www-form-urlencoded";

    private RequestTool requestTool;
    private String[] scopes;
    private String clientId;
    private String clientSecret;
    private String redirectURL;
    private String authCode;
    private AuthenticationInfo authInfo;
    private String fullToken;

    public AuthHelper( String[] scopes, String clientId, String clientSecret, String redirectURL, RequestTool requestTool) {
        this.scopes = scopes;
        this.clientId = clientId;
        this.clientSecret = clientSecret;
        this.redirectURL = redirectURL;
        this.requestTool = requestTool;
    }

    public boolean isLogin() {
        return authCode != null && authInfo != null;
    }


     public boolean isExpired() {
        if (!isLogin())
            System.out.println("LOGIN_FIRST");
        //noinspection ConstantConditions
        return System.currentTimeMillis() >= authInfo.getExpiresIn();
    }

     public  String getTokenType() {
        checkExpired();
        return authInfo.getTokenType();
    }

     public  String getAccessToken() {
        checkExpired();
        return authInfo.getAccessToken();
    }

     public  String getRefreshToken() {
        checkExpired();
        return authInfo.getRefreshToken();
    }

     public  String getAuthCode() {
        checkExpired();
        //noinspection ConstantConditions
        return authCode;
    }

     public long getExpirationTime() {
        checkExpired();
        return authInfo.getExpiresIn();
    }

     public  String getFullToken() {
        checkExpired();
        return fullToken;
    }

    public void checkExpired() {
        if (!isLogin())
            System.out.println("LOGIN_FIRST");
        if (isExpired()) refreshLogin();
    }
    public void login() {
        if (!isLogin()) {
//            authCode = getCode();
            redeemToken();
        }
    }
    public String refreshLogin() {
        if (!isLogin())
            System.out.println("LOGIN_FIRST");
        return getToken(
                String.format("client_id=%s&redirect_uri=%s&client_secret=%s&refresh_token=%s&grant_type" +
                                "=refresh_token",
                        clientId, redirectURL, clientSecret, authInfo.getRefreshToken()));
    }

    /**
     * Get token from server with login information that given when {@code Client} object was constructed.<br>
     * And save to their own {@code Client} object.
     * <a href="https://dev.onedrive.com/auth/msa_oauth.htm#step-3-get-a-new-access-token-or-refresh-token">detail</a>
     *
     */
    private void redeemToken() {
        getToken(String.format("client_id=%s&redirect_uri=%s&client_secret=%s&code=%s&grant_type=authorization_code",
                clientId, redirectURL, clientSecret, authCode));
    }

    /**
     * Posting login information to server, be granted and get access token from server. and save them to this
     * {@code Client} object.
     *
     * @param httpBody HTTP POST's body that will be sent to server for being granted.
     *
     * @return access token {@code String} that given from server.
     *
     */
    private  String getToken(String httpBody) {
        SyncResponse response = new SyncRequest(AUTH_URL + "/token")
                .setHeader(CONTENT_TYPE, APPLICATION_X_WWW_FORM_URLENCODED)
                .doPost(httpBody);

        try {
            authInfo = requestTool.parseAuthAndHandle(response, HTTP_OK);
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        this.fullToken = authInfo.getTokenType() + ' ' + authInfo.getAccessToken();

        return authInfo.getAccessToken();
    }
}
