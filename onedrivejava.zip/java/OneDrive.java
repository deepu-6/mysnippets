import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import org.apache.commons.dbutils.QueryRunner;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.stringtemplate.v4.ST;
import org.stringtemplate.v4.STGroupFile;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.*;

public class OneDrive  {
    public static void main(String[] args)throws Exception {
        HttpResponse<String> response = Unirest.get("https://graph.microsoft.com/v1.0/me/drive/root/children/")
                .header("Authorization", "Bearer eyJ0eXAiOiJKV1QiLCJub25jZSI6ImlaVERNSUVUck5QVDhlaDhLcEtwc1lBODdOUGwyS1ZyRUNjdG1iOFlKdmMiLCJhbGciOiJSUzI1NiIsIng1dCI6IkJCOENlRlZxeWFHckdOdWVoSklpTDRkZmp6dyIsImtpZCI6IkJCOENlRlZxeWFHckdOdWVoSklpTDRkZmp6dyJ9.eyJhdWQiOiIwMDAwMDAwMy0wMDAwLTAwMDAtYzAwMC0wMDAwMDAwMDAwMDAiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9mZGNmNmZhZC1jM2YwLTRjNjYtOGNhMS0xZTNhYWFjNjUxNTAvIiwiaWF0IjoxNTc0MDczNzEzLCJuYmYiOjE1NzQwNzM3MTMsImV4cCI6MTU3NDA3NzYxMywiYWNjdCI6MCwiYWNyIjoiMSIsImFpbyI6IkFTUUEyLzhOQUFBQXlUblJEUW41Zkc2bEZzRlU1YStnYnpUMnloZTBuNE1zZGNxVWxZY3VpRGM9IiwiYW1yIjpbInB3ZCJdLCJhcHBfZGlzcGxheW5hbWUiOiJHcmFwaCBleHBsb3JlciIsImFwcGlkIjoiZGU4YmM4YjUtZDlmOS00OGIxLWE4YWQtYjc0OGRhNzI1MDY0IiwiYXBwaWRhY3IiOiIwIiwiZmFtaWx5X25hbWUiOiJHdW50dWthIiwiZ2l2ZW5fbmFtZSI6IlN1ZGVlcCIsImlwYWRkciI6IjE0LjE0My4xNzMuOTgiLCJuYW1lIjoiU3VkZWVwIEd1bnR1a2EiLCJvaWQiOiI0NWJmNTViNS1hOTRiLTQ0ODgtOGM5Ny02NzJhYzEwNjI4MTciLCJwbGF0ZiI6IjMiLCJwdWlkIjoiMTAwMzIwMDA0RjdCODc3QyIsInNjcCI6IkNhbGVuZGFycy5SZWFkV3JpdGUgQ29udGFjdHMuUmVhZFdyaXRlIEZpbGVzLlJlYWRXcml0ZS5BbGwgTWFpbC5SZWFkV3JpdGUgTm90ZXMuUmVhZFdyaXRlLkFsbCBvcGVuaWQgUGVvcGxlLlJlYWQgcHJvZmlsZSBTaXRlcy5SZWFkV3JpdGUuQWxsIFRhc2tzLlJlYWRXcml0ZSBVc2VyLlJlYWQgVXNlci5SZWFkQmFzaWMuQWxsIFVzZXIuUmVhZFdyaXRlIGVtYWlsIiwic2lnbmluX3N0YXRlIjpbImttc2kiXSwic3ViIjoiSHVucmZQZTlZdWtHMU1kcHduTnVkM1lvb09pTmt5aF9wUm5SR1RBSVFjWSIsInRpZCI6ImZkY2Y2ZmFkLWMzZjAtNGM2Ni04Y2ExLTFlM2FhYWM2NTE1MCIsInVuaXF1ZV9uYW1lIjoic3VkZWVwLmd1bnR1a2FAbW9kYWthbmFseXRpY3MuY29tIiwidXBuIjoic3VkZWVwLmd1bnR1a2FAbW9kYWthbmFseXRpY3MuY29tIiwidXRpIjoiWV9UMFZkR21pVUdmZENHWml5bDBBQSIsInZlciI6IjEuMCIsInhtc19zdCI6eyJzdWIiOiJERS1Pam5odkt1NS10TU5uQTMxODJFejZNNFlmUlc1c3RoS28xdWRIQWkwIn0sInhtc190Y2R0IjoxNTE0ODc5OTI5fQ.CzsC0yqfo-00R8WUPK_i-NYiHzZgevdHh1fm0xTo4G6muFilMftSaw2DW9K4XBUAIAHJnoQ5VSpfzYvNjSy37R2YcoIgwSUF4NKg9D_ZHChs0RXFb0sH4U-3xquoRM_LKuYnYPD9muPej1VtZbpGMkW8Z6Pcv-Yz3DJEfieiM4i0xjG5qv3PctiKMGwGgkOw2UFKA6CU2D_cjgew3IIUZ2bH2RQJ4QdaqMKNAV3AqsUyWql_MC7-71HtL8m83O5xtP6TxeLMUh3_drw7BTnnn32Uc8OKZs0npcWVZwtewibl3VLjplOghnLZ5HexMp1HSlQfz3OqIgSpScIWm5XlFQ")
                .header("User-Agent", "PostmanRuntime/7.17.1")
                .header("Accept", "*/*")
                .header("Cache-Control", "no-cache")
                .header("Postman-Token", "67a2aba8-ad53-4c25-b2da-ac20c696211c")
                .header("Host", "graph.microsoft.com")
                .header("Accept-Encoding", "gzip, deflate")
                .header("Connection", "keep-alive")
                .header("cache-control", "no-cache")
                .asString();
        System.out.println(response.getBody());
        Map<String, Object> hm = JsonToMap.jsonString2Map(response.getBody());

        List<Map<String, Object>> list=new ArrayList<Map<String, Object>>();
        ArrayList<Object> arr = (ArrayList<Object>) hm.get("value");

        System.out.println(arr);
        for (Object obj:arr) {
            Map<String, Object> map = (Map<String, Object>) obj ;
            Map<String,Object> createdBy = (Map<String,Object>) map.get("createdBy");
            Map<String,Object> app = (Map<String,Object>)createdBy.get("application");
            Map<String,Object> user = (Map<String,Object>)createdBy.get("user");

            String user_id=(String) user.get("id");
            String user_email=(String) user.get("email");
            String user_displayname=(String) user.get("email");
            String app_id=(String) app.get("id");
            String app_displayname=(String) user.get("email");
            list.add(map);
        }


        System.out.println("List: " + list);
        for (Map<String, Object> map : list) {
            if(map.containsKey("folder")){
                System.out.println("true");
            }
            if(map.containsKey("file")){
                jdbcConnection(map);
                System.out.println("vijay: "+map);
                System.out.println();
            }
            System.out.println(map.get("createdBy.application"));
        }

    }
    static void jdbcConnection(Map<String,Object> map )throws Exception
    {
        QueryRunner queryrunner = new QueryRunner();
        Class.forName("org.postgresql.Driver");
        Connection conn= DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres","postgres","Temp@123");
        STGroupFile groupfile = new STGroupFile("C:\\WorkSpace\\botworks-master\\OneDriveCrawler\\src\\main\\resources", '$', '$');
        ST myTemplate = groupfile.getInstanceOf("stagingInsertDriveFilemeta")
                .add("map",map );
//        queryrunner.update(conn,myTemplate.render());
        System.out.println(myTemplate.render());
//        ST myTemplate2 = groupfile.getInstanceOf("koshInsertTablemeta");
//        queryrunner.update(conn,myTemplate2.render());
        conn.close();

    }
}





class JsonToMap {
    static String jsonString = null;

    public static Map<String, Object> jsonString2Map(String jsonString) throws JSONException {
        Map<String, Object> keys = new HashMap<String, Object>();

        JSONObject jsonObject = new JSONObject(jsonString);
        Iterator<?> keyset = jsonObject.keys();

        while (keyset.hasNext()) {
            String key = (String) keyset.next();
            Object value = jsonObject.get(key);
            if (value instanceof JSONObject) {
                keys.put(key, jsonString2Map(value.toString()));

            } else if (value instanceof JSONArray) {
                JSONArray jsonArray = jsonObject.getJSONArray(key);
                keys.put(key, jsonArray2List(jsonArray));

            } else {
                keys.put(key, value);
            }
        }
        return keys;
    }

    public static List<Object> jsonArray2List(JSONArray arrayOFKeys) throws JSONException {
        List<Object> array2List = new ArrayList<Object>();
        for (int i = 0; i < arrayOFKeys.length(); i++) {
            if (arrayOFKeys.opt(i) instanceof JSONObject) {
                Map<String, Object> subObj2Map = jsonString2Map(arrayOFKeys.opt(i).toString());
                array2List.add(subObj2Map);
            } else if (arrayOFKeys.opt(i) instanceof JSONArray) {
                List<Object> subarray2List = jsonArray2List((JSONArray) arrayOFKeys.opt(i));
                array2List.add(subarray2List);
            } else {
                array2List.add(arrayOFKeys.opt(i));
            }
        }
        return array2List;
    }
}
