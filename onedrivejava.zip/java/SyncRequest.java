import java.io.*;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPInputStream;

public class SyncRequest {
    private HttpURLConnection httpConnection;

    public SyncRequest(String s) {
    }

    public SyncResponse doPost(String content) {
        byte[] bytes = content.getBytes(StandardCharsets.UTF_8);
        return doPost(bytes);
    }

    public SyncResponse doPost(String content, Charset charset) {
        byte[] bytes = content.getBytes(charset);
        return doPost(bytes);
    }

    public SyncResponse doPost(byte[] content) {
        try {
            httpConnection.setRequestMethod("POST");
            return sendContent(content);
        }
        catch (ProtocolException e) {
            throw new UnsupportedOperationException("unsupported method POST. contact author with stacktrace", e);
        }
    }
    public SyncResponse sendContent(byte[] content) {
        try {
            httpConnection.setDoOutput(true);

            httpConnection.setFixedLengthStreamingMode(content.length);

            OutputStream out = httpConnection.getOutputStream();
            out.write(content);
            out.flush();
            out.close();

            return makeResponse();
        }
        catch (IOException e) {
            // FIXME: custom exception
            System.out.println("IOException: ");
            e.printStackTrace();
        }
        return null;
    }
    protected SyncResponse makeResponse() {
        try {
            int code = httpConnection.getResponseCode();
            String message = httpConnection.getResponseMessage();
            Map<String, List<String>> header = httpConnection.getHeaderFields();
            URL url = httpConnection.getURL();
            /*
            // TODO: performance test for directBuffer or Pooled buffer
            ByteBuf byteBuf = Unpooled.buffer(512);
            InputStream body;

            // TODO: how about directly pass this steams to jackson for performance
            if (code < 400)
                if ("gzip".equals(httpConnection.getContentEncoding()))
                    body = new GZIPInputStream(httpConnection.getInputStream());
                else
                    body = httpConnection.getInputStream();
            else
                body = httpConnection.getErrorStream();

            byte[] buffer = new byte[512];

            int readBytes;
            while ((readBytes = body.read(buffer)) >= 0) {
                byteBuf.writeBytes(buffer, 0, readBytes);
            }
            body.close();
            return new SyncResponse(url, code, message, header, byteBuf);
            */
            // which one is better?

            ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
			BufferedInputStream body;

			if (code < 400)
				body = new BufferedInputStream(httpConnection.getInputStream());
			else
				body = new BufferedInputStream(httpConnection.getErrorStream());

			int bytes;
			while ((bytes = body.read()) != -1) {
				byteStream.write(bytes);
			}

			body.close();
			body.close();
			return new SyncResponse(url, code, message, header, byteStream.toByteArray());

        }
        catch (IOException e) {
            // FIXME: custom exception
            System.out.println("IOException: ");
            e.printStackTrace();
        }
        finally {
            httpConnection.disconnect();
        }
        return null;
    }
    /**
     * Add {@code key}, {@code value} pair to http request's header.<br>
     * Like: {@code key}: {@code value}.
     *
     * @param key   Key to add in request's header.
     * @param value Value to add in request's header. It could be {@code null}.
     */
    public SyncRequest setHeader( CharSequence key, CharSequence value) {
        httpConnection.setRequestProperty(key.toString(), value != null ? value.toString() : null);
        return this;
    }

}
