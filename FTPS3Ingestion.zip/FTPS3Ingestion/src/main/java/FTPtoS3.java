import com.amazonaws.ClientConfiguration;
import com.amazonaws.Protocol;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import org.apache.commons.net.PrintCommandListener;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;

import java.io.InputStream;
import java.io.PrintWriter;

public class FTPtoS3 {
    public static void main(String[] args) {
//        HashMap<String, Object> sourceConfig = null;
        String filename = args[0];
        FTPClient ftpClient;
        try {
            ftpClient = initSourceConnection();
            String fileRelativePath = "/pub/databases/uniprot/current_release/rdf/" + filename;
            InputStream fileinputStream = ftpClient.retrieveFileStream(fileRelativePath);
            System.out.println("Start");
//            ftpClient.sendCommand("SIZE", fileRelativePath);
//            String fileSize = ftpClient.getReplyString();
//            System.out.println("Reply for SIZE command: " + fileSize);
//
//            FTPFile ftpFile = ftpClient.mlistFile(fileRelativePath);
//            System.out.println("End");
//            long fileSize = ftpFile.getSize();
            long fileSize = Long.parseLong(args[1]);
            System.setProperty("com.amazonaws.sdk.s3.defaultStreamBufferSize", String.valueOf(fileSize + 1));
            AmazonS3 s3Client = configureS3Client();
            streamDataToS3Bucket(s3Client, "nabugluecrawler", "ftpTest/" + filename, fileSize, fileinputStream);
            System.out.println("END");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //FTP
    public static FTPClient initSourceConnection() throws Exception {
        FTPClient ftpClient = new FTPClient();
        ftpClient.addProtocolCommandListener(new PrintCommandListener(new PrintWriter(System.out)));
        ftpClient.connect("ftp.uniprot.org");
        ftpClient.login("anonymous", "anonymous");
        ftpClient.enterLocalPassiveMode();
        ftpClient.setFileType(FTP.BINARY_FILE_TYPE);
        ftpClient.setRemoteVerificationEnabled(false);
        return ftpClient;
    }

    //S3
    public static AmazonS3 configureS3Client() {
        AWSCredentials credentials = new BasicAWSCredentials("AKIA2HNV7Z7OKEDMYOOI", "COXhFgev3/YDtW4SvOvosr36Yaw09m8oHLQj4FWD");
        ClientConfiguration clientConfig = new ClientConfiguration();
        clientConfig.setProtocol(Protocol.HTTP);
        clientConfig.setConnectionTimeout(1800000);
        clientConfig.setSocketTimeout(1800000);
        clientConfig.setConnectionMaxIdleMillis(1800000);
        AmazonS3 s3client = AmazonS3ClientBuilder
                .standard()
                .withCredentials(new AWSStaticCredentialsProvider(credentials))
                .withClientConfiguration(clientConfig)
                .withRegion("us-west-2")
                .build();
        return s3client;
    }

    public static void streamDataToS3Bucket(AmazonS3 s3Client, String bucketName, String filePath, Long fileSize, InputStream inputStream) {
        ObjectMetadata metadata = new ObjectMetadata();
        metadata.setContentLength(fileSize);
        s3Client.putObject(new PutObjectRequest(bucketName, filePath, inputStream, metadata));
    }
}