from pyspark.sql.types import FloatType
from pyspark.sql.functions import col


class KnowledgeGraphBuilder:

    def __init__(self, neo4j_config, spark_session):
        self.__neo4j_uri = neo4j_config['uri']
        self.__neo4j_user = neo4j_config['user']
        self.__neo4j_pwd = neo4j_config['pwd']
        self.__neo4j_db = neo4j_config['db']
        self.__spark = spark_session
        self.__data = {}

    def neo4j_overwrite_framewriter(self, __df, executors):
        return __df\
            .repartition(executors).write.format("org.neo4j.spark.DataSource").mode("Overwrite") \
            .option("url", self.__neo4j_uri) \
            .option("authentication.type", "basic") \
            .option("authentication.basic.password", self.__neo4j_pwd) \
            .option("authentication.basic.username", self.__neo4j_user) \
            .option("database", self.__neo4j_db)
			
    def neo4j_errorifexists_framewriter(self, __df, executors):
        return __df\
            .repartition(executors).write.format("org.neo4j.spark.DataSource").mode("ErrorIfExists") \
            .option("url", self.__neo4j_uri) \
            .option("authentication.type", "basic") \
            .option("authentication.basic.password", self.__neo4j_pwd) \
            .option("authentication.basic.username", self.__neo4j_user) \
            .option("database", self.__neo4j_db)


    def write_entities(self, source_df, executors=10):
        df = source_df.filter("LABEL IS NOT NULL").filter("ID IS NOT NULL").dropDuplicates()
        e_reference = {
            "labels": [str(x.LABEL) for x in df.select(col("LABEL")).distinct().collect()],
            "key_column": "ID",
            "property_columns": ','.join([c for c in df.columns if c not in ['ID', 'LABEL']])
        }
        print(e_reference)
        df.printSchema()
        for node_label in e_reference["labels"]:
            df_l = df \
                .filter("LABEL='" + node_label + "'")
            print('Writing ' + str(df_l.count()) + ' nodes of type ' + node_label)
            self.neo4j_overwrite_framewriter(df_l, executors=executors) \
                .option("labels", ":" + node_label) \
                .option("node.keys", e_reference["key_column"]) \
                .option("node.properties", e_reference["property_columns"]) \
                .save()
    
    def write_relations(self, source_df, executors):

        df = source_df.select(
            col("ENTITY1"),
            col("ENTITY1_TYPE"),
            col("ENTITY2"),
            col("ENTITY2_TYPE"),
            col("REL_TYPE"),
            col("STRENGTH"),
            col("RESULT"),
            col("RESULT_TYPE"),
            col("CONFIDENCE").cast(FloatType()),
            col("METADATA.*"),
            col("LINEAGE.*")
        ).filter("ENTITY1 IS NOT NULL").filter("ENTITY2 IS NOT NULL")
        df.printSchema()
        e1_ref = {
            "labels": [str(x.ENTITY1_TYPE) for x in df.select(col("ENTITY1_TYPE")).distinct().collect()],
            "key_column": "ENTITY1"
        }
        e2_ref = {
            "labels": [str(x.ENTITY2_TYPE) for x in df.select(col("ENTITY2_TYPE")).distinct().collect()],
            "key_column": "ENTITY2"
        }
        rel_ref = {
            "labels": [str(x.REL_TYPE) for x in df.select(col("REL_TYPE")).distinct().collect()],
            "property_columns": ','.join(
                [c for c in df.columns if c not in ['ENTITY1', 'ENTITY1_TYPE', 'ENTITY2', 'ENTITY2_TYPE', 'REL_TYPE']]
            )
        }
        print('Writing '+str(df.count())+' relationships')
        for rel_label in rel_ref["labels"]:
            for e1_label in e1_ref["labels"]:
                for e2_label in e2_ref["labels"]:
                    df_r = df \
                        .filter("REL_TYPE='" + rel_label + "'") \
                        .filter("ENTITY1_TYPE='" + e1_label + "'") \
                        .filter("ENTITY2_TYPE='" + e2_label + "'")
                    print('Writing ' + str(df_r.count()) + ' relationships of type '+rel_label+
                          ' between '+e1_label+' and '+e2_label)
                    self.neo4j_overwrite_framewriter(df_r, executors=executors)\
                        .option("relationship", rel_label) \
                        .option("relationship.save.strategy", "keys") \
                        .option("relationship.source.labels", e1_label) \
                        .option("relationship.source.save.mode", "Overwrite") \
                        .option("relationship.source.node.keys", e1_ref["key_column"]+":ID") \
                        .option("relationship.target.labels", e2_label) \
                        .option("relationship.target.save.mode", "Overwrite") \
                        .option("relationship.target.node.keys", e2_ref["key_column"]+":ID") \
                        .option("relationship.properties", rel_ref["property_columns"]) \
                        .save()

    def load_entities_from_tables(self, table_config):
        for table_name in table_config:
            self.__data[table_name] = {
                'dataframe': self.__spark.table(table_name).distinct(),
                'ent_count': self.__spark.table(table_name).distinct().count()
            }
            self.write_entities(
                source_df=self.__data[table_name]['dataframe']
            )

    def load_relationships_from_tables(self, table_config):
        for table_name, bidir_rels in table_config:
            self.__data[table_name] = {
                'dataframe': self.__spark.table(table_name).distinct(),
                'ent_count': self.__spark.table(table_name).distinct().count()
            }
            self.write_relations(
                source_df=self.__data[table_name]['dataframe']
            )
	
    def load_relationships_from_sequence_partitions(self, table_config):
        for table_name, bidir_rels in table_config:
            df = self.__spark.table(table_name).distinct()
            df_tilesrc_list = df.select(col("tilesrc")).distinct().rdd.flatMap(lambda x: x).collect()
            for partition in df_tilesrc_list:
                df_l = df.filter("TILESRC='" + partition + "'")
                print('Writing partition ' + partition + ', partition row count ' + str(df_l.count()))
                self.write_relations(source_df=df_l)

    def load_relationships_from_parallel_partitions(self, table_config, tilesrc_list, executors):
        for table_name, bidir_rels in table_config:
            df = self.__spark.table(table_name).distinct()
            df = df.filter(df.TILESRC.isin(tilesrc_list))
            self.write_relations(source_df=df, , executors=executors)

	
