from kgb import KnowledgeGraphBuilder
from neo4j import GraphDatabase
from pyspark.context import SparkContext
from pyspark.sql import HiveContext,SparkSession
import argparse
import requests
import logging
from pyspark.sql.functions import col

logging.basicConfig(level = logging.INFO)


spark = (SparkSession
 .builder
 .appName('ABBVIE NEO4J PARALLEL LOADING PIPELINE')
 .enableHiveSupport()
 .getOrCreate())


class Safetynet:

    def __init__(self, spark_session,uri,user,password,database_name):
        self.neo4j_config={
            'uri':uri,
            'user':user,
            'pwd':password,
            'db': database_name
        }
        self.kgb = KnowledgeGraphBuilder(neo4j_config=self.neo4j_config, spark_session=spark_session)

    def load_graph(self, tilesrc_list):
        self.load_relationships(tilesrc_list)

    def load_relationships(self, tilesrc_list):

        safetynet_tables = [
            ('ark.t_compound_compound_relationships', False)
        ]
        #self.kgb.load_relationships_from_sequence_partitions(safetynet_tables)
        self.kgb.load_relationships_from_parallel_partitions(safetynet_tables, tilesrc_list)



class vault_password:

    def get_password(self,token,cred_id,cred_type,fireshots_url):
        payload= {"credential_id": cred_id, "credential_type_id": cred_type}
        url= '{0}'.format(fireshots_url)
        r= requests.post(url, headers={"Content-Type":"application/json","Authorization" : token,"Accept": "application/json"},json= payload)
        if r.status_code == 200:
            logging.info("[+] Password obtained [+]")
            return r.json()
        else:
            logging.info(r.json())

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("token")
    parser.add_argument("cred_id")
    parser.add_argument("cred_type")
    parser.add_argument("neo4j_uri")
    parser.add_argument("database")
    parser.add_argument("fireshots_url")
    parser.add_argument("tilesrc_args")
    parser.add_argument("num_executors")
    args = parser.parse_args()
    neo4j_token =args.token
    cred_id= args.cred_id
    cred_type= args.cred_type
    neo4j_uri= args.neo4j_uri
    database_name= args.database
    fireshots_uri= args.fireshots_url
    executors= args.num_executors

    tilesrc_args = args.tilesrc_args
    print("Safetynet tile src")
    tilesrc_str = tilesrc_args.replace('[', '').replace(']', '')
    tilesrc_list = list(tilesrc_str.split(","))
    print(tilesrc_list)
    print(len(tilesrc_list))

    '''vault_obj= vault_password()
    dict_pass= vault_obj.get_password(neo4j_token,cred_id,cred_type,fireshots_uri)

    print(cred_id)
    print(cred_type)

    neo4j_password= dict_pass["data"]["password"]
    neo4j_user= dict_pass["data"]["username"]'''

    uri= '{0}'.format(neo4j_uri)
    database= '{0}'.format(database_name)

    neo4j_password= "Clmsdhoeshfjdfb1"
    neo4j_user= "archwriter"
    user= neo4j_user

    neo4j_load= Safetynet(spark,uri,user,neo4j_password,database)
    neo4j_load.load_graph(tilesrc_list, executors)
