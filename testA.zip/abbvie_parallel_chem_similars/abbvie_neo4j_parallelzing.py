import os.path
import os
import subprocess
import logging
import sys
import requests
import math
from pyspark.sql.functions import col
from pyspark.context import SparkContext
from pyspark.sql import HiveContext,SparkSession

spark = (SparkSession
 .builder
 .appName('ABBVIE NEO4J PARALLEL LOADING PIPELINE')
 .enableHiveSupport()
 .getOrCreate())

def parallelPartitions(git_folder_abbvie,abbvie_neo4j_script_name,token,cred_id_abbvie_neo4j,cred_type_abbvie_neo4j,keytab_path,principal,abbvie_neo4j_path,neo4j_jar_path,user_home_directory,abbvie_neo4j_uri,abbvie_neo4j_database_name,fireshots_url, db_table_name, df_tile_list):
   x=90
   list1=[]
   list2=[]

   if(x%2==1):
      dummy=True
      rounds=x
      x+=1
   else :
      dummy=False
      rounds=x-1

   for i in range(1,int(x/2)+1) :
       list1.append(i)
   for i in range(x,int(x/2),-1):
       list2.append(i)
   for i in range(rounds) :
       partitionPairings(list1,list2,x,dummy,git_folder_abbvie,abbvie_neo4j_script_name,token,cred_id_abbvie_neo4j,cred_type_abbvie_neo4j,keytab_path,principal,abbvie_neo4j_path,neo4j_jar_path,user_home_directory,abbvie_neo4j_uri,abbvie_neo4j_database_name,fireshots_url, db_table_name, df_tile_list)
       reArrange(list1,list2,x)

def reArrange(list1,list2,x):
    for i in range(int(x/2)):
        list1[i]-=1
        list2[i]-=1

    for i in range(int(x/2)):
        if(list1[i]==1):
            list1[i]=x
        if(list2[i]==1):
            list2[i]=x
    list1[0]=1

def partitionPairings(list1,list2,x,dummy,git_folder_abbvie,abbvie_neo4j_script_name,token,cred_id_abbvie_neo4j,cred_type_abbvie_neo4j,keytab_path,principal,abbvie_neo4j_path,neo4j_jar_path,user_home_directory,abbvie_neo4j_uri,abbvie_neo4j_database_name,fireshots_url, db_table_name, df_tile_list):
    tilesrc_list1=[]
    tilesrc_list2=[]
    for i in range(int(x/2)):
        if (not dummy) or (list1[i]!=x and list2[i]!=x):
            tilesrc_list1.append(str(list1[i]-1)+"x"+str(list2[i]-1))
            tilesrc_list2.append(str(list2[i]-1)+"x"+str(list1[i]-1))

    tilesrc_list = list(set(df_tile_list) & set(tilesrc_list1))
    abbvie_neo4j_parallel_load(tilesrc_list,git_folder_abbvie,abbvie_neo4j_script_name,token,cred_id_abbvie_neo4j,cred_type_abbvie_neo4j,keytab_path,principal,abbvie_neo4j_path,neo4j_jar_path,user_home_directory,abbvie_neo4j_uri,abbvie_neo4j_database_name,fireshots_url)

    tilesrc_list = list(set(df_tile_list) & set(tilesrc_list2))
    abbvie_neo4j_parallel_load(tilesrc_list,git_folder_abbvie,abbvie_neo4j_script_name,token,cred_id_abbvie_neo4j,cred_type_abbvie_neo4j,keytab_path,principal,abbvie_neo4j_path,neo4j_jar_path,user_home_directory,abbvie_neo4j_uri,abbvie_neo4j_database_name,fireshots_url)

def abbvie_neo4j_parallel_load(tilesrc_list, git_folder_abbvie,abbvie_neo4j_script_name,token,cred_id,cred_type,keytab_path, principal,abbvie_neo4j_path,neo4j_jar_path,user_home_directory,abbvie_neo4j_uri,database_name,fireshots_url):
    os.environ["PYSPARK_PYTHON"]="python3.6"
    '''kinit_cmd = "kinit -kt {0} {1}".format(keytab_path, principal)
    kinit_result= subprocess.Popen(kinit_cmd, shell=True, stdout= subprocess.PIPE)
    data,err= kinit_result.communicate()
    if kinit_result.returncode==0:
        logging.info("[+] kinit command succeeded [+]")
    else:
        for line in err.splitlines():
            print(line)
            logging.info("[+] kinit failed [+]")
    abbvie_neo4j_abs_path= '{0}'.format(abbvie_neo4j_path)
    os.chdir(abbvie_neo4j_abs_path)'''
    tilesrc_list_length = len(tilesrc_list)
    if tilesrc_list_length > 0 :
       num_cores = 5
       num_executors = math.ceil(tilesrc_list_length/num_cores)
       tilesrc_args = str(tilesrc_list).replace(' ', '')
       abbvie_neo4j_cmd= "spark-submit --executor-memory 40G --driver-memory 30G --packages org.neo4j.driver:neo4j-java-driver:4.2.0,org.neo4j:neo4j-cypher-dsl:2020.1.4 --executor-cores {8} --num-executors {9} --jars {0} {1} {2} {3} {4} {5} {6} {7} {10} {9}".format(neo4j_jar_path,abbvie_neo4j_script_name,token,cred_id,cred_type,abbvie_neo4j_uri,database_name,fireshots_url, num_cores, num_executors, tilesrc_args)
       print(abbvie_neo4j_cmd)
       abbvie_neo4j_result= subprocess.Popen(abbvie_neo4j_cmd,shell=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
       #Output of the cmd
       data, err = abbvie_neo4j_result.communicate()
       if abbvie_neo4j_result.returncode == 0:
           for line in data.splitlines():
               print(line)
           logging.info("[+] Abbvie neo4j parallel script successfull [+]")
       else:
           for line in err.splitlines():
               print(line)
           logging.critical("[+] Abbvie neo4j parallel script failed with {0} : {1} {2} [+]" .format(abbvie_neo4j_result.returncode, data, err))
           exit_with_error(abbvie_neo4j_result.returncode)

def exit_with_error(exit_code):
    sys.exit(exit_code)
    
if __name__ == "__main__":
    print("Started loading Chem Similars Relationships partitions parallelly...")
    db_table_name = 'ark.t_compound_compound_relationships'

    '''token= sys.argv[1]
    git_folder_abbvie= sys.argv[2]
    abbvie_neo4j_script_name= sys.argv[3]
    keytab_path = sys.argv[4]
    principal = sys.argv[5]
    user_home_directory = sys.argv[6]
    abbvie_neo4j_path = sys.argv[7]
    neo4j_jar_path = sys.argv[8]
    fireshots_url=sys.argv[9]
    cred_id_abbvie_neo4j= sys.argv[10]
    cred_type_abbvie_neo4j= sys.argv[11]
    abbvie_neo4j_uri= sys.argv[12]
    abbvie_neo4j_database_name= sys.argv[13]'''
    
    token= "sys.argv[1]"
    git_folder_abbvie= "sys.argv[1]"
    abbvie_neo4j_script_name= "/home/guntusk/safetynet_kgb_chem_parallel.py"
    keytab_path = "sys.argv[1]"
    principal = "sys.argv[1]"
    user_home_directory = "sys.argv[1]"
    abbvie_neo4j_path = "sys.argv[1]"
    neo4j_jar_path = "/home/guntusk/neo4j-connector-apache-spark_2.11-4.0.0.jar"
    fireshots_url="sys.argv[1]"
    cred_id_abbvie_neo4j= "sys.argv[1]"
    cred_type_abbvie_neo4j= "sys.argv[1]"
    abbvie_neo4j_uri= "neo4j+ssc://arch-dev-graph-gateway1.arch-dev.awscloud.abbvienet.com:7687"
    abbvie_neo4j_database_name= "safetynetdev"

    df = spark.sql("""select distinct tilesrc from """ + db_table_name)
    df_tile_list = df.select(col("tilesrc")).rdd.flatMap(lambda x: x).collect()

    parallelPartitions(git_folder_abbvie,abbvie_neo4j_script_name,token,cred_id_abbvie_neo4j,cred_type_abbvie_neo4j,keytab_path,principal,abbvie_neo4j_path,neo4j_jar_path,user_home_directory,abbvie_neo4j_uri,abbvie_neo4j_database_name,fireshots_url, db_table_name, df_tile_list)
