from neo4j import GraphDatabase
from neo4j.exceptions import ServiceUnavailable
from pyspark.sql import SparkSession
from logging import getLogger, StreamHandler, DEBUG
import logging
import re

logging.basicConfig(level = logging.INFO)

handler = StreamHandler()
handler.setLevel(DEBUG)
logging.getLogger("neo4j").addHandler(handler)

spark = (SparkSession
 .builder
 .appName('ABBVIE SCHEMA PIPELINE')
 .enableHiveSupport()
 .getOrCreate())

class Arch_constraints:
    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password)) 
        self.__spark = spark

    def create_constraints(self, database_name, arch_entities):
        labels = []
        flag = False
        for table_name in arch_entities:
            self.__spark.sql("REFRESH TABLE " + table_name)
            label_df = self.__spark.sql("SELECT DISTINCT LABEL FROM " + table_name).dropDuplicates()
            labels.extend([str(x.LABEL) for x in label_df.collect()])            
        labels = list(set(''.join(labels).split(':')))	
        try:
            with self.driver.session(database = database_name) as session:
                for label in labels:
                    if label :
                        alias = re.sub('[^a-zA-Z0-9]', '', label).lower()
                        constraint_cql = "CREATE CONSTRAINT {0} IF NOT EXISTS ON ({0}:`{1}`) ASSERT {0}.ID IS UNIQUE;".format(alias, label)
                        #print(constraint_cql)
                        session.run(constraint_cql)
                        flag = True
                        logging.info("Created unique constraint on {0}.".format(label))
         #Capture any errors along with the query and data for traceability
        except ServiceUnavailable as exception:
                logging.error("Table {} nodes, raised an error: \n {exception}".format(table_name, exception=exception))
               
        if flag:
            logging.info("[+] Created Constraints [+]")

        return labels
        
    def close(self):
        self.driver.close()

class Arch_indexes:

    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password))
        self.__spark = spark

    def create_indexes(self, database_name):
        try:
            with self.driver.session(database= database_name) as session:        
                session.run("CREATE INDEX inchi_key IF NOT EXISTS for (c:Compound) ON (c.INCHI_KEY);")
                session.run("CREATE INDEX chembl_id IF NOT EXISTS for (c:Compound) ON (c.CHEMBL_ID);")
                session.run("CREATE INDEX abbvie_id IF NOT EXISTS for (c:Compound) ON (c.ABBVIE_ID);")
                session.run("CREATE INDEX primaryidentifier IF NOT EXISTS for (c:Compound) ON (c.PRIMARYIDENTIFIER);")
                session.run("CREATE INDEX primarysource IF NOT EXISTS for (c:Compound) ON (c.PRIMARYSOURCE);")
                session.run("CREATE INDEX gene_primaryidentifier IF NOT EXISTS for (g:Gene) ON (g.PRIMARYIDENTIFIER);")
                session.run("CREATE INDEX preferred_name IF NOT EXISTS for (e:Endpoint) ON (e.PREFERRED_NAME);")
                session.run("CREATE INDEX label IF NOT EXISTS for (e:Endpoint) ON (e.LABEL);")
                session.run("CREATE INDEX meddra_id_increases_relationship IF NOT EXISTS FOR ()-[r:DECREASES]-() ON (r.MEDDRA_ID);")
                session.run("CREATE INDEX meddra_id_decreases_relationship IF NOT EXISTS FOR ()-[r:INCREASES]-() ON (r.MEDDRA_ID);")
                session.run("CREATE INDEX meddra_id_has_property_relationship IF NOT EXISTS FOR ()-[r:`Has Property`]-() ON (r.MEDDRA_ID);")
                session.run("CREATE INDEX meddra_id_impact_on_relationship IF NOT EXISTS FOR ()-[r:IMPACT_ON]-() ON (r.MEDDRA_ID);")
                session.run("CREATE INDEX meddra_id_does_not_significantly_affect_relationship IF NOT EXISTS FOR ()-[r:DOES_NOT_SIGNIFICANTLY_AFFECT]-() ON (r.MEDDRA_ID);")
                session.run("CREATE INDEX meddra_id_has_no_effect_relationship IF NOT EXISTS FOR ()-[r:HAS_NO_EFFECT]-() ON (r.MEDDRA_ID);")
                session.run("CREATE INDEX lineage_timestamp_is_chem_sim_to IF NOT EXISTS FOR ()-[r:`Is Chemically Similar To`]-() ON (r.TIMESTAMP);")
                session.run("CREATE INDEX tilesrc_is_chem_sim_to IF NOT EXISTS FOR ()-[r:`Is Chemically Similar To`]-() ON (r.TILESRC);")
                session.run("CREATE INDEX strength_is_chem_sim_to IF NOT EXISTS FOR ()-[r:`Is Chemically Similar To`]-() ON (r.STRENGTH);")
                session.run("CREATE INDEX metadata_belief_is_chem_sim_to IF NOT EXISTS FOR ()-[r:`Is Chemically Similar To`]-() ON (r.BELIEF);")
                session.run("CREATE INDEX ae_primaryidentifier IF NOT EXISTS for (ae:`Patient Adverse Event`) ON (ae.PRIMARYIDENTIFIER);")
                session.run("CREATE INDEX root_inchi_key IF NOT EXISTS for (c:Compound) ON (c.ROOT_INCHI_KEY);")
                session.run("CREATE INDEX adme_group_has_property IF NOT EXISTS FOR ()-[r:`Has Property`]-() ON (r.ADME_GROUP);") 
         #Capture any errors along with the query and data for traceability
        except ServiceUnavailable as exception:
                logging.error("Whhile creating required indexes, raised an error: \n {exception}".format(exception=exception))
                        
        logging.info("[+] Created Indexes. [+]")

    def create_index_on_modak_uid(self, database_name, entities_labels, relationships_tables):
        if len(entities_labels) != 0:
            try:
                
                with self.driver.session(database = database_name) as session:
                    for label in entities_labels:
                        #print( label)
                        if label :
                            alias = re.sub('[^a-zA-Z0-9]', '', label).lower() + "_mid_index"
                            index_cql = "CREATE INDEX {0} IF NOT EXISTS for (n:`{1}`) ON (n.MODAK_UID)".format(alias, label)
                            #print(index_cql)
                            session.run(index_cql)
                            logging.info("Created index for {0} on MODAK_UID.".format(label)) 
            #Capture any errors along with the query and data for traceability
            except ServiceUnavailable as exception:
                logging.error("While creating index for LABEL on MODAK_UID, raised an error: \n {exception}".format( exception=exception))
                        
            logging.info("[+] Created Indexes for Labels on MODAK_UID. [+]")

        if len(relationships_tables) != 0:
            rel_types = []
            for table_name in relationships_tables:
                self.__spark.sql("REFRESH TABLE " + table_name)
                rels_df = self.__spark.sql("SELECT DISTINCT REL_TYPE FROM " + table_name).dropDuplicates()
                rel_types.extend([str(x.REL_TYPE) for x in rels_df.collect()]) 
            rel_types = list(set(rel_types))
            
            try:
                with self.driver.session(database = database_name) as session:
                    for rel_type in rel_types:
                        #print(rel_type)
                        if rel_type :
                            alias = re.sub('[^a-zA-Z0-9]', '', rel_type).lower() + "_mid_index"
                            index_cql = "CREATE INDEX {0} IF NOT EXISTS for ()-[r:`{1}`]-() ON (r.MODAK_UID);".format(alias, rel_type)    
                            #print(index_cql)
                            session.run(index_cql)
                            logging.info("Created index {0} on MODAK_UID.".format(rel_type)) 
            #Capture any errors along with the query and data for traceability
            except ServiceUnavailable as exception:
                logging.error("While creating index for RELATIONSHIPS on MODAK_UID , raised an error: \n {exception}".format(exception=exception))
             
            logging.info("[+] Created Indexes for Relationship types on MODAK_UID. [+]")
        
    def close(self):
        self.driver.close()
