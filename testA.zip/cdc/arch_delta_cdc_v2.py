from kgb_cdc import KnowledgeGraphBuilder
from neo4j import GraphDatabase
from neo4j.exceptions import ServiceUnavailable
from pyspark.sql import SparkSession
from pyspark.sql.functions import col,monotonically_increasing_id
from logging import getLogger, StreamHandler, DEBUG
import logging
import requests
import re
import time
import datetime

logging.basicConfig(level = logging.INFO)

handler = StreamHandler()
handler.setLevel(DEBUG)
logging.getLogger("neo4j").addHandler(handler)

spark = (SparkSession
 .builder
 .appName('ABBVIE NEO4J CDC PIPELINE')
 .enableHiveSupport()
 .getOrCreate())

class Arch_constraints:
    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password)) 
        self.__spark = spark

    def create_constraints(self, database_name, arch_entities):
        labels = []
        flag = False
        for table_name in arch_entities:
            self.__spark.sql("REFRESH TABLE " + table_name)
            label_df = self.__spark.sql("SELECT DISTINCT LABEL FROM " + table_name).dropDuplicates()
            labels.extend([str(x.LABEL) for x in label_df.collect()])            
        labels = list(set(''.join(labels).split(':')))	
        with self.driver.session(database = database_name) as session:
            for label in labels:
                if label :
                    alias = re.sub('[^a-zA-Z0-9]', '', label).lower()
                    constraint_cql = "CREATE CONSTRAINT {0} IF NOT EXISTS ON ({0}:`{1}`) ASSERT {0}.ID IS UNIQUE;".format(alias, label)
                    #print(constraint_cql)
                    session.run(constraint_cql)
                    flag = True
                    logging.info("Created unique constraint on {0}.".format(label))
        if flag:
            logging.info("[+] Created Constraints [+]")

        return labels
        
    def close(self):
        self.driver.close()

class Arch_indexes:

    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password))
        self.__spark = spark

    def create_indexes(self, database_name):
        with self.driver.session(database= database_name) as session:        
            session.run("CREATE INDEX inchi_key IF NOT EXISTS for (c:Compound) ON (c.INCHI_KEY);")
            session.run("CREATE INDEX chembl_id IF NOT EXISTS for (c:Compound) ON (c.CHEMBL_ID);")
            session.run("CREATE INDEX abbvie_id IF NOT EXISTS for (c:Compound) ON (c.ABBVIE_ID);")
            session.run("CREATE INDEX primaryidentifier IF NOT EXISTS for (c:Compound) ON (c.PRIMARYIDENTIFIER);")
            session.run("CREATE INDEX primarysource IF NOT EXISTS for (c:Compound) ON (c.PRIMARYSOURCE);")
            session.run("CREATE INDEX gene_primaryidentifier IF NOT EXISTS for (g:Gene) ON (g.PRIMARYIDENTIFIER);")
            session.run("CREATE INDEX preferred_name IF NOT EXISTS for (e:Endpoint) ON (e.PREFERRED_NAME);")
            session.run("CREATE INDEX label IF NOT EXISTS for (e:Endpoint) ON (e.LABEL);")
            session.run("CREATE INDEX meddra_id_increases_relationship IF NOT EXISTS FOR ()-[r:DECREASES]-() ON (r.MEDDRA_ID);")
            session.run("CREATE INDEX meddra_id_decreases_relationship IF NOT EXISTS FOR ()-[r:INCREASES]-() ON (r.MEDDRA_ID);")
            session.run("CREATE INDEX meddra_id_has_property_relationship IF NOT EXISTS FOR ()-[r:`Has Property`]-() ON (r.MEDDRA_ID);")
            session.run("CREATE INDEX meddra_id_impact_on_relationship IF NOT EXISTS FOR ()-[r:IMPACT_ON]-() ON (r.MEDDRA_ID);")
            session.run("CREATE INDEX meddra_id_does_not_significantly_affect_relationship IF NOT EXISTS FOR ()-[r:DOES_NOT_SIGNIFICANTLY_AFFECT]-() ON (r.MEDDRA_ID);")
            session.run("CREATE INDEX meddra_id_has_no_effect_relationship IF NOT EXISTS FOR ()-[r:HAS_NO_EFFECT]-() ON (r.MEDDRA_ID);")
            session.run("CREATE INDEX lineage_timestamp_is_chem_sim_to IF NOT EXISTS FOR ()-[r:`Is Chemically Similar To`]-() ON (r.TIMESTAMP);")
            session.run("CREATE INDEX tilesrc_is_chem_sim_to IF NOT EXISTS FOR ()-[r:`Is Chemically Similar To`]-() ON (r.TILESRC);")
            session.run("CREATE INDEX strength_is_chem_sim_to IF NOT EXISTS FOR ()-[r:`Is Chemically Similar To`]-() ON (r.STRENGTH);")
            session.run("CREATE INDEX metadata_belief_is_chem_sim_to IF NOT EXISTS FOR ()-[r:`Is Chemically Similar To`]-() ON (r.BELIEF);")
            session.run("CREATE INDEX ae_primaryidentifier IF NOT EXISTS for (ae:`Patient Adverse Event`) ON (ae.PRIMARYIDENTIFIER);")
            session.run("CREATE INDEX root_inchi_key IF NOT EXISTS for (c:Compound) ON (c.ROOT_INCHI_KEY);")
            session.run("CREATE INDEX adme_group_has_property IF NOT EXISTS FOR ()-[r:`Has Property`]-() ON (r.ADME_GROUP);")                
        print("Created Indexes")

    def create_index_on_modak_uid(self, database_name, entities_labels, relationships_tables):
        if entities_labels:
            with self.driver.session(database = database_name) as session:
                for label in entities_labels:
                    if label :
                        alias = re.sub('[^a-zA-Z0-9]', '', label).lower() + "_mid_index"
                        index_cql = "CREATE INDEX {0} IF NOT EXISTS for (n:`{1}`) ON (n.MODAK_UID)".format(alias, rel_types)
                        print(index_cql)
                        session.run(index_cql)
                        logging.info("Created index {0} on MODAK_UID.".format(label)) 
            logging.info("[+] Created Indexes on Labels. [+]")

        if relationships_tables:
            rel_types = []
            for table_name in relationships_tables:
                self.__spark.sql("REFRESH TABLE " + table_name)
                rels_df = self.__spark.sql("SELECT DISTINCT REL_TYPE FROM " + table_name).dropDuplicates()
                rel_types.extend([str(x.REL_TYPE) for x in rels_df.collect()]) 
            rel_types = list(set(rel_types))
            with self.driver.session(database = database_name) as session:
                for rel_type in rel_types:
                    if label :
                        alias = re.sub('[^a-zA-Z0-9]', '', rel_type).lower() + "_mid_index"
                        index_cql = "CREATE INDEX {0} IF NOT EXISTS for ()-[r:`{1}`]-() ON (r.MODAK_UID);".format(alias, rel_type)    
                        print(index_cql)
                        session.run(index_cql)
                        logging.info("Created index {0} on MODAK_UID.".format(rel_type)) 
            logging.info("[+] Created Indexes on Relationship types. [+]")
        
    def close(self):
        self.driver.close()


class Arch_cdc:
    def __init__(self, spark_session, uri, user, password, database_name):
        self.driver = GraphDatabase.driver(uri, auth=(user, password))
        self.__spark = spark
        self.__database_name = database_name
        self.neo4j_config={
            'uri':uri,
            'user':user,
            'pwd':password,
            'db': database_name
        }
        self.kgb = KnowledgeGraphBuilder(neo4j_config=self.neo4j_config, spark_session=spark_session)
    
    def cdc_load(self, delta_entities, delta_rels):
        self.kgb.load_entities_from_tables(delta_entities) 
        self.kgb.load_relationships_from_tables(delta_rels)

    def cdc_delete(self, delta_entities, delta_rels):
        self.delete_entities_delta(delta_entities)
        self.delete_relationships_delta(delta_rels)

    def delete_entities_delta(self, delta_entities):
        '''
            This function deletes the graph nodes on respective database based on MODAK_UID.
        '''
        for table_name in delta_entities:
            start_time = time.time()
            modak_uid_batch_size=1000

            self.__spark.sql("REFRESH TABLE " + table_name)
            df = self.__spark.table(table_name)

            if(df.count() > 0):

                df = df.filter("LABEL IS NOT NULL").filter("MODAK_UID IS NOT NULL").dropDuplicates()
                label_df = df.select(col("LABEL")).distinct()
                e_reference = {
                    "labels": [str(x.LABEL) for x in label_df.collect()]
                    }
                try:
                    with self.driver.session(database = self.__database_name) as session:
                        for node_label in e_reference["labels"]:
                            df_l = df. \
                                    filter("LABEL =='" + node_label + "'")
                            hash_df = df_l.select(df_l.MODAK_UID.alias("modak_uid")).distinct()
                            hash_df = hash_df.coalesce(1).withColumn("row_num", monotonically_increasing_id())
                            delete_count = hash_df.count() + 1
                            total_count=committed=failed=0
                            errors = ''
                            for rows in range(0, delete_count, modak_uid_batch_size):
                                #print("row_num >= {} and row_num < {}".format(rows, rows+modak_uid_batch_size))
                                df_sub = hash_df.filter("row_num >= {} and row_num < {}".format(rows, rows+modak_uid_batch_size)).drop("row_num")
                                modak_uid_list = [str(x.modak_uid) for x in df_sub.collect()]
                                config = """
                                            { 
                                            batchSize:10, 
                                            parallel:false, 
                                            retries:5, 
                                            params:{modak_uid_list:$modak_uid_list} 
                                            }
                                        """
                                node_cql = "CALL apoc.periodic.iterate(\"UNWIND $modak_uid_list as mid MATCH (n{}) WHERE n.MODAK_UID = mid RETURN id(n) as nodeId\", \"MATCH (n{}) WHERE id(n)=nodeId DETACH DELETE n\", {})".format(self.label_parser(node_label), config)
                                print(node_cql)
                                delete_ops_result = session.write_transaction(self.delete_entities_delta_tx, modak_uid_list, node_cql)
                                total_count = total_count + int(delete_ops_result["total"])
                                committed = committed + int(delete_ops_result["committed"])
                                failed = failed + int(delete_ops_result["failed"])
                                errors = errors + str(delete_ops_result["errors"])

                            '''
                                Below find nodes deletion stats
                            '''
                            print("Deleted nodes total count: " + str(total_count))
                            print("Deleted nodes committed count: " + str(committed))
                            print("Deleted nodes failed count: " + str(failed))
                            print("Deleted nodes errors: " + str(errors))
                            print("[+] Deleted n{} nodes count: {}. [+]".format(self.label_parser(node_label), total_count))
                #Capture any errors along with the query and data for traceability
                except ServiceUnavailable as exception:
                        logging.error("Table {} nodes, raised an error: \n {exception}".format(table_name, exception=exception))
                print("Time taken to delete {} is {} duration.".format(table_name, str(datetime.timedelta(seconds=(time.time()-start_time)))))

            self.driver.close()

    def delete_entities_delta_tx(self, tx, modak_uid_list, node_cql):
        
        delete_result = tx.run("{0}".format(node_cql), modak_uid_list=modak_uid_list)
        delete_ops_result = delete_result.peek()['operations']       

        '''
            Verify, is total nodes and deleted nodes are matching or not.
        '''
        if delete_ops_result["total"] != delete_ops_result["committed"]:
            logging.info("Thread sleep for 3 seconds")
            time.sleep(3)
            logging.info("Retry attempt")
            self.delete_entities_delta_tx(tx, modak_uid_list, node_cql)

        return delete_ops_result
        
    def delete_relationships_delta(self, delta_rels):
        '''
            This function deletes the graph relationships on respective database based on MODAK_UID.
        '''
        for table_name in delta_rels:
            start_time = time.time()
            modak_uid_batch_size=100000

            self.__spark.sql("REFRESH TABLE " + table_name)
            df = self.__spark.table(table_name)

            if(df.count() > 0):

                rels_df = df.select(col("ENTITY1_TYPE"),col("REL_TYPE"),col("ENTITY2_TYPE")).distinct()
                e1_ref = {
                    "labels": [str(x.ENTITY1_TYPE) for x in rels_df.select(col("ENTITY1_TYPE")).distinct().collect()]
                    }
                e2_ref = {
                    "labels": [str(x.ENTITY2_TYPE) for x in rels_df.select(col("ENTITY2_TYPE")).distinct().collect()]
                    }
                rel_ref = {
                    "rel_types": [str(x.REL_TYPE) for x in rels_df.select(col("REL_TYPE")).distinct().collect()]
                    }
                try:
                    with self.driver.session(database = self.__database_name) as session:
                        for rel_label in rel_ref["rel_types"]:
                            for e1_label in e1_ref["labels"]:
                                for e2_label in e2_ref["labels"]:
                                    if e1_ref["labels"] and e2_ref["labels"]:
                                        total_count=committed=failed=0
                                        errors = ''
                                        df_r = df \
                                            .filter("REL_TYPE='" + rel_label + "'") \
                                            .filter("ENTITY1_TYPE='" + e1_label + "'") \
                                            .filter("ENTITY2_TYPE='" + e2_label + "'")
                                        hash_df = df_r.select(df_r.MODAK_UID.alias("modak_uid")).distinct()
                                        hash_df = hash_df.coalesce(1).withColumn("row_num", monotonically_increasing_id())
                                        delete_count = hash_df.count()+1
                                        for rows in range(0, delete_count, modak_uid_batch_size):
                                            #print("row_num >= {} and row_num < {}".format(rows, rows+modak_uid_batch_size))
                                            df_sub = hash_df.filter("row_num >= {} and row_num < {}".format(rows, rows+modak_uid_batch_size)).drop("row_num")
                                            modak_uid_list = [str(x.modak_uid) for x in df_sub.collect()]
                                            config = """
                                                        {
                                                            batchSize:5000,
                                                            parallel:false,
                                                            retries:5,
                                                            params:{modak_uid_list:$modak_uid_list}
                                                        }
                                                    """
                                            relationship = "CALL apoc.periodic.iterate(\"UNWIND $modak_uid_list as mid MATCH (n{0})-[r:`{1}`]->(m{2}) WHERE r.MODAK_UID = mid RETURN id(r) as relId\", \"MATCH (n{0})-[r:`{1}`]->(m{2}) WHERE id(r)=relId DELETE r\", {3})".format(self.label_parser(e1_label), rel_label, self.label_parser(e2_label), config)
                                            print(relationship)
                                            delete_ops_result = session.write_transaction(self.delete_relationships_delta_tx, modak_uid_list, relationship)
                                            total_count = total_count + int(delete_ops_result["total"])
                                            committed = committed + int(delete_ops_result["committed"])
                                            failed = failed + int(delete_ops_result["failed"])
                                            errors = errors + str(delete_ops_result["errors"])

                                        '''
                                            Below find relationships deletion stats
                                        '''
                                        print("Deleted relationships total count: " + str(total_count))
                                        print("Deleted relationships committed count: " + str(committed))
                                        print("Deleted relationships failed count: " + str(failed))
                                        print("Deleted relationships errors: " + str(errors))
                                        print("[+] Deleted (n{0})-[r:`{1}`]->(m{2}) relationships count: {3}. [+]".format(self.label_parser(e1_label), rel_label, self.label_parser(e2_label), total_count))
                except ServiceUnavailable as exception:
                    logging.error("Table {} relationships, raised an error: \n {exception}".format(table_name, exception=exception))
                      
                print("Time taken to delete {} is {} duration.".format(table_name, str(datetime.timedelta(seconds=(time.time()-start_time)))))
        
    def delete_relationships_delta_tx(self, tx, modak_uid_list, relationship):
        print(relationship)
        delete_result = tx.run("{0}".format(relationship), modak_uid_list=modak_uid_list)
        delete_ops_result = delete_result.peek()['operations']
        '''
            Verify, is total relationships and deleted relationships are matching or not.
        '''
        if delete_ops_result["total"] != delete_ops_result["committed"]:
            logging.info("Thread sleep for 3 seconds")
            time.sleep(3)
            logging.info("Retry attempt")
            print("Retry attempt")
            self.delete_relationships_delta_tx(tx, modak_uid_list, relationship)

        return delete_ops_result

    def label_parser(self, labels):
        ''' 
            Utility function for parsing labels to compute on Neo4j. 
            Input - LabelX(:LabelY)* Output - `LabelX`(:`LabelY`)*
        '''       
        labels_arr =  labels.split(':')       
        if len(labels_arr) > 1:
            labels = '`:`'.join(labels_arr) + '`'
        else:
            labels = " :`{0}`".format(labels_arr[0])
        return labels[1:]

class vault_password:
    def get_password(self,token,cred_id,cred_type,fireshots_url):
        payload= {"credential_id": cred_id, "credential_type_id": cred_type}
        url= '{0}'.format(fireshots_url)
        r= requests.post(url, headers={"Content-Type":"application/json","Authorization" : token,"Accept": "application/json"},json= payload)
        if r.status_code == 200:
            logging.info("[+] Password obtained. [+]")
            return r.json()
        else:
            logging.info(r.json())
   
if __name__ == "__main__":   
    args = spark.conf.get("spark.driver.args").split(" ")
    cred_id = args[0]
    cred_type = args[1]
    neo4j_uri = args[2]
    database_name = args[3]
    arch_delta_table_list=args[4]

    token = spark.conf.get("spark.nabu.token")
    fireshots_uri = spark.conf.get("spark.nabu.fireshots_url")

    arch_tables = list(arch_delta_table_list.split(","))

    delta_entities = []	
    delta_relationships = []
    for table in arch_tables:
        if spark.catalog._jcatalog.tableExists(table):
            if "_entities" in table:
                delta_entities.append(table)
            if "_relationship" in table:
                delta_relationships.append(table)
        else:
            logging.info("[-] Table does not extists: {0} [-]".format(str(table)))
    print("Entities tables:", delta_entities)
    print()
    print("Relationships tables:", delta_relationships)

			
    vault_obj = vault_password()
    dict_pass = vault_obj.get_password(token, cred_id, cred_type, fireshots_uri)
    neo4j_password= dict_pass["data"]["password"]
    neo4j_user = dict_pass["data"]["username"]    
    uri = '{0}'.format(neo4j_uri)
    user = neo4j_user
    database = '{0}'.format(database_name)
 
    constraint_obj= Arch_constraints(uri, user, neo4j_password)
    entities_labels = constraint_obj.create_constraints(database, delta_entities)
    constraint_obj.close()

    index_obj= Arch_indexes(uri,user,neo4j_password)
    index_obj.create_indexes(database)
    index_obj.create_index_on_modak_uid(database, entities_labels, delta_relationships)
    index_obj.close()

    cdc_obj = Arch_cdc(spark, uri, user, neo4j_password, database)
    cdc_obj.cdc_delete(delta_entities, delta_relationships)
    cdc_obj.cdc_load(delta_entities, delta_relationships)
