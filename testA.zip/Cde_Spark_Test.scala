val df = Seq(
  (1, "bat","animal",101),
  (4, "dog","animal",101),
  (6, "hat","bird",101),
  (7, "sdf","bird",101),
  (8, "qwerty","bird",101),
  (9, "zxcv","bird",101),
  (10, "sdfg","article",101),
  (11, "asfsdfv","article",101),
  (12, "vbmnvb","article",101),
  (13, "sdfg","article",101),
  (14, "asfsdfv","article",101),
  (15, "vbmnvb","article",101)
).toDF("id", "name","description","another_id")



df.show()