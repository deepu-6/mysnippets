Add the loading scripts for AbbVie Neo4j, Tellic Neo4j, Tellic Solr in arch_curation/src/publication
