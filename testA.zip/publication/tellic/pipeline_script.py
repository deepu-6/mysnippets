from functools import reduce
import json
import time
import uuid
import sys
from pyspark.sql.functions import *
from knowledgen.tellic_nlp import TripleCurator
from pyspark.context import SparkContext
from pyspark.sql import HiveContext,SparkSession,DataFrame,SQLContext
from pyspark.sql.types import *
from pyspark.sql import functions as F
from pyspark import SparkContext

spark = (SparkSession
 .builder
 .appName('TELLIC PIPELINE')
 .enableHiveSupport()
 .getOrCreate())

sqlContext = SQLContext(spark)
hiveContext = HiveContext(spark)
LOG4JLOGGER = spark._jvm.org.apache.log4j
LOGGER = LOG4JLOGGER.LogManager.getLogger(__name__)
LOG4JLOGGER.LogManager.getLogger("org").setLevel(LOG4JLOGGER.Level.ERROR)
global curator
#Using function currying to dynamically pass config of different triples to 'knowledgen'
#Using try-except to avoid creating new 'curator' object for every map run.
def extract_set_config(config):
    def extract(triple_string):
        global curator
        try:
            curator
        except NameError:
            curator= TripleCurator(configs=config)
        output_triple= curator.process_triple(triple_string)
        return output_triple
    return extract
#Class to read input triples from Hive into Dataframe and another function to normalize using rdd.map
class normalization_and_Solr_generation:
    def read_from_hive(self,triple_name,spark):
        LOGGER.info("Loading Input Triples in df: {0}".format(triple_name))
        df_triple= spark.sql("SELECT * from ark.{0}".format(triple_name))
        df_final=df_triple.select([F.col(x).alias(x.lower()) for x in df_triple.columns])
        return df_final

    def normalization(self,df_original,config,schema):
        df_original= df_original.repartition(400)
        rdd_input= df_original.toJSON().map(lambda x: eval(x))
        rdd_normalized= rdd_input.map(extract_set_config(config))
        normalized_df = sqlContext.createDataFrame(rdd_normalized,schema)
        return normalized_df    

def writeToS3(df, pipeline_s3_path, database_name, table_name):	
		df.write.mode("overwrite").format("parquet").option("path",pipeline_s3_path + table_name).saveAsTable(database_name + "." + table_name)
		
#Main: to pass all input triples for normalizing     
if __name__ == "__main__":
    #database_name= 'pipeline_tellic'
    #s3_path= "s3a://arch-dev-datalake/development/data/warehouse/integrated/"
    s3_path= sys.argv[1]
    database_name= sys.argv[2]
    pipeline_s3_path= s3_path + database_name + ".db/"
    pipeline_transformations= normalization_and_Solr_generation()
    LOGGER.info("PIPELINE START")

  
    #cv solr_abbvie_timeline
    compound_cv_endpoint_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_compound_cv_endpoint_solr""")
    compound_cv_endpoint_medmsd_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_compound_cv_endpoint_medmsd_solr""")
    timeline_cv_union_dfs =compound_cv_endpoint_solr_df.union(compound_cv_endpoint_medmsd_solr_df)
    writeToS3(timeline_cv_union_dfs, pipeline_s3_path, database_name, "solr_abbvie_timeline_cv")
    
    #uc84 solr_abbvie_timeline
    variant_variant_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_variant_variant_solr""")
    finngen_variant_phenotype_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_finngen_variant_phenotype_solr""")
    ukbb_variant_phenotype_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_ukbb_variant_phenotype_solr""")
    finngen_gene_variant_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_finngen_gene_variant_solr""")
    ukbb_gene_variant_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_ukbb_gene_variant_solr""")
    omim_gene_phenotype_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic. t_omim_gene_phenotype_solr""")
    timeline_uc84_union_dfs =variant_variant_df.union(finngen_variant_phenotype_df).union(ukbb_variant_phenotype_df).union(finngen_gene_variant_df).union(ukbb_gene_variant_df).union(omim_gene_phenotype_df)
    writeToS3(timeline_uc84_union_dfs, pipeline_s3_path, database_name, "solr_abbvie_timeline_uc84")
     
     
     #ccle solr_abbvie_timeline
    t_gene_cell_line_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_gene_cell_line_solr""")
    t_gene_disease_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_gene_disease_solr""")
    t_gene_tissue_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_gene_tissue_solr""")
    timeline_ccle_union_dfs =t_gene_cell_line_solr_df.union(t_gene_disease_solr_df).union(t_gene_tissue_solr_df)
    writeToS3(timeline_ccle_union_dfs, pipeline_s3_path, database_name, "solr_abbvie_timeline_ccle")
    
    
    #humanpk solr_abbvie_timeline
    pkpairing_endpoint_pk_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_pkpairing_endpoint_pk_solr""")
    compound_pkpairing_dosed_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_compound_pkpairing_dosed_solr""")
    compound_pkpairing_measured_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_compound_pkpairing_measured_solr""")
    compound_compound_metabolite_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_compound_compound_metabolite_solr""")
    timeline_humanpk_union_dfs =pkpairing_endpoint_pk_solr_df.union(compound_pkpairing_dosed_solr_df).union(compound_pkpairing_measured_solr_df).union(compound_compound_metabolite_solr_df)
    writeToS3(timeline_humanpk_union_dfs, pipeline_s3_path, database_name, "solr_abbvie_timeline_invivopk")
	
   #health_event_solr_timeline
    dci_health_event_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.dci_health_condition_solr""")
    ddi_health_event_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.ddi_health_condition_solr""")
    drug_health_event_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.drug_health_condition_solr""")
    ukbb_variant_health_condition_solr = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_ukbb_variant_health_condition_solr""")
    finngen_variant_health_condition_solr = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_finngen_variant_health_condition_solr""")
    phenotype_health_condition_solr = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_phenotype_health_condition_solr""")
    timeline_union_hc_df =[dci_health_event_solr_df,ddi_health_event_solr_df,drug_health_event_solr_df,ukbb_variant_health_condition_solr,finngen_variant_health_condition_solr,phenotype_health_condition_solr]
    timeline_union_hc_dfs = reduce(DataFrame.unionAll, timeline_union_hc_df)
    writeToS3(timeline_union_hc_dfs, pipeline_s3_path, database_name, "solr_abbvie_timeline_health_event")
    
####################################################################################################################################################################################
    #node_chemical 
    '''
    chem_subset_df=spark.sql("""
with compound_entity as ( 
    select sort_array(collect_set(cast(replace(abbvie_id,'A-','') as double))) as ANUMBER,inchi_key,concat_ws('|',collect_set(abbvie_id)) as synonymn_list
    from ark.t_compound_entities
    where inchi_key is not null
    group by inchi_key
    )
    ,fdb_sm_gene_triple as (
    select distinct entity1 as inchi_key,metadata.REL_PROP.SOURCE_ID as ANUMBER
    from ark.t_fdb_compound_gene_triples
    where metadata.REL_PROP.SOURCE_ID like '%A-%'
    ) 
    ,tdb_sm_cell_triple as (
    select distinct entity1 as inchi_key, metadata.ENTITY1_PROP.ANUMBER as ANUMBER
    from ark.t_tdb_compound_cell_triples
    ),
    compound_entities_unmapped as (
    SELECT distinct coalesce(concat('A-',a.ANUMBER[0]),a.inchi_key) as ANUMBER,a.inchi_key as inchi_key
    FROM compound_entity a left outer join tellic_abbvie.tellic_graph_data_node_chem_subset b
    on a.inchi_key = b.inchi_key
    where b.inchi_key is null
    ),
    fdb_sm_gene_unmapped as(
    SELECT distinct coalesce(a.ANUMBER,a.inchi_key) as ANUMBER,
    a.inchi_key as inchi_key
    FROM fdb_sm_gene_triple a left outer join tellic_abbvie.tellic_graph_data_node_chem_subset b
    on a.inchi_key = b.inchi_key
    where b.inchi_key is null
    ),
    tdb_sm_cell_unmapped as(
    SELECT distinct coalesce(a.ANUMBER,a.inchi_key) as ANUMBER,
    a.inchi_key as inchi_key
    FROM tdb_sm_cell_triple a left outer join tellic_abbvie.tellic_graph_data_node_chem_subset b
    on a.inchi_key = b.inchi_key
    where b.inchi_key is null
    ),
    compound_entities_unmapped_triples as (
    select distinct coalesce(a.ANUMBER, h.ANUMBER,g.ANUMBER) as ANUMBER,a.inchi_key as inchi_key
    FROM compound_entities_unmapped  a
    left join fdb_sm_gene_unmapped h
    on a.inchi_key = h.inchi_key
    left join ark.t_pcsdw_compound_endpoint_triples b
    on a.inchi_key=b.entity1
    left join ark.t_compound_endpoint_medmsd_triples c
    on a.inchi_key = c.entity1
    left join ark.t_fdb_compound_compound_triples d
    on a.inchi_key = d.entity1
    left join ark.t_fdb_compound_compound_triples e
    on a.inchi_key = e.entity2
    left join ark.t_fdb_drug_compound_triples f
    on a.inchi_key = f.entity2
    left join tdb_sm_cell_unmapped g
    on a.inchi_key = g.inchi_key
    WHERE b.entity1 is not null OR c.entity1 is not null or d.entity1 is not null or e.entity2 is not null or f.entity2 is not null 
    or g.inchi_key is not null or h.inchi_key is not null 
    ),
    compound_pkpairing_dosed_triples as (
        select distinct metadata.ENTITY1_PROP.ANUMBER as ANUMBER,entity1 as inchi_key
        from ark.t_compound_pkpairing_dosed_triples
    ),
    compound_pkpairing_measured_triples as (
        select distinct metadata.ENTITY1_PROP.ANUMBER as ANUMBER,entity1 as inchi_key
        from ark.t_compound_pkpairing_measured_triples
    ),
    compound_compound_metabolite_triples as (
        select distinct metadata.ENTITY1_PROP.ANUMBER as ANUMBER,entity1 as inchi_key
        from ark.t_compound_compound_metabolite_triples
        union
        select distinct metadata.ENTITY2_PROP.ANUMBER as ANUMBER,entity2 as inchi_key
        from ark.t_compound_compound_metabolite_triples
    ),
    compound_gene_bioactivity_triples as (
        select distinct metadata.ENTITY1_PROP.ANUMBER as ANUMBER,entity1 as inchi_key
        from ark.t_compound_gene_bioactivity_triples
    )
    
    (select distinct entity_type as entity_type,ontology as ontology,concept_id as concept_id,coalesce(ANUMBER, entity_name) as entity_name,class as class,label as label,
    case 
    when coalesce(ANUMBER, entity_name)=ANUMBER then 
        case
        when coalesce(synonyms,'')='' then concat(entity_name,'|',replace(regexp_replace(replace(synonymn_list,ANUMBER,''),'^\\||\\|$',''),'||','|'))
        when ANUMBER not like '%|%' and coalesce(synonyms,'')='' then entity_name
        when ANUMBER not like '%|%' then concat(synonyms,'|',entity_name)
        else
        concat(synonyms,'|',entity_name,'|',replace(regexp_replace(replace(synonymn_list,ANUMBER,''),'^\\||\\|$',''),'||','|'))
        end
    else synonyms
    end as synonyms,
    pubchem_ids as pubchem_ids,chebi_ids as chebi_ids,
    rxnorm_ids as rxnorm_ids,inchi_key as inchi_key,smiles as smiles,iupac_name as iupac_name
    from(
    SELECT coalesce(concat('A-',t1.ANUMBER[0]), t2.ANUMBER,t3.ANUMBER,t4.metadata.ENTITY1_PROP.ANUMBER,t5.metadata.ENTITY1_PROP.ANUMBER,t6.ANUMBER,t7.ANUMBER,t8.ANUMBER) as ANUMBER,t1.synonymn_list as synonymn_list,a.*
    FROM tellic_abbvie.tellic_graph_data_node_chem_subset a 
    left outer join compound_entity t1
    on a.inchi_key = t1.inchi_key
    left outer join fdb_sm_gene_triple t2
    on a.inchi_key = t2.inchi_key
    left outer join tdb_sm_cell_triple t3
    on a.inchi_key = t3.inchi_key
    left outer join ark.t_compound_cv_endpoint_triples t4
    on a.inchi_key=t4.entity1
    left outer join ark.t_compound_cv_endpoint_medmsd_triples t5
    on a.inchi_key=t5.entity1
    left outer join compound_pkpairing_dosed_triples t6
    on a.inchi_key=t6.inchi_key
    left outer join compound_pkpairing_measured_triples t7
    on a.inchi_key=t7.inchi_key
    left outer join compound_compound_metabolite_triples t8
    on a.inchi_key=t8.inchi_key
    left outer join compound_gene_bioactivity_triples t9
    on a.inchi_key=t9.inchi_key
    )x
    )
    union all
    (
    SELECT distinct 'Chemical' as entity_type,'custom' as ontology,concat(coalesce(t1.inchi_key, t2.inchi_key,t3.inchi_key),'_Chemical') as concept_id,coalesce(t1.ANUMBER, t2.ANUMBER,t3.ANUMBER) as entity_name,'Entity' as class,'Chemical' as label,cast(null as string) as synonyms,cast(null as string) as pubchem_ids,cast(null as string) as chebi_ids,
    cast(null as string) as rxnorm_ids,coalesce(t1.inchi_key, t2.inchi_key,t3.inchi_key) as inchi_key,cast(null as string) as smiles,cast(null as string) as iupac_name
    from compound_entities_unmapped_triples t1
    full outer join fdb_sm_gene_unmapped t2
    on t1.inchi_key = t2.inchi_key
    full outer join tdb_sm_cell_unmapped t3
    on t1.inchi_key = t3.inchi_key
    )
    union all
    (SELECT distinct 'Chemical' as entity_type,'custom' as ontology,concat(a.entity2, '_Chemical') as concept_id,a.entity2 as entity_name,'Entity' as class,'Chemical' as label,cast(null as string) as synonyms,cast(null as string) as pubchem_ids,cast(null as string) as chebi_ids,
    cast(null as string) as rxnorm_ids,a.entity2 as inchi_key,cast(null as string) as smiles,cast(null as string) as iupac_name
    FROM ark.t_fdb_drug_compound_triples a
    left outer join
    ark.t_compound_entities b
    on a.entity2 = b.inchi_key
    where b.inchi_key is null)
    union all
    (SELECT distinct 'Chemical' as entity_type,'custom' as ontology,concat(a.entity1, '_Chemical') as concept_id,a.entity1 as entity_name,'Entity' as class,'Chemical' as label,cast(null as string) as synonyms,cast(null as string) as pubchem_ids,cast(null as string) as chebi_ids,
    cast(null as string) as rxnorm_ids,a.entity1 as inchi_key,cast(null as string) as smiles,cast(null as string) as iupac_name
    FROM ark.t_pcsdw_compound_endpoint_triples a
    left outer join
    ark.t_compound_entities b
    on a.entity1 = b.inchi_key
    where b.inchi_key is null)
""")
    chem_subset_df.dropDuplicates().createOrReplaceTempView("chem_subset_anumber_df")
    chem_subset_df2=spark.sql("""
with compound_entity as ( 
    select sort_array(collect_set(cast(replace(abbvie_id,'A-','') as double))) as ANUMBER,inchi_key,concat_ws('|',collect_set(abbvie_id)) as synonymn_list
    from ark.t_compound_entities
    where inchi_key is not null
    group by inchi_key
    ),
    all_triples as(
    (SELECT  distinct 'Chemical' as entity_type,'custom' as ontology,concat(a.entity1, '_Chemical') as concept_id,a.entity1 as entity_name,'Entity' as class,'Chemical' as label,cast(null as string) as synonyms,cast(null as string) as pubchem_ids,cast(null as string) as chebi_ids,
    cast(null as string) as rxnorm_ids,a.entity1 as inchi_key,cast(null as string) as smiles,cast(null as string) as iupac_name
    FROM ark.t_fdb_compound_compound_triples a
    left outer join 
    chem_subset_anumber_df b
    on a.entity1 = b.inchi_key
    where b.inchi_key is null 
    )
    UNION
    (SELECT distinct 'Chemical' as entity_type,'custom' as ontology,concat(a.entity2, '_Chemical') as concept_id,a.entity2 as entity_name,'Entity' as class,'Chemical' as label,cast(null as string) as synonyms,cast(null as string) as pubchem_ids,cast(null as string) as chebi_ids,
    cast(null as string) as rxnorm_ids,a.entity2 as inchi_key,cast(null as string) as smiles,cast(null as string) as iupac_name
    FROM ark.t_fdb_compound_compound_triples a
    left outer join
    chem_subset_anumber_df b
    on a.entity2 = b.inchi_key
    where b.inchi_key is null)
    UNION 
    (
    SELECT distinct 'Chemical' as entity_type,'custom' as ontology,concat(a.entity1, '_Chemical') as concept_id,coalesce(a.metadata.ENTITY1_PROP.ANUMBER,a.entity1) as entity_name,'Entity' as class,'Chemical' as label,cast(null as string) as synonyms,cast(null as string) as pubchem_ids,cast(null as string) as chebi_ids,
    cast(null as string) as rxnorm_ids,a.entity1 as inchi_key,cast(null as string) as smiles,cast(null as string) as iupac_name
    FROM ark.t_compound_cv_endpoint_medmsd_triples a
    left outer join chem_subset_anumber_df b
    on a.entity1 = b.inchi_key
    where b.inchi_key is null
    )
    UNION
    (
    SELECT distinct 'Chemical' as entity_type,'custom' as ontology,concat(a.entity1, '_Chemical') as concept_id,coalesce(a.metadata.ENTITY1_PROP.ANUMBER,a.entity1) as entity_name,'Entity' as class,'Chemical' as label,cast(null as string) as synonyms,cast(null as string) as pubchem_ids,cast(null as string) as chebi_ids,
    cast(null as string) as rxnorm_ids,a.entity1 as inchi_key,cast(null as string) as smiles,cast(null as string) as iupac_name
    FROM ark.t_compound_cv_endpoint_triples a
    left outer join chem_subset_anumber_df b
    on a.entity1 = b.inchi_key
    where b.inchi_key is null
    )
    UNION 
    (
    SELECT distinct 'Chemical' as entity_type,'custom' as ontology,concat(a.entity1, '_Chemical') as concept_id,coalesce(a.metadata.ENTITY1_PROP.ANUMBER,a.entity1) as entity_name,'Entity' as class,'Chemical' as label,cast(null as string) as synonyms,cast(null as string) as pubchem_ids,cast(null as string) as chebi_ids,
    cast(null as string) as rxnorm_ids,a.entity1 as inchi_key,cast(null as string) as smiles,cast(null as string) as iupac_name
    FROM ark.t_compound_pkpairing_dosed_triples a
    left outer join chem_subset_anumber_df b
    on a.entity1 = b.inchi_key
    where b.inchi_key is null
    )
    UNION
    (
    SELECT distinct 'Chemical' as entity_type,'custom' as ontology,concat(a.entity1, '_Chemical') as concept_id,coalesce(a.metadata.ENTITY1_PROP.ANUMBER,a.entity1) as entity_name,'Entity' as class,'Chemical' as label,cast(null as string) as synonyms,cast(null as string) as pubchem_ids,cast(null as string) as chebi_ids,
    cast(null as string) as rxnorm_ids,a.entity1 as inchi_key,cast(null as string) as smiles,cast(null as string) as iupac_name
    FROM ark.t_compound_pkpairing_measured_triples a
    left outer join chem_subset_anumber_df b
    on a.entity1 = b.inchi_key
    where b.inchi_key is null
    )
    UNION 
    (
    SELECT distinct 'Chemical' as entity_type,'custom' as ontology,concat(a.entity1, '_Chemical') as concept_id,coalesce(a.metadata.ENTITY1_PROP.ANUMBER,a.entity1) as entity_name,'Entity' as class,'Chemical' as label,cast(null as string) as synonyms,cast(null as string) as pubchem_ids,cast(null as string) as chebi_ids,
    cast(null as string) as rxnorm_ids,a.entity1 as inchi_key,cast(null as string) as smiles,cast(null as string) as iupac_name
    FROM ark.t_compound_compound_metabolite_triples a
    left outer join chem_subset_anumber_df b
    on a.entity1 = b.inchi_key
    where b.inchi_key is null
    )
    UNION
    (
    SELECT distinct 'Chemical' as entity_type,'custom' as ontology,concat(a.entity2, '_Chemical') as concept_id,coalesce(a.metadata.ENTITY2_PROP.ANUMBER,a.entity2) as entity_name,'Entity' as class,'Chemical' as label,cast(null as string) as synonyms,cast(null as string) as pubchem_ids,cast(null as string) as chebi_ids,
    cast(null as string) as rxnorm_ids,a.entity2 as inchi_key,cast(null as string) as smiles,cast(null as string) as iupac_name
    FROM ark.t_compound_compound_metabolite_triples a
    left outer join chem_subset_anumber_df b
    on a.entity2 = b.inchi_key
    where b.inchi_key is null
    ) 
UNION
    (
    SELECT distinct 'Chemical' as entity_type,'custom' as ontology,concat(a.entity1, '_Chemical') as concept_id,coalesce(a.metadata.ENTITY1_PROP.ANUMBER,a.entity1) as entity_name,'Entity' as class,'Chemical' as label,cast(null as string) as synonyms,cast(null as string) as pubchem_ids,cast(null as string) as chebi_ids,
    cast(null as string) as rxnorm_ids,a.entity1 as inchi_key,cast(null as string) as smiles,cast(null as string) as iupac_name
    FROM ark.t_compound_gene_bioactivity_triples a
    left outer join chem_subset_anumber_df b
    on a.entity1 = b.inchi_key
    where b.inchi_key is null
    ) 		
    ),
    sm_gene as(
    (SELECT distinct 'Chemical' as entity_type,'custom' as ontology,concat(a.entity1, '_Chemical') as concept_id,coalesce(concat('A-',c.ANUMBER[0]),entity1) as entity_name,'Entity' as class,'Chemical' as label,cast(null as string) as synonyms,cast(null as string) as pubchem_ids,cast(null as string) as chebi_ids,
cast(null as string) as rxnorm_ids,a.entity1 as inchi_key,cast(null as string) as smiles,cast(null as string) as iupac_name
FROM ark.t_fdb_compound_gene_triples a
left outer join chem_subset_anumber_df b
on a.entity1=b.inchi_key
left outer join compound_entity c
on a.entity1=c.inchi_key
where a.metadata.REL_PROP.SOURCE_ID not like '%A-%' and  b.inchi_key is null)
    ),
    sm_gene1 as(
    select a.* from sm_gene a
    left outer join 
    all_triples b
    on 
    a.inchi_key=b.inchi_key
    where b.inchi_key is null
    )
    select * from sm_gene1
    union  
    select * from all_triples
""")
    chem_subset_df_final=chem_subset_df.union(chem_subset_df2).dropDuplicates()

    writeToS3(chem_subset_df_final, pipeline_s3_path, database_name, "tellic_node_chem_subset") 
    
#######################################################################################################################################################################################

#compound entities used to replace compound entities(inchi_key) with corresponding A-NUMBER(smallest) for all compound tables except fdb_sm_gene and tdb_sm_cell
    compound_entities_table=spark.sql("""with compound_entity as ( 
select sort_array(collect_set(cast(replace(abbvie_id,'A-','') as double))) as ANUMBER,inchi_key
from ark.t_compound_entities
where inchi_key is not null
group by inchi_key
)
,fdb_sm_gene_triple as (
select distinct entity1 as inchi_key,metadata.REL_PROP.SOURCE_ID as ANUMBER
from ark.t_fdb_compound_gene_triples
where metadata.REL_PROP.SOURCE_ID like '%A-%'
) 
,tdb_sm_cell_triple as (
select distinct entity1 as inchi_key, metadata.ENTITY1_PROP.ANUMBER as ANUMBER
from ark.t_tdb_compound_cell_triples
),
compound_entities_unmapped as (
SELECT distinct coalesce(concat('A-',a.ANUMBER[0]),a.inchi_key) as ANUMBER,a.inchi_key as inchi_key
FROM compound_entity a left outer join tellic_abbvie.tellic_graph_data_node_chem_subset b
on a.inchi_key = b.inchi_key
where b.inchi_key is null
),
fdb_sm_gene_unmapped as(
SELECT distinct coalesce(a.ANUMBER,a.inchi_key) as ANUMBER,
a.inchi_key as inchi_key
FROM fdb_sm_gene_triple a left outer join tellic_abbvie.tellic_graph_data_node_chem_subset b
on a.inchi_key = b.inchi_key
where b.inchi_key is null
),
tdb_sm_cell_unmapped as(
SELECT distinct coalesce(a.ANUMBER,a.inchi_key) as ANUMBER,
a.inchi_key as inchi_key
FROM tdb_sm_cell_triple a left outer join tellic_abbvie.tellic_graph_data_node_chem_subset b
on a.inchi_key = b.inchi_key
where b.inchi_key is null
)
(select coalesce(ANUMBER,entity_name) as ANUMBER,inchi_key as inchi_key from(
SELECT coalesce(concat('A-',t1.ANUMBER[0]), t2.ANUMBER,t3.ANUMBER) as ANUMBER,a.*
FROM tellic_abbvie.tellic_graph_data_node_chem_subset a 
left outer join compound_entity t1
on a.inchi_key = t1.inchi_key
left outer join fdb_sm_gene_triple t2
on a.inchi_key = t2.inchi_key
left outer join tdb_sm_cell_triple t3
on a.inchi_key = t3.inchi_key)x
)
union 
(
SELECT coalesce(t1.ANUMBER, t2.ANUMBER,t3.ANUMBER) as ANUMBER,coalesce(t1.inchi_key, t2.inchi_key,t3.inchi_key) as inchi_key
from compound_entities_unmapped t1
full outer join fdb_sm_gene_unmapped t2
on t1.inchi_key = t2.inchi_key
full outer join tdb_sm_cell_unmapped t3
on t1.inchi_key = t3.inchi_key
)""")
    compound_entities_table.createOrReplaceTempView("compound_entities_vw")

#####################################################################################################################################################################################
#NORMALIZATION
    #SCOPIA_DRUG_AE 
    scopia_drug_ae_config={
        "entity_type_list": [
            {
                "entity_type": "AdverseEvent",
                "ontology": "MedDRA"
            }
        ],
        "column_list": [
            {
                "column_name": "entity2",
                "entity_type": "AdverseEvent"
            }
        ]
    }
    scopia_drug_ae_name='t_scopia_drug_ae_triples'
    df_scopia_drug_ae_original= pipeline_transformations.read_from_hive(scopia_drug_ae_name,spark)
#joining with drug_entities table to obtain preferred_name as entity1
    df_scopia_drug_ae_original.createOrReplaceTempView("scopia_drug_ae_original_vw")
    df_scopia_drug_ae_original=spark.sql("""select distinct coalesce(b.name,b1.entity_name,a.entity1) as entity1,entity1_type,coalesce(c.name,a.entity2) as entity2, entity2_type, rel_type, strength, result, result_type, confidence, a.lineage, metadata,a.entity1 as entity1_concept_id
    from (select * from scopia_drug_ae_original_vw where entity1 is not null or entity2 is not null) a
    LEFT JOIN 
    (select distinct id,concat_ws('|',collect_set(preferred_name)) AS name
        from (select * from ark.t_drug_entities DISTRIBUTE BY id SORT BY preferred_name,id)y group by id) b
    on a.entity1=b.id
    LEFT JOIN 
    tellic_abbvie.tellic_graph_data_node_drug b1
    on a.entity1=b1.concept_id
    LEFT JOIN 
    (select distinct id,concat_ws('|',collect_set(preferred_name)) AS name
        from (select * from ark.t_adverseevent_entities DISTRIBUTE BY id SORT BY preferred_name,id)y group by id) c
    on a.entity2=c.id""")
    schema_scopia_drug_ae=StructType([StructField("entity1",StringType(),True),StructField("entity1_type",StringType(),True),StructField("entity2",StringType(),True),StructField("entity2_type",StringType(),True),StructField("rel_type",StringType(),True),StructField("strength",IntegerType(),True),StructField("confidence",FloatType(),True),StructField("result",StringType(),True),StructField("result_type",StringType(),True),StructField("entity1_concept_id",StringType(),True),StructField("entity2_concept_id",StringType(),True),StructField("lineage",MapType(StringType(),StringType(),True),True),StructField("metadata",MapType(StringType(),MapType(StringType(),StringType(),True),True),True)])
    LOGGER.info("Normalizing SCOPIA_DRUG_AE")
    scopia_drug_ae_normalized_df= pipeline_transformations.normalization(df_scopia_drug_ae_original,scopia_drug_ae_config,schema_scopia_drug_ae)
    
    writeToS3(scopia_drug_ae_normalized_df, pipeline_s3_path, database_name, "t_scopia_drug_ae_normalized_triples")

##############################################################################################################################################################################
   

    #PCSDW(Currently not normalized by Tellic, directly creating solr output)
    pcsdw_name='t_pcsdw_compound_endpoint_triples'
    df_pcsdw_original= pipeline_transformations.read_from_hive(pcsdw_name,spark)
    df_pcsdw_original.createOrReplaceTempView("pcsdw_compound_table")
    pcsdw_normalized_df= spark.sql("""SELECT a.*, coalesce(b.concept_id,concat(a.entity1, '_Chemical')) as entity1_concept_id, concat(a.entity2, '_', a.entity2_type) AS entity2_concept_id from pcsdw_compound_table a left outer join tellic_abbvie.tellic_graph_data_node_chem_subset b on a.entity1=b.inchi_key """)
    pcsdw_normalized_df.createOrReplaceTempView("pcsdw_normalized_vw")
    pcsdw_normalized_df=spark.sql("""select distinct coalesce(ANUMBER, entity1) as entity1,entity1_type, rel_type, entity2, entity2_type, confidence, result, result_type, strength,lineage, metadata,entity1_concept_id, entity2_concept_id
    FROM pcsdw_normalized_vw a 
    left outer join compound_entities_vw t1 
    on a.entity1 = t1.inchi_key
    """)
    writeToS3(pcsdw_normalized_df, pipeline_s3_path, database_name, "t_pcsdw_compound_endpoint_normalized_triples")

#######################################################################################################################################################################
   
#compound_endpoint_medmsd(Currently not normalized by Tellic, directly creating solr output)
    medmsd_name='t_compound_endpoint_medmsd_triples'
    df_medmsd_original= pipeline_transformations.read_from_hive(medmsd_name,spark)
    df_medmsd_original.createOrReplaceTempView("medmsd_compound_table")
    medmsd_normalized_df= spark.sql("""SELECT a.*, coalesce(b.concept_id,concat(a.entity1, '_Chemical')) as entity1_concept_id, concat(a.entity2, '_', a.entity2_type) AS entity2_concept_id from medmsd_compound_table a left outer join tellic_abbvie.tellic_graph_data_node_chem_subset b on a.entity1=b.inchi_key """)
    medmsd_normalized_df.createOrReplaceTempView("medmsd_normalized_vw")
    medmsd_normalized_df=spark.sql("""select distinct coalesce(ANUMBER, entity1) as entity1,entity1_type, rel_type, entity2, entity2_type, confidence, result, result_type, strength, lineage, metadata,entity1_concept_id, entity2_concept_id 
    FROM medmsd_normalized_vw a 
    left outer join compound_entities_vw t1 
    on a.entity1 = t1.inchi_key""") 
    writeToS3(medmsd_normalized_df, pipeline_s3_path, database_name, "t_compound_endpoint_medmsd_normalized_triples")

    
#####################################################################################################################################################################################
 #t_compound_cv_endpoint
    LOGGER.info("Creating t_compound_cv_endpoint_normalized_triples table")
    df_compound_cv_endpoint_original= spark.sql("select * from ark.t_compound_cv_endpoint_triples")
    df_compound_cv_endpoint_original.createOrReplaceTempView("compound_cv_endpoint_table")
    compound_cv_endpoint_normalized_df= spark.sql("""
    with compound_cv_endpoint_normalized as(
    SELECT a.*, 
    coalesce(b.concept_id,concat(a.entity1, '_Chemical')) as entity1_concept_id, 
    concat(a.entity2, '_', a.entity2_type) AS entity2_concept_id 
    from compound_cv_endpoint_table a 
    left outer join 
    tellic_abbvie.tellic_graph_data_node_chem_subset b 
    on a.entity1=b.inchi_key
    )
    select distinct 
    coalesce(metadata.entity1_prop.anumber, entity1) as entity1,
    entity1_type,
    entity1_concept_id,
    rel_type, 
    entity2, 
    entity2_type, 
    entity2_concept_id,
    confidence, 
    result, 
    result_type, 
    strength,
    lineage, 
    metadata
    FROM compound_cv_endpoint_normalized""")

    writeToS3(compound_cv_endpoint_normalized_df, pipeline_s3_path, database_name, "t_compound_cv_endpoint_normalized_triples")
    LOGGER.info("Created t_compound_cv_endpoint_normalized_triples table")
    
####################################################################################################################################################################################
#compound_cv_endpoint_medmsd
    LOGGER.info("Creating t_compound_cv_endpoint_medmsd_normalized_triples table")
    df_compound_cv_endpoint_medmsd_original= spark.sql("select * from ark.t_compound_cv_endpoint_medmsd_triples")
    df_compound_cv_endpoint_medmsd_original.createOrReplaceTempView("compound_cv_endpoint_medmsd_table")
    compound_cv_endpoint_medmsd_normalized_df= spark.sql("""
    with compound_cv_endpoint_medmsd_normalized as(
    SELECT a.*, 
    coalesce(b.concept_id,concat(a.entity1, '_Chemical')) as entity1_concept_id, 
    concat(a.entity2, '_', a.entity2_type) AS entity2_concept_id 
    from compound_cv_endpoint_medmsd_table a 
    left outer join 
    tellic_abbvie.tellic_graph_data_node_chem_subset b 
    on a.entity1=b.inchi_key
    )
    select distinct 
    coalesce(metadata.entity1_prop.anumber, entity1) as entity1,
    entity1_type,
    entity1_concept_id,
    rel_type, 
    entity2, 
    entity2_type, 
    entity2_concept_id,
    confidence, 
    result, 
    result_type, 
    strength,
    lineage, 
    metadata
    FROM compound_cv_endpoint_medmsd_normalized""")

    writeToS3(compound_cv_endpoint_medmsd_normalized_df, pipeline_s3_path, database_name, "t_compound_cv_endpoint_medmsd_normalized_triples")
    LOGGER.info("Created t_compound_cv_endpoint_medmsd_normalized_triples table")

####################################################################################################################################################################################
    #EXTRACTION OF SOLR TABLES 


    #SCOPIA_DRUG_AE_SOLR_TABLE
    LOGGER.info("Creating scopia_drug_ae_solr output")
    uuidUdf_scopia_drug_ae= udf(lambda : str(uuid.uuid4()),StringType())
    scopia_drug_ae_normalized_df_hive=spark.sql("SELECT * from pipeline_tellic.t_scopia_drug_ae_normalized_triples")
    scopia_drug_ae_solr_df=scopia_drug_ae_normalized_df_hive.select(concat(regexp_replace(col("entity1_concept_id"),"[^a-zA-Z0-9]", "_"),lit("-"),regexp_replace(col("entity2_concept_id"),"[^a-zA-Z0-9]","_"),lit("-E10")).alias("reluid"),lit(uuidUdf_scopia_drug_ae()).alias("tellic_evidence_id"),col("entity1_concept_id").alias("start_node"),regexp_replace(col("entity2_concept_id"),':','').alias("end_node"),col("entity1").alias("entity_1_name"),col("rel_type").alias("relationship_type"),col("entity2").alias("entity_2_name"),col("strength").alias("strength"),col("result").alias("result"),col("result_type").alias("result_type"),col("confidence").alias("confidence"),lit("NULL").cast(IntegerType()).alias("epoch_time"),lit("AbbVieTriples").alias("source_type"),lit("ScopiaRx - MAIN").alias("source_name"),regexp_replace(col("lineage.RULESETS").cast(StringType()),'\\[|\\]','').alias("lineage_rulesets"),regexp_replace(col("lineage.SOURCES").cast(StringType()),'\\[|\\]','').alias("lineage_sources"),regexp_replace(col("lineage.FILTERS").cast(StringType()),'\\[|\\]','').alias("lineage_filters"),col("lineage.VERSION").alias("lineage_version"),col("lineage.TIMESTAMP").alias("lineage_timestamp"),col("metadata.ENTITY1_PROP.ACTIVE_INGREDIENT").alias("metadata_ENTITY1_PROP_ACTIVE_INGREDIENT"),col("metadata.ENTITY1_PROP.ID").alias("metadata_ENTITY1_PROP_ID"),regexp_replace(col("metadata.ENTITY1_PROP.MOA").cast(StringType()),'\\[|\\]','').alias("metadata_ENTITY1_PROP_MOA"),col("metadata.ENTITY2_PROP.ADVERSE_EVENT").alias("metadata_ENTITY2_PROP_ADVERSE_EVENT"),col("metadata.REL_PROP.COMMENT").alias("metadata_REL_PROP_COMMENT"),col("metadata.REL_PROP.REPORTS").alias("metadata_REL_PROP_REPORTS"),col("metadata.REL_PROP.AES").alias("metadata_REL_PROP_AES"),col("metadata.REL_PROP.SEVERITY").alias("metadata_REL_PROP_SEVERITY"),col("metadata.REL_PROP.FREQUENCY").alias("metadata_REL_PROP_FREQUENCY"),col("metadata.REL_PROP.SOURCE").alias("metadata_REL_PROP_SOURCE"),col("metadata.REL_PROP.ONLABEL").alias("metadata_REL_PROP_ONLABEL"),col("metadata.REL_PROP.GRADE_3_PERCENT").alias("metadata_REL_PROP_GRADE_3_PERCENT"),col("metadata.REL_PROP.GRADE_4_PERCENT").alias("metadata_REL_PROP_GRADE_4_PERCENT"),col("metadata.REL_PROP.GRADE_3OR4_PERCENT").alias("metadata_REL_PROP_GRADE_3OR4_PERCENT"))    
    writeToS3(scopia_drug_ae_solr_df, pipeline_s3_path, database_name, "t_scopia_drug_ae_solr")
    LOGGER.info("Writing scopia_drug_ae_solr output")


    #PCSDW_SOLR_TABLE
    #Need to perform Union of 3 solr output dataframes since there are 3 rel_types for PCSDW
    LOGGER.info("Creating pcsdw_solr output")
    
    pcsdw_normalized_df_hive= spark.sql("SELECT * from pipeline_tellic.t_pcsdw_compound_endpoint_normalized_triples")  
    uuidUdf_pcsdw1= udf(lambda : str(uuid.uuid4()),StringType())
    pcsdw_solr_df=pcsdw_normalized_df_hive.select(when(col("rel_type") == "DECREASES",concat(regexp_replace(col("entity1_concept_id"),"[^a-zA-Z0-9]", "_"),lit("-"),regexp_replace(col("entity2_concept_id"),"[^a-zA-Z0-9]","_"),lit("-E15"))).when(col("rel_type") == "INCREASES",concat(regexp_replace(col("entity1_concept_id"),"[^a-zA-Z0-9]", "_"),lit("-"),regexp_replace(col("entity2_concept_id"),"[^a-zA-Z0-9]","_"),lit("-E16"))).when(col("rel_type") == "DOES_NOT_SIGNIFICANTLY_AFFECT",concat(regexp_replace(col("entity1_concept_id"),"[^a-zA-Z0-9]", "_"),lit("-"),regexp_replace(col("entity2_concept_id"),"[^a-zA-Z0-9]","_"),lit("-E19"))).alias('relUid'),lit(uuidUdf_pcsdw1()).alias("tellic_evidence_id"),col("entity1_concept_id").alias("start_node"),col("entity2_concept_id").alias("end_node"),col("entity1").alias("entity_1_name"),col("rel_type").alias("relationship_type"),col("entity2").alias("entity_2_name"),col("strength").alias("strength"),(col("result")).alias("result"),col("result_type").alias("result_type"),col("confidence").alias("confidence"),lit("NULL").cast(IntegerType()).alias("epoch_time"),lit("AbbVieTriples").alias("source_type"),lit("PCSDW").alias("source_name"),regexp_replace(col("lineage.RULESETS").cast(StringType()),'\\[|\\]','').alias("lineage_rulesets"),regexp_replace(col("lineage.SOURCES").cast(StringType()),'\\[|\\]','').alias("lineage_sources"),regexp_replace(col("lineage.FILTERS").cast(StringType()),'\\[|\\]','').alias("lineage_filters"),col("lineage.VERSION").alias("lineage_version"),col("lineage.TIMESTAMP").alias("lineage_timestamp"),col("metadata.ENTITY1_PROP.INCHI_KEY").alias("metadata_ENTITY1_PROP_INCHI_KEY"),col("metadata.ENTITY1_PROP.ANUMBER").alias("metadata_ENTITY1_PROP_ANUMBER"),col("metadata.ENTITY2_PROP.MEAS_AREA").alias("metadata_ENTITY2_PROP_MEAS_AREA"),col("metadata.REL_PROP.SPECIES").alias("metadata_REL_PROP_SPECIES"),col("metadata.REL_PROP.STUDY_GROUP_ID").alias("metadata_REL_PROP_STUDY_GROUP_ID"),col("metadata.REL_PROP.DAY_OF_PHASE").alias("metadata_REL_PROP_DAY_OF_PHASE"),col("metadata.REL_PROP.STUDY_ID").alias("metadata_REL_PROP_STUDY_ID"),col("metadata.REL_PROP.STUDY").alias("metadata_REL_PROP_STUDY"),col("metadata.REL_PROP.SEX").alias("metadata_REL_PROP_SEX"),col("metadata.REL_PROP.DOSE_GROUP").alias("metadata_REL_PROP_DOSE_GROUP"),col("metadata.REL_PROP.CONDITION").alias("metadata_REL_PROP_CONDITION"),col("metadata.REL_PROP.DOSE").alias("metadata_REL_PROP_DOSE"),col("metadata.REL_PROP.ROUTE").alias("metadata_REL_PROP_ROUTE"),col("metadata.REL_PROP.UNITS").alias("metadata_REL_PROP_UNITS"),col("metadata.REL_PROP.PHASE").alias("metadata_REL_PROP_PHASE"),col("metadata.REL_PROP.VEHICLE").alias("metadata_REL_PROP_VEHICLE"),col("metadata.REL_PROP.DURATION_DAYS").alias("metadata_REL_PROP_DURATION_DAYS"),col("metadata.REL_PROP.LINK").alias("metadata_REL_PROP_LINK"),col("metadata.REL_PROP.SOURCE").alias("metadata_REL_PROP_SOURCE"),col("metadata.REL_PROP.CHANGE").alias("metadata_REL_PROP_CHANGE"),col("metadata.REL_PROP.FOLD_OVER_THRESHOLD").alias("metadata_REL_PROP_FOLD_OVER_THRESHOLD"),col("metadata.REL_PROP.MEDDRA_ID").alias("metadata_REL_PROP_MEDDRA_ID"),col("metadata.REL_PROP.MEDDRA_NAME").alias("metadata_REL_PROP_MEDDRA_NAME"))
    writeToS3(pcsdw_solr_df, pipeline_s3_path, database_name, "t_pcsdw_solr")
    LOGGER.info("Writing pcsdw_solr output")
	
	
    #COMPOUND_ENDPOINT_MEDMSD_SOLR_TABLE
    #Need to perform Union of 2 solr output dataframes since there are 2 rel_types for medmsd
    LOGGER.info("Creating medmsd_solr output")
    medmsd_normalized_df_hive= spark.sql("SELECT * from pipeline_tellic.t_compound_endpoint_medmsd_normalized_triples")
    uuidUdf_medmsd1= udf(lambda : str(uuid.uuid4()),StringType())
    medmsd_solr_df=medmsd_normalized_df_hive.select(when(col("rel_type") == "IMPACT_ON",concat(regexp_replace(col("entity1_concept_id"),"[^a-zA-Z0-9]", "_"),lit("-"),regexp_replace(col("entity2_concept_id"),"[^a-zA-Z0-9]","_"),lit("-E21"))).when(col("rel_type") == "HAS_NO_EFFECT",concat(regexp_replace(col("entity1_concept_id"),"[^a-zA-Z0-9]", "_"),lit("-"),regexp_replace(col("entity2_concept_id"),"[^a-zA-Z0-9]","_"),lit("-E17"))).alias('relUid'),lit(uuidUdf_medmsd1()).alias("tellic_evidence_id"),col("entity1_concept_id").alias("start_node"),col("entity2_concept_id").alias("end_node"),col("entity1").alias("entity_1_name"),col("rel_type").alias("relationship_type"),col("entity2").alias("entity_2_name"),col("strength").alias("strength"),(col("result")).alias("result"),col("result_type").alias("result_type"),col("confidence").alias("confidence"),lit("NULL").cast(IntegerType()).alias("epoch_time"),lit("AbbVieTriples").alias("source_type"),lit("PCSDW_MEDMSD").alias("source_name"),regexp_replace(col("lineage.RULESETS").cast(StringType()),'\\[|\\]','').alias("lineage_rulesets"),regexp_replace(col("lineage.SOURCES").cast(StringType()),'\\[|\\]','').alias("lineage_sources"),regexp_replace(col("lineage.FILTERS").cast(StringType()),'\\[|\\]','').alias("lineage_filters"),col("lineage.VERSION").alias("lineage_version"),col("lineage.TIMESTAMP").alias("lineage_timestamp"),col("metadata.ENTITY1_PROP.INCHI_KEY").alias("metadata_ENTITY1_PROP_INCHI_KEY"),col("metadata.ENTITY1_PROP.ANUMBER").alias("metadata_ENTITY1_PROP_ANUMBER"),col("metadata.ENTITY2_PROP.MEAS_AREA").alias("metadata_ENTITY2_PROP_MEAS_AREA"),col("metadata.REL_PROP.SPECIES").alias("metadata_REL_PROP_SPECIES"),col("metadata.REL_PROP.EFFECT_AT_MSD").alias("metadata_REL_PROP_EFFECT_AT_MSD"),col("metadata.REL_PROP.STRENGTH_AT_MSD").alias("metadata_REL_PROP_STRENGTH_AT_MSD"),col("metadata.REL_PROP.FOLDOVER_AT_MSD").alias("metadata_REL_PROP_FOLDOVER_AT_MSD"),col("metadata.REL_PROP.STUDY").alias("metadata_REL_PROP_STUDY"),col("metadata.REL_PROP.MAXIMUM_EFFECT_DOSE").alias("metadata_REL_PROP_MAXIMUM_EFFECT_DOSE"),col("metadata.REL_PROP.MED_UNITS").alias("metadata_REL_PROP_MED_UNITS"),col("metadata.REL_PROP.MAXIMUM_STRENGTH_AT_MED").alias("metadata_REL_PROP_MAXIMUM_STRENGTH_AT_MED"),col("metadata.REL_PROP.MAXIMUM_FOLDOVER_AT_MED").alias("metadata_REL_PROP_MAXIMUM_FOLDOVER_AT_MED"),col("metadata.REL_PROP.MINIMUM_SIGNIFICANT_DOSE").alias("metadata_REL_PROP_MINIMUM_SIGNIFICANT_DOSE"),col("metadata.REL_PROP.MSD_UNITS").alias("metadata_REL_PROP_MSD_UNITS"),col("metadata.REL_PROP.MAXIMUM_EFFECT_AT_MED").alias("metadata_REL_PROP_MAXIMUM_EFFECT_AT_MED"),col("metadata.REL_PROP.SOURCE").alias("metadata_REL_PROP_SOURCE"),col("metadata.REL_PROP.DURATION_DAYS").alias("metadata_REL_PROP_DURATION_DAYS"),col("metadata.REL_PROP.LINK").alias("metadata_REL_PROP_LINK"))
    writeToS3(medmsd_solr_df, pipeline_s3_path, database_name, "t_compound_endpoint_medmsd_solr") 
    LOGGER.info("Writing medmsd_solr output")
    
   
    
    #COMPOUND_CV_ENDPOINT_SOLR_TABLE
    LOGGER.info("Creating compound_cv_endpoint_solr output")
    cv_normalized_df_hive= spark.sql("SELECT * from pipeline_tellic.t_compound_cv_endpoint_normalized_triples")
    uuidUdf_compound_cv_endpoint= udf(lambda : str(uuid.uuid4()),StringType())
    compound_cv_endpoint_solr_df=cv_normalized_df_hive.select(when(col("rel_type") == "DECREASES",concat(regexp_replace(col("entity1_concept_id"),"[^a-zA-Z0-9]", "_"),lit("-"),regexp_replace(col("entity2_concept_id"),"[^a-zA-Z0-9]","_"),lit("-E15"))).when(col("rel_type") == "INCREASES",concat(regexp_replace(col("entity1_concept_id"),"[^a-zA-Z0-9]", "_"),lit("-"),regexp_replace(col("entity2_concept_id"),"[^a-zA-Z0-9]","_"),lit("-E16"))).when(col("rel_type") == "DOES_NOT_SIGNIFICANTLY_AFFECT",concat(regexp_replace(col("entity1_concept_id"),"[^a-zA-Z0-9]", "_"),lit("-"),regexp_replace(col("entity2_concept_id"),"[^a-zA-Z0-9]","_"),lit("-E19"))).alias('relUid'),lit(uuidUdf_compound_cv_endpoint()).alias("tellic_evidence_id"),col("entity1_concept_id").alias("start_node"),col("entity2_concept_id").alias("end_node"),col("entity1").alias("entity_1_name"),col("rel_type").alias("relationship_type"),col("entity2").alias("entity_2_name"),col("strength").alias("strength"),(col("result")).alias("result"),col("result_type").alias("result_type"),col("confidence").alias("confidence"),lit("NULL").cast(IntegerType()).alias("epoch_time"),lit("AbbVieTriples").alias("source_type"),lit("CV").alias("source_name"),regexp_replace(col("lineage.RULESETS").cast(StringType()),'\\[|\\]','').alias("lineage_rulesets"),regexp_replace(col("lineage.SOURCES").cast(StringType()),'\\[|\\]','').alias("lineage_sources"),regexp_replace(col("lineage.FILTERS").cast(StringType()),'\\[|\\]','').alias("lineage_filters"),col("lineage.VERSION").alias("lineage_version"),col("lineage.TIMESTAMP").alias("lineage_timestamp"),col("metadata.ENTITY1_PROP.INCHI_KEY").alias("metadata_ENTITY1_PROP_INCHI_KEY"),col("metadata.ENTITY1_PROP.ANUMBER").alias("metadata_ENTITY1_PROP_ANUMBER"),col("metadata.ENTITY1_PROP.DRUG_NAME").alias("metadata_ENTITY1_PROP_DRUG_NAME"),col("metadata.ENTITY1_PROP.CHEMBL_ID").alias("metadata_ENTITY1_PROP_CHEMBL_ID"),col("metadata.ENTITY1_PROP.MOLECULE_TYPE").alias("metadata_ENTITY1_PROP_MOLECULE_TYPE"),col("metadata.ENTITY1_PROP.PRIMARYIDENTIFIER").alias("metadata_ENTITY1_PROP_PRIMARYIDENTIFIER"),col("metadata.ENTITY2_PROP.MEAS_AREA").alias("metadata_ENTITY2_PROP_MEAS_AREA"),col("metadata.ENTITY2_PROP.MEAS_NAME").alias("metadata_ENTITY2_PROP_MEAS_NAME"),col("metadata.ENTITY2_PROP.ASSAY").alias("metadata_ENTITY2_PROP_ASSAY"),col("metadata.REL_PROP.SPECIES").alias("metadata_REL_PROP_SPECIES"),col("metadata.REL_PROP.DOSE").alias("metadata_REL_PROP_DOSE"),col("metadata.REL_PROP.DOSE_UNITS").alias("metadata_REL_PROP_DOSE_UNITS"),col("metadata.REL_PROP.MEASUREMENT_TIME").alias("metadata_REL_PROP_MEASUREMENT_TIME"),col("metadata.REL_PROP.MEASUREMENT_TIME_UNITS").alias("metadata_REL_PROP_MEASUREMENT_TIME_UNITS"),col("metadata.REL_PROP.DRUG_LEVEL").alias("metadata_REL_PROP_DRUG_LEVEL"),col("metadata.REL_PROP.DRUG_LEVEL_QUAL").alias("metadata_REL_PROP_DRUG_LEVEL_QUAL"),col("metadata.REL_PROP.FOLD_OVER_THRESHOLD").alias("metadata_REL_PROP_FOLD_OVER_THRESHOLD"),col("metadata.REL_PROP.MEASUREMENT_AREA").alias("metadata_REL_PROP_MEASUREMENT_AREA"),col("metadata.REL_PROP.MEDDRA_ID").alias("metadata_REL_PROP_MEDDRA_ID"),col("metadata.REL_PROP.MEDDRA_NAME").alias("metadata_REL_PROP_MEDDRA_NAME"),col("metadata.REL_PROP.SOURCE").alias("metadata_REL_PROP_SOURCE"),col("metadata.REL_PROP.LINK").alias("metadata_REL_PROP_LINK"))
    writeToS3(compound_cv_endpoint_solr_df, pipeline_s3_path, database_name, "t_compound_cv_endpoint_solr")
    LOGGER.info("Created compound_cv_endpoint_solr output")

	
    #COMPOUND_CV_ENDPOINT_MEDMSD_SOLR_TABLE
    LOGGER.info("Creating cv_medmsd_solr output")
    cv_medmsd_normalized_df_hive= spark.sql("SELECT * from pipeline_tellic.t_compound_cv_endpoint_medmsd_normalized_triples")
    uuidUdf_cv_medmsd= udf(lambda : str(uuid.uuid4()),StringType())
    cv_medmsd_solr_df=cv_medmsd_normalized_df_hive.select(when(col("rel_type") == "IMPACT_ON",concat(regexp_replace(col("entity1_concept_id"),"[^a-zA-Z0-9]", "_"),lit("-"),regexp_replace(col("entity2_concept_id"),"[^a-zA-Z0-9]","_"),lit("-E21"))).when(col("rel_type") == "HAS_NO_EFFECT",concat(regexp_replace(col("entity1_concept_id"),"[^a-zA-Z0-9]", "_"),lit("-"),regexp_replace(col("entity2_concept_id"),"[^a-zA-Z0-9]","_"),lit("-E17"))).alias('relUid'),lit(uuidUdf_cv_medmsd()).alias("tellic_evidence_id"),col("entity1_concept_id").alias("start_node"),col("entity2_concept_id").alias("end_node"),col("entity1").alias("entity_1_name"),col("rel_type").alias("relationship_type"),col("entity2").alias("entity_2_name"),col("strength").alias("strength"),(col("result")).alias("result"),col("result_type").alias("result_type"),col("confidence").alias("confidence"),lit("NULL").cast(IntegerType()).alias("epoch_time"),lit("AbbVieTriples").alias("source_type"),lit("CV_MEDMSD").alias("source_name"),regexp_replace(col("lineage.RULESETS").cast(StringType()),'\\[|\\]','').alias("lineage_rulesets"),regexp_replace(col("lineage.SOURCES").cast(StringType()),'\\[|\\]','').alias("lineage_sources"),regexp_replace(col("lineage.FILTERS").cast(StringType()),'\\[|\\]','').alias("lineage_filters"),col("lineage.VERSION").alias("lineage_version"),col("lineage.TIMESTAMP").alias("lineage_timestamp"),col("metadata.ENTITY1_PROP.INCHI_KEY").alias("metadata_ENTITY1_PROP_INCHI_KEY"),col("metadata.ENTITY1_PROP.ANUMBER").alias("metadata_ENTITY1_PROP_ANUMBER"),col("metadata.ENTITY1_PROP.DRUG_NAME").alias("metadata_ENTITY1_PROP_DRUG_NAME"),col("metadata.ENTITY1_PROP.CHEMBL_ID").alias("metadata_ENTITY1_PROP_CHEMBL_ID"),col("metadata.ENTITY1_PROP.MOLECULE_TYPE").alias("metadata_ENTITY1_PROP_MOLECULE_TYPE"),col("metadata.ENTITY1_PROP.PRIMARYIDENTIFIER").alias("metadata_ENTITY1_PROP_PRIMARYIDENTIFIER"),col("metadata.ENTITY2_PROP.MEAS_AREA").alias("metadata_ENTITY2_PROP_MEAS_AREA"),col("metadata.ENTITY2_PROP.MEAS_NAME").alias("metadata_ENTITY2_PROP_MEAS_NAME"),col("metadata.ENTITY2_PROP.ASSAY").alias("metadata_ENTITY2_PROP_ASSAY"),col("metadata.REL_PROP.SPECIES").alias("metadata_REL_PROP_SPECIES"),col("metadata.REL_PROP.EFFECT_AT_MSD").alias("metadata_REL_PROP_EFFECT_AT_MSD"),col("metadata.REL_PROP.STRENGTH_AT_MSD").alias("metadata_REL_PROP_STRENGTH_AT_MSD"),col("metadata.REL_PROP.FOLDOVER_AT_MSD").alias("metadata_REL_PROP_FOLDOVER_AT_MSD"),col("metadata.REL_PROP.MAXIMUM_EFFECT_DOSE").alias("metadata_REL_PROP_MAXIMUM_EFFECT_DOSE"),col("metadata.REL_PROP.MAXIMUM_STRENGTH_AT_MED").alias("metadata_REL_PROP_MAXIMUM_STRENGTH_AT_MED"),col("metadata.REL_PROP.MAXIMUM_FOLDOVER_AT_MED").alias("metadata_REL_PROP_MAXIMUM_FOLDOVER_AT_MED"),col("metadata.REL_PROP.EFFECT_TYPE").alias("metadata_REL_PROP_EFFECT_TYPE"),col("metadata.REL_PROP.MINIMUM_SIGNIFICANT_DOSE").alias("metadata_REL_PROP_MINIMUM_SIGNIFICANT_DOSE"),col("metadata.REL_PROP.SOURCE").alias("metadata_REL_PROP_SOURCE"),col("metadata.REL_PROP.FOLD_OVER_THRESHOLD").alias("metadata_REL_PROP_FOLD_OVER_THRESHOLD"),col("metadata.REL_PROP.MAXIMUM_EFFECT_AT_MED").alias("metadata_REL_PROP_MAXIMUM_EFFECT_AT_MED"),col("metadata.REL_PROP.LINK").alias("metadata_REL_PROP_LINK"))
    writeToS3(cv_medmsd_solr_df, pipeline_s3_path, database_name, "t_compound_cv_endpoint_medmsd_solr")
    LOGGER.info("Created cv_medmsd_solr output")
    
    #DRUG_HEALTH_EVENT_SOLR
    drug_df=spark.sql("""SELECT CONCAT(regexp_replace(drug.start_node,"[^a-zA-Z0-9]","_"), '-', he.end_node, '-E10') as relUid,drug.tellic_evidence_id, drug.start_node, drug.entity_1_name,he.end_node, he.entity_2_name, drug.relationship_type, drug.strength,drug. result,drug. result_type,drug. confidence,drug. epoch_time, drug.source_type,drug. source_name,drug. lineage_rulesets,drug.lineage_sources, drug.lineage_filters, drug.lineage_version, drug.lineage_timestamp, drug. metadata_entity1_prop_active_ingredient,drug. metadata_entity1_prop_id,drug. metadata_entity1_prop_moa,drug. metadata_entity2_prop_adverse_event,drug. metadata_rel_prop_comment,drug. metadata_rel_prop_reports,drug. metadata_rel_prop_aes, drug.metadata_rel_prop_severity,drug. metadata_rel_prop_frequency, drug.metadata_rel_prop_source,drug.metadata_rel_prop_onlabel,drug.metadata_rel_prop_grade_3_percent,drug.metadata_rel_prop_grade_4_percent,drug.metadata_rel_prop_grade_3or4_percent
  FROM pipeline_tellic.t_scopia_drug_ae_solr drug
   JOIN tellic_abbvie.tellic_graph_data_solr_relationships_is_member_health_event he
  ON drug.end_node = he.start_node""")
    writeToS3(drug_df, pipeline_s3_path, database_name, "drug_health_condition_solr")



##################################################################################################################################################################################

#EXTRACTION OF NODE TABLES(adding unmapped concept ids to existing node tables)
    
    #node_measurement 
    pcsdw_normalized_df_hive.createOrReplaceTempView("pcsdw_normalized_table")
    medmsd_normalized_df_hive.createOrReplaceTempView("compound_endpoint_medmsd_normalized_table")
    cv_normalized_df_hive.createOrReplaceTempView("compound_cv_endpoint_normalized_table")
    cv_medmsd_normalized_df_hive.createOrReplaceTempView("compound_cv_endpoint_medmsd_normalized_table")
    LOGGER.info("Creating Neo4j_node_measurement table")
    tellic_node_measurement_df1=spark.sql("""SELECT DISTINCT 'Measurement' AS entity_type,'Custom' AS ontology,entity2_concept_id AS concept_id,entity2 AS entity_name,'Measurement' AS label,entity2_type as meas_area FROM pcsdw_normalized_table""")
    tellic_node_measurement_df2=spark.sql("""SELECT DISTINCT 'Measurement' AS entity_type,'Custom' AS ontology,entity2_concept_id AS concept_id,entity2 AS entity_name,'Measurement' AS label,entity2_type as meas_area FROM compound_endpoint_medmsd_normalized_table""")
    tellic_node_measurement_df3=spark.sql("""SELECT DISTINCT 'Measurement' AS entity_type,'Custom' AS ontology,entity2_concept_id AS concept_id,entity2 AS entity_name,'Measurement' AS label,entity2_type as meas_area FROM compound_cv_endpoint_normalized_table""")
    tellic_node_measurement_df4=spark.sql("""SELECT DISTINCT 'Measurement' AS entity_type,'Custom' AS ontology,entity2_concept_id AS concept_id,entity2 AS entity_name,'Measurement' AS label,entity2_type as meas_area FROM compound_cv_endpoint_medmsd_normalized_table""")
    tellic_node_measurement_df5=spark.sql("""SELECT DISTINCT 'Measurement' AS entity_type,'Custom' AS ontology,entity2_concept_id AS concept_id,entity2 AS entity_name,'Measurement' AS label,entity2_type as meas_area FROM pipeline_tellic.t_pkpairing_endpoint_pk_normalized_triples""")
    tellic_final_node_measurement_df=tellic_node_measurement_df1.union(tellic_node_measurement_df2).union(tellic_node_measurement_df3).union(tellic_node_measurement_df4).union(tellic_node_measurement_df5).dropDuplicates()
    LOGGER.info("Writing Neo4j_node_measurement table")
    writeToS3(tellic_final_node_measurement_df, pipeline_s3_path, database_name, "tellic_node_measurement") 
    
    
    #node_AdverseEvent

    LOGGER.info("Creating Neo4j_node_ae table")
    
    unmapped_node_ae_df= spark.sql("""with cte as (
    SELECT distinct entity2 as entity,entity2_concept_id as concept_id from pipeline_tellic.t_scopia_drug_ae_normalized_triples 
    union 
    SELECT distinct entity2 as entity,entity2_concept_id as concept_id from pipeline_tellic.t_scopia_dci_ae_normalized_triples 
    union 
    SELECT distinct entity2 as entity,entity2_concept_id as concept_id from pipeline_tellic.t_scopia_ddi_ae_normalized_triples )
    select a.* from cte a
    left outer join 
    (select concept_id from tellic_abbvie.tellic_graph_data_node_ae) b
    on regexp_replace(a.concept_id,'\:','') = b.concept_id
    where b.concept_id is null
""")
    unmapped_node_ae_df.createOrReplaceTempView("unmapped_node_ae_view")
    tellic_abbvie_node_ae_df=spark.sql("""SELECT * FROM tellic_abbvie.tellic_graph_data_node_ae""")
    final_unmapped_node_ae_df=spark.sql("""SELECT distinct 'AdverseEvent' AS entity_type,'Custom' AS ontology,concept_id AS concept_id,entity AS entity_name,'Entity' AS class,'Adverse Event' AS label,'' AS synonyms,'' AS term_class,'' AS system_organ_classes,'' as run_date FROM unmapped_node_ae_view""")
    tellic_final_node_ae_df = final_unmapped_node_ae_df.union(tellic_abbvie_node_ae_df).dropDuplicates()
    writeToS3(tellic_final_node_ae_df, pipeline_s3_path, database_name, "tellic_node_ae") 

    #node_drug
	
    LOGGER.info("Creating Neo4j_node_drug table")
   
    unmapped_node_drug_df= spark.sql("""with cte as (
SELECT distinct entity1 as entity,entity1_concept_id as concept_id from pipeline_tellic.t_scopia_drug_ae_normalized_triples 
union 
SELECT distinct entity1 as entity,entity1_concept_id as concept_id from pipeline_tellic.t_scopia_drug_ci_normalized_triples 
union 
SELECT distinct entity2 as entity,entity2_concept_id as concept_id from pipeline_tellic.t_scopia_drug_drug_normalized_triples 
union 
SELECT distinct entity1 as entity,entity1_concept_id as concept_id from pipeline_tellic.t_scopia_drug_drug_normalized_triples
union 
SELECT distinct entity1 as entity,entity1_concept_id as concept_id from pipeline_tellic.t_scopia_dci_ai_normalized_triples 
union 
SELECT distinct entity1 as entity,entity1_concept_id as concept_id from pipeline_tellic.t_scopia_ddi_di_normalized_triples 
union 
SELECT distinct entity1 as entity,entity1_concept_id as concept_id from pipeline_tellic.t_scopia_ddi_dps_normalized_triples 
union 
SELECT distinct entity1 as entity,entity1_concept_id as concept_id from pipeline_tellic.t_fdb_drug_compound_normalized_triples
union 
SELECT distinct entity1 as entity,entity1_concept_id as concept_id from pipeline_tellic.t_drug_gene_normalized_triples)
select a.* from cte a
left outer join 
(select concept_id from tellic_abbvie.tellic_graph_data_node_drug) b
on regexp_replace(a.concept_id,'\:','') = b.concept_id
where b.concept_id is null
    """)
    unmapped_node_drug_df.createOrReplaceTempView("unmapped_node_drug_view")
    tellic_abbvie_node_drug_df=spark.sql("""SELECT * FROM tellic_abbvie.tellic_graph_data_node_drug""")
    final_unmapped_node_drug_df=spark.sql("""SELECT distinct 'Drug' AS entity_type,'Custom' AS ontology,concept_id AS concept_id,entity AS entity_name,'Entity' AS class,'Drug' AS label,'' AS molecule_type,'' AS max_phase,'' AS therapeutic_flag,'' AS first_approval,'' AS rxcui,'' AS pharmacological_action_classes,'' AS moa_classes,'' AS atc_classes,'' AS targets,'' as action_type,'' as target_type,'' AS synonyms,'' AS run_date FROM unmapped_node_drug_view""")
    tellic_final_node_drug_df = final_unmapped_node_drug_df.union(tellic_abbvie_node_drug_df).dropDuplicates()
    writeToS3(tellic_final_node_drug_df, pipeline_s3_path, database_name, "tellic_node_drug") 

#############################################################################################################################################################################
#CREATION OF RELATIONSHIP TABLES

#neo4j_has_side_effect
    LOGGER.info("Creating neo4j_has_side_effect relationship table.")
    neo4j_has_side_effect_df =  spark.sql("""SELECT relUid
    ,count(*) as num_of_merged
    ,avg(strength) as avg_strength, avg(confidence) as avg_confidence
    ,min_epoch_time, max_epoch_time, concept_1_id, concept_2_id, entity1_type, entity2_type
    from (
        SELECT  reluid as relUid,strength,confidence,
        cast(null as Integer) as min_epoch_time,
        cast(null as Integer) as max_epoch_time,
        start_node as concept_1_id,
        end_node as concept_2_id,
        'Drug' as entity1_type,
        'Adverse Event' as entity2_type
        from pipeline_tellic.t_scopia_drug_ae_solr where relationship_type = "Has Side Effect" 
        union all
        SELECT reluid as relUid,strength,confidence,
        cast(null as Integer) as min_epoch_time,
        cast(null as Integer) as max_epoch_time,
        start_node as concept_1_id,
        end_node as concept_2_id,
        'Drug' as entity1_type,
        'Health Condition' as entity2_type
        from pipeline_tellic.drug_health_condition_solr where relationship_type = "Has Side Effect"
    )x
    GROUP BY relUid, concept_1_id, concept_2_id, entity1_type, entity2_type, min_epoch_time, max_epoch_time""")
    neo4j_has_side_effect_df.dropDuplicates()
    writeToS3(neo4j_has_side_effect_df, pipeline_s3_path, database_name, "neo4j_has_side_effect")
    
 
	
            #neo4j_has_no_effect - MEDMSD 

    LOGGER.info("Creating NEO4J_HAS_NO_EFFECT relationship table.")

    neo4j_has_no_effect_df=spark.sql("""
                    SELECT relUid,
                    count(*) as num_of_merged,
                    avg(strength) as avg_strength,
                    avg(confidence) as avg_confidence,
                    min_epoch_time, max_epoch_time, concept_1_id, concept_2_id, entity1_type, entity2_type
                    from (
                            SELECT reluid as relUid, strength,confidence,
                            cast(null as Integer) as min_epoch_time,
                            cast(null as Integer) as max_epoch_time,
                            start_node as concept_1_id,
                            end_node as concept_2_id,
                            'Chemical' as entity1_type,
                            'Measurement' as entity2_type
                            from pipeline_tellic.t_compound_endpoint_medmsd_solr  where relationship_type = "HAS_NO_EFFECT" 
                            
                            union all
                            
                            SELECT reluid as relUid,strength,confidence,
                            cast(null as Integer) as min_epoch_time,
                            cast(null as Integer) as max_epoch_time,
                            start_node as concept_1_id,
                            end_node as concept_2_id,
                            'Chemical' as entity1_type,
                            'Measurement' as entity2_type
                            from pipeline_tellic.t_compound_cv_endpoint_medmsd_solr where relationship_type =  "HAS_NO_EFFECT"
                    )x		
            GROUP BY  relUid, concept_1_id, concept_2_id, entity1_type, entity2_type, min_epoch_time, max_epoch_time """)

    neo4j_has_no_effect_table_name=  "neo4j_has_no_effect"
    neo4j_has_no_effect_df=neo4j_has_no_effect_df.dropDuplicates()
    writeToS3(neo4j_has_no_effect_df, pipeline_s3_path, database_name, "neo4j_has_no_effect")

    #neo4j_impact_on MEDMSD
    LOGGER.info("Creating neo4j_impact_on relationship table.")

    neo4j_impact_on_df=spark.sql("""
                    SELECT relUid,
                    count(*) as num_of_merged,
                    avg(strength) as avg_strength,
                    avg(confidence) as avg_confidence,
                    min_epoch_time, max_epoch_time, concept_1_id, concept_2_id, entity1_type, entity2_type
                    from (
                            SELECT reluid as relUid, strength,confidence,
                            cast(null as Integer) as min_epoch_time,
                            cast(null as Integer) as max_epoch_time,
                            start_node as concept_1_id,
                            end_node as concept_2_id,
                            'Chemical' as entity1_type,
                            'Measurement' as entity2_type
                            from pipeline_tellic.t_compound_endpoint_medmsd_solr  where relationship_type = "IMPACT_ON" 
                            
                            union all
                            
                            SELECT reluid as relUid,strength,confidence,
                            cast(null as Integer) as min_epoch_time,
                            cast(null as Integer) as max_epoch_time,
                            start_node as concept_1_id,
                            end_node as concept_2_id,
                            'Chemical' as entity1_type,
                            'Measurement' as entity2_type
                            from pipeline_tellic.t_compound_cv_endpoint_medmsd_solr where relationship_type =  "IMPACT_ON"
                    )x	
            GROUP BY  relUid, concept_1_id, concept_2_id, entity1_type, entity2_type, min_epoch_time, max_epoch_time """)
    neo4j_impact_on_table_name=  "neo4j_impact_on"
    neo4j_impact_on_df=neo4j_impact_on_df.dropDuplicates()
    writeToS3(neo4j_impact_on_df, pipeline_s3_path, database_name, "neo4j_impact_on")


    #neo4j_does_not_significantly_affect_df
    LOGGER.info("Creating neo4j_does_not_significantly_affect view.")

    neo4j_does_not_significantly_affect_df =spark.sql("""
                    SELECT relUid,
                    count(*) as num_of_merged,
                    avg(strength) as avg_strength,
                    avg(confidence) as avg_confidence,
                    min_epoch_time, max_epoch_time, concept_1_id, concept_2_id, entity1_type, entity2_type
                    from (
                            SELECT reluid as relUid, strength,confidence,
                            cast(null as Integer) as min_epoch_time,
                            cast(null as Integer) as max_epoch_time,
                            start_node as concept_1_id,
                            end_node as concept_2_id,
                            'Chemical' as entity1_type,
                            'Measurement' as entity2_type
                            from pipeline_tellic.t_pcsdw_solr where relationship_type =  "DOES_NOT_SIGNIFICANTLY_AFFECT" 
                            
                            union all
                            
                            SELECT reluid as relUid,strength,confidence,
                            cast(null as Integer) as min_epoch_time,
                            cast(null as Integer) as max_epoch_time,
                            start_node as concept_1_id,
                            end_node as concept_2_id,
                            'Chemical' as entity1_type,
                            'Measurement' as entity2_type
                            from pipeline_tellic.t_compound_cv_endpoint_solr where relationship_type =  "DOES_NOT_SIGNIFICANTLY_AFFECT"
                    )x			
            GROUP BY  relUid, concept_1_id, concept_2_id, entity1_type, entity2_type, min_epoch_time, max_epoch_time """)

    neo4j_does_not_significantly_affect_table_name=  "neo4j_does_not_significantly_affect"
    neo4j_does_not_significantly_affect_df=neo4j_does_not_significantly_affect_df.dropDuplicates()
    writeToS3(neo4j_does_not_significantly_affect_df, pipeline_s3_path, database_name, "neo4j_does_not_significantly_affect")

    #neo4j_increases
    LOGGER.info("Creating neo4j_increases view.")


    neo4j_increases_df =spark.sql("""
                    SELECT relUid,
                    count(*) as num_of_merged,
                    avg(strength) as avg_strength,
                    avg(confidence) as avg_confidence,
                    min_epoch_time, max_epoch_time, concept_1_id, concept_2_id, entity1_type, entity2_type
                    from (
                            SELECT reluid as relUid, strength,confidence,
                            cast(null as Integer) as min_epoch_time,
                            cast(null as Integer) as max_epoch_time,
                            start_node as concept_1_id,
                            end_node as concept_2_id,
                            'Chemical' as entity1_type,
                            'Measurement' as entity2_type
                            from pipeline_tellic.t_pcsdw_solr where relationship_type = "INCREASES" 
                            
                            union all
                            
                            SELECT reluid as relUid,strength,confidence,
                            cast(null as Integer) as min_epoch_time,
                            cast(null as Integer) as max_epoch_time,
                            start_node as concept_1_id,
                            end_node as concept_2_id,
                            'Chemical' as entity1_type,
                            'Measurement' as entity2_type
                            from pipeline_tellic.t_compound_cv_endpoint_solr where relationship_type =  "INCREASES"
                    )x			
            GROUP BY  relUid, concept_1_id, concept_2_id, entity1_type, entity2_type, min_epoch_time, max_epoch_time """)
    neo4j_increases_table_name=  "neo4j_increases"
    neo4j_increases_df=neo4j_increases_df.dropDuplicates()
    writeToS3(neo4j_increases_df, pipeline_s3_path, database_name, "neo4j_increases")


    #neo4j_decreases
    LOGGER.info("Creating neo4j_decreases view.")

    neo4j_decreases_df = spark.sql("""
                    SELECT relUid,
                    count(*) as num_of_merged,
                    avg(strength) as avg_strength,
                    avg(confidence) as avg_confidence,
                    min_epoch_time, max_epoch_time, concept_1_id, concept_2_id, entity1_type, entity2_type
                    from (
                            SELECT reluid as relUid, strength,confidence,
                            cast(null as Integer) as min_epoch_time,
                            cast(null as Integer) as max_epoch_time,
                            start_node as concept_1_id,
                            end_node as concept_2_id,
                            'Chemical' as entity1_type,
                            'Measurement' as entity2_type
                            from pipeline_tellic.t_pcsdw_solr where relationship_type = "DECREASES" 
                            
                            union all
                            
                            SELECT reluid as relUid,strength,confidence,
                            cast(null as Integer) as min_epoch_time,
                            cast(null as Integer) as max_epoch_time,
                            start_node as concept_1_id,
                            end_node as concept_2_id,
                            'Chemical' as entity1_type,
                            'Measurement' as entity2_type
                            from pipeline_tellic.t_compound_cv_endpoint_solr where relationship_type =  "DECREASES"
                    )x
                            
            GROUP BY  relUid, concept_1_id, concept_2_id, entity1_type, entity2_type, min_epoch_time, max_epoch_time """)

    neo4j_decreases_table_name=  "neo4j_decreases"
    neo4j_decreases_df=neo4j_decreases_df.dropDuplicates()
    writeToS3(neo4j_decreases_df, pipeline_s3_path, database_name, "neo4j_decreases")
#####################################################################################################################################################################################

# timeline tables

#solr_abbvie timeline table
    tdb_sm_cell_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_tdb_sm_cell_solr""")
    cpdb_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_cpdb_gene_gene_solr""")
    fdb_sm_gene_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_fdb_sm_gene_solr""")
    fdb_drug_comp_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_fdb_drug_comp_solr""")
    fdb_comp_sim_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_fdb_comp_sim_solr""")
    scopia_dci_ae_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_scopia_dci_ae_solr""")
    scopia_dci_ai_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_scopia_dci_ai_solr""")
    scopia_dci_ci_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_scopia_dci_ci_solr""")
    scopia_ddi_ae_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_scopia_ddi_ae_solr""")
    scopia_ddi_di_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_scopia_ddi_di_solr""")
    scopia_ddi_dps_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_scopia_ddi_dps_solr""")
    scopia_drug_ae_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_scopia_drug_ae_solr""")
    scopia_drug_ci_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_scopia_drug_ci_solr""")
    scopia_drug_drug_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_scopia_drug_drug_solr""")
    pcsdw_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_pcsdw_solr""")
    compound_endpoint_medmsd_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from pipeline_tellic.t_compound_endpoint_medmsd_solr""")
    drug_gene_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_drug_gene_solr""")
    
    timeline_union_df =[tdb_sm_cell_solr_df,compound_endpoint_medmsd_df,drug_gene_df,fdb_sm_gene_solr_df,cpdb_solr_df,fdb_drug_comp_solr_df,fdb_comp_sim_solr_df,scopia_dci_ae_solr_df,scopia_dci_ai_solr_df,scopia_dci_ci_solr_df,scopia_ddi_ae_solr_df,scopia_ddi_di_solr_df,scopia_ddi_dps_solr_df,scopia_drug_ae_solr_df,scopia_drug_ci_solr_df,scopia_drug_drug_solr_df,pcsdw_solr_df]
    timeline_union_dfs = reduce(DataFrame.unionAll, timeline_union_df)
    writeToS3(timeline_union_dfs, pipeline_s3_path, database_name, "solr_abbvie_timeline")
   
    #cv solr_abbvie_timeline
    compound_cv_endpoint_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_compound_cv_endpoint_solr""")
    compound_cv_endpoint_medmsd_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_compound_cv_endpoint_medmsd_solr""")
    timeline_cv_union_dfs =compound_cv_endpoint_solr_df.union(compound_cv_endpoint_medmsd_solr_df)
    writeToS3(timeline_cv_union_dfs, pipeline_s3_path, database_name, "solr_abbvie_timeline_cv")
    
    #uc84 solr_abbvie_timeline
    variant_variant_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_variant_variant_solr""")
    finngen_variant_phenotype_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_finngen_variant_phenotype_solr""")
    ukbb_variant_phenotype_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_ukbb_variant_phenotype_solr""")
    finngen_gene_variant_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_finngen_gene_variant_solr""")
    ukbb_gene_variant_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_ukbb_gene_variant_solr""")
    omim_gene_phenotype_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic. t_omim_gene_phenotype_solr""")
    timeline_uc84_union_dfs =variant_variant_df.union(finngen_variant_phenotype_df).union(ukbb_variant_phenotype_df).union(finngen_gene_variant_df).union(ukbb_gene_variant_df).union(omim_gene_phenotype_df)
    writeToS3(timeline_uc84_union_dfs, pipeline_s3_path, database_name, "solr_abbvie_timeline_uc84")
     
     
     #ccle solr_abbvie_timeline
    t_gene_cell_line_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_gene_cell_line_solr""")
    t_gene_disease_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_gene_disease_solr""")
    t_gene_tissue_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_gene_tissue_solr""")
    timeline_ccle_union_dfs =t_gene_cell_line_solr_df.union(t_gene_disease_solr_df).union(t_gene_tissue_solr_df)
    writeToS3(timeline_ccle_union_dfs, pipeline_s3_path, database_name, "solr_abbvie_timeline_ccle")
    
    
    #humanpk solr_abbvie_timeline
    pkpairing_endpoint_pk_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_pkpairing_endpoint_pk_solr""")
    compound_pkpairing_dosed_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_compound_pkpairing_dosed_solr""")
    compound_pkpairing_measured_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_compound_pkpairing_measured_solr""")
    compound_compound_metabolite_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_compound_compound_metabolite_solr""")
    timeline_humanpk_union_dfs =pkpairing_endpoint_pk_solr_df.union(compound_pkpairing_dosed_solr_df).union(compound_pkpairing_measured_solr_df).union(compound_compound_metabolite_solr_df)
    writeToS3(timeline_humanpk_union_dfs, pipeline_s3_path, database_name, "solr_abbvie_timeline_invivopk")
	
   #health_event_solr_timeline
    dci_health_event_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.dci_health_condition_solr""")
    ddi_health_event_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.ddi_health_condition_solr""")
    drug_health_event_solr_df = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.drug_health_condition_solr""")
    ukbb_variant_health_condition_solr = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_ukbb_variant_health_condition_solr""")
    finngen_variant_health_condition_solr = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_finngen_variant_health_condition_solr""")
    phenotype_health_condition_solr = spark.sql("""select reluid,strength,confidence,'AbbVieTriples' as source_type,cast(null as Int) as epoch_time from  pipeline_tellic.t_phenotype_health_condition_solr""")
    timeline_union_hc_df =[dci_health_event_solr_df,ddi_health_event_solr_df,drug_health_event_solr_df,ukbb_variant_health_condition_solr,finngen_variant_health_condition_solr,phenotype_health_condition_solr]
    timeline_union_hc_dfs = reduce(DataFrame.unionAll, timeline_union_hc_df)
    writeToS3(timeline_union_hc_dfs, pipeline_s3_path, database_name, "solr_abbvie_timeline_health_event")

'''
