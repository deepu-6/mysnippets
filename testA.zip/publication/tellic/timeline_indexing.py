import com.github.music.of.the.ainur.almaren.Almaren
import com.github.music.of.the.ainur.almaren.solr.Solr.SolrImplicit
import org.apache.spark.sql.SaveMode
import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.lucidworks.spark.util.SolrSupport
import com.lucidworks.spark.util.SolrSupport.CloudClientParams
import com.lucidworks.spark.util.SolrQuerySupport
import org.apache.solr.client.solrj.SolrQuery
val almaren = Almaren("Triple Solr Indexing")
var solrQuery: SolrQuery = new SolrQuery
val args = sc.getConf.get("spark.driver.args").split("\\s+")
val zkhost= args(0)
def indexTable(db_table_name:String,zkhost:String,batch_size:Int,commit_within:Int,collection_name:String){
	var table_names_array = db_table_name.split("\\.")
	var table_name = table_names_array(1)
	print(table_name+"tname")
	var view_name = s"$table_name"+"_vw" 
	spark.table(s"$db_table_name")
		.withColumn("id",concat(monotonicallyIncreasingId(),lit(s"$table_name")))
		.withColumn("table_name", lit(s"$table_name"))
		.withColumnRenamed("reluid","relUid")
		.createOrReplaceTempView(s"$view_name") 
	almaren.builder.sourceSql("SELECT * from " + s"$view_name")
		.targetSolr(s"$collection_name",s"$zkhost",Map("batch_size" ->s"$batch_size" ,"commit_within" ->s"$commit_within" ),SaveMode.Overwrite).batch
}
def deleteTable(db_table_name:String,zkhost:String,collection_name:String){
	var delete_table_name = "table_name:"+s"$db_table_name"
	val count_check1 = SolrQuerySupport.getNumDocsFromSolr(s"$collection_name",s"$zkhost",None)
	if(count_check1>0){
		lazy val cloudSolrClient = SolrSupport.getCachedCloudClient(CloudClientParams(s"$zkhost"))
		cloudSolrClient.setDefaultCollection(s"$collection_name")
		cloudSolrClient.deleteByQuery(s"$delete_table_name")
		cloudSolrClient.commit()
	}
	else{return}
	solrQuery = solrQuery.setQuery(s"$delete_table_name")
	val count_check2 = SolrQuerySupport.getNumDocsFromSolr(s"$collection_name",s"$zkhost",Option(solrQuery))
	if(count_check2 > 0){
		deleteTable(db_table_name,zkhost,collection_name)
	}
	else{return}
}
	val collection_name =  "timeline"
	val batch_size = 500
	val commit_within = 10000
	var solr_index_table_list=Array("pipeline_tellic.solr_abbvie_timeline_health_event","pipeline_tellic.solr_abbvie_timeline_invivopk","pipeline_tellic.solr_abbvie_timeline_ccle","pipeline_tellic.solr_abbvie_timeline_uc84","pipeline_tellic.solr_abbvie_timeline_cv","pipeline_tellic.solr_abbvie_timeline");
	var solr_delete_tables_list=Array("solr_abbvie_timeline_health_event","solr_abbvie_timeline");
	for(table_name <- solr_delete_tables_list){
		print("solr deleting table name : "+table_name)
		deleteTable(table_name,zkhost,collection_name)
		print("solr deleted table name: "+table_name)
	}
	for (db_table_name <- solr_index_table_list){
		print("solr indexing table name : "+db_table_name)
		indexTable(db_table_name,zkhost,batch_size,commit_within,collection_name)
		print("solr indexed table name : "+db_table_name)
	}
	System.exit(0)
