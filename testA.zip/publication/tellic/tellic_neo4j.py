import org.apache.spark.sql.{DataFrame,SaveMode,SparkSession}
import org.slf4j.LoggerFactory
import org.apache.spark.sql.types.DoubleType
import org.apache.spark.sql.functions.col
import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.{Almaren,Tree}
import org.neo4j.driver._
import scala.util.control._
import com.modak.common._
import com.modak.common.credential.Credential
val almaren = Almaren("Tellic Neo4j Pipeline")
val spark = SparkSession.builder().getOrCreate()
val logger = LoggerFactory.getLogger("Neo4J")

class Tellic(neo4j_url:String, user:String, pass:String, neo4j_db:String)  {
	import spark.implicits._

	private val driver = GraphDatabase.driver(neo4j_url, AuthTokens.basic(user, pass))
	
	private def session_open(): Session = {
		driver.session(SessionConfig.forDatabase(neo4j_db))
	}
	private def session_close(session:Session) {			
		session.close()
	}
	def create_constriants(node_tables: List[String]) {
		val session = session_open()
		for(table_name <-  node_tables) {
			var constraint_labels = spark.sql("SELECT DISTINCT label FROM " + table_name).map(r => r.getString(0)).collect.toList
			for(constraint_label <- constraint_labels) {
				var alias = constraint_label.replace(' ', '_').toLowerCase()
				var script = "CREATE CONSTRAINT " + alias + " IF NOT EXISTS ON ( " + alias + ":`" + constraint_label + "` ) ASSERT " + alias +".concept_id IS UNIQUE; "
				println("Constraints CQL: " + script)	
				val result = session.run(script)
			}
		}
		logger.info("[+] Created Constraints Successfully. [+]")
		session_close(session)		
	}
	def getTellicAbbvieRelationshipType(): Map[String, String]={
		val multi_rel = Map(
			"tellic_abbvie.tellic_graph_data_processed_relationships_with_strength" -> "RELATED_TO",
			"tellic_abbvie.tellic_graph_data_processed_relationships_without_strength" -> "RELATED_TO",
			"tellic_abbvie.tellic_graph_data_processed_relationships_targets" -> "TARGETS",
			"tellic_abbvie.tellic_graph_data_processed_relationships_is_member" -> "IS_MEMBER",
			"tellic_abbvie.tellic_graph_data_processed_relationships_adverse_event" -> "HAS_ADVERSE_EVENT",
			"tellic_abbvie.tellic_graph_data_processed_relationships_has_ingredient" -> "HAS_INGREDIENT",
			"tellic_abbvie.tellic_graph_data_processed_relationships_has_isomer" -> "HAS_ISOMER",
			"tellic_abbvie.tellic_graph_data_processed_relationships_has_parent" -> "HAS_PARENT",
			"tellic_abbvie.tellic_graph_data_processed_relationships_has_precise_ingredient" -> "HAS_PRECISE_INGREDIENT",
			"tellic_abbvie.tellic_graph_data_processed_relationships_is_equal_to" -> "IS_EQUAL_TO",
			"tellic_abbvie.tellic_graph_data_processed_relationships_shares_family" -> "SHARES_FAMILY",			
			"tellic_abbvie.tellic_graph_data_processed_relationships_associated_with" -> "ASSOCIATED_WITH",
			"tellic_abbvie.tellic_graph_data_processed_relationships_has_interaction" -> "HAS_INTERACTION",	
			"tellic_abbvie.tellic_graph_data_processed_relationships_has_variant" -> "HAS_VARIANT"
		)
		multi_rel
	}
	def delete_relationships(rel_tables:List[String]) {
		for(table_name <- rel_tables) {
			spark.sql("REFRESH TABLE " + table_name)
			logger.info("[+] Deleting relationship types from table: " + table_name + ". [+]")
			println("[+] Deleting relationship types from table: " + table_name + ". [+]")
			/*
			*	Table from tellic abbvie DB fetch relationship type from above mapper method(getTellicAbbvieRelationshipType)
			*/
			if("tellic_abbvie" == table_name.split("\\.")(0)) {
				val multi_rel_map = getTellicAbbvieRelationshipType()
				if(multi_rel_map.contains(table_name)) {
					val e1_label = ""
					val rel_type = multi_rel_map(table_name)
					val e2_label = ""
					if(rel_type != null) {
						delete_relationships(e1_label,rel_type, e2_label)
					}
				} else {
					println("[-] Table not found: " + table_name + ". [-]")
				}
			} 
			/*
			*	Generated tables from abbvie relationship tables, fetch relationship type from tables itself
			*/
			else{
				val rels_df = spark.sql("SELECT DISTINCT ENTITY1_TYPE, RELATIONSHIP_TYPE, ENTITY2_TYPE FROM " + table_name).dropDuplicates()
				val e1_labels = rels_df.select("ENTITY1_TYPE").distinct().map(f=>f.getString(0)).collect().toList
				val e2_labels = rels_df.select("ENTITY2_TYPE").distinct().map(f=>f.getString(0)).collect().toList
				val rel_types = rels_df.select("RELATIONSHIP_TYPE").distinct().map(f=>f.getString(0)).collect().toList 
				for(e1_label <- e1_labels ) {
					for(e2_label <- e2_labels ) {
						for(rel_type <- rel_types ) {
							delete_relationships("n:`"+e1_label+"`", rel_type, "m:`"+e2_label+"`")
						}
					}
				}
			}
			logger.info("[+] Deleted relationship types from table: " + table_name + ". [+]")
		}
	}
	def delete_relationships(e1_label: String, rel_type: String, e2_label: String) {	
		val session = session_open()
		//Delete is performed between specific src LABEL and dest LABEL with particular RELATIONSHIP TYPE
		val relationship = "(" + e1_label + ")-[r:`" + rel_type + "`]->(" + e2_label + ")"					
		logger.info("[+] Deleting relationship type between nodes: " + relationship + ". [+]")
		var rel_delete_cql = "CALL apoc.periodic.iterate(\"MATCH " + relationship + " RETURN r\", \"DELETE r\", {batchSize:1000, parallel:false, retries:5})"
		println("Relationship delete CQL: " + rel_delete_cql)
		var delete_result = session.run(rel_delete_cql)					
		var batch = delete_result.next.get("batch").asObject().toString()
		var delete_ops_result = batch.substring(1, batch.length - 1).split(",").map(_.trim().split("=")).map { case Array(k, v) => (k, v)}.toMap
		/*
		 * Below find relationships deletion stats
		 */
		logger.info("Deleted relationships total count: " + delete_ops_result("total"))
		logger.info("Deleted relationships committed count: " + delete_ops_result("committed"))
		logger.info("Deleted relationships failed count: " + delete_ops_result("failed"))
		logger.info("Deleted relationships errors: " + delete_ops_result("errors"))
		/*
		 * Verify, is total relationships and deleted relationships are matching or not.
		 */
		if(delete_ops_result("total") != delete_ops_result("committed")) {
			//Count the number of remaining relationships.
			var count = "MATCH " + relationship + " RETURN count(r) as count"
			var count_result = session.run(count)
			var rem_count = count_result.next.get("count").asObject().toString()
			if(rem_count != 0) {
				//if remaining relationships not equal to zero, thread sleep for 3s and calls drop_relationships recursive method
				logger.info("Thread sleep for 3 seconds")
				Thread.sleep(3000)
				logger.info("Retry attempt")
				delete_relationships(e1_label,rel_type, e2_label)			}	
		} else {
			logger.info("[+] Deleted relationship type between nodes: " + relationship + ". [+]")	
		}	
	}
	def delete_nodes(node_tables:List[String]) {	
		for(table_name <- node_tables) {
			spark.sql("REFRESH TABLE " + table_name)
			val labels = spark.sql("SELECT DISTINCT label FROM " + table_name).map(r => r.getString(0)).collect.toList
			logger.info("[+] Deleting label nodes from table: " + table_name + ". [+]")
			for(label <- labels ) {
				delete_nodes(label)
			}
			logger.info("[+] Deleted label nodes from table: " + table_name + ". [+]")
		}	
	}
	def delete_nodes(label:String) {
		val session = session_open()	
		val label_node = "(n:`" + label + "`)"					
		logger.info("[+] Deleting label nodes : " + label_node + ". [+]")
		var node_delete_cql = "CALL apoc.periodic.iterate(\"MATCH " + label_node + " RETURN n\", \"DETACH DELETE n\", {batchSize:1000, parallel:false, retries:5})"
		println("Label nodes delete CQL: " + node_delete_cql)
		var delete_result = session.run(node_delete_cql)					
		var batch = delete_result.next.get("batch").asObject().toString()
		var delete_ops_result = batch.substring(1, batch.length - 1).split(",").map(_.trim().split("=")).map { case Array(k, v) => (k, v)}.toMap
		/*
		 * Below find nodes deletion stats
		 */
		logger.info("Deleted nodes total count: " + delete_ops_result("total"))
		logger.info("Deleted nodes committed count: " + delete_ops_result("committed"))
		logger.info("Deleted nodes failed count: " + delete_ops_result("failed"))
		logger.info("Deleted nodes errors: " + delete_ops_result("errors"))
		/*
		 * Verify, is total nodes and deleted nodes are matching or not.
		 */
		if(delete_ops_result("total") != delete_ops_result("committed")) {
			//Count the number of remaining nodes.
			var count = "MATCH" + label_node + " RETURN count(r) as count"
			var count_result = session.run(count)
			var rem_count = count_result.next.get("count").asObject().toString()
			if(rem_count != 0) {
				//if remaining nodes not equal to zero, thread sleep for 3s and calls delete_nodes recursive method
				logger.info("Thread sleep for 3 seconds")
				Thread.sleep(3000)
				logger.info("Retry attempt")
				delete_nodes(label)
			}	
		} else {
			logger.info("[+] Deleted label nodes : " + label_node + ". [+]")
		}
		session_close(session)	
	}
	def id_to_label(x: String): String = x match {
		case "CHEMBL" => "Drug"
		case "HGNC" => "Gene"
		case "CL" => "CellType"
		case "EFO" => "Phenotype"
		case "MESH" => "Disease"
		case "tellicVO" => "Variant"
		case "DP" => "Drug Parent"
		case "RXCUI" => "Drug Product"
		case "HE" => "Health Condition"
		case "MEDDRA" => "Adverse Event"
		case "T000" => "Chemical"
		case _ => throw new Exception("Currently unable avalible for other Labels")
	}
	def load_relationships(rel_tables:List[String]) {
		for(table_name <- rel_tables) {
			if(getTellicAbbvieRelationshipType().contains(table_name)) {
				load_tellic_relationships(table_name)
			} else {
				load_abbvie_relationships(table_name)
			}
		}
	}
	def load_abbvie_relationships(table_name:String) {
		spark.sql("REFRESH TABLE " + table_name)
		val rels_df = spark.sql("SELECT DISTINCT ENTITY1_TYPE, RELATIONSHIP_TYPE, ENTITY2_TYPE FROM " + table_name).dropDuplicates()
		val e1_labels = rels_df.select("ENTITY1_TYPE").distinct().map(f=>f.getString(0)).collect().toList
		val e2_labels = rels_df.select("ENTITY2_TYPE").distinct().map(f=>f.getString(0)).collect().toList
		val rel_types = rels_df.select("RELATIONSHIP_TYPE").distinct().map(f=>f.getString(0)).collect().toList 

		for(e1_label <- e1_labels ) {
			for(e2_label <- e2_labels ) {
				for(rel_type <- rel_types ) {
					logger.info("Loading " + rel_type + " relationships between " + s"$e1_label" + " and " + s"$e2_label" + ".")
					var abbvie_df = spark.sql("SELECT * FROM " + table_name + " WHERE entity1_type = '" + e1_label + "' AND entity2_type =  '" + e2_label + "'")
					write_relationships(abbvie_df, rel_type, e1_label.toString, e2_label.toString)
				}
			}
		}
	}
	def load_tellic_relationships(table_name: String) {
		val ID = List("CHEMBL", "HGNC", "CL", "EFO", "MESH", "tellicVO", "DP", "RXCUI", "HE", "MEDDRA", "T000")
		val c1_id = List[String]()
		val c2_id = List[String]()
		for( id_prefix <- ID ){	
			var df1 = spark.sql(s"SELECT * FROM $table_name WHERE concept_1_id LIKE '$id_prefix%'")
			if(df1.count() > 0) {
				c1_id += id_prefix
			}
			var df2 = spark.sql(s"SELECT * FROM $table_name WHERE concept_2_id LIKE '$id_prefix%'")
			if(df2.count() > 0) {
				c2_id += id_prefix
			}
		}
		val multi_rel_map = getTellicAbbvieRelationshipType()
		val rel_type = multi_rel_map(table_name)
		for( e1 <- c1_id ){
			for( e2 <- c2_id ){
				var query = s"SELECT * FROM $table_name WHERE concept_1_id LIKE '$e1%' AND concept_2_id LIKE '$e2%'"
				var multi_label_df = spark.sql(query)
				var cnt = multi_label_df.count()	
				if (cnt > 0) {
					var e1_label = id_to_label(e1) 
					var e2_label = id_to_label(e2)
					write_relationships(multi_label_df, rel_type, e1_label, e2_label)
				}
			}
		}	
	}
	def write_relationships(table_df:DataFrame, rel_type:String, e1_label:String, e2_label:String) {
        var df = table_df.withColumnRenamed("reluid", "relUid")
        if(df.columns.contains("avg_confidence")) {
	        df = df.withColumn("avg_confidence",col("avg_confidence").cast(DoubleType))  
		}
		var properties = df.columns.filter(! _.contains("concept_1_id")).filter(! _.contains("concept_2_id")).filter(! _.contains("relationship_type")).mkString(", ")
		df = df.filter(col("concept_1_id").isNotNull && col("concept_2_id").isNotNull)
		println("Writing " + df.count() +s" $rel_type relationships between  $e1_label -> $e2_label")
        df.printSchema()		
		val rel_df = df.repartition(1)
				.write.format("org.neo4j.spark.DataSource")
				.option("url", neo4j_url)
				.option("authentication.basic.username", user)
				.option("authentication.basic.password", pass)
				.option("database", neo4j_db)
				.option("relationship" , rel_type)
				.option("relationship.source.labels" , e1_label)
				.option("relationship.source.node.keys" , "concept_1_id:concept_id")
				.option("relationship.source.save.mode" , "Overwrite")
				.option("relationship.target.labels" ,e2_label )
				.option("relationship.target.node.keys" , "concept_2_id:concept_id")
				.option("relationship.target.save.mode" , "Overwrite")
				.option("relationship.save.strategy" , "keys")
				.option("relationship.properties" , properties)
				.option("batch.size" , "5000")
				.option("transaction.retries" , "5")
				.mode(SaveMode.Overwrite)
				.save()
	}	
	def write_nodes(node_tables: List[String]) {
		if(node_tables.length > 0) {
			for(table_name <- node_tables) {
				var labels = spark.sql("SELECT DISTINCT label FROM " + table_name).map(r => r.getString(0)).collect.toList
				var properties = spark.table(table_name).columns.filter(! _.contains("concept_id")).mkString(", ")
				println(properties)
				for(label <- labels) {
					println("Writing " + spark.table(table_name).count() +" "+ label + " nodes.")
					val query = s"SELECT DISTINCT * FROM $table_name  WHERE concept_id IS NOT NULL AND label='$label'"
					val node_df = spark.sql(query)
                        .repartition(1)
                        .write.format("org.neo4j.spark.DataSource")
                        .option("url", neo4j_url)
                        .option("authentication.basic.username", user)
                        .option("authentication.basic.password", pass)
						.option("database", neo4j_db)
                        .option("labels" , label)
                        .option("node.keys" , "concept_id")
                        .option("batch.size" , "20000")
                        .mode(SaveMode.Overwrite)
                        .save()
				}
			}
		}			
	}
}
class vault_password {
	def getCredentials(token:String,cred_id:Int,cred_type:Int,endpoint:String): ldap = {
		val CredentialResult = Credential.getCredentialData( CredentialPayload(s"$token", cred_id,cred_type, s"$endpoint") )
		val ldap = CredentialResult.data match {
			case ldap: ldap => ldap
			case _ => throw new Exception("Currently unable avalible for other credentials Types")
		}
		ldap
	}
}
	val node_tables_list = List(
		"trek.tellic_node_ae",
		"trek.tellic_node_cellline",
		"trek.tellic_node_chem_subset",
		"trek.tellic_node_clinicalcondition",
		"trek.tellic_node_dci",
		"trek.tellic_node_ddi",
		"trek.tellic_node_disease",
		"trek.tellic_node_drug",
		"trek.tellic_node_gene",
		"trek.tellic_node_measurement",
		"trek.tellic_node_pkpairing",
		"trek.tellic_node_tissue",
		"trek.tellic_node_variant",
		"tellic_abbvie.tellic_graph_data_node_celltype",
		"tellic_abbvie.tellic_graph_data_node_drug_parent",
		"tellic_abbvie.tellic_graph_data_node_drug_product",
		"tellic_abbvie.tellic_graph_data_node_pheno",
		"trek.tellic_node_health_event"
	)
	val rel_tables = List(
		"trek.neo4j_has_modulated_ae_relationships",
		"trek.neo4j_affects_activation_relationships",
		"trek.neo4j_affects_expression_relationships",
		"trek.neo4j_affects_inhibition_relationships",
		"trek.neo4j_affects_localization_relationships",
		"trek.neo4j_affects_modification_relationships",
		"trek.neo4j_affects_molecular_cleavage_relationships",
		"trek.neo4j_affects_phosphorylation_relationships",
		"trek.neo4j_affects_regulation_of_binding_relationships",
		"trek.neo4j_affects_transcription_relationships",
		"trek.neo4j_affects_translocation_relationships",
		"trek.neo4j_affects_ubiquitination_relationships",
		"trek.neo4j_decreases_activation_relationships",
		"trek.neo4j_decreases_expression_relationships",
		"trek.neo4j_decreases_inhibition_relationships",
		"trek.neo4j_decreases_phosphorylation_relationships",
		"trek.neo4j_decreases_transcription_relationships",
		"trek.neo4j_decreases_ubiquitination_relationships",
		"trek.neo4j_increases_activation_relationships",
		"trek.neo4j_increases_expression_relationships",
		"trek.neo4j_increases_inhibition_relationships",
		"trek.neo4j_increases_phosphorylation_relationships",
		"trek.neo4j_increases_transcription_relationships",
		"trek.neo4j_increases_ubiquitination_relationships",
		"trek.neo4j_microrna_targeting_relationships",
		"trek.neo4j_processing_yields_relationships",
		"trek.neo4j_protein_dna_interactions_relationships",
		"trek.neo4j_protein_protein_interactions_relationships",
		"trek.neo4j_protein_rna_interactions_relationships",
		"trek.neo4j_rna_rna_interactions_relationships",
		"trek.neo4j_translocation_relationships",
		"trek.neo4j_as_dosed_relationships",
		"trek.neo4j_as_measured_relationships",
		"trek.neo4j_associated_with_relationships",
		"trek.neo4j_contains_relationships",
		"trek.neo4j_decreases_relationships",
		"trek.neo4j_decreases_the_effect_of_relationships",
		"trek.neo4j_does_not_significantly_affect_relationships",
		"trek.neo4j_has_activity_against_relationships",
		"trek.neo4j_has_agonism_against_relationships",
		"trek.neo4j_has_an_interaction_with_relationships",
		"trek.neo4j_has_antagonism_against_relationships",
		"trek.neo4j_has_binding_kinetics_relationships",
		"trek.neo4j_has_induction_or_activation_against_relationships",
		"trek.neo4j_has_metabolite_relationships",
		"trek.neo4j_has_moa_relationships",
		"trek.neo4j_has_modulated_side_effect_relationships",
		"trek.neo4j_has_modulation_against_relationships",
		"trek.neo4j_has_no_effect_relationships",
		"trek.neo4j_has_property_relationships",
		"trek.neo4j_has_recognized_antigen_relationships",
		"trek.neo4j_has_side_effect_relationships",
		"trek.neo4j_impact_on_relationships",
		"trek.neo4j_increases_relationships",
		"trek.neo4j_increases_the_effect_of_relationships",
		"trek.neo4j_is_chemically_similar_to_relationships",
		"trek.neo4j_is_equivalent_to_relationships",
		"trek.neo4j_is_expressed_in_relationships",
		"trek.neo4j_is_member_of_relationships",
		"trek.neo4j_shares_pathway_relationships",
		"tellic_abbvie.tellic_graph_data_processed_relationships_has_ingredient",
		"tellic_abbvie.tellic_graph_data_processed_relationships_has_isomer",
		"tellic_abbvie.tellic_graph_data_processed_relationships_has_parent",
		"tellic_abbvie.tellic_graph_data_processed_relationships_has_precise_ingredient",
		"tellic_abbvie.tellic_graph_data_processed_relationships_is_equal_to",
		"tellic_abbvie.tellic_graph_data_processed_relationships_shares_family",				
		"tellic_abbvie.tellic_graph_data_processed_relationships_associated_with",
		"tellic_abbvie.tellic_graph_data_processed_relationships_has_interaction",
		"tellic_abbvie.tellic_graph_data_processed_relationships_has_variant",	
		"tellic_abbvie.tellic_graph_data_processed_relationships_with_strength",
		"tellic_abbvie.tellic_graph_data_processed_relationships_without_strength",
		"tellic_abbvie.tellic_graph_data_processed_relationships_targets",
		"tellic_abbvie.tellic_graph_data_processed_relationships_is_member",
		"tellic_abbvie.tellic_graph_data_processed_relationships_adverse_event"
	)
	val args = sc.getConf.get("spark.driver.args").split("\\s+")
	val token = sc.getConf.get("spark.nabu.token")
	val endpoint = sc.getConf.get("spark.nabu.fireshots_url")
	val cred_id = args(0).toInt
	val cred_type = args(1).toInt
	val neo4j_url = args(2)
	val neo4j_db = args(3)
	
	logger.info("Tellic Neo4J DATABASE: " + neo4j_db)
	
	val vault = new vault_password()
	val ldap = vault.getCredentials(token, cred_id, cred_type, endpoint)
	val user = ldap.username
	val pass = ldap.password
	val tellic = new Tellic(neo4j_url, user, pass, neo4j_db)

	tellic.create_constriants(node_tables_list)
	tellic.delete_relationships(rel_tables) 
	tellic.delete_nodes(node_tables_list) 
	tellic.write_nodes(node_tables_list)
	tellic.load_relationships(rel_tables)
