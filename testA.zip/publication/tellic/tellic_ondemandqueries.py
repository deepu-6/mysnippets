from neo4j import GraphDatabase
from neo4j.exceptions import ServiceUnavailable
from pyspark.sql import HiveContext,SparkSession
from pyspark.context import SparkContext
from logging import getLogger, StreamHandler, DEBUG
import logging
import requests
import sys
import time
import argparse

logging.basicConfig(level = logging.INFO)

handler = StreamHandler()
handler.setLevel(DEBUG)
logging.getLogger("neo4j").addHandler(handler)

spark = (SparkSession
 .builder
 .appName('Tellic NEO4J 4.3v PIPELINE')
 .enableHiveSupport()
 .getOrCreate())

class vault_password:
    def get_password(self,token,cred_id,cred_type,fireshots_url):
        payload= {"credential_id": cred_id, "credential_type_id": cred_type}
        url= '{0}'.format(fireshots_url)
        r= requests.post(url, headers={"Content-Type":"application/json","Authorization" : token,"Accept": "application/json"},json= payload)
        if r.status_code == 200:
            logging.info("[+] Password obtained [+]")
            return r.json()
        else:
            logging.info(r.json())

class Tellic_Utility:
    
    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password))
        self.__spark = spark

    def utility(self,database_name):
        start_time = time.time()
        with self.driver.session(database = database_name) as session:
            '''config = "{batchSize:500, parallel:false, retries:5}"
            relationship = "CALL apoc.periodic.iterate(\"MATCH ()-[r]->() WHERE r.rel_type <> 'RELATED_TO' RETURN r\", \"SET r.unique_other = r.num_of_merged\", {0})".format(config)
            print(relationship)
            total=session.write_transaction(self.match_node_tx, relationship)'''
            relationship = "MATCH (n:`Health Condition`) SET n.synonyms = n.synonym REMOVE n.synonym;"
            print(relationship)
            total=session.run(relationship)
            print("[+] Completed running {} [+].".format(relationship))
            relationship = "DROP INDEX gl_fulltext_node_index;"
            print(relationship)
            total=session.run(relationship)
            print("[+] Completed running {} [+].".format(relationship))
            relationship = "CREATE FULLTEXT INDEX gl_fulltext_node_index for (n:Chemical|Drug|Gene|`Health Condition`|Measurement|Variant) on each [n.concept_id, n.entity_name, n.synonyms];"
            print(relationship)
            total=session.run(relationship)
            print("[+] Completed running {} [+].".format(relationship))

        self.driver.close()                       
        print("Time taken to run query: " + str(time.time()-start_time))
        
    def match_node_tx(self, tx, relationship) :
        
        result = tx.run("{0}".format(relationship))
        record = result.single()
        return record["total"]
   
    
if __name__ == "__main__":
    
    args = spark.conf.get("spark.driver.args").split(" ")
    neo4j_token = spark.conf.get("spark.nabu.token")
    fireshots_uri = spark.conf.get("spark.nabu.fireshots_url")
    
    cred_id = args[0]
    cred_type = args[1]
    neo4j_uri = args[2]
    database_name = args[3]
   		
    vault_obj = vault_password()
    dict_pass = vault_obj.get_password(neo4j_token, cred_id, cred_type, fireshots_uri)
    neo4j_password= dict_pass["data"]["password"]
    neo4j_user = dict_pass["data"]["username"]    
    uri = '{0}'.format(neo4j_uri)
    user = neo4j_user
    database = '{0}'.format(database_name)
    print("URL: "+uri)
    print("Database Name: "+database) 
 
    utility_obj = Tellic_Utility(uri, user, neo4j_password)
    utility_obj.utility(database)
