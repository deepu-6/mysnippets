var df = spark.sql("""SELECT ENTITY1, ENTITY1_TYPE, ENTITY2, ENTITY2_TYPE, REL_TYPE, STRENGTH, RESULT, RESULT_TYPE, CONFIDENCE, LINEAGE, named_struct(
		"MODALITY", METADATA.MODALITY , 
		"PARENT_ID", METADATA.PARENT_ID , 
		"MOLECULE_ID", METADATA.MOLECULE_ID , 
		"TARGET", METADATA.TARGET ,
		"ACTION_TYPE", METADATA.ACTION_TYPE ,
		"MOA", METADATA.MOA ,
		"SOURCE", METADATA.SOURCE ,
		"REFERENCES", to_json(METADATA.REFERENCES )
     ) as METADATA FROM ark_2_8.t_drug_gene_relationships""")
val db_name="dev_ark"
val table="t_drug_gene_relationships_test"
df.printSchema
df.write.mode("OVERWRITE").option("format", "parquet").option("path", "s3a://arch-prod-datalake/data/warehouse/integrated/"+db_name+".db/"+table).saveAsTable(db_name+"."+table)
