var df = spark.table("ark_2_8.t_drug_entities")
val db_name="dev_ark"
val table="t_drug_entities_test"
df=df.withColumn("CHEMBL_ID", flatten(col("CHEMBL_ID"))).withColumn("SYNONYMS", flatten(col("SYNONYMS")))
df.printSchema
df.write.mode("OVERWRITE").option("format", "parquet").option("path", "s3a://arch-prod-datalake/data/warehouse/integrated/"+db_name+".db/"+table).saveAsTable(db_name+"."+table)
