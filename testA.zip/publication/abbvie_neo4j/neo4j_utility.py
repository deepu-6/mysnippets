from neo4j import GraphDatabase
from neo4j.exceptions import ServiceUnavailable, ClientError, TransientError
from pyspark.sql import SparkSession
from logging import getLogger, StreamHandler, DEBUG
import logging
import requests
import time
import datetime
import json

logging.basicConfig(level = logging.INFO)

handler = StreamHandler()
handler.setLevel(DEBUG)
logging.getLogger("neo4j").addHandler(handler)

spark = (SparkSession
 .builder
 .appName('ABBVIE NEO4J Pause/Unpause PIPELINE')
 .enableHiveSupport()
 .getOrCreate())

class utility:
    def __init__(self, url, user, password):
        self.url=url
        self.user=user
        self.password=password
        self._driver = GraphDatabase.driver(self.url, auth=(self.user, self.password), max_connection_lifetime=3600, max_transaction_retry_time = 15) 

    def get_graph_counts(self, database):
        stats={}
        print("Empty stats:",str(stats))
        with self._driver.session(database=database) as session:
            stats_cql="CALL apoc.meta.stats() YIELD stats RETURN stats"
            print(stats_cql)
            result = session.read_transaction(self._graph_count, stats_cql)
            stats = result['stats']
            print("stats:",stats)
            
        print("stats nodeCount:",str(stats["nodeCount"]))
        print("stats relCount:",str(stats["relCount"]))
        print("stats labels:",str(stats["labels"]))

    def _graph_count(self, tx, query):
        res = tx.run(query)
        return res.peek()

    def show_databases(self):
        db_list = []
        print("Empty dbs:",str(db_list))
        with self._driver.session(database="SYSTEM") as session:
            db_cql="SHOW DATABASES YIELD name, address, role, requestedStatus, currentStatus, error, default, home RETURN name, address, role, requestedStatus, currentStatus, error, default, home"
            print(db_cql)
            result = session.read_transaction(self._show_databases, db_cql) 
            print("Dbs result:",result)   
            df = spark.createDataFrame(result)   
            df.printSchema
            df.show() 
            '''for r in result:   
                d = r.data()
                db_list.append({
                'name':d['name'],
                'address':d['address'],
                'role':d['role'],
                'requestedStatus':d['requestedStatus'],
                'currentStatus':d['currentStatus'],
                'error':d['error'],
                'default':d['default'],
                'home':d['home']
                })
                print("For loop: ",db_list)'''
        print(db_list)
        if len(db_list) >0:
            db_df = spark.createDataFrame(db_list)
            db_df.printSchema
            db_df.show()

    def _show_databases(self, tx, query):
        res = tx.run(query)
        return res.data()
                
    def close_driver(self):
        self._driver.close()

class vault_password:
    def get_password(self,token,cred_id,cred_type,fireshots_url):
        payload= {"credential_id": cred_id, "credential_type_id": cred_type}
        url= '{0}'.format(fireshots_url)
        r= requests.post(url, headers={"Content-Type":"application/json","Authorization" : token,"Accept": "application/json"},json= payload)
        if r.status_code == 200:
            logging.info("[+] Password obtained [+]")
            return r.json()
        else:
            logging.info(r.json())

if __name__ == "__main__":
        
    token = spark.conf.get("spark.nabu.token")
    fireshots_uri = spark.conf.get("spark.nabu.fireshots_url")
    args = spark.conf.get("spark.driver.args").split(" ")
    cred_id = args[0]
    cred_type = args[1]
    neo4j_url= args[2]
    database_name= args[3]
    
    print("Details:",neo4j_url," : ",database_name)

    vault_obj = vault_password()
    dict_pass = vault_obj.get_password(token, cred_id, cred_type, fireshots_uri)
    neo4j_password = dict_pass["data"]["password"]
    neo4j_user = dict_pass["data"]["username"]  

    utility_obj=utility(neo4j_url, neo4j_user, neo4j_password)
    utility_obj.get_graph_counts(database_name)
    utility_obj.show_databases()
    utility_obj.close_driver()
