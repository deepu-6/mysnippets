from neo4j import GraphDatabase
import argparse
import requests
import logging

logging.basicConfig(level=logging.INFO)


class unknown_molecule_type_hotfix:

    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password))

    def execute_hotfix(self, database_name):
        with self.driver.session(database=database_name) as session:
            session.run(
                """CALL apoc.periodic.iterate("MATCH (c:Compound) WHERE c.MOLECULE_TYPE='Unknown' AND ((c.PRIMARYSOURCE='ChEMBL' and c.INCHI_KEY is not null) or (c.PRIMARYSOURCE='AbbVie' and c.ABBVIE_ID STARTS WITH 'A-')) RETURN c","SET c.MOLECULE_TYPE='Small molecule',c.`LINEAGE.VERSION`=c.`LINEAGE.VERSION`+'.hf5'",{batchSize:10000, parallel:true})"""
            )
            session.run(
                """CALL apoc.periodic.iterate("MATCH (c:Compound) WHERE c.MOLECULE_TYPE='Unclassified' RETURN c","SET c.MOLECULE_TYPE='Small molecule',c.`LINEAGE.VERSION`=c.`LINEAGE.VERSION`+'.hf5'",{batchSize:10000, parallel:true})"""
            )
            session.run(
                """CALL apoc.periodic.iterate("MATCH (c:Compound) WHERE c.MOLECULE_TYPE='Unknown' and c.PRIMARYSOURCE='GOSTAR' and c.INCHI_KEY is not null RETURN c","SET c.MOLECULE_TYPE='Small molecule',c.`LINEAGE.VERSION`=c.`LINEAGE.VERSION`+'.hf5'",{batchSize: 10000, parallel: true})"""
            )
            session.run(
                """CALL apoc.periodic.iterate("MATCH (c:Compound) WHERE c.MOLECULE_TYPE='Unknown' and c.PRIMARYSOURCE='Solvay' and c.INCHI_KEY is not null RETURN c","SET c.MOLECULE_TYPE='Small molecule',c.`LINEAGE.VERSION`=c.`LINEAGE.VERSION`+'.hf5'",{batchSize: 10000, parallel: true})"""
            )
            session.run(
                """CALL apoc.periodic.iterate("MATCH (c:Compound) WHERE c.MOLECULE_TYPE='Unknown' and c.PRIMARYSOURCE='Integrity' and c.INCHI_KEY is not null RETURN c","SET c.MOLECULE_TYPE='Small molecule',c.`LINEAGE.VERSION`=c.`LINEAGE.VERSION`+'.hf5'",{batchSize: 10000, parallel: true})"""
            )
            session.run(
                """CALL apoc.periodic.iterate("MATCH (c:Compound) WHERE c.MOLECULE_TYPE='Unknown' and c.PRIMARYSOURCE='Wombat' and c.INCHI_KEY is not null RETURN c","SET c.MOLECULE_TYPE='Small molecule',c.`LINEAGE.VERSION`=c.`LINEAGE.VERSION`+'.hf5'",{batchSize: 10000, parallel: true})"""
            )
            session.run(
                """CALL apoc.periodic.iterate("MATCH (c:Compound) WHERE c.MOLECULE_TYPE='Unknown' and c.PRIMARYSOURCE='DrugMatrix' and c.INCHI_KEY is not null RETURN c","SET c.MOLECULE_TYPE='Small molecule',c.`LINEAGE.VERSION`=c.`LINEAGE.VERSION`+'.hf5'",{batchSize: 10000, parallel: true})"""
            )
            session.run(
                """CALL apoc.periodic.iterate("MATCH (c:Compound) WHERE c.MOLECULE_TYPE='Unknown' and c.PRIMARYSOURCE IS NULL and 'FD-FPS' IN c.FD_ID_SOURCES and c.INCHI_KEY is not null RETURN c","SET c.MOLECULE_TYPE='Small molecule',c.`LINEAGE.VERSION`=c.`LINEAGE.VERSION`+'.hf5'",{batchSize:10000, parallel:true})"""
            )
            session.run(
                """CALL apoc.periodic.iterate("MATCH (c:Compound) WHERE c.MOLECULE_TYPE='Unknown' and c.PRIMARYSOURCE='AbbVie' and c.INCHI_KEY is not null and c.PRIMARYIDENTIFIER STARTS WITH 'A-' RETURN c","SET c.MOLECULE_TYPE='Small molecule',c.`LINEAGE.VERSION`=c.`LINEAGE.VERSION`+'.hf5'",{batchSize:10000, parallel:true})"""
            )
            session.run(
                """CALL apoc.periodic.iterate("MATCH (c:Compound) WHERE c.MOLECULE_TYPE='Unknown' and c.DRUG_NAME ends with 'MAB' RETURN c","SET c.MOLECULE_TYPE='Biologic',c.`LINEAGE.VERSION`=c.`LINEAGE.VERSION`+'.hf5'",{batchSize: 10000, parallel: true})"""
            )

            session.run(
                """CALL apoc.periodic.iterate("MATCH (c:Compound) WHERE c.MOLECULE_TYPE='Unknown' and right(c.DRUG_NAME,3) IN ['ATE','ASE','IUM','NIB','IDE','INE','TIN','N A','MER','N B'] RETURN c","SET c.MOLECULE_TYPE='Small molecule',c.`LINEAGE.VERSION`=c.`LINEAGE.VERSION`+'.hf5'",{batchSize: 10000, parallel: true})"""
            )

            session.run(
                """CALL apoc.periodic.iterate("MATCH (c:Compound) WHERE c.MOLECULE_TYPE='Unknown' and right(c.DRUG_NAME,3) IN ['LFA','MIN','LIN','KIN','CIN','EPT'] RETURN c","SET c.MOLECULE_TYPE='Protein',c.`LINEAGE.VERSION`=c.`LINEAGE.VERSION`+'.hf5'",{batchSize: 10000, parallel: true})"""
            )

            session.run(
                """CALL apoc.periodic.iterate("MATCH (c:Compound) WHERE c.MOLECULE_TYPE='Unknown' and right(c.DRUG_NAME,3) IN ['SEN'] RETURN c","SET c.MOLECULE_TYPE='Oligonucleotide',c.`LINEAGE.VERSION`=c.`LINEAGE.VERSION`+'.hf5'",{batchSize: 10000, parallel: true})"""
            )

        logging.info("[+] Executed unknown_molecule_type_hotfix [+]")

class vault_password:

    def get_password(self, token, cred_id, cred_type, fireshots_url):
        payload = {"credential_id": cred_id, "credential_type_id": cred_type}
        url = '{0}'.format(fireshots_url)
        r = requests.post(url, headers={"Content-Type": "application/json", "Authorization": token,
                                        "Accept": "application/json"}, json=payload)
        if r.status_code == 200:
            logging.info("[+] Password obtained [+]")
            return r.json()
        else:
            logging.info(r.json())


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("token")
    parser.add_argument("cred_id")
    parser.add_argument("cred_type")
    parser.add_argument("neo4j_uri")
    parser.add_argument("database")
    parser.add_argument("fireshots_url")
    args = parser.parse_args()
    neo4j_token = args.token
    cred_id = args.cred_id
    cred_type = args.cred_type
    neo4j_uri = args.neo4j_uri
    database_name = args.database
    fireshots_uri = args.fireshots_url

    vault_obj = vault_password()
    dict_pass = vault_obj.get_password(neo4j_token, cred_id, cred_type, fireshots_uri)

    print(cred_id)
    print(cred_type)

    neo4j_password = dict_pass["data"]["password"]
    neo4j_user = dict_pass["data"]["username"]

    uri = '{0}'.format(neo4j_uri)
    user = neo4j_user
    database = '{0}'.format(database_name)
    hotfix_obj = unknown_molecule_type_hotfix(uri, user, neo4j_password)
    hotfix_obj.execute_hotfix(database)



