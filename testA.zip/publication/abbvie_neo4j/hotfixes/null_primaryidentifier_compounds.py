from neo4j import GraphDatabase
import argparse
import requests
import logging

logging.basicConfig(level=logging.INFO)


class null_primaryidentifier_compounds_hotfix:

    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password))

    def execute_hotfix(self, database_name):
        with self.driver.session(database=database_name) as session:
            session.run(
                """CALL apoc.periodic.iterate("MATCH (c:Compound) WHERE c.PRIMARYIDENTIFIER IS NULL and 'FD-FPS' IN c.FD_ID_SOURCES and c.INCHI_KEY is not null RETURN c","SET c.PRIMARYIDENTIFIER=c.INCHI_KEY,c.PRIMARYSOURCE='FD-FPS',c.`LINEAGE.VERSION`=c.`LINEAGE.VERSION`+'.hf6'",{batchSize:10000, parallel:true})"""
            )
            session.run(
                """CALL apoc.periodic.iterate("MATCH (c:Compound) WHERE c.PRIMARYIDENTIFIER IS NULL and c.FD_ID_SOURCES IS NULL and c.INCHI_KEY is null AND c.IDENTIFIERS IS NULL RETURN c","SET c:Compound,c.INCHI_KEY=c.ID,c.PRIMARYIDENTIFIER=c.ID,c.PRIMARYSOURCE='FD-FPS',c.`LINEAGE.VERSION`='unknown.hf6',c.PREFERRED_NAME=c.ID,c.MOLECULE_TYPE='Small molecule'",{batchSize:10000, parallel:true})"""
            )

        logging.info("[+] Executed null_primaryidentifier_compounds_hotfix [+]")

class vault_password:

    def get_password(self, token, cred_id, cred_type, fireshots_url):
        payload = {"credential_id": cred_id, "credential_type_id": cred_type}
        url = '{0}'.format(fireshots_url)
        r = requests.post(url, headers={"Content-Type": "application/json", "Authorization": token,
                                        "Accept": "application/json"}, json=payload)
        if r.status_code == 200:
            logging.info("[+] Password obtained [+]")
            return r.json()
        else:
            logging.info(r.json())


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("token")
    parser.add_argument("cred_id")
    parser.add_argument("cred_type")
    parser.add_argument("neo4j_uri")
    parser.add_argument("database")
    parser.add_argument("fireshots_url")
    args = parser.parse_args()
    neo4j_token = args.token
    cred_id = args.cred_id
    cred_type = args.cred_type
    neo4j_uri = args.neo4j_uri
    database_name = args.database
    fireshots_uri = args.fireshots_url

    vault_obj = vault_password()
    dict_pass = vault_obj.get_password(neo4j_token, cred_id, cred_type, fireshots_uri)

    print(cred_id)
    print(cred_type)

    neo4j_password = dict_pass["data"]["password"]
    neo4j_user = dict_pass["data"]["username"]

    uri = '{0}'.format(neo4j_uri)
    user = neo4j_user
    database = '{0}'.format(database_name)
    hotfix_obj = null_primaryidentifier_compounds_hotfix(uri, user, neo4j_password)
    hotfix_obj.execute_hotfix(database)



