from neo4j import GraphDatabase
import argparse
import requests
import logging
 
logging.basicConfig(level = logging.INFO)
 
class merge_duplicate_nodes_hotfix:
    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password))
        self.label = 'Compound' 

    def execute_hotfix(self, database_name):
        with self.driver.session(database = database_name) as session:
            upa_tartrate_count_query = """match (c:Compound) where c.ABBVIE_ID = 'A-1293543.74' or c.CHEMBL_ID = 'CHEMBL3707269' or c.INCHI_KEY = 'LATZVDXOTDYECD-UFTFXDLESA-N' return count(c) as count"""
            upa_tartrate_count_result = session.run(upa_tartrate_count_query)
            upa_tartrate_count = upa_tartrate_count_result.peek()['count']
            if upa_tartrate_count==2:
                upa_tartrate_query="""match (c:Compound) where c.ABBVIE_ID = 'A-1293543.74' or c.CHEMBL_ID = 'CHEMBL3707269' or c.INCHI_KEY = 'LATZVDXOTDYECD-UFTFXDLESA-N' return id(c) as node,c.CHEMBL_ID as chembl_id, exists(c.CHEMBL_ID) as chembl_id_check"""
                upa_tartrate_result = session.run(upa_tartrate_query)
                node1=0
                node2=0
                for result in upa_tartrate_result:
                    if result['chembl_id_check']:
                        node2=result['node']
                    else:
                        node1=result['node']
                logging.info('node1: {0} node2: {1}'.format(node1,node2))
                
                self.merge_nodes(session,database_name,self.label, node1, node2)
                self.set_properties_upa_tartrate(session)
            else:
                logging.info("Cannot apply merge nodes hotfix for upa tartrate drug. Number of nodes: {0}".format(upa_tartrate_count))
            
            upadacitinib_count_query = """match (c:Compound) where c.ABBVIE_ID = 'A-1293543.0' or c.CHEMBL_ID = 'CHEMBL3622821' or c.INCHI_KEY = 'WYQFJHHDOKWSHR-MNOVXSKESA-N' return count(c) as count"""
            upadacitinib_count_result = session.run(upadacitinib_count_query)
            upadacitinib_count = upadacitinib_count_result.peek()['count']
            if upadacitinib_count==2:
                upadacitinib_query="""match (c:Compound) where c.ABBVIE_ID = 'A-1293543.0' or c.CHEMBL_ID = 'CHEMBL3622821' or c.INCHI_KEY = 'WYQFJHHDOKWSHR-MNOVXSKESA-N' return id(c) as node,c.CHEMBL_ID as chembl_id, exists(c.CHEMBL_ID) as chembl_id_check"""
                upadacitinib_result = session.run(upadacitinib_query)
                node1=0
                node2=0
                for result in upadacitinib_result:
                    if result['chembl_id_check']:
                        node2=result['node']
                    else:
                        node1=result['node']
                logging.info('node1: {0} node2: {1}'.format(node1,node2))
                
                self.merge_nodes(session,database_name,self.label, node1, node2)
                self.set_properties_upadacitinib(session)
            else:
                logging.info("Cannot apply merge nodes hotfix for upadacitinib drug. Number of nodes: {0}".format(upa_tartrate_count))
                

        
    def merge_nodes(self, session,database_name, label, node1, node2):
        properties = '{properties:"overwrite",mergeRels:false}'
        merge_nodes_cql = """match (c1:{label}) where id(c1)={node1} match (c2:{label}) where id(c2)={node2} call apoc.refactor.mergeNodes([c1,c2],{properties}) yield node return node,c1,c2""".format(label=label,node1=node1,node2=node2,properties=properties)
        print(merge_nodes_cql)
        session.run(merge_nodes_cql)
        logging.info("Executed merge nodes hotfix")

    def set_properties_upa_tartrate(self,session):
        set_properties_cql = """match (c2:Compound) where c2.CHEMBL_ID='CHEMBL3707269' set c2.ABBVIE_ID='A-1293543.74', c2.PREFERRED_NAME='A-1293543.74', c2.PRIMARYIDENTIFIER='A-1293543.74', c2.PRIMARYSOURCE='AbbVie', c2.DRUG_NAME='UPADACITINIB TARTRATE', c2.INCHI_KEY='LATZVDXOTDYECD-UFTFXDLESA-N', c2.ROOT_INCHI_KEY='WYQFJHHDOKWSHR-MNOVXSKESA-N' return c2"""
        print(set_properties_cql)
        session.run(set_properties_cql)
        logging.info("Executed upa tartrate set properties hotfix")

    def set_properties_upadacitinib(self,session):
        set_properties_cql = """match (c1:Compound) where c1.CHEMBL_ID='CHEMBL3622821' set  c1.ABBVIE_ID='A-1293543.0', c1.PREFERRED_NAME='A-1293543.0', c1.PRIMARYIDENTIFIER='A-1293543.0', c1.PRIMARYSOURCE='AbbVie', c1.DRUG_NAME='UPADACITINIB', c1.INCHI_KEY='WYQFJHHDOKWSHR-MNOVXSKESA-N', c1.ROOT_INCHI_KEY='WYQFJHHDOKWSHR-MNOVXSKESA-N' return c1"""
        print(set_properties_cql)
        session.run(set_properties_cql)
        logging.info("Executed upadacitinib set properties hotfix")


    def close(self):
        self.driver.close()
 
class vault_password:
    def get_password(self,token,cred_id,cred_type,fireshots_url):
        payload= {"credential_id": cred_id, "credential_type_id": cred_type}
        url= '{0}'.format(fireshots_url)
        r= requests.post(url, headers={"Content-Type":"application/json","Authorization" : token,"Accept": "application/json"},json= payload)
        if r.status_code == 200:
            logging.info("[+] Password obtained [+]")
            return r.json()
        else:
            logging.info(r.json())
            
    
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("token")
    parser.add_argument("cred_id")
    parser.add_argument("cred_type")
    parser.add_argument("neo4j_uri")
    parser.add_argument("database")
    parser.add_argument("fireshots_url")
    args = parser.parse_args()
    neo4j_token = args.token
    cred_id = args.cred_id
    cred_type = args.cred_type
    neo4j_uri = args.neo4j_uri
    database_name = args.database
    fireshots_uri = args.fireshots_url
 
        
    vault_obj = vault_password()
    dict_pass = vault_obj.get_password(neo4j_token,cred_id,cred_type,fireshots_uri)
    neo4j_password = dict_pass["data"]["password"]
    neo4j_user = dict_pass["data"]["username"]    
    uri = '{0}'.format(neo4j_uri)
    user = neo4j_user
    database = '{0}'.format(database_name)
    logging.info("[+] Neo4j DATABASE - {0} [+]".format(database))
 
    hotfix_obj = merge_duplicate_nodes_hotfix(uri,user,neo4j_password)
    hotfix_obj.execute_hotfix(database)

    hotfix_obj.close()
    
