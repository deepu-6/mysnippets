from neo4j import GraphDatabase
import argparse
import requests
import logging

logging.basicConfig(level=logging.INFO)


class abv_drug_biologic_comps_hotfix:

    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password))

    def execute_hotfix(self, database_name):
        with self.driver.session(database=database_name) as session:
            session.run(
                "MATCH (c:Compound {ID:'CHEMBL1201580'}) SET c.ABBVIE_ID='PR-765865',c.PRIMARYIDENTIFIER='PR-765865',c.PREFERRED_NAME='PR-765865',c.MOLECULE_TYPE='Antibody',c.PRIMARYSOURCE='AbbVie',c.`LINEAGE.VERSION`=c.`LINEAGE.VERSION`+'.hf4' RETURN c;")

        logging.info("[+] Executed abv_drug_biologic_comps_hotfix [+]")


class abv_drug_sm_comps_hotfix:

    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password))

    def execute_hotfix(self, database_name):
        with self.driver.session(database=database_name) as session:
            pass
        logging.info("[+] Executed non_abv_drug_sm_comps_hotfix [+]")



class vault_password:

    def get_password(self, token, cred_id, cred_type, fireshots_url):
        payload = {"credential_id": cred_id, "credential_type_id": cred_type}
        url = '{0}'.format(fireshots_url)
        r = requests.post(url, headers={"Content-Type": "application/json", "Authorization": token,
                                        "Accept": "application/json"}, json=payload)
        if r.status_code == 200:
            logging.info("[+] Password obtained [+]")
            return r.json()
        else:
            logging.info(r.json())


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("token")
    parser.add_argument("cred_id")
    parser.add_argument("cred_type")
    parser.add_argument("neo4j_uri")
    parser.add_argument("database")
    parser.add_argument("fireshots_url")
    args = parser.parse_args()
    neo4j_token = args.token
    cred_id = args.cred_id
    cred_type = args.cred_type
    neo4j_uri = args.neo4j_uri
    database_name = args.database
    fireshots_uri = args.fireshots_url

    vault_obj = vault_password()
    dict_pass = vault_obj.get_password(neo4j_token, cred_id, cred_type, fireshots_uri)

    print(cred_id)
    print(cred_type)

    neo4j_password = dict_pass["data"]["password"]
    neo4j_user = dict_pass["data"]["username"]

    uri = '{0}'.format(neo4j_uri)
    user = neo4j_user
    database = '{0}'.format(database_name)
    hotfix_obj = abv_drug_biologic_comps_hotfix(uri, user, neo4j_password)
    hotfix_obj.execute_hotfix(database)
    hotfix_obj = abv_drug_sm_comps_hotfix(uri, user, neo4j_password)
    hotfix_obj.execute_hotfix(database)



