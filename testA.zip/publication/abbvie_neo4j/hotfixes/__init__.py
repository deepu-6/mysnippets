from .ae_exclusions import ae_exclusion_hotfix as hf1_ae_exclusions
from .non_abv_drugs import non_abv_drug_biologic_comps_hotfix as hf2_non_abv_drug_biologic_comps
from .non_abv_drugs import non_abv_drug_sm_comps_hotfix as hf2_non_abv_drug_sm_comps
from .ae_duplicates import remove_ae_duplicates_hotfix as hf3_remove_ae_duplicates
from .abv_drugs import abv_drug_biologic_comps_hotfix as hf4_abv_drug_biologic_comps
from .abv_drugs import abv_drug_sm_comps_hotfix as hf4_abv_drug_sm_comps
from .unknown_molecule_type import unknown_molecule_type_hotfix as hf5_unknown_molecule_type
from .null_primaryidentifier_compounds import null_primaryidentifier_compounds_hotfix as hf6_null_primaryidentifier_compounds
from .null_preferred_name_gene_form import null_preferred_name_gene_form_hotfix as hf7_null_preferred_name_gene_form
from .remove_pl_cl_biologics import remove_pl_cl_biologics_hotfix as hf8_remove_pl_cl_biologics
from .merge_duplicate_nodes import merge_duplicate_nodes_hotfix as hf9_merge_duplicate_nodes
from .fix_pcsdw_strength_datatype import fix_pcsdw_strength_datatype_hotfix as hf10_fix_pcsdw_strength_datatype


#Removing hotfix hf4 as 'PR-765865' is coming in GBRS data
#Removing hotfix hf8 as PL- and CL- are filtered in ark.t_compound_gene_bioactivity_relationships table
hotfixes = {
    "hf1":[hf1_ae_exclusions],
    "hf2":[hf2_non_abv_drug_biologic_comps,hf2_non_abv_drug_sm_comps],
    "hf3":[hf3_remove_ae_duplicates],
    "hf4":[],
    "hf5":[hf5_unknown_molecule_type],
    "hf6":[hf6_null_primaryidentifier_compounds],
    "hf7":[hf7_null_preferred_name_gene_form],
    "hf8":[],
    "hf9":[hf9_merge_duplicate_nodes],
    "hf10":[hf10_fix_pcsdw_strength_datatype]
}

def run_all_hotfixes(uri, database, user, password, hotfixes_keys):
    for hf in hotfixes_keys:
        for h in hotfixes[hf]:
            h_obj = h(uri=uri, user=user, password=password)
            h_obj.execute_hotfix(database)
