from kgb_cdc import KnowledgeGraphBuilder
from arch_schema import Arch_constraints, Arch_indexes
from neo4j import GraphDatabase
from neo4j.exceptions import ServiceUnavailable, ClientError, TransientError
from pyspark.sql import SparkSession
from pyspark.sql.functions import col,monotonically_increasing_id
from logging import getLogger, StreamHandler, DEBUG
import logging
import requests
import time
import datetime

logging.basicConfig(level = logging.INFO)

handler = StreamHandler()
handler.setLevel(DEBUG)
logging.getLogger("neo4j").addHandler(handler)

spark = (SparkSession
 .builder
 .appName('ABBVIE NEO4J CDC PIPELINE')
 .enableHiveSupport()
 .getOrCreate())

class Arch_cdc_load:
    def __init__(self, spark_session, uri, user, password, database_name):
        self.__spark = spark_session
        self.__data = {}
        self.neo4j_config={
            'uri':uri,
            'user':user,
            'pwd':password,
            'db': database_name
        }
        self.kgb = KnowledgeGraphBuilder(neo4j_config=self.neo4j_config, spark_session=spark_session)
    
    def cdc_load(self, delta_entities, delta_rels):
        self.load_delta_entities_from_tables(delta_entities) 
        self.load_delta_relationships_from_tables(delta_rels)
    
    
    def load_delta_entities_from_tables(self, delta_entities):
        for table_name in delta_entities:
            self.__spark.sql("REFRESH TABLE " + table_name)
            self.__data[table_name] = {
                'dataframe': self.__spark.table(table_name).filter("FLAG <> 'D'").drop("FLAG").distinct()
            }
            start_time = time.time()
            try:
                self.kgb.write_entities(
                    source_df=self.__data[table_name]['dataframe']
                )
            #Capture any errors along with the query and data for traceability
            except ClientError as error:
                logging.error("Table {} relationships, ClientException raised an error: \n {exception}".format(table_name, exception=error))
                continue
            except TransientError as error:
                logging.error("Table {} relationships, TransientException raised an error: \n {exception}".format(table_name, exception=error))
                continue
            print("Time taken to load {} is {} duration.".format(table_name, str(datetime.timedelta(seconds=(time.time()-start_time)))))


    def load_delta_relationships_from_tables(self, delta_rels):
        for table_name in delta_rels:
            self.__spark.sql("REFRESH TABLE " + table_name)
            cols  = self.__spark.table(table_name).columns
            start_time = time.time()
            try:
                if "TILESRC" in cols:
                    self.load_relationships_from_table_partitions(table_name)
                else:
                    self.__data[table_name] = {
                        'dataframe': self.__spark.table(table_name).filter("FLAG <> 'D'").drop("FLAG").distinct()
                    }
                    self.kgb.write_relations(
                        source_df = self.__data[table_name]['dataframe']
                    )
            #Capture any errors along with the query and data for traceability
            except ClientError as error:
                logging.error("Table {} relationships, ClientException raised an error: \n {exception}".format(table_name, exception=error))
                continue
            except TransientError as error:
                logging.error("Table {} relationships, TransientException raised an error: \n {exception}".format(table_name, exception=error))
                continue
            print("Time taken to load {} is {} duration.".format(table_name, str(datetime.timedelta(seconds=(time.time()-start_time)))))
			
	
    def load_relationships_from_table_partitions(self, table_name):
        pass

class Arch_cdc_delete:

    def __init__(self, spark_session, uri, user, password, database_name):
        self.driver = GraphDatabase.driver(uri, auth=(user, password))
        self.__spark = spark_session
        self.__database_name = database_name

    def cdc_delete(self, delta_entities, delta_rels):
        self.delete_relationships_delta(delta_rels)
        self.delete_entities_delta(delta_entities)
        
    def delete_entities_delta(self, delta_entities):
        '''
            This function deletes the graph nodes on respective database based on MODAK_UID.
        '''
        for table_name in delta_entities:
            start_time = time.time()
            modak_uid_batch_size=10000

            self.__spark.sql("REFRESH TABLE " + table_name)
            df = self.__spark.table(table_name).filter("FLAG = 'D'")

            if(df.count() > 0):

                df = df.filter("LABEL IS NOT NULL").filter("MODAK_UID IS NOT NULL").dropDuplicates()
                label_df = df.select(col("LABEL")).distinct()
                e_reference = {
                    "labels": [str(x.LABEL) for x in label_df.collect()]
                    }
                try:
                    with self.driver.session(database = self.__database_name) as session:
                        for node_label in e_reference["labels"]:
                            df_l = df. \
                                    filter("LABEL =='" + node_label + "'")
                            hash_df = df_l.select(df_l.MODAK_UID.alias("modak_uid")).distinct()
                            hash_df = hash_df.coalesce(1).withColumn("row_num", monotonically_increasing_id())
                            delete_count = hash_df.count() + 1
                            total_count=committed=failed=0
                            errors = ''
                            logging.info("[+] Deleting {} labels. [+]".format(self.label_parser(node_label)))
                            for rows in range(0, delete_count, modak_uid_batch_size):
                                #print("row_num >= {} and row_num < {}".format(rows, rows+modak_uid_batch_size))
                                df_sub = hash_df.filter("row_num >= {} and row_num < {}".format(rows, rows+modak_uid_batch_size)).drop("row_num")
                                modak_uid_list = [str(x.modak_uid) for x in df_sub.collect()]
                                rel_config = """
                                                {
                                                    batchSize:5000,
                                                    parallel:false,
                                                    retries:5,
                                                    params:{modak_uid_list:$modak_uid_list}
                                                }
                                            """
                                relationship_out_cql = "CALL apoc.periodic.iterate(\"UNWIND $modak_uid_list as mid MATCH (n{0})-[r]->(m) USING INDEX n:{0}(MODAK_UID) WHERE n.MODAK_UID = mid RETURN id(r) as relId\", \"MATCH (n{0})-[r]->(m) WHERE id(r)=relId DELETE r\", {1})".format(self.label_parser(node_label), rel_config)
                                delete_rel_ops_result = session.write_transaction(self._delete_delta_tx, modak_uid_list, relationship_out_cql)
                                
                                relationship_in_cql = "CALL apoc.periodic.iterate(\"UNWIND $modak_uid_list as mid MATCH (n{0})<-[r]-(m) USING INDEX n:{0}(MODAK_UID) WHERE n.MODAK_UID = mid RETURN id(r) as relId\", \"MATCH (n{0})-[r]->(m) WHERE id(r)=relId DELETE r\", {1})".format(self.label_parser(node_label), rel_config)
                                delete_rel_ops_result = session.write_transaction(self._delete_delta_tx, modak_uid_list, relationship_in_cql)
                                
                                node_config = """
                                                { 
                                                    batchSize:10, 
                                                    parallel:false, 
                                                    retries:5, 
                                                    params:{modak_uid_list:$modak_uid_list} 
                                                }
                                        """
                                node_cql = "CALL apoc.periodic.iterate(\"UNWIND $modak_uid_list as mid MATCH (n{0}) USING INDEX n:{0}(MODAK_UID) WHERE n.MODAK_UID = mid RETURN id(n) as nodeId\", \"MATCH (n{0}) WHERE id(n)=nodeId DETACH DELETE n\", {1})".format(self.label_parser(node_label), node_config)
                                #print(node_cql)
                                delete_ops_result = session.write_transaction(self._delete_delta_tx, modak_uid_list, node_cql)
                                total_count = total_count + int(delete_ops_result["total"])
                                committed = committed + int(delete_ops_result["committed"])
                                failed = failed + int(delete_ops_result["failed"])
                                errors = errors + str(delete_ops_result["errors"])

                            '''
                                Below find nodes deletion stats
                            '''
                            print("Deleted nodes total count: " + str(total_count))
                            print("Deleted nodes committed count: " + str(committed))
                            print("Deleted nodes failed count: " + str(failed))
                            print("Deleted nodes errors: " + str(errors))
                            print("[+] Deleted n{0} nodes count: {1} in {2} duration. [+]".format(self.label_parser(node_label), total_count, str(datetime.timedelta(seconds=(time.time()-start_time)))))
                #Capture any errors along with the query and data for traceability
                except ServiceUnavailable as exception:
                        logging.error("Table {} nodes, raised an error: \n {exception}".format(table_name, exception=exception))
                print("Time taken to delete {} is {} duration.".format(table_name, str(datetime.timedelta(seconds=(time.time()-start_time)))))

            self.driver.close()
  
    def delete_relationships_delta(self, delta_rels):
        '''
            This function deletes the graph relationships on respective database based on MODAK_UID.
        '''
        for table_name in delta_rels:
            start_time = time.time()
            modak_uid_batch_size=100000

            self.__spark.sql("REFRESH TABLE " + table_name)
            df = self.__spark.table(table_name).filter("FLAG = 'D'")

            if(df.count() > 0):

                rels_df = df.select(col("ENTITY1_TYPE"),col("REL_TYPE"),col("ENTITY2_TYPE")).distinct()
                e1_ref = {
                    "labels": [str(x.ENTITY1_TYPE) for x in rels_df.select(col("ENTITY1_TYPE")).distinct().collect()]
                    }
                e2_ref = {
                    "labels": [str(x.ENTITY2_TYPE) for x in rels_df.select(col("ENTITY2_TYPE")).distinct().collect()]
                    }
                rel_ref = {
                    "rel_types": [str(x.REL_TYPE) for x in rels_df.select(col("REL_TYPE")).distinct().collect()]
                    }
                try:
                    with self.driver.session(database = self.__database_name) as session:
                        for rel_label in rel_ref["rel_types"]:
                            for e1_label in e1_ref["labels"]:
                                for e2_label in e2_ref["labels"]:
                                    if e1_ref["labels"] and e2_ref["labels"]:
                                        total_count=committed=failed=0
                                        rel_st_time=time.time()
                                        errors = ''
                                        df_r = df \
                                            .filter("REL_TYPE='" + rel_label + "'") \
                                            .filter("ENTITY1_TYPE='" + e1_label + "'") \
                                            .filter("ENTITY2_TYPE='" + e2_label + "'")
                                        hash_df = df_r.select(df_r.MODAK_UID.alias("modak_uid")).distinct()
                                        hash_df = hash_df.coalesce(1).withColumn("row_num", monotonically_increasing_id())
                                        delete_count = hash_df.count()+1
                                        print("Deleting (n{0})-[r:`{1}`]->(m{2})".format(self.label_parser(e1_label), rel_label, self.label_parser(e2_label)))
                                        for rows in range(0, delete_count, modak_uid_batch_size):
                                            #print("row_num >= {} and row_num < {}".format(rows, rows+modak_uid_batch_size))
                                            df_sub = hash_df.filter("row_num >= {} and row_num < {}".format(rows, rows+modak_uid_batch_size)).drop("row_num")
                                            modak_uid_list = [str(x.modak_uid) for x in df_sub.collect()]
                                            config = """
                                                        {
                                                            batchSize:5000,
                                                            parallel:false,
                                                            retries:5,
                                                            params:{modak_uid_list:$modak_uid_list}
                                                        }
                                                    """
                                            
                                            relationship = "CALL apoc.periodic.iterate(\"UNWIND $modak_uid_list as mid MATCH (n{0})-[r:`{1}`]->(m{2}) USING INDEX r:`{1}`(MODAK_UID) WHERE r.MODAK_UID = mid RETURN id(r) as relId\", \"MATCH (n{0})-[r:`{1}`]->(m{2}) WHERE id(r)=relId DELETE r\", {3})".format(self.label_parser(e1_label), rel_label, self.label_parser(e2_label), config)
                                            #print(relationship)
                                            delete_ops_result = session.write_transaction(self._delete_delta_tx, modak_uid_list, relationship)
                                            total_count = total_count + int(delete_ops_result["total"])
                                            committed = committed + int(delete_ops_result["committed"])
                                            failed = failed + int(delete_ops_result["failed"])
                                            errors = errors + str(delete_ops_result["errors"])

                                        '''
                                            Below find relationships deletion stats
                                        '''
                                        print("Deleted relationships total count: " + str(total_count))
                                        print("Deleted relationships committed count: " + str(committed))
                                        print("Deleted relationships failed count: " + str(failed))
                                        print("Deleted relationships errors: " + str(errors))
                                        print("[+] Deleted (n{0})-[r:`{1}`]->(m{2}) relationships count: {3} in {4} duration. [+]".format(self.label_parser(e1_label), rel_label, self.label_parser(e2_label), total_count,str(datetime.timedelta(seconds=(time.time()-rel_st_time)))))
                except ServiceUnavailable as exception:
                    logging.error("Table {} relationships, raised an error: \n {exception}".format(table_name, exception=exception))
                      
                print("Time taken to delete {} is {} duration.".format(table_name, str(datetime.timedelta(seconds=(time.time()-start_time)))))
                self.driver.close()
        
    def _delete_delta_tx(self, tx, modak_uid_list, delete_cql):
        
        delete_result = tx.run("{0}".format(delete_cql), modak_uid_list=modak_uid_list)
        delete_ops_result = delete_result.peek()['operations']       

        '''
            Verify, is total nodes/relationships and deleted nodes/relationships are matching or not.
        '''
        if delete_ops_result["total"] != delete_ops_result["committed"]:
            logging.info("Thread sleep for 3 seconds")
            time.sleep(3)
            logging.info("Retry attempt")
            self._delete_delta_tx(tx, modak_uid_list, delete_cql)

        return delete_ops_result
      
    def label_parser(self, labels):
        ''' 
            Utility function for parsing labels to compute on Neo4j. 
            Input - :Label X(:Label Y)* Output - :`Label X`(:`Label Y`)*
        '''       
        labels_arr =  labels.split(':')       
        if len(labels_arr) > 1:
            labels = '`:`'.join(labels_arr) + '`'
        else:
            labels = " :`{0}`".format(labels_arr[0])
        return labels[1:]

class vault_password:
    def get_password(self,token,cred_id,cred_type,fireshots_url):
        payload= {"credential_id": cred_id, "credential_type_id": cred_type}
        url= '{0}'.format(fireshots_url)
        r= requests.post(url, headers={"Content-Type":"application/json","Authorization" : token,"Accept": "application/json"},json= payload)
        if r.status_code == 200:
            logging.info("[+] Password obtained. [+]")
            return r.json()
        else:
            logging.info(r.json())
   
if __name__ == "__main__":   
    args = spark.conf.get("spark.driver.args").split(" ")
    cred_id = args[0]
    cred_type = args[1]
    neo4j_uri = args[2]
    database_name = args[3]
    arch_delta_table_list=args[4]

    token = spark.conf.get("spark.nabu.token")
    fireshots_uri = spark.conf.get("spark.nabu.fireshots_url")

    arch_tables = list(arch_delta_table_list.split(","))

    delta_entities = []	
    delta_relationships = []
    for table in arch_tables:
        if spark.catalog._jcatalog.tableExists(table):
            if "_entities" in table:
                delta_entities.append(table)
            if "_relationship" in table:
                delta_relationships.append(table)
        else:
            logging.info("[-] Table does not extists: {0} [-]".format(str(table)))
    print("Entities tables: {} \n".format(delta_entities))
    print("Relationships tables: {} \n".format(delta_relationships))
			
    vault_obj = vault_password()
    dict_pass = vault_obj.get_password(token, cred_id, cred_type, fireshots_uri)
    neo4j_password= dict_pass["data"]["password"]
    neo4j_user = dict_pass["data"]["username"]    
    uri = '{0}'.format(neo4j_uri)
    user = neo4j_user
    database = '{0}'.format(database_name)

    logging.info("[+] An Operational Neo4j 4.3v Database: {}. [+]".format(database))
 
    constraint_obj= Arch_constraints(uri, user, neo4j_password)
    constraint_labels = constraint_obj.create_constraints(database, delta_entities)
    constraint_obj.close()

    index_obj= Arch_indexes(uri,user,neo4j_password)
    index_obj.create_indexes(database)
    index_obj.create_index_on_modak_uid(database, constraint_labels, delta_relationships)
    index_obj.close()

    cdc_delete_obj = Arch_cdc_delete(spark, uri, user, neo4j_password, database)
    cdc_delete_obj.cdc_delete(delta_entities, delta_relationships)

    cdc_load_obj = Arch_cdc_load(spark, uri, user, neo4j_password, database)
    cdc_load_obj.cdc_load(delta_entities, delta_relationships)
