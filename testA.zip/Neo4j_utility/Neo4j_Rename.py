from neo4j import GraphDatabase
from pyspark.context import SparkContext
from pyspark.sql import HiveContext,SparkSession
import argparse
import requests
import logging
import re
from pyspark.sql.functions import col


logging.basicConfig(level = logging.INFO)


spark = (SparkSession
 .builder
 .appName('ABBVIE NEO4J')
 .enableHiveSupport()
 .getOrCreate())

class Neo4j_Rename:
    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password)) 
        self.__spark = spark
        
    def rename_property_name(self, database_name):
        with self.driver.session(database = database_name) as session:
            rename_cql = """MATCH (c:`Cell Line`) WITH collect(c) AS people CALL apoc.refactor.rename.nodeProperty(\"label_changed\", \"LABEL\", people, {batchSize:1000, parallel:true}) YIELD total, timeTaken, committedOperations, failedOperations, errorMessages RETURN total, timeTaken, committedOperations, failedOperations, errorMessages;"""
            print("Rename Property CQL: " + rename_cql)
            record = session.run(rename_cql)
            #result_list = [record.single()['total'], record.single()['timeTaken'], record.single()['committedOperations'], record.single()['failedOperations'], record.single()['errorMessages']]
            print(record.single())
            logging.info("Renamed property name.")

			 
class vault_password:
    def get_password(self,token,cred_id,cred_type,fireshots_url):
        payload= {"credential_id": cred_id, "credential_type_id": cred_type}
        url= '{0}'.format(fireshots_url)
        r= requests.post(url, headers={"Content-Type":"application/json","Authorization" : token,"Accept": "application/json"},json= payload)
        if r.status_code == 200:
            logging.info("[+] Password obtained [+]")
            return r.json()
        else:
            logging.info(r.json())
			
    
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("token")
    parser.add_argument("cred_id")
    parser.add_argument("cred_type")
    parser.add_argument("neo4j_uri")
    parser.add_argument("database")
    parser.add_argument("fireshots_url")
    args = parser.parse_args()
    neo4j_token = args.token
    cred_id = args.cred_id
    cred_type = args.cred_type
    neo4j_uri = args.neo4j_uri
    database_name = args.database
    fireshots_uri = args.fireshots_url


		
    vault_obj = vault_password()
    dict_pass = vault_obj.get_password(neo4j_token,cred_id,cred_type,fireshots_uri)

    neo4j_password = dict_pass["data"]["password"]
    neo4j_user = dict_pass["data"]["username"]    
    uri = '{0}'.format(neo4j_uri)
    user = neo4j_user
    database = '{0}'.format(database_name)
    logging.info("[+] Neo4j DATABASE - {0} [+]".format(database))

    rename_obj = Neo4j_Rename(uri,user,neo4j_password)
    rename_obj.rename_property_name(database)
