from neo4j import GraphDatabase
from pyspark.context import SparkContext
from pyspark.sql import HiveContext,SparkSession
import argparse
import requests
import logging
import re
from pyspark.sql.functions import col
 
logging.basicConfig(level = logging.INFO)
 
spark = (SparkSession
 .builder
 .appName('ABBVIE NEO4J')
 .enableHiveSupport()
 .getOrCreate())
class Neo4j_delete:
    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password)) 
        self.__spark = spark
        
    def delete_relationships(self, database_name, rel_type):
        with self.driver.session(database = database_name) as session:
             neo4j_rel_types_result = session.run("CALL apoc.meta.stats() yield relTypesCount as rel_types")
             neo4j_rel_types = [record["rel_types"] for record in neo4j_rel_types_result]
             if rel_type in neo4j_rel_types[0]:
                 logging.info("Deleting relationship type: {0}".format(rel_type))
                 retry_attempt = 0
                 while True:
                     #rel_delete_cql = "CALL apoc.periodic.iterate(\"MATCH ()-[n:`" + rel_type + "`]-() RETURN n\", \"DELETE n\", {batchSize:1000, parallel:false})"
                     rel_cql = "\"MATCH (n)-[r:`{0}`]->(m) RETURN r\"".format(rel_type)
                     config = "{batchSize:5000, parallel:false}"
                     rel_delete_cql = "CALL apoc.periodic.iterate({0}, \"DELETE r\",{1})".format(rel_cql, config)                 
                     print("Relationship delete CQL: " + rel_delete_cql)
                     delete_result = session.run(rel_delete_cql)
                     count_cql = "{0}".format(rel_cql)
                     print(count_cql)
                     #count_result = session.run(count_cql)
                     #rem_count = count_result.peek()['count']
                     rem_count = 0
                     if rem_count == 0:
                         break
                     retry_attempt += 1
                     logging.info("Retry attempt {0}".format(retry_attempt))
                 logging.info("Deleted {0} relationships.".format(rel_type))
   
        
    def delete_nodes(self, database_name, label):    
        with self.driver.session(database = database_name) as session:
             neo4j_labels_result = session.run("CALL apoc.meta.stats() yield labels as entities")
             neo4j_labels = [record["entities"] for record in neo4j_labels_result]
             if label in neo4j_labels[0]:
                 logging.info("Label: {0}".format(label))
                 retry_attempt = 0
                 while True:
                     node_cql = "\"MATCH (n:`{0}`) RETURN n\"".format(label)
                     config = "{batchSize:1000, parallel:true}"
                     node_delete_cql = "CALL apoc.periodic.iterate({0}, \"DETACH DELETE n\", {1})".format(node_cql, config)
                     print(node_delete_cql)
                     delete_result = session.run(node_delete_cql)
                     count_cql = "{0}".format(node_cql)
                     print(count_cql)
                     count_result = session.run(count_cql)
                     rem_count = count_result.peek()['count']
                     if rem_count == 0:
                         break
                     retry_attempt += 1
                     logging.info("Retry attempt {0}".format(retry_attempt))
                 logging.info("Deleted {0} nodes.".format(label))   
 
class vault_password:
    def get_password(self,token,cred_id,cred_type,fireshots_url):
        payload= {"credential_id": cred_id, "credential_type_id": cred_type}
        url='{0}'.format(fireshots_url)
        r= requests.post(url, headers={"Content-Type":"application/json","Authorization" : token,"Accept": "application/json"},json= payload)
        if r.status_code == 200:
            logging.info("[+] Password obtained [+]")
            return r.json()
        else:
            logging.info(r.json())
            
    
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("token")
    parser.add_argument("cred_id")
    parser.add_argument("cred_type")
    parser.add_argument("neo4j_uri")
    parser.add_argument("database")
    parser.add_argument("fireshots_url")
    args = parser.parse_args()
    neo4j_token = args.token
    cred_id = args.cred_id
    cred_type = args.cred_type
    neo4j_uri = args.neo4j_uri
    database_name = args.database
    fireshots_uri = args.fireshots_url
 
        
    vault_obj = vault_password()
    dict_pass = vault_obj.get_password(neo4j_token,cred_id,cred_type,fireshots_uri)
    neo4j_password = dict_pass["data"]["password"]
    neo4j_user = dict_pass["data"]["username"]    
    uri = '{0}'.format(neo4j_uri)
    user = neo4j_user
    database = '{0}'.format(database_name)
    logging.info("[+] Neo4j DATABASE - {0} [+]".format(database))
    delete_obj = Neo4j_delete(uri,user,neo4j_password)
    label = "Adverse Event"
    relationship_type = "Contains"
    delete_obj.delete_relationships(database, relationship_type)
    delete_obj.delete_nodes(database, label)


