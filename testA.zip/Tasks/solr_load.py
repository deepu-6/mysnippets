import com.github.music.of.the.ainur.almaren.Almaren
import com.github.music.of.the.ainur.almaren.solr.Solr.SolrImplicit
import org.apache.spark.sql.SaveMode
import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.lucidworks.spark.util.SolrSupport
import com.lucidworks.spark.util.SolrSupport.CloudClientParams
import com.lucidworks.spark.util.SolrQuerySupport
import org.apache.solr.client.solrj.SolrQuery


val almaren = Almaren("Triple Solr Indexing")
var solrQuery: SolrQuery = new SolrQuery
val args = sc.getConf.get("spark.driver.args").split("\\s+")
val zkhost= "arch-dev-tellic-leader0.arch-dev.l6rn-zj16.cloudera.site:2181,arch-dev-tellic-master0.arch-dev.l6rn-zj16.cloudera.site:2181,arch-dev-tellic-master1.arch-dev.l6rn-zj16.cloudera.site:2181/solr-dde"


def indexTable(db_table_name:String,zkhost:String,batch_size:Int,commit_within:Int,collection_name:String){
  var table_names_array = db_table_name.split("\\.")
  var table_name = table_names_array(1)
  print(table_name+"tname")
  var view_name = s"$table_name"+"_vw"
  
  spark.table(s"$db_table_name").distinct()
  .withColumn("id",concat(monotonicallyIncreasingId(),lit(s"$table_name")))
  .withColumn("table_name", lit(s"$table_name"))
  .withColumnRenamed("reluid","relUid")
  .createOrReplaceTempView(s"$view_name")
  
  almaren.builder.sourceSql("SELECT * from " + s"$view_name")
  .targetSolr(s"$collection_name",s"$zkhost",Map("batch_size" ->s"$batch_size" ,"commit_within" ->s"$commit_within" ),SaveMode.Overwrite).batch
}

def deleteTable(db_table_name:String,zkhost:String,collection_name:String){
  var delete_table_name = "table_name:"+s"$db_table_name"
  //checking if the collection is empty or not
  val count_check1 = SolrQuerySupport.getNumDocsFromSolr(s"$collection_name",s"$zkhost",None)
  if(count_check1>0){
    lazy val cloudSolrClient = SolrSupport.getCachedCloudClient(CloudClientParams(s"$zkhost"))
    cloudSolrClient.setDefaultCollection(s"$collection_name")
    cloudSolrClient.deleteByQuery(s"$delete_table_name")
    cloudSolrClient.commit()
  }
  else{
  return
  }
  solrQuery = solrQuery.setQuery(s"$delete_table_name")
  //checking if the given table is deleted or not 
  val count_check2 = SolrQuerySupport.getNumDocsFromSolr(s"$collection_name",s"$zkhost",Option(solrQuery))
  if(count_check2 > 0){
  deleteTable(db_table_name,zkhost,collection_name)
  }
  else{
  return
  }
}


    val collection_name =  "evidence_test"
    val batch_size = 500
    val commit_within = 10000
    //list of tables to be indexed and deleted
    var solr_index_table_list=Array("preclinical_dev.t_scopia_dci_ae_solr");
    var solr_delete_tables_list=Array("t_scopia_dci_ae_solr");
    
    for(table_name <- solr_delete_tables_list){
    print(table_name)
    deleteTable(table_name,zkhost,collection_name)
    }
    
    for (db_table_name <- solr_index_table_list){
    print(db_table_name)
      indexTable(db_table_name,zkhost,batch_size,commit_within,collection_name)
    }
    System.exit(0)    