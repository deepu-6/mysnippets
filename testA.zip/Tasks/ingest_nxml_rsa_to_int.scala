import java.net.URI
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.Path
import org.apache.hadoop.conf.Configuration
import scala.collection.mutable.ListBuffer

val environment = "dev"
val data_store = "integrated"
val db_name = "nih_livertox"
val path = "s3a://arch-dev-datalake/data/unstructured/rsa/test/" -- s3a://arch-dev-datalake/data/unstructured/rsa/NIH LiverTox/

val fs = FileSystem.get(URI.create(path), new Configuration())
val status = fs.listStatus(new Path(path))

var listOfFiles = new ListBuffer[String]()

status.foreach(x=> if(x.getPath.toString.contains(".nxml"))(listOfFiles += x.getPath.toString))
val filesList = listOfFiles.toList

val nonSecTagList = List[String]()

for( file <- filesList) {
	val file_name = file.replace(path,"")
	val set_name = file_name.replace(".nxml","")

	val df = spark.read.format("com.databricks.spark.xml").option("rowTag", "sec").load(path + file_name)
	if(df.count() > 0) {

		val res = df.columns.foldLeft(df)((curr, n) => curr.withColumnRenamed(n, n.replaceAll("-", "_")))

		val res2 = res.select(res.columns.map(c => col(c).cast("string")) : _*)
		//write_table
		}
	else {
		nonSecTagList :+ file_name
	}
}

if(nonSecTagList.length > 0) {
	println("Number of Files without rowTag as sec: " + nonSecTagList.length)
	println("Files: " + nonSecTagList)
}
else{
	println("Hamayya.... aipoindi")
}

val path = "s3a://arch-dev-datalake/data/unstructured/rsa/NIH%20LiverTox/"
val fs = FileSystem.get(URI.create(path), new Configuration())
val status = fs.listStatus(new Path("s3a://arch-dev-datalake/data/unstructured/rsa/NIH LiverTox/"))

