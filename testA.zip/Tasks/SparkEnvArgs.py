from pyspark.context import SparkContext
from pyspark.sql import HiveContext,SparkSession
import argparse
import requests
import logging
import re
from pyspark.sql.functions import col
spark = (SparkSession
 .builder
 .appName('PySparkShell')
 .enableHiveSupport()
 .getOrCreate())
if __name__ == "__main__":   
    args = spark.conf.get("spark.driver.args").split(" ")
    cred_id = args[0]
    cred_type = args[1]
    neo4j_uri = args[2]
    database_name = args[3]
    arch_tables = args[4]
    print(arch_tables)
    arch_tables = list(arch_tables.split(","))
    load_entities = eval(spark.conf.get("spark.driver.load_entities"))
    load_relationships = eval(spark.conf.get("spark.driver.load_relationships"))
    publish_nodes = eval(spark.conf.get("spark.driver.publish_nodes"))
    publish_relationships1 = eval(spark.conf.get("spark.driver.publish_relationships"))
    
    arch_entities = []	
    arch_relationships = []

    for table in arch_tables:
        if "_entities" in table:
            arch_entities.append(table)
        if "_relationship" in table:
            arch_relationships.append(table)
    print(arch_entities)
    print()
    print(arch_relationships)

    publish_relationships = arch_relationships[:]
    publish_entities = arch_entities[:]
    if "ark.t_compound_compound_relationships" in publish_relationships:
       publish_relationships.remove("ark.t_compound_compound_relationships")
    if "ark.t_compound_entities" in publish_entities:
       publish_entities.remove("ark.t_compound_entities")
			
    '''vault_obj = vault_password()
    dict_pass = vault_obj.get_password(neo4j_token, cred_id, cred_type, fireshots_uri)

    neo4j_password = dict_pass["data"]["password"]
    neo4j_user = dict_pass["data"]["username"]    
    uri = '{0}'.format(neo4j_uri)
    user = neo4j_user
    database = '{0}'.format(database_name)
    
    constraint_obj= Arch_constraints(uri, user, neo4j_password)
    constraint_obj.create_constraints(database, arch_entities)
    constraint_obj.close()

    index_obj= Arch_indexes(uri,user,neo4j_password)
    index_obj.create_indexes(database)
    index_obj.close()

    arch_details_obj = Arch_table_details()
    arch_rels = arch_details_obj.getRelationshipDetails(arch_relationships)
    load_entities
    load_relationships
    publish_nodes
    publish_relationships

    print('load_entities' + load_entities)
    print('load_relationships' + load_relationships)
    print('publish_nodes' + publish_nodes)
    print('publish_relationships' + publish_relationships)
    print('load_entities' + load_entities)
    print('load_relationships' + load_relationships)
    print('publish_nodes' + publish_nodes)
    print('publish_relationships' + publish_relationships1)'''

    #load_entities() loads respective nodes
    if(load_entities):
        #neo4j_load = Arch(spark, uri, user, neo4j_password, database)
        print('neo4j_load.load_entities(arch_entities)')
    
    #load_relationships() loads respective relationships
    if(load_relationships):
        #neo4j_load = Arch(spark, uri, user, neo4j_password, database)
        print('neo4j_load.load_relationships(arch_rels)')

    #publish_nodes() deletes the nodes and connected relationships and loads respective nodes
    if(publish_nodes):
        #publish_obj = Arch_publish(uri, user, neo4j_password, database)
        print('publish_obj.(database, publish_entities)')
        #publish_obj.close()

	
    #publish_relationships() deletes given relationships between specific labels(start_label,end_label) and loads respective relationships
    if(publish_relationships1):
        #publish_obj = Arch_publish(uri, user, neo4j_password, database)
        print('publish_obj.publish_relationships(database, publish_relationships)')
        #publish_obj.close()
