import pprint
from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *
import sys
import requests
import logging
import json
from neo4j import GraphDatabase

s3_bucket = 's3a://arch-dev-datalake'
spark = SparkSession\
  .builder\
  .appName('graphlytic')\
  .config('spark.yarn.access.hadoopFileSystems',s3_bucket)\
  .config('spark.yarn.historyServer.allowTracking',True)\
  .config('spark.kubernetes.local.dirs.tmpfs','true')\
  .enableHiveSupport()\
  .getOrCreate()

class vault_password:
    def get_password(self,token,cred_id,cred_type,fireshots_url):
        payload= {"credential_id": cred_id, "credential_type_id": cred_type}
        url= '{0}'.format(fireshots_url)
        r= requests.post(url, headers={"Content-Type":"application/json","Authorization" : token,"Accept": "application/json"},json= payload)
        if r.status_code == 200:
            logging.info("[+] Password obtained [+]")
            return r.json()
        else:
            logging.info(r.json())

if __name__ == "__main__":

  parser = argparse.ArgumentParser()
  parser.add_argument("token")
  parser.add_argument("cred_id")
  parser.add_argument("cred_type")
  parser.add_argument("neo4j_uri")
  parser.add_argument("fireshots_url")
  parser.add_argument("environment")
  args = parser.parse_args()
  neo4j_token = args.token
  cred_id = args.cred_id
  cred_type = args.cred_type
  neo4j_uri = args.neo4j_uri
  fireshots_uri = args.fireshots_url
  environment = args.environment
  
  vault_obj = vault_password()
  dict_pass = vault_obj.get_password(neo4j_token,cred_id,cred_type,fireshots_uri)

  neo4j_password = dict_pass["data"]["password"]
  neo4j_user = dict_pass["data"]["username"]
  uri = '{0}'.format(neo4j_uri)	
  #############################################
  
  pp = pprint.PrettyPrinter(indent=4)
  
  s3_bucket_loc = 's3a://arch-'+environment+'-datalake'
  data_store = 'integrated'
  db_name = 'preclinical'
  set_name = 'nodeid_lookup'

  nodes = spark.sql("select collect_set(explored_Node_Ids) as nodelist from tellic_graphlytic.graphlytic")
  nodelist = nodes.collect()[0]['nodelist']

  print(len(nodelist))
  print(json.dumps([int(i) for i in nodelist]))

  driver =  GraphDatabase.driver(uri, auth=(neo4j_user, neo4j_password))
  session = driver.session()

  result = session.run('MATCH (n) WHERE id(n) IN '+json.dumps([int(i) for i in nodelist])+'RETURN id(n) as id,n.concept_id as concept_id,n.entity_name as entity_name,n.entity_type as entity_type')

  datalist = []
  for r in result:   
    d = r.data()
    datalist.append({
      'id':d['id'],
      'concept_id':d['concept_id'],
      'entity_name':d['entity_name'],
      'entity_type':d['entity_type']
    })
    
  pp.pprint(datalist)

  df = spark.createDataFrame(datalist)
  print(df.schema)
  df.show()

  df.write.mode("OVERWRITE").option("format", "parquet").option("path",s3_bucket_loc+"/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name).saveAsTable(db_name+"."+set_name)
