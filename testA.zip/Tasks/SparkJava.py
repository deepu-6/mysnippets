import subprocess
java_cmd = "java -cp /home/gudurvk/carolina-jdbc-2.4.3-lic.jar com.dullesopen.jdbc.Driver --as-sas7bdat /home/gudurvk/mk_m14465z_anon.csv "
java_result= subprocess.Popen(java_cmd, shell=True, stdout= subprocess.PIPE)
data,err= java_result.communicate()
if java_result.returncode==0:
    print("[+] java command succeeded [+]")
else:
    for line in err.splitlines():
        print(line)
print("[+] java command failed [+]")