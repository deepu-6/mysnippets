#!/bin/bash
file_path=$1
dir_path=$2
driver_memory=$3
exec_memory=$4
num_executors=$5
no_of_cores=$6
git_url=$7
git_version=$8
application_name=$9
packages=${10}
env=${11}
 

if [ -d "$dir_path" ]; then
echo "Directory $dir_path already exists so doing a git pull"
cd $dir_path
git pull $git_url || { echo 'git pull failed' ; exit 1; }
cd -

 

else
echo "Directory $dir_path is new so cloning for the first time"
git clone $git_url || { echo 'git clone failed' ; exit 1; }
fi

 

cd $dir_path
git checkout $git_version || { echo 'git checkot failed' ; exit 1; }
cd -

 

cat $file_path | spark-shell --master yarn --conf spark.yarn.keytab=/opt/nabu/etc/keytab/nabu-spark-bots.keytab --conf spark.yarn.principal=svc-arch-dev-spark@ARCH-DEV.L6RN-ZJ16.CLOUDERA.SITE --conf spark.dynamicAllocation.enabled=false --name "$application_name" --packages "$packages" --jars "/opt/nabu/nabu-almaren-jobs/jars/crawlers-2.1.2.jar" --executor-cores $no_of_cores --num-executors $num_executors --executor-memory $exec_memory --driver-memory $driver_memory --conf spark.driver.args="$env" || { echo 'spark job failed' ; exit 1; }


rm -rf $dir_path
echo "Directory $dir_path was removed"
