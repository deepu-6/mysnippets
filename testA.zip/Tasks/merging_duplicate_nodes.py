from neo4j import GraphDatabase
from pyspark.context import SparkContext
from pyspark.sql import HiveContext,SparkSession
import argparse
import requests
import logging
import re
from pyspark.sql.functions import col
 
logging.basicConfig(level = logging.INFO)
 
spark = (SparkSession
 .builder
 .appName('ABBVIE NEO4J')
 .enableHiveSupport()
 .getOrCreate())
class Neo4j_delete:
    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password)) 
        self.__spark = spark
        
    def delete_relationships(self, database_name, rel_type):
        with self.driver.session(database = database_name) as session:
             neo4j_rel_types_result = session.run("CALL apoc.meta.stats() yield relTypesCount as rel_types")
             neo4j_rel_types = [record["rel_types"] for record in neo4j_rel_types_result]
             if rel_type in neo4j_rel_types[0]:
                 logging.info("Deleting relationship type: {0}".format(rel_type))
                 retry_attempt = 0
                 while True:
                     #rel_delete_cql = "CALL apoc.periodic.iterate(\"MATCH ()-[n:`" + rel_type + "`]-() RETURN n\", \"DELETE n\", {batchSize:1000, parallel:false})"
                     rel_delete_cql = "CALL apoc.periodic.iterate(\"MATCH (n:Drug)-[r:`" + rel_type + "`]->(m:Disease) RETURN r\", \"DELETE r\", {batchSize:5000, parallel:false})"                    
                     print("Relationship delete CQL: " + rel_delete_cql)
                     delete_result = session.run(rel_delete_cql)
                     count_cql = "MATCH (n:Drug)-[r:`{0}`]->(m:Disease) RETURN count(r) as count".format(rel_type)
                     print(count_cql)
                     count_result = session.run(count_cql)
                     rem_count = count_result.peek()['count']
                     if rem_count == 0:
                         break
                     retry_attempt += 1
                     logging.info("Retry attempt {0}".format(retry_attempt))
                 logging.info("Deleted {0} relationships.".format(rel_type))
   
        
    def delete_nodes(self, database_name, label):    
        with self.driver.session(database = database_name) as session:
             neo4j_labels_result = session.run("CALL apoc.meta.stats() yield labels as entities")
             neo4j_labels = [record["entities"] for record in neo4j_labels_result]
             if label in neo4j_labels[0]:
                 logging.info("Label: {0}".format(label))
                 retry_attempt = 0
                 while True:
                     node_delete_cql = "CALL apoc.periodic.iterate(\"MATCH (n:`" + label + "`) where n.ID='PR-765865' RETURN n\", \"DETACH DELETE n\", {batchSize:1000, parallel:true})"
                     print(node_delete_cql)
                     delete_result = session.run(node_delete_cql)
                     count_cql = "MATCH (n:`{0}`) where n.ID='PR-765865' RETURN count(n) AS count".format(label)
                     print(count_cql)
                     count_result = session.run(count_cql)
                     rem_count = count_result.peek()['count']
                     if rem_count == 0:
                         break
                     retry_attempt += 1
                     logging.info("Retry attempt {0}".format(retry_attempt))
                 logging.info("Deleted {0} nodes.".format(label))

class Neo4j_merge:
    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password)) 
        self.__spark = spark
    def merge_nodes(self, database_name, label, node1, node2):
        with self.driver.session(database = database_name) as session:
            merge_nodes_cql = """match (c1:Compound) where id(c1)=7448993 match (c2:Compound) where id(c2)=8673078 call apoc.refactor.mergeNodes([c1,c2],{properties:"overwrite",mergeRels:false}) yield node return node,c1,c2"""
            print(merge_nodes_cql)
            session.run(merge_nodes_cql)
            logging.info("Executed merge nodes hotfix")
                    
    def set_properties(self):
        with self.driver.session(database = database_name) as session:
            set_properties_cql = """match (c2:Compound) where c2.CHEMBL_ID='CHEMBL3707269' set c2.ABBVIE_ID='A-1293543.74', c2.PREFERRED_NAME='A-1293543.74', c2.PRIMARYIDENTIFIER='A-1293543.74', c2.PRIMARYSOURCE='AbbVie', c2.DRUG_NAME='UPADACITINIB TARTRATE', c2.INCHI_KEY='LATZVDXOTDYECD-UFTFXDLESA-N', c2.ROOT_INCHI_KEY='WYQFJHHDOKWSHR-MNOVXSKESA-N' return c2"""
            print(set_properties_cql)
            session.run(set_properties_cql)
            logging.info("Executed set properties hotfix")
 
class vault_password:
    def get_password(self,token,cred_id,cred_type,fireshots_url):
        payload= {"credential_id": cred_id, "credential_type_id": cred_type}
        url= '{0}'.format(fireshots_url)
        r= requests.post(url, headers={"Content-Type":"application/json","Authorization" : token,"Accept": "application/json"},json= payload)
        if r.status_code == 200:
            logging.info("[+] Password obtained [+]")
            return r.json()
        else:
            logging.info(r.json())
            
    
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("token")
    parser.add_argument("cred_id")
    parser.add_argument("cred_type")
    parser.add_argument("neo4j_uri")
    parser.add_argument("database")
    parser.add_argument("fireshots_url")
    args = parser.parse_args()
    neo4j_token = args.token
    cred_id = args.cred_id
    cred_type = args.cred_type
    neo4j_uri = args.neo4j_uri
    database_name = args.database
    fireshots_uri = args.fireshots_url
 
        
    vault_obj = vault_password()
    dict_pass = vault_obj.get_password(neo4j_token,cred_id,cred_type,fireshots_uri)
    neo4j_password = dict_pass["data"]["password"]
    neo4j_user = dict_pass["data"]["username"]    
    uri = '{0}'.format(neo4j_uri)
    user = neo4j_user
    database = '{0}'.format(database_name)
    logging.info("[+] Neo4j DATABASE - {0} [+]".format(database))
 
    merge_obj = Neo4j_merge(uri,user,neo4j_password)
    label = "Compound"
    node1 = 7448993
    node2 = 8673078
    #merge_obj.merge_nodes(database,label,node1,node2)
    merge_obj.set_properties()
    
