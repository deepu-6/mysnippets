from kgb import KnowledgeGraphBuilder
from neo4j import GraphDatabase
from pyspark.context import SparkContext
from pyspark.sql import HiveContext, SparkSession
import argparse
import requests
import logging
import re
from pyspark.sql.functions import col
import hotfixes

logging.basicConfig(level=logging.INFO)

spark = (SparkSession
         .builder
         .appName('ABBVIE NEO4J Orchestrated PIPELINE')
         .enableHiveSupport()
         .getOrCreate())


class Arch:
    def __init__(self, spark_session, uri, user, password, database_name):
        self.neo4j_config = {
            'uri': uri,
            'user': user,
            'pwd': password,
            'db': database_name
        }
        self.kgb = KnowledgeGraphBuilder(neo4j_config=self.neo4j_config, spark_session=spark_session)

    def load_graph(self, arch_entities, arch_tables):
        self.load_entities(arch_entities)
        self.load_relationships(arch_tables)

    def load_entities(self, arch_entities):
        self.kgb.load_entities_from_tables(arch_entities)

    def load_relationships(self, arch_tables):
        self.kgb.load_relationships_from_tables(arch_tables)


class Arch_constraints:

    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password))
        self.__spark = spark

    def create_constraints(self, database_name, arch_entities):
        labels = []
        for table_name in arch_entities:
            self.__spark.sql("REFRESH TABLE " + table_name)
            label_df = self.__spark.sql("SELECT DISTINCT LABEL FROM " + table_name).dropDuplicates()
            labels.extend([str(x.LABEL) for x in label_df.collect()])
        labels = list(set(''.join(labels).split(':')))
        with self.driver.session(database=database_name) as session:
            for label in labels:
                if label:
                    alias = re.sub('[^a-zA-Z0-9\n\.]', '', label).lower()
                    constraint_cql = "CREATE CONSTRAINT {0} IF NOT EXISTS ON ({0}:`{1}`) ASSERT {0}.ID  IS UNIQUE;".format(
                        alias, label)
                    print(constraint_cql)
                    session.run(constraint_cql)
                    logging.info("Created unique constraint on {0}.".format(label))
        logging.info("[+] Created Constraints [+]")


class Arch_indexes:

    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password))

    def create_indexes(self, database_name):
        with self.driver.session(database=database_name) as session:
            session.run("CREATE INDEX inchi_key IF NOT EXISTS for (c:Compound) ON (c.INCHI_KEY);")
            session.run("CREATE INDEX chembl_id IF NOT EXISTS for (c:Compound) ON (c.CHEMBL_ID);")
            session.run("CREATE INDEX abbvie_id IF NOT EXISTS for (c:Compound) ON (c.ABBVIE_ID);")
            session.run("CREATE INDEX primaryidentifier IF NOT EXISTS for (c:Compound) ON (c.PRIMARYIDENTIFIER);")
            session.run("CREATE INDEX primarysource IF NOT EXISTS for (c:Compound) ON (c.PRIMARYSOURCE);")
            session.run("CREATE INDEX abbv_code IF NOT EXISTS for (g:Gene) ON (g.ABBV_CODE);")
            session.run("CREATE INDEX preferred_name IF NOT EXISTS for (e:Endpoint) ON (e.PREFERRED_NAME);")
            session.run("CREATE INDEX gene_primaryidentifier IF NOT EXISTS for (g:Gene) ON (g.PRIMARYIDENTIFIER);")
        print("Created Indexes")


class Arch_delete:
    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password))
        self.__spark = spark

    def delete_relationships(self, database_name, arch_tables):
        rels = []
        flag = False
        for table_name in arch_tables:
            self.__spark.sql("REFRESH TABLE " + table_name)
            rels_df = self.__spark.sql("SELECT DISTINCT REL_TYPE FROM " + table_name).dropDuplicates()
            rels.extend([str(x.REL_TYPE) for x in rels_df.collect()])
        rel_types = list(set(rels))
        with self.driver.session(database=database_name) as session:
            neo4j_rel_types_result = session.run("CALL apoc.meta.stats() yield relTypesCount as rel_types")
            neo4j_rel_types = [record["rel_types"] for record in neo4j_rel_types_result]
            for rel_type in rel_types:
                if rel_type in neo4j_rel_types[0]:
                    logging.info("Deleting relationship type: {0}".format(rel_type))
                    flag = True
                    retry_attempt = 0
                    while True:
                        rel_delete_cql = "CALL apoc.periodic.iterate(\"MATCH ()-[n:`" + rel_type + "`]-() RETURN n\", \"DELETE n\", {batchSize:1000, parallel:false})"
                        print("Relationship delete CQL: " + rel_delete_cql)
                        delete_result = session.run(rel_delete_cql)
                        count_cql = "MATCH ()-[r:`{0}`]->() RETURN count(r) as count".format(rel_type)
                        print(count_cql)
                        count_result = session.run(count_cql)
                        rem_count = count_result.peek()['count']
                        if rem_count == 0:
                            break
                        retry_attempt += 1
                        logging.info("Retry attempt {0}".format(retry_attempt))
                    logging.info("Deleted {0} relationships.".format(rel_type))
        if flag:
            logging.info("[+] Deleted relationships Successfully [+]")

    def delete_nodes(self, database_name, arch_entities):
        labels = []
        flag = False
        for table_name in arch_entities:
            self.__spark.sql("REFRESH TABLE " + table_name)
            label_df = self.__spark.sql("SELECT DISTINCT LABEL FROM " + table_name).dropDuplicates()
            labels.extend([str(x.LABEL) for x in label_df.collect()])
        labels = list(set(''.join(labels).split(':')))
        with self.driver.session(database=database_name) as session:
            neo4j_labels_result = session.run("CALL apoc.meta.stats() yield labels as entities")
            neo4j_labels = [record["entities"] for record in neo4j_labels_result]
            for label in labels:
                if label in neo4j_labels[0]:
                    logging.info("Label: {0}".format(label))
                    flag = True
                    retry_attempt = 0
                    while True:
                        node_delete_cql = "CALL apoc.periodic.iterate(\"MATCH (n:`" + label + "`) RETURN n\", \"DETACH DELETE n\", {batchSize:1000, parallel:true})"
                        print(node_delete_cql)
                        delete_result = session.run(node_delete_cql)
                        count_cql = "MATCH (n:`{0}`) RETURN count(n) AS count".format(label)
                        print(count_cql)
                        count_result = session.run(count_cql)
                        rem_count = count_result.peek()['count']
                        if rem_count == 0:
                            break
                        retry_attempt += 1
                        logging.info("Retry attempt {0}".format(retry_attempt))
                    logging.info("Deleted {0} nodes.".format(label))
        if flag:
            logging.info("[+] Deleted nodes Successfully [+]")
    def delete_chem_similars_relationships(self, table_name, database_name):
        '''
        xxxxx: Index on Tilesrc
        1. Get comp_comp table tilesrc list
        2. for(list)
        3. cypher delete with where tilesrc
        xxxxx: DROP Tilesrc
        '''
        self.__spark.sql("REFRESH TABLE " + table_name)
        df = self.__spark.table(table_name)
        df_tile_list = df.select(col("TILESRC")).distinct().rdd.flatMap(lambda x: x).collect()
        
        with self.driver.session(database=database_name) as session:
            session.run("CREATE INDEX tilesrc IF NOT EXISTS for (c:Compound) ON (c.TILESRC);")
            for partition in df_tile_list:
                print('Deleting partition: ' + partition)
                rel_delete_cql = "CALL apoc.periodic.iterate(\"MATCH (a:Compound)-[n:`" + rel_type + "`]-(b:Compound) WHERE n.TILESRC = \'"+ partition +"\' RETURN n\", \"DELETE n\", {batchSize:100, parallel:false})"
                print("Relationship delete CQL: " + rel_delete_cql)
                delete_result = session.run(rel_delete_cql)
        session.run("DROP INDEX tilesrc")


class vault_password:
    def get_password(self, token, cred_id, cred_type, fireshots_url):
        payload = {"credential_id": cred_id, "credential_type_id": cred_type}
        url = '{0}'.format(fireshots_url)
        r = requests.post(url, headers={"Content-Type": "application/json", "Authorization": token,
                                        "Accept": "application/json"}, json=payload)
        if r.status_code == 200:
            logging.info("[+] Password obtained [+]")
            return r.json()
        else:
            logging.info(r.json())


class Arch_table_details:
    def getRelationshipDetails(self, arch_relationships):
        rel_tables = []
        for rel_table in arch_relationships:
            rel_tuple = (rel_table, False)
            rel_tables.append(rel_tuple)
        return rel_tables


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("token")
    parser.add_argument("cred_id")
    parser.add_argument("cred_type")
    parser.add_argument("neo4j_uri")
    parser.add_argument("database")
    parser.add_argument("fireshots_url")
    parser.add_argument("arch_tables")
    args = parser.parse_args()
    neo4j_token = args.token
    cred_id = args.cred_id
    cred_type = args.cred_type
    neo4j_uri = args.neo4j_uri
    database_name = args.database
    fireshots_uri = args.fireshots_url

    arch_tables = args.arch_tables
    arch_tables = list(arch_tables.split(","))

    arch_entities = []
    arch_relationships = []

    for table in arch_tables:
        if "_entities" in table:
            arch_entities.append(table)
        if "_relationship" in table:
            arch_relationships.append(table)

    print(arch_entities)
    print(arch_relationships)

    vault_obj = vault_password()
    dict_pass = vault_obj.get_password(neo4j_token, cred_id, cred_type, fireshots_uri)

    neo4j_password = dict_pass["data"]["password"]
    neo4j_user = dict_pass["data"]["username"]
    uri = '{0}'.format(neo4j_uri)
    user = neo4j_user
    database = '{0}'.format(database_name)

    delete_relationships = arch_relationships[:]
    delete_entities = arch_entities[:]
    if "ark.t_compound_compound_relationships" in delete_relationships:
        delete_relationships.remove("ark.t_compound_compound_relationships")

    if "ark.t_compound_entities" in delete_entities:
        delete_entities.remove("ark.t_compound_entities")
    delete_obj = Arch_delete(uri, user, neo4j_password)
    delete_obj.delete_relationships(database, delete_relationships)
    #delete_obj.delete_nodes(database, delete_entities)

    constraint_obj = Arch_constraints(uri, user, neo4j_password)
    constraint_obj.create_constraints(database, arch_entities)

    index_obj = Arch_indexes(uri, user, neo4j_password)
    index_obj.create_indexes(database)

    arch_details_obj = Arch_table_details()
    arch_tables = arch_details_obj.getRelationshipDetails(arch_relationships)

    neo4j_load = Arch(spark, uri, user, neo4j_password, database, )
    neo4j_load.load_graph(arch_entities, arch_tables)

    if "ark.t_compound_entities" in arch_entities:
        hotfixes_keys = ['hf1', 'hf2', 'hf3', 'hf4', 'hf5', 'hf6', 'hf9']
        hotfixes.run_all_hotfixes(uri, database, user, neo4j_password, hotfixes_keys)
    else:
        for rel_table in arch_relationships:
            if "compound" in rel_table:
                hotfixes_keys = ['hf9']
                hotfixes.run_all_hotfixes(uri, database, user, neo4j_password, hotfixes_keys)

    if "ark.t_gene_form_entities" in arch_entities:
        hotfixes_keys = ['hf7']
        hotfixes.run_all_hotfixes(uri, database, user, neo4j_password, hotfixes_keys)
