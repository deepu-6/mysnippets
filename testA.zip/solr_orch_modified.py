import com.github.music.of.the.ainur.almaren.Almaren
import com.github.music.of.the.ainur.almaren.solr.Solr.SolrImplicit
import org.apache.spark.sql.SaveMode
import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.lucidworks.spark.util.SolrSupport
import com.lucidworks.spark.util.SolrSupport.CloudClientParams

val almaren = Almaren("Triple Solr Indexing")

/*
val zkhost= args(0)
val batch_size =args(1) 
val commit_within = args(2)
val source = args(3)
val collection = args(4)
*/
val zkhost="arch-dev-tellic-leader0.arch-dev.l6rn-zj16.cloudera.site:2181,arch-dev-tellic-master0.arch-dev.l6rn-zj16.cloudera.site:2181,arch-dev-tellic-master1.arch-dev.l6rn-zj16.cloudera.site:2181/solr-dde"
val collection_name =  "evidence_test"
val batch_size = 30000
val commit_within = 100000
val solr_url="https://arch-dev-tellic-worker0.arch-dev.l6rn-zj16.cloudera.site:8985/solr/"
val source="all"
val args = sc.getConf.get("spark.driver.args").split("\\s+")
var solr_tables_list =Array[String]()

if(source == "compound_endpoint_triples"){
	solr_tables_list=Array("preclinical_dev.t_compound_endpoint_medmsd_solr_check1","preclinical_dev.t_pcsdw_solr_check1");
}
else if (source== "tdb_triples"){
	solr_tables_list=Array("preclinical_dev.t_tdb_sm_cell_solr_check1");
}
else if (source=="gene_triples"){
	solr_tables_list=Array("preclinical_dev.t_cpdb_gene_gene_solr_check1","preclinical_dev.t_drug_gene_solr_check1","preclinical_dev.t_fdb_sm_gene_solr_check1");
}
else if (source=="compound_triples"){
	solr_tables_list=Array("preclinical_dev.t_fdb_comp_sim_solr_check11","preclinical_dev.t_fdb_drug_comp_solr_check1","preclinical_dev.t_tdb_sm_cell_solr_check1","preclinical_dev.t_fdb_sm_gene_solr_check1","preclinical_dev.t_pcsdw_solr_check1","preclinical_dev.t_compound_endpoint_medmsd_solr_check1");
}
else if (source=="scopia_triples"){
	solr_tables_list=Array("preclinical_dev.t_scopia_dci_ae_solr_check1","preclinical_dev.t_scopia_dci_ai_solr_check1","preclinical_dev.t_scopia_dci_ci_solr_check1","preclinical_dev.t_scopia_ddi_ae_solr_check1","preclinical_dev.t_scopia_ddi_di_solr_check1","preclinical_dev.t_scopia_ddi_dps_solr_check1","preclinical_dev.t_scopia_drug_ae_solr_check1","preclinical_dev.t_scopia_drug_ci_solr_check1","preclinical_dev.t_scopia_drug_drug_solr_check1","preclinical_dev.t_scopia_rare_ae_solr_check1");
}
else if(source=="federated_triples"){
	solr_tables_list=Array("preclinical_dev.t_cpdb_gene_gene_solr_check1","preclinical_dev.t_drug_gene_solr_check1","preclinical_dev.t_fdb_sm_gene_solr_check1","preclinical_dev.t_fdb_comp_sim_solr_check11","preclinical_dev.t_fdb_drug_comp_solr_check1","preclinical_dev.t_tdb_sm_cell_solr_check1","preclinical_dev.t_pcsdw_solr_check1","t_compound_endpoint_medmsd_solr_check1");
}
else if(source=="all") {
	if(collection == "evidence") {
		solr_tables_list=Array("tellic_abbvie.tellic_graph_data_solr_relationships_chem_chem","tellic_abbvie.tellic_graph_data_solr_relationships_ct","tellic_abbvie.tellic_graph_data_solr_relationships_faers","tellic_abbvie.tellic_graph_data_solr_relationships_gwas","tellic_abbvie.tellic_graph_data_solr_relationships_ingredients","tellic_abbvie.tellic_graph_data_solr_relationships_patents","tellic_abbvie.tellic_graph_data_solr_relationships_pubs","tellic_abbvie.tellic_graph_data_solr_relationships_gene_shares_family","tellic_abbvie.tellic_graph_data_solr_relationships_gwas_rollup","tellic_abbvie.tellic_graph_data_solr_relationships_has_variant","tellic_abbvie.tellic_graph_data_solr_relationships_is_member_drug_parent","tellic_abbvie.tellic_graph_data_solr_relationships_is_member_health_event","tellic_abbvie.tellic_graph_data_solr_relationships_patents_rollup","tellic_abbvie.tellic_graph_data_solr_relationships_pubs_rollup","tellic_abbvie.tellic_graph_data_solr_relationships_associated_with","tellic_abbvie.tellic_graph_data_solr_relationships_cpdb_ppi","tellic_abbvie.tellic_graph_data_solr_relationships_ct_rollup","tellic_abbvie.tellic_graph_data_solr_relationships_drug_targets_gene","tellic_abbvie.tellic_graph_data_solr_relationships_drug_targets_gene_rollup","tellic_abbvie.tellic_graph_data_solr_relationships_gene_is_member","preclinical_dev.t_compound_endpoint_medmsd_solr_check1","preclinical_dev.t_pcsdw_solr_check1","preclinical_dev.t_tdb_sm_cell_solr_check1","preclinical_dev.t_cpdb_gene_gene_solr_check1","preclinical_dev.t_drug_gene_solr_check1","preclinical_dev.t_fdb_sm_gene_solr_check1","preclinical_dev.t_fdb_comp_sim_solr_check11","preclinical_dev.t_fdb_drug_comp_solr_check1","preclinical_dev.t_tdb_sm_cell_solr_check1","preclinical_dev.t_fdb_sm_gene_solr_check1","preclinical_dev.t_pcsdw_solr_check1","preclinical_dev.t_compound_endpoint_medmsd_solr_check1","preclinical_dev.t_scopia_dci_ae_solr_check1","preclinical_dev.t_scopia_dci_ai_solr_check1","preclinical_dev.t_scopia_dci_ci_solr_check1","preclinical_dev.t_scopia_ddi_ae_solr_check1","preclinical_dev.t_scopia_ddi_di_solr_check1","preclinical_dev.t_scopia_ddi_dps_solr_check1","preclinical_dev.t_scopia_drug_ae_solr_check1","preclinical_dev.t_scopia_drug_ci_solr_check1","preclinical_dev.t_scopia_drug_drug_solr_check1","preclinical_dev.t_scopia_rare_ae_solr_check1","preclinical_dev.t_cpdb_gene_gene_solr_check1","preclinical_dev.t_drug_gene_solr_check1","preclinical_dev.t_fdb_sm_gene_solr_check1","preclinical_dev.t_fdb_comp_sim_solr_check11","preclinical_dev.t_fdb_drug_comp_solr_check1","preclinical_dev.t_tdb_sm_cell_solr_check1","preclinical_dev.t_pcsdw_solr_check1","t_compound_endpoint_medmsd_solr_check1");
		deleteAll(zkhost,collection_name)
	}
	else {
		solr_tables_list=Array("tellic_abbvie.tellic_graph_data_solr_timeline_relationships_with_strength","tellic_abbvie.tellic_graph_data_solr_timeline_relationships_without_strength";
		deleteAll(zkhost,collection_name)
	}
}
else {
	solr_tables_list=Array("preclinical_dev.t_compound_endpoint_medmsd_solr_check1");
}
  
for (db_table_name <- solr_tables_list){
	deleteTable(db_table_name,zkhost,collection_name)
	indexTable(db_table_name, zkhost, batch_size, commit_within, collection_name)
}
System.exit(0)    
  
      
def indexTable(db_table_name:String, zkhost:String, batch_size:Int, commit_within:Int, collection_name:String){
  var table_names_array = db_table_name.split("\\.")
  var table_name = table_names_array(1)
  print(table_name+"tname")
  var view_name = s"$table_name"+"_vw"
  
  spark.table(s"$db_table_name").distinct()
  .withColumn("id",concat(monotonicallyIncreasingId(),lit(s"$table_name")))
  .withColumn("table_name", lit(s"$table_name"))
  .withColumnRenamed("reluid","relUid")
  .createOrReplaceTempView(s"$view_name")
  
  almaren.builder.sourceSql("SELECT * from " + s"$view_name")
  .targetSolr(s"$collection_name",s"$zkhost",Map("batch_size" ->s"$batch_size" ,"commit_within" ->s"$commit_within" ),SaveMode.Overwrite).batch
}

def deleteTable(db_table_name:String, zkhost:String, collection_name:String){
	var table_names_array = db_table_name.split("\\.")
	var table_name = table_names_array(1)
	var delete_table_name = "table_name:"+s"$table_name"
	print(delete_table_name)
	val df = almaren.builder.sourceSolr("collection",s"$zkhost",Map("query" -> s"$delete_table_name"))
	val count = df.show()
	if(count > 0){
		lazy val cloudSolrClient = SolrSupport.getCachedCloudClient(CloudClientParams(s"$zkhost"))
		cloudSolrClient.setDefaultCollection(s"$collection_name")
		cloudSolrClient.deleteByQuery(s"$delete_table_name")
		cloudSolrClient.commit()
	}
}


def deleteAll(zkhost:String, collection_name:String){
	val df = almaren.builder.sourceSolr("collection",s"$zkhost",Map("query" -> "*:*"))
	val count = df.show()
	if(count > 0){
		lazy val cloudSolrClient = SolrSupport.getCachedCloudClient(CloudClientParams(s"$zkhost"))
		cloudSolrClient.setDefaultCollection(s"$collection_name")
		cloudSolrClient.deleteByQuery("*:*")
		cloudSolrClient.commit()
	}
}