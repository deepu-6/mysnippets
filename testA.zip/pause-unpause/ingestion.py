val tables = sc.getConf.get("spark.driver.tables").split(",")
val db_name = "bkp_ark"
tables.foreach { table =>
var df = spark.table("ark."+ table )
df.write.mode("OVERWRITE").option("format", "parquet").option("path", "s3a://arch-prod-datalake/data/warehouse/integrated/"+db_name+".db/3210/10/ark/ark/"+table).saveAsTable(db_name+"."+table)
}