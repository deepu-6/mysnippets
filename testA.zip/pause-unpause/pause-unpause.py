from neo4j import GraphDatabase
from neo4j.exceptions import ServiceUnavailable, ClientError, TransientError
from pyspark.sql import SparkSession
from logging import getLogger, StreamHandler, DEBUG
import logging
import requests
import time
import datetime

logging.basicConfig(level = logging.INFO)

handler = StreamHandler()
handler.setLevel(DEBUG)
logging.getLogger("neo4j").addHandler(handler)

spark = (SparkSession
 .builder
 .appName('ABBVIE NEO4J Pause/Unpause PIPELINE')
 .enableHiveSupport()
 .getOrCreate())

class sync_database:

    def __init__(self, user, password, leader_url):
        self.__spark = spark
        self.user = user
        self.password = password
        self.leader_url = leader_url 

    def unpause_database(self, read_replica_urls, database_names):
        for neo4j_db in database_names:
            leader_stats = self.get_graph_counts(self.leader_url, neo4j_db)
            for url in read_replica_urls:
                try:
                    if self.get_database_status(url, neo4j_db) is False:
                        logging.error("[-] Neo4j database: {} on read replica: {} is not available.[-]".format(neo4j_db, url))
                        continue
                    _driver_rr = GraphDatabase.driver(url, auth=(self.user, self.password), max_connection_lifetime=3600, max_transaction_retry_time = 15) 
                    with _driver_rr.session(database = neo4j_db) as session:
                        unpause_cql="CALL dbms.cluster.readReplicaToggle(\"{0}\", false)".format(neo4j_db)
                        print(unpause_cql)
                        result = session.write_transaction(self._query_runner, unpause_cql)
                        print("Unpause state: {}".format(str(result['state'])))
                        rr_stats = self.get_graph_counts(url, neo4j_db)

                        if(leader_stats['relCount'] == rr_stats['relCount'] and leader_stats['nodeCount'] == rr_stats['nodeCount']):
                            logging.info("[+] Sync successfully completed on read replica: {}. Counts are matching with ingestion node: {}.[+]".format(url, self.leader_url))
                        else:
                            logging.error("[-] Sync failed on read replica: {}. Counts are not matching with ingestion node: {}.[-]".format(url, self.leader_url))
                            _driver_rr.close()
                            continue
                #Capture any errors along with the query and data for traceability
                except (ServiceUnavailable, ClientError, TransientError) as exception:
                    logging.error("Query raised an error: \n {exception}".format(exception=exception))
                finally:
                    _driver_rr.close()
                    if self.get_database_status(url, neo4j_db) is False :
                        logging.error("[-] Neo4j database: {} on read replica: {} is not available.[-]".format(neo4j_db, url))
                        
        logging.info("[+] Sync completed on read replica(s): {0} for neo4j database(s): {1} [+]".format(str(read_replica_urls), str(database_names)))
    
    def pause_database(self, read_replica_urls, database_names):
    
        for neo4j_db in database_names:
            for url in read_replica_urls:
                try:
                    _driver_rr = GraphDatabase.driver(url, auth=(self.user, self.password), max_connection_lifetime=3600, max_transaction_retry_time = 15) 
                    with _driver_rr.session(database = neo4j_db) as session:
                        pause_cql="CALL dbms.cluster.readReplicaToggle(\"{0}\", true)".format(neo4j_db)
                        print(pause_cql)
                        result = session.write_transaction(self._query_runner, pause_cql)
                        print("Neo4j database: {}, pause state: {} on read replica url: {}".format(str(neo4j_db), result['state'], str(url)))
                #Capture any errors along with the query and data for traceability
                except (ServiceUnavailable, ClientError, TransientError) as exception:
                    logging.error("Query raised an error: \n {exception}".format(exception=exception))
                finally:
                    _driver_rr.close()

    def get_graph_counts(self, url, neo4j_db):
        stats = {}
        try:
            _driver = GraphDatabase.driver(url, auth=(self.user, self.password), max_connection_lifetime=3600, max_transaction_retry_time = 15)        
            with _driver.session(database = neo4j_db) as session:
                stats_cql="CALL apoc.meta.stats() YIELD stats RETURN stats"
                result = session.read_transaction(self._query_runner, stats_cql)
                stats = result['stats']
        #Capture any errors along with the query and data for traceability
        except (ServiceUnavailable, ClientError, TransientError) as exception:
            logging.error("Query raised an error: \n {exception}".format(exception=exception))
        finally:
            _driver.close()
        return stats

    def _query_runner(self, tx, query):
        res = tx.run(query)
        return res.peek()
    
    def get_database_status(self, url, neo4j_db):
        flag=True
        try:
            _driver = GraphDatabase.driver(url, auth=(self.user, self.password), max_connection_lifetime=3600, max_transaction_retry_time = 15) 
            with _driver.session(database = "SYSTEM") as session:
                db_cql="SHOW DATABASES"
                #print(db_cql)
                result = session.read_transaction(self._show_status, db_cql) 
                df = self.__spark.createDataFrame(result) 
                df1=df.filter("name='"+neo4j_db+"'")  
                #df.printSchema()
                #df1.show()
                if (df1.filter("lower(currentStatus) <> lower(requestedStatus)").count() > 0
                        and df1.filter("lower(currentStatus) <> 'online'").count() > 0
                            and df1.filter("lower(requestedStatus) <> 'online'").count() > 0 ):
                    flag=False
                else:
                    flag=True
            
        #Capture any errors along with the query and data for traceability
        except (ServiceUnavailable, ClientError, TransientError) as exception:
            logging.error("Query raised an error: \n {exception}".format(exception=exception))
        finally:
           _driver.close()
        return flag

    def get_indexes_status(self, url, neo4j_db):
        try:
            _driver = GraphDatabase.driver(url, auth=(self.user, self.password), max_connection_lifetime=3600, max_transaction_retry_time = 15) 
            with _driver.session(database = neo4j_db) as session:
                index_cql="SHOW INDEXES"
                print(index_cql)
                result = session.read_transaction(self._show_status, index_cql) 
                #print(result)  
                for d in result:
                    for k,v in d.items():
                        if v is None:
                            d[k]=[]
                df = self.__spark.createDataFrame(result)   
                df.printSchema()
                if df.filter("lower(state) <> 'online'").count() > 0:
                    logging.error("Indexes on neo4j database: {} on {} are unavailable.".format(str(neo4j_db), str(url)))
                    df.filter("lower(state) <> 'online'").show()
                else:
                    logging.info("Indexes on neo4j database: {} on {} are online.".format(str(neo4j_db), str(url)))
                    df.show() 

        #Capture any errors along with the query and data for traceability
        except (ServiceUnavailable, ClientError, TransientError) as exception:
            logging.error("Query raised an error: \n {exception}".format(exception=exception))
        finally:
            _driver.close()

    def _show_status(self, tx, query):
        res = tx.run(query)
        return res.data()
                

class vault_password:
    def get_password(self,token,cred_id,cred_type,fireshots_url):
        payload= {"credential_id": cred_id, "credential_type_id": cred_type}
        url= '{0}'.format(fireshots_url)
        r= requests.post(url, headers={"Content-Type":"application/json","Authorization" : token,"Accept": "application/json"},json= payload)
        if r.status_code == 200:
            logging.info("[+] Password obtained [+]")
            return r.json()
        else:
            logging.info(r.json())

if __name__ == "__main__":   
    '''
    i/p args: neo4j_url_leader, list(read1, read2), neo4j creds(id, type), fireshotsUrl, token, list(database_name)
    methods: pause, unpause, get_graph_counts, get_db_status, get_indexes_status

    '''
    
    token = spark.conf.get("spark.nabu.token")
    fireshots_url = spark.conf.get("spark.nabu.fireshots_url")
    leader_url = spark.conf.get("spark.driver.neo4j_leader_url")
    read_replica_urls = spark.conf.get("spark.driver.neo4j_replica_urls").split(",")
    database_names = spark.conf.get("spark.driver.databases").split(",")  
    pause = eval(spark.conf.get("spark.driver.pause")) 
    unpause = eval(spark.conf.get("spark.driver.unpause"))
    args = spark.conf.get("spark.driver.args").split(" ")
    cred_id = args[0]
    cred_type = args[1]
    
    vault_obj = vault_password()
    dict_pass = vault_obj.get_password(token, cred_id, cred_type, fireshots_url)
    neo4j_password = dict_pass["data"]["password"]
    neo4j_user = dict_pass["data"]["username"]   

    sync_db_obj = sync_database(neo4j_user, neo4j_password, leader_url)
            
    if unpause:
        sync_db_obj.unpause_database(read_replica_urls, database_names)
    if pause:
        sync_db_obj.pause_database(read_replica_urls, database_names)

    for neo4j_db in database_names:
        for url in read_replica_urls:           
            sync_db_obj.get_indexes_status(url, neo4j_db)