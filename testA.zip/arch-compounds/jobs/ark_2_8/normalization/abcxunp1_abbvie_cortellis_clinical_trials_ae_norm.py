import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)
from pyspark.sql.functions import col,element_at,split,lit,array_contains,trim,lower,when,concat_ws,concat
from archwelder import *

w = Welder(config = WelderConfig(config_file="config.json"))
arch = w.ignite('arch')
print(arch.spark.sparkContext.getConf().get('spark.ui.proxyRedirectUri'))

df_base = arch.query("""
with drug_data as(
SELECT
    dg.DRUG_ID,
    dg.DRUG_NAME,
    ind.INDICATION_NAME,
    ids.IDENTIFIER_VALUE AS NCT_ID,
    ti.REGIMEN_TYPE,
    cast(ae.PATIENTS_TOTAL as int) as PATIENTS_TOTAL,
    cast(ae.PATIENTS_AFFECTED as int) as PATIENTS_AFFECTED,
    cast(ae.PATIENTS_AFFECTED_PERCENTAGE as double) AS PATIENTS_AFFECTED_PERCENTAGE,
    ae.DOSE,
    ae.DOSE_UNIT,
    ind.INDICATION_ID, 
    t.TRIAL_ID
FROM abcxunp1_abbvie_cortellis_clinical.DRUGS dg
INNER JOIN abcxunp1_abbvie_cortellis_clinical.INTERVENTIONS intv ON dg.DRUG_ID = intv.DRUG_ID
INNER JOIN abcxunp1_abbvie_cortellis_clinical.TRIALS_INTERVENTIONS ti ON intv.INTERVENTION_NAME = ti.INTERVENTION_NAME
INNER JOIN abcxunp1_abbvie_cortellis_clinical.ADVERSE_EVENTS ae ON intv.INTERVENTION_NAME = ae.INTERVENTION_NAME
INNER JOIN abcxunp1_abbvie_cortellis_clinical.TRIALS t ON t.TRIAL_ID = ae.TRIAL_ID AND t.TRIAL_ID = ti.TRIAL_ID
INNER JOIN abcxunp1_abbvie_cortellis_clinical.INDICATIONS ind ON ind.INDICATION_ID = ae.INDICATION_ID
INNER JOIN abcxunp1_abbvie_cortellis_clinical.IDENTIFIERS ids ON t.TRIAL_ID = ids.TRIAL_ID
WHERE ti.INTERVENTION_TYPE = 'InterventionPrimary' AND ids.TRIAL_REGISTRY_ID = 1000 AND ti.REGIMEN_TYPE = 'single'
ORDER BY dg.drug_id, ind.INDICATION_ID, t.TRIAL_ID
)

,calculate_freq as(
select  
    dd.DRUG_ID,
    dd.DRUG_NAME,
    dd.INDICATION_NAME,
    dd.NCT_ID,
    dd.REGIMEN_TYPE,
    dd.PATIENTS_TOTAL,
    dd.PATIENTS_AFFECTED,
    dd.DOSE,
    dd.DOSE_UNIT,
    case 
    when dd.PATIENTS_AFFECTED_PERCENTAGE is NULL  
        THEN(
        case 
            when dd.patients_total is not NULL and dd.patients_total >0 
                and dd.patients_affected is NOT NULL and dd.patients_affected >0 
            THEN cast(100*dd.patients_affected/dd.patients_total as DECIMAL(3,1)) 
        END)
        else dd.PATIENTS_AFFECTED_PERCENTAGE
    END AS PATIENTS_AFFECTED_PERCENTAGE
from drug_data dd
)

,sort_frequency as(
select  
    cf.DRUG_ID,
    cf.DRUG_NAME,
    cf.INDICATION_NAME,
    cf.NCT_ID,
    cf.REGIMEN_TYPE,
    cf.PATIENTS_TOTAL,
    cf.PATIENTS_AFFECTED,
    cf.DOSE,
    cf.DOSE_UNIT,
    cf.PATIENTS_AFFECTED_PERCENTAGE as REPORTING_FREQUENCY
from calculate_freq cf
where PATIENTS_AFFECTED_PERCENTAGE is NOT NULL
order by REPORTING_FREQUENCY
)

,min_max as (
select  
    DRUG_ID,
    DRUG_NAME,
    INDICATION_NAME,
    collect_list(DRUG_ID) as DRUG_IDS,
    max(REPORTING_FREQUENCY)  as MAX_REPORTING_FREQUENCY,
    min(REPORTING_FREQUENCY) as MIN_REPORTING_FREQUENCY,
    count(REPORTING_FREQUENCY) as REPORTING_FREQUENCY_N,
    sum(REPORTING_FREQUENCY)/count(REPORTING_FREQUENCY) as REPORTING_FREQUENCY_MEAN
FROM sort_frequency
group by DRUG_ID, DRUG_NAME, INDICATION_NAME
)

select 
    DISTINCT 
    mm.DRUG_ID,
    mm.DRUG_NAME,   
    mm.INDICATION_NAME,
    mm.REPORTING_FREQUENCY_MEAN,
    mm.REPORTING_FREQUENCY_N,
    mm.MIN_REPORTING_FREQUENCY,
    mm.MAX_REPORTING_FREQUENCY,
    'Clarivate' as SOURCE
from min_max mm
""",format='df',rows=0)

df_drugs = arch.query("""
  SELECT
    dc.abbv_uid as abbvie_drug_uid,
    split(
      lower(
      concat(
        concat_ws('|',dc.cortellis_code),
        '|',
        concat_ws('|',dc.cortellis_terms),
        '|',
        concat_ws('|',dc.cortellis_syns)
      )
      )
      ,'\\\\|') as cortellis_ids
  FROM academe_2_8.drug_concept_v dc
  WHERE
    dc.abbv_uid is not null and 
    dc.abbv_uid not like '%|%' and 
    dc.cortellis_code is not null and 
    dc.cortellis_terms is not null and 
    dc.cortellis_syns is not null
""",format='df',rows=0)
#df_drugs.show(truncate=False)

df_hc = arch.query("""
  SELECT DISTINCT
    abbv_uid as abbvie_disease_uid,
    split(cortellis_term,'\\\\|')[0] as cort_term,
    abbv_term
  FROM academe_2_8.health_condition_v hc
  WHERE 
    abbv_uid is not null and 
    abbv_uid not like '%|%' and 
    abbv_term_source = 'meddra'
""",format='df',rows=0)
#df_hc.show(truncate=False)

logging.info('Normalizing '+str(df_base.count())+' rows against '+str(df_drugs.count())+' drugs and '+str(df_hc.count())+' diseases')


#df_base.show(truncate=False)

df1 = df_base.join(df_drugs,array_contains(col('cortellis_ids'),lower(col('DRUG_NAME'))),'leftouter')

#df1.show(truncate=False)

df2 = df1.join(df_hc,trim(lower(col('INDICATION_NAME')))==trim(lower(col('cort_term'))),'leftouter')

#df2.show(truncate=False)

df3 = df2\
  .withColumn('Reporting_Frequency_Range',
    when(
      col('Reporting_Frequency_N')>1,concat(col('MIN_REPORTING_FREQUENCY'),lit(' - '),col('MAX_REPORTING_FREQUENCY'))
    ).otherwise(
      col('MAX_REPORTING_FREQUENCY')
    )
  )

#df3.show(truncate=False)
  
    
df4 = df3.select(['abbvie_drug_uid','abbvie_disease_uid','DRUG_ID','DRUG_NAME','INDICATION_NAME','REPORTING_FREQUENCY_MEAN','REPORTING_FREQUENCY_N','Reporting_Frequency_Range','SOURCE'])\
  .filter(col('abbvie_drug_uid').isNotNull())\
  .filter(col('abbvie_disease_uid').isNotNull())

#df4.show(truncate=False)

logging.info('Writing '+str(df4.count())+' normalized rows')

arch.saveARCHTable(df4,
                         environment='prod',
                         data_store='integrated',
                         db_name='arch_normalized_2_8',
                         set_name='abcxunp1_abbvie_cortellis_clinical_trials_ae_norm',
                         partitions=1,
                         partitionBy=None)

dfx = df3\
  .filter(col('abbvie_drug_uid').isNull() | col('abbvie_disease_uid').isNull())

logging.info('Writing '+str(dfx.count())+' unmatched rows')
  
arch.saveARCHTable(dfx,
                         environment='prod',
                         data_store='integrated',
                         db_name='arch_normalized_2_8',
                         set_name='abcxunp1_abbvie_cortellis_clinical_trials_ae_norm_unmatched',
                         partitions=1,
                         partitionBy=None)    