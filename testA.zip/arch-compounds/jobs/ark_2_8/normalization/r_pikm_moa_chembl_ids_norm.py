import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)
from pyspark.sql.functions import col,element_at,split
from archwelder import *

w = Welder(config = WelderConfig(config_file="config.json"))
arch = w.ignite('arch')
print(arch.spark.sparkContext.getConf().get('spark.ui.proxyRedirectUri'))

df_base = arch.query("""
  SELECT DISTINCT 
    molecule_name,
    target,
    molecule_id,
    parent_id 
  FROM preclinical.r_pikm_moa_chembl_ids 
  GROUP BY
    molecule_name,
    target,
    molecule_id,
    parent_id
  """,format='df',rows=0)

df_drugs = arch.query("""
  SELECT
    dc.abbv_uid as abbvie_drug_uid,
    dc.abbv_term
  FROM academe_2_8.drug_concept_v dc
  WHERE
    dc.abbv_uid is not null and 
    dc.abbv_uid not like '%|%' and 
    dc.abbv_term is not null
""",format='df',rows=0)
#df_drugs.show(truncate=False)

df_genes = arch.query("""
  SELECT
    g.abbv_uid as abbvie_gene_uid,
    g.abbv_code
  FROM academe_2_8.gte_gene_v g
  WHERE 
    g.abbv_term is not null
""",format='df',rows=0)


logging.info('Normalizing '+str(df_base.count())+' rows against '+str(df_drugs.count())+' drugs and '+str(df_genes.count())+' genes')

#df_base.show(truncate=False)

df1 = df_base.join(df_drugs,lower(trim(col('molecule_name')))==lower(trim(col('abbv_term'))),'leftouter')

#df1.show(truncate=False)

df2 = df1.join(df_genes,trim(lower(col('target')))==trim(lower(col('abbv_code'))),'leftouter')

#df2.show(truncate=False)
df2.printSchema()
df3 = df2\
  .select(['abbvie_drug_uid','abbvie_gene_uid','molecule_name','target','molecule_id','parent_id'])\
  .filter(col('abbvie_drug_uid').isNotNull())\
  .filter(col('abbvie_gene_uid').isNotNull())

#df4.show(truncate=False)

logging.info('Writing '+str(df3.count())+' normalized rows')

arch.saveARCHTable(df3,
                         environment='prod',
                         data_store='integrated',
                         db_name='arch_normalized_2_8',
                         set_name='r_pikm_moa_chembl_ids_norm',
                         partitions=1,
                         partitionBy=None)

dfx = df2\
  .filter(col('abbvie_drug_uid').isNull() | col('abbvie_gene_uid').isNull())

logging.info('Writing '+str(dfx.count())+' unmatched rows')
  
arch.saveARCHTable(dfx,
                         environment='prod',
                         data_store='integrated',
                         db_name='arch_normalized_2_8',
                         set_name='r_pikm_moa_chembl_ids_norm_unmatched',
                         partitions=1,
                         partitionBy=None)    

  