import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)
from pyspark.sql.functions import col,element_at,split,array_contains,trim,upper,lower
from archwelder import *

w = Welder(config = WelderConfig(config_file="config.json"))
arch = w.ignite('arch')
print(arch.spark.sparkContext.getConf().get('spark.ui.proxyRedirectUri'))

df_base = arch.query("""
  SELECT 
    abbvie_drug_uid,
    abbvie_gene_uid,
    molecule_id,
    target,
    ensembl_hgnc_symbol,
    action_type,
    moa,
    parent_id,
    source,
    `references`
  FROM arch_normalized_2_8.open_targets_drug_mechanism_of_action_norm
""",format='df',rows=0)

df_base.printSchema()

df_base2 = arch.query("""
  SELECT 
    t.molecule_id as molecule_id,
    t.target as target,
    t.target as ensembl_hgnc_symbol,
    t.action_type as action_type,
    t.moa as moa,
    t.parent_id as parent_id,
    t.source as source,
    array(named_struct(
      'source',cast(null as string),
      'ids',array(cast(null as string)),
      'urls',array(cast(null as string))
    )) as `references`
  FROM dependency_2_8.t_chembl_pikm_moa t
""",format='df',rows=0)

df_base2.printSchema()

df_drugs = arch.query("""
  SELECT
    dc.abbv_uid as abbvie_drug_uid,
    dc.chembl_id as chembl_ids
  FROM academe_2_8.drug_concept_v dc
  WHERE
    dc.abbv_uid is not null and 
    dc.abbv_uid not like '%|%' and 
    dc.chembl_id is not null
""",format='df',rows=0)
#df_drugs.show(truncate=False)

df_genes = arch.query("""
  SELECT
    g.abbv_uid as abbvie_gene_uid,
    g.abbv_term
  FROM academe_2_8.gte_gene_v g
  WHERE 
    g.abbv_term is not null
""",format='df',rows=0)


logging.info('Normalizing '+str(df_base.count())+' rows against '+str(df_drugs.count())+' drugs and '+str(df_genes.count())+' genes')

#df_base.show(truncate=False)

df1 = df_base2.join(df_drugs,array_contains(col('chembl_ids'),trim(upper(col('molecule_id')))),'leftouter')

#df1.show(truncate=False)

df2 = df1.join(df_genes,trim(lower(col('target')))==trim(lower(col('abbv_term'))),'leftouter')\
  .select(['abbvie_drug_uid','abbvie_gene_uid','molecule_id','target','ensembl_hgnc_symbol','action_type','moa','parent_id','source','references'])

#df2.show(truncate=False)
df2.printSchema()
df3 = df2\
  .drop('chembl_ids')\
  .drop('abbv_term')\
  .union(df_base)\
  .select(['abbvie_drug_uid','abbvie_gene_uid','molecule_id','target','ensembl_hgnc_symbol','action_type','moa','parent_id','source','references'])\
  .filter(col('abbvie_drug_uid').isNotNull())\
  .filter(col('abbvie_gene_uid').isNotNull())

#df4.show(truncate=False)

logging.info('Writing '+str(df3.count())+' normalized rows')

arch.saveARCHTable(df3,
                         environment='prod',
                         data_store='integrated',
                         db_name='arch_normalized_2_8',
                         set_name='r_moa_ids_norm',
                         partitions=1,
                         partitionBy=None)

dfx = df2\
  .filter(col('abbvie_drug_uid').isNull() | col('abbvie_gene_uid').isNull())

logging.info('Writing '+str(dfx.count())+' unmatched rows')
  
arch.saveARCHTable(dfx,
                         environment='prod',
                         data_store='integrated',
                         db_name='arch_normalized_2_8',
                         set_name='r_moa_ids_norm_unmatched',
                         partitions=1,
                         partitionBy=None)    


