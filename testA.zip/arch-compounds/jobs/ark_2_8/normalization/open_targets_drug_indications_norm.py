import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)
from pyspark.sql.functions import col,element_at,split,coalesce,array_contains,trim,lower
from archwelder import *

w = Welder(config = WelderConfig(config_file="config.json"))
arch = w.ignite('arch')
print(arch.spark.sparkContext.getConf().get('spark.ui.proxyRedirectUri'))

df_base = arch.query("""
with source_norm as(
  SELECT
    drugs.id as drug_id,
    drugs.indications as indications,
    drugs.approvedindications as approved
  FROM open_targets.drug_indications drugs
),

json_data as (
  SELECT
    drug_id,
    explod.disease as explod_disease,
    explod.efoname as explod_efoname,
    explod.maxPhaseForIndication as explod_maxPhaseForIndication,
    approved,
    indications
  FROM source_norm
  LATERAL VIEW explode(indications) exploded_table as explod
)


SELECT
DISTINCT
  drug_id,
  explod_efoname as efoname,
  explod_disease as disease,
  explod_maxPhaseForIndication as maxPhaseForIndication,
  indications,
  approved
FROM json_data json
  """,format='df',rows=0)

df_drugs = arch.query("""
  SELECT
    dc.abbv_uid as abbvie_drug_uid,
    dc.chembl_id as chembl_ids
  FROM academe_2_8.drug_concept_v dc
  WHERE
    dc.abbv_uid is not null and 
    dc.abbv_uid not like '%|%' and 
    dc.chembl_id is not null
    
""",format='df',rows=0)
#df_drugs.show(truncate=False)

df_hc_abbv = arch.query("""
  SELECT
    hc.abbv_uid as hc_abbv_uid,
    hc.abbv_term as hc_abbv_term
  FROM academe_2_8.health_condition_v hc
  WHERE 
    hc.abbv_term is not null
""",format='df',rows=0)

df_hc_efo = arch.query("""
with hc_efo_syns_exploded as (
  SELECT
    abbv_uid,
    trim(upper(hc_efo_syns_exploded)) as hc_efo_syns_exploded,
    abbv_term
  FROM academe_2_8.health_condition_v hc
  LATERAL VIEW explode(split(efo_term,'\\|')) expval as hc_efo_syns_exploded
  UNION
  SELECT
    abbv_uid,
    trim(upper(hc_efo_syns_exploded)) as efo_syns_exploded,
    abbv_term
  FROM academe_2_8.health_condition_v hc
  LATERAL VIEW explode(split(efo_syns,'\\|')) expval as hc_efo_syns_exploded
)

SELECT
  abbv_uid as hc_efo_uid,
  hc_efo_syns_exploded,
  abbv_term as efo_abbv_term
FROM (
  SELECT
    abbv_uid,
    hc_efo_syns_exploded,
    abbv_term,
    row_number() over(
      partition by hc_efo_syns_exploded
      order by levenshtein(trim(upper(hc.hc_efo_syns_exploded)),trim(upper(hc.abbv_term))) asc
    )  as rownum
  FROM hc_efo_syns_exploded hc
)x
WHERE rownum = 1
""",format='df',rows=0)
#df_hc.show(truncate=False)

logging.info('Normalizing '+str(df_base.count())+' rows against '+str(df_drugs.count())+' drugs and '+str(df_hc_abbv.count())+' abbv diseases and '+str(df_hc_efo.count())+' efo diseases')

#df_base.show(truncate=False)

df1 = df_base.join(df_drugs,array_contains(col('chembl_ids'),col('drug_id')),'leftouter')

#df1.show(truncate=False)

df2 = df1.join(df_hc_abbv,trim(lower(col('efoname')))==trim(lower(col('hc_abbv_term'))),'leftouter')

#df2.show(truncate=False)

df3 = df2.join(df_hc_efo,trim(lower(col('efoname')))==trim(lower(col('hc_efo_syns_exploded'))),'leftouter')

df4 = df3.withColumn('abbvie_disease_uid',coalesce(col('hc_efo_uid'),col('hc_abbv_uid')))

df5 = df4\
  .filter(col('abbvie_drug_uid').isNotNull())\
  .filter(col('abbvie_disease_uid').isNotNull())

#df4.show(truncate=False)

logging.info('Writing '+str(df4.count())+' normalized rows')

arch.saveARCHTable(df4,
                         environment='prod',
                         data_store='integrated',
                         db_name='arch_normalized_2_8',
                         set_name='open_targets_drug_indications_norm',
                         partitions=1,
                         partitionBy=None)

dfx = df4\
  .filter(col('abbvie_drug_uid').isNull() | col('abbvie_disease_uid').isNull())

logging.info('Writing '+str(dfx.count())+' unmatched rows')
  
arch.saveARCHTable(dfx,
                         environment='prod',
                         data_store='integrated',
                         db_name='arch_normalized_2_8',
                         set_name='open_targets_drug_indications_norm_unmatched',
                         partitions=1,
                         partitionBy=None)    


  