import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)
from pyspark.sql.functions import col,element_at,split
from archwelder import *

w = Welder(config = WelderConfig(config_file="config.json"))
arch = w.ignite('arch')
print(arch.spark.sparkContext.getConf().get('spark.ui.proxyRedirectUri'))

df_base = arch.query("""
with moa1 as (
  SELECT
    molecule_id, 
    target, 
    moa.actiontype, 
    moa.chemblids,
    moa.targetname,
    moa.targettype, 
    moa.targets, 
    moa.mechanismofaction ,
    moa.`references`
  FROM open_targets.drug_mechanism_of_action moa
  LATERAL VIEW explode(chemblids) expval as molecule_id
  LATERAL VIEW explode(targets) expval as target
  WHERE
    moa.chemblids is not null 
    and moa.targets is not null 
    and target is not null
),

duplicate_targets_chemblids as (
  SELECT *,
    row_number() over (
      PARTITION BY moa1.target,moa1.molecule_id 
      ORDER BY moa1.target
    ) as dup_flag
  FROM moa1
)

SELECT DISTINCT 
  dup.molecule_id as molecule_id, 
  dup.target as target, 
  dup.actiontype as action_type,
  dup.chemblids as chemblids, 
  dup.targets as targets,
  dup.targetname as targetname,
  dup.targettype as targettype,
  dup.mechanismofaction as moa, 
  'Open Targets' as source, 
  dup.`references`
FROM (
  SELECT * 
  FROM duplicate_targets_chemblids
  WHERE dup_flag = 1
) dup
""",format='df',rows=0)


df_drugs = arch.query("""
  SELECT
    dc.abbv_uid as abbvie_drug_uid,
    dc.chembl_id as chembl_ids,
    '' as parent_id
  FROM academe_2_8.drug_concept_v dc
  WHERE
    dc.abbv_uid is not null and 
    dc.abbv_uid not like '%|%' and 
    dc.chembl_id is not null
""",format='df',rows=0)
#df_drugs.show(truncate=False)

df_genes = arch.query("""
  SELECT
    g.abbv_uid as abbvie_gene_uid,
    g.abbv_term,
    g.ensembl_hgnc_symbol
  FROM academe_2_8.gte_gene_v g
  WHERE 
    g.abbv_term is not null
""",format='df',rows=0)


logging.info('Normalizing '+str(df_base.count())+' rows against '+str(df_drugs.count())+' drugs and '+str(df_genes.count())+' genes')

#df_base.show(truncate=False)

df1 = df_base.join(df_drugs,array_contains(col('chembl_ids'),trim(upper(col('molecule_id')))),'leftouter')

#df1.show(truncate=False)

df2 = df1.join(df_genes,trim(lower(col('target')))==trim(lower(col('abbv_term'))),'leftouter')

#df2.show(truncate=False)

df3 = df2.select(['abbvie_drug_uid','abbvie_gene_uid','ensembl_hgnc_symbol','parent_id','molecule_id','target','action_type','chemblids','targets','targetname','targettype','moa','source','references'])\
  .filter(col('abbvie_drug_uid').isNotNull())\
  .filter(col('abbvie_gene_uid').isNotNull())

#df4.show(truncate=False)

logging.info('Writing '+str(df3.count())+' normalized rows')

arch.saveARCHTable(df3,
                         environment='prod',
                         data_store='integrated',
                         db_name='arch_normalized_2_8',
                         set_name='open_targets_drug_mechanism_of_action_norm',
                         partitions=1,
                         partitionBy=None)

dfx = df2\
  .filter(col('abbvie_drug_uid').isNull() | col('abbvie_gene_uid').isNull())

logging.info('Writing '+str(dfx.count())+' unmatched rows')
  
arch.saveARCHTable(dfx,
                         environment='prod',
                         data_store='integrated',
                         db_name='arch_normalized_2_8',
                         set_name='open_targets_drug_mechanism_of_action_norm_unmatched',
                         partitions=1,
                         partitionBy=None)    


  