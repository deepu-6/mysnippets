import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)
from pyspark.sql.functions import col,element_at,split
from archwelder import *

w = Welder(config = WelderConfig(config_file="config.json"))
arch = w.ignite('arch')
print(arch.spark.sparkContext.getConf().get('spark.ui.proxyRedirectUri'))

df_base = arch.query("""
SELECT 
	didb.AI_DI,
	regexp_replace(didb.embl_di,"&","|") as EMBL_DI,
	LENGTH(regexp_replace(didb.embl_di,"[^&]",""))+1 as NUM_IDS1,
	didb.di_route as DI_ROUTE,
	didb.AI_DPS,
	regexp_replace(didb.embl_dps,"&","|") as EMBL_DPS,
	LENGTH(regexp_replace(didb.embl_dps,"[^&]",""))+1 as NUM_IDS2,
	didb.dps_route as DPS_ROUTE,
	didb.ae as AE,
	concat("MDR",didb.meddra_code) as AE_ID,
	didb.score as SCORE,
	didb.explicit_flag_1 as EXPLICIT_FLAG_1,
	didb.source_label_1 as SOURCE_LABEL_1,
	didb.interaction_code_1 as INTERACTION_CODE_1,
	didb.drug_interaction_type_1 as INTERACTION_TYPE_1,
	didb.source_rxclass_1 as SOURCE_RXCLASS_1,
	didb.explicit_flag_2 as EXPLICIT_FLAG_2,
	didb.source_label_2 as SOURCE_LABEL_2,
	didb.interaction_code_2 as INTERACTION_CODE_2,
	didb.drug_interaction_type_2 as INTERACTION_TYPE_2,
	didb.source_rxclass_2 as SOURCE_RXCLASS_2
FROM scopiarx.di_main_db didb 
""",format='df',rows=0)


df_drugs = arch.query("""
  SELECT
    dc.abbv_uid as abbvie_drug_uid,
    dc.chembl_terms,
    dc.abbv_term,
    dc.chembl_id
  FROM academe_2_8.drug_concept_v dc
  WHERE
    dc.abbv_uid is not null and 
    dc.chembl_terms is not null
""",format='df',rows=0)
#df_drugs.show(truncate=False)

df_hc = arch.query("""
  SELECT DISTINCT
    abbv_uid as abbvie_disease_uid,
    abbv_term
  FROM academe_2_8.health_condition_v hc
  WHERE 
    abbv_uid is not null and 
    abbv_uid not like '%|%' and
    abbv_term_source='meddra'
""",format='df',rows=0)
#df_hc.show(truncate=False)

logging.info('Normalizing '+str(df_base.count())+' rows against '+str(df_drugs.count())+' drugs and '+str(df_hc.count())+' adverse events')
                     
#df_base.show(truncate=False)

df1 = df_base.join(df_drugs,array_contains(col('chembl_terms'),col('ai_di')),'leftouter')\
  .withColumnRenamed('abbvie_drug_uid','abbvie_drug1_uid')\
  .withColumnRenamed('abbv_term','drug1_er_abbv_term')\
  .withColumnRenamed('chembl_id','drug1_er_chembl_molecule_id')\
  .drop('chembl_terms')

df2 = df1.join(df_drugs,array_contains(col('chembl_terms'),col('ai_dps')),'leftouter')\
  .withColumnRenamed('abbvie_drug_uid','abbvie_drug2_uid')\
  .withColumnRenamed('abbv_term','drug2_er_abbv_term')\
  .withColumnRenamed('chembl_id','drug2_er_chembl_molecule_id')\
  .drop('chembl_terms')
                     

#df1.show(truncate=False)

df3 = df2.join(df_hc,trim(lower(col('abbv_term')))==trim(lower(col('ae'))),'leftouter')

#df2.show(truncate=False)
    
df4 = df3.select(['abbvie_drug1_uid','abbvie_drug2_uid','abbvie_disease_uid','ai_di','embl_di','num_ids1','di_route','ai_dps','embl_dps','num_ids2','dps_route','ae',
                  'ae_id','score','explicit_flag_1','source_label_1','interaction_code_1','interaction_type_1','source_rxclass_1','explicit_flag_2','source_label_2','interaction_code_2',
                  'interaction_type_2','source_rxclass_2','drug1_er_abbv_term','drug1_er_chembl_molecule_id','drug2_er_abbv_term','drug2_er_chembl_molecule_id'])\
  .filter(col('abbvie_drug1_uid').isNotNull())\
  .filter(col('abbvie_drug2_uid').isNotNull())\
  .filter(col('abbvie_disease_uid').isNotNull())

#df4.show(truncate=False)

logging.info('Writing '+str(df4.count())+' normalized rows')

arch.saveARCHTable(df4,
                         environment='prod',
                         data_store='integrated',
                         db_name='arch_normalized_2_8',
                         set_name='scopiarx_di_main_db_norm',
                         partitions=1,
                         partitionBy=None)

dfx = df3\
  .filter(col('abbvie_drug1_uid').isNull() | col('abbvie_drug2_uid').isNull() | col('abbvie_disease_uid').isNull())

logging.info('Writing '+str(dfx.count())+' unmatched rows')
  
arch.saveARCHTable(dfx,
                         environment='prod',
                         data_store='integrated',
                         db_name='arch_normalized_2_8',
                         set_name='scopiarx_di_main_db_norm_unmatched',
                         partitions=1,
                         partitionBy=None)    

