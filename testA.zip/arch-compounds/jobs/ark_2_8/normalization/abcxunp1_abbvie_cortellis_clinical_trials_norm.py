import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)
from pyspark.sql.functions import col,element_at,split,array_contains,trim,lower
from archwelder import *

w = Welder(config = WelderConfig(config_file="config.json"))
arch = w.ignite('arch')
print(arch.spark.sparkContext.getConf().get('spark.ui.proxyRedirectUri'))

df_base = arch.query("""
with cortellis_norm as (
  SELECT
  date_end,
  date_end_type,
  date_enrollment_end,
  date_start,
  drug_id,
  endpoints_achieved,
  identifier_value,
  drug_name,
  number_of_sites,
  patient_count_enrollment,
  patient_count_evaluable,
  phase,
  primary_completion_date,
  title_display,
  title_official,
  trial_id,
  regimen_type,
  intervention_type,
  outcomes_available,
  recruitment_status_name,
  criteria_inclusion,
  criteria_exclusion,
  indication_names,
  explod_indication_name as indication_name,
  intervention_name,
  dose_unit as dose_units,
  dosing_summary,
  maximum_dose,
  minimum_dose,
  concat_ws('-',cast(minimum_dose as string),cast(maximum_dose as string)) as dose_range,
  CASE 
    WHEN routes is null or routes = ''  THEN NULL 
    ELSE routes 
  END AS route,
  adverse_events,
  aims_and_scope,
  outcomes_summary as outcomes,
  protocol_description,
  regimen_summary,
  suspension_reason,
  sponsor,
  collaborator,
  intervention_name as xtra_interventions
  FROM dependency_2_8.v_cortellis_ct_full_view
  LATERAL VIEW OUTER explode(split(indication_names,'\\;'))  expval as explod_indication_name 
  where 1=1
  --and drug_id = 64060
  --and indication_names = 'Psoriatic arthritis'
  --and lower(trim(indication_names)) like '%polymyalgia rheumatica%'
),

calc_dose_group as (
  SELECT
  date_end,
  date_end_type,
  date_enrollment_end,
  date_start,
  drug_id,
  endpoints_achieved,
  identifier_value,
  drug_name,
  number_of_sites,
  patient_count_enrollment,
  patient_count_evaluable,
  phase,
  primary_completion_date,
  title_display,
  title_official,
  trial_id,
  regimen_type,
  intervention_type,
  outcomes_available,
  recruitment_status_name,
  criteria_inclusion,
  criteria_exclusion,
  indication_names,
  indication_name,
  intervention_name,
  dose_units,
  dosing_summary,
  --explod_dosing_summary,
  --count(distinct explod_dosing_summary) over (partition by dosing_summary) as dose_group,
  length(dosing_summary) - length(replace(dosing_summary, ';', '')) + 1 as dose_group,
  minimum_dose,
  maximum_dose,
  dose_range,
  route,
  adverse_events,
  aims_and_scope,
  outcomes,
  protocol_description,
  regimen_summary,
  suspension_reason,
  sponsor,
  collaborator,
  xtra_interventions
  FROM cortellis_norm
  --where  'polymyalgia rheumatica' = lower(trim(indication_name))
  --where dose_unit is not null
  --LATERAL VIEW explode(split(dosing_summary,'\\;'))  expval as explod_dosing_summary
),

calc_harmonized_phase as (
  SELECT 
  date_end,
  date_end_type,
  date_enrollment_end,
  date_start,
  drug_id,
  endpoints_achieved,
  identifier_value,
  drug_name,
  number_of_sites,
  patient_count_enrollment,
  patient_count_evaluable,
  phase,
  CASE 
    WHEN locate('Phase 4',phase)> 0 THEN '4'
    WHEN locate('Phase 3',phase)> 0 THEN '3'
    WHEN locate('Phase 2',phase)> 0 THEN '2' 
    WHEN locate('Phase 1',phase)> 0 THEN '1'
    WHEN locate('Phase 0',phase)> 0 THEN '0'
  END AS HARMONIZED_PHASE,
  primary_completion_date,
  title_display,
  title_official,
  trial_id,
  regimen_type,
  intervention_type,
  outcomes_available,
  recruitment_status_name,
  criteria_inclusion,
  criteria_exclusion,
  indication_names,
  indication_name,
  intervention_name,
  dose_units,
  dosing_summary,
  dose_group,
  maximum_dose,
  minimum_dose,
  dose_range,
  route,
  adverse_events,
  aims_and_scope,
  outcomes,
  protocol_description,
  regimen_summary,
  suspension_reason,
  sponsor,
  collaborator,
  xtra_interventions,
  'CLARIVATE' as Source
  from calc_dose_group
)

select 
  hp.*
from calc_harmonized_phase hp 
  """,format='df',rows=0)


df_drugs = arch.query("""
  SELECT
    dc.abbv_uid as abbvie_drug_uid,
    split(
      lower(
      concat(
        concat_ws('|',dc.cortellis_code),
        '|',
        concat_ws('|',dc.cortellis_terms),
        '|',
        concat_ws('|',dc.cortellis_syns)
      )
      )
      ,'\\\\|') as cortellis_ids
  FROM academe_2_8.drug_concept_v dc
  WHERE
    dc.abbv_uid is not null and 
    dc.abbv_uid not like '%|%' and 
    dc.cortellis_code is not null and 
    dc.cortellis_terms is not null and 
    dc.cortellis_syns is not null
""",format='df',rows=0)
#df_drugs.show(truncate=False)

df_hc = arch.query("""
  SELECT DISTINCT
    abbv_uid as abbvie_disease_uid,
    split(cortellis_term,'\\\\|')[0] as cort_term,
    abbv_term
  FROM academe_2_8.health_condition_v hc
  WHERE 
    abbv_uid is not null and 
    abbv_uid not like '%|%' and 
    abbv_term_source = 'meddra'
""",format='df',rows=0)
#df_hc.show(truncate=False)

logging.info('Normalizing '+str(df_base.count())+' rows against '+str(df_drugs.count())+' drugs and '+str(df_hc.count())+' diseases')


#df_base.show(truncate=False)

df1 = df_base.join(df_drugs,array_contains(col('cortellis_ids'),lower(col('DRUG_NAME'))),'leftouter')

#df1.show(truncate=False)

df2 = df1.join(df_hc,trim(lower(col('INDICATION_NAME')))==trim(lower(col('cort_term'))),'leftouter')

#df2.show(truncate=False)

df3 = df2\
  .filter(col('abbvie_drug_uid').isNotNull())\
  .filter(col('abbvie_disease_uid').isNotNull())

#df3.show(truncate=False)

logging.info('Writing '+str(df3.count())+' normalized rows')

arch.saveARCHTable(df3,
                         environment='prod',
                         data_store='integrated',
                         db_name='arch_normalized_2_8',
                         set_name='abcxunp1_abbvie_cortellis_clinical_trials_norm',
                         partitions=1,
                         partitionBy=None)

dfx = df2\
  .filter(col('abbvie_drug_uid').isNull() | col('abbvie_disease_uid').isNull())

logging.info('Writing '+str(dfx.count())+' unmatched rows')
  
arch.saveARCHTable(dfx,
                         environment='prod',
                         data_store='integrated',
                         db_name='arch_normalized_2_8',
                         set_name='abcxunp1_abbvie_cortellis_clinical_trials_norm_unmatched',
                         partitions=1,
                         partitionBy=None)  