import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)
from pyspark.sql.functions import col,element_at,split,array_contains,trim,lower
from archwelder import *

w = Welder(config = WelderConfig(config_file="config.json"))
arch = w.ignite('arch')
print(arch.spark.sparkContext.getConf().get('spark.ui.proxyRedirectUri'))

df_base = arch.query("""
  SELECT
  date_end,
  --date_end_type,
  --date_enrollment_end,
  --date_start,
  drug_id,
  --endpoints_achieved,
  --identifier_value,
  drug_name,
  lower(regexp_replace(regexp_replace(regexp_replace(drug_name, " \\\(.*\\\)",""),", ?.*$", ""), "\\\s+", " "))  name_for_match,
  --number_of_sites,
  --patient_count_enrollment,
  --patient_count_evaluable,
  --phase,
  --primary_completion_date,
  --title_display,
  --title_official,
  --trial_id,
  --regimen_type,
  --intervention_type,
  --outcomes_available,
  --recruitment_status_name,
  --criteria_inclusion,
  --criteria_exclusion,
  --indication_names,
  explod_indication_name as indication_name
  --intervention_name,
  --dose_unit as dose_units,
  --dosing_summary,
  --maximum_dose,
  --minimum_dose,
  --concat_ws('-',cast(minimum_dose as string),cast(maximum_dose as string)) as dose_range,
  --CASE 
  --  WHEN routes is null or routes = ''  THEN NULL 
  --  ELSE routes 
  --END AS route,
  --adverse_events,
  --aims_and_scope,
  --outcomes_summary as outcomes,
  --protocol_description,
  --regimen_summary,
  --suspension_reason,
  --sponsor,
  --collaborator,
  --intervention_name as xtra_interventions
  FROM dependency_2_8.v_cortellis_ct_full_view
  LATERAL VIEW OUTER explode(split(indication_names,'\\;'))  expval as explod_indication_name 
  where 1=1
  and drug_id in (56368)
  """,format='df',rows=0)


df_drugs = arch.query("""
  SELECT
    dc.abbv_uid as abbvie_drug_uid,
    split(
      lower(
      concat(
        concat_ws('|',dc.cortellis_code),
        '|',
        concat_ws('|',dc.cortellis_terms),
        '|',
        concat_ws('|',dc.cortellis_syns)
      )
      )
      ,'\\\\|') as cortellis_ids
  FROM academe_2_8.drug_concept_v dc
  WHERE
    dc.abbv_uid is not null and 
    dc.abbv_uid not like '%|%' and 
    dc.cortellis_code is not null and 
    dc.cortellis_terms is not null and 
    dc.cortellis_syns is not null
    --and dc.abbv_uid in ('d340f376-d624-4624-8282-1f0d469e33c5')
""",format='df',rows=0)
#df_drugs.show(truncate=False)

df_hc = arch.query("""
  SELECT DISTINCT
    abbv_uid as abbvie_disease_uid,
    split(lower(cortellis_term),' \\\\| ') as cort_terms,
    abbv_term
  FROM academe_2_8.health_condition_v hc
  WHERE 
    abbv_uid is not null and 
    abbv_uid not like '%|%' and 
    abbv_term_source in ('meddra','mesh','doid','ncit','cortellis')
""",format='df',rows=0)
#df_hc.show(truncate=False)

logging.info('Normalizing '+str(df_base.cache().count())+' rows against '+str(df_drugs.cache().count())+' drugs and '+str(df_hc.cache().count())+' diseases')


df_base.show(truncate=False)

df1 = df_base.join(df_drugs,array_contains(col('cortellis_ids'),lower(col('name_for_match'))),'leftouter')

df1.show(truncate=False)

df2 = df1.join(df_hc,array_contains(col('cort_terms'),trim(lower(col('INDICATION_NAME')))),'leftouter')

df2.show(truncate=False)

df3 = df2.cache()\
  .filter(col('abbvie_drug_uid').isNotNull())\
  .filter(col('abbvie_disease_uid').isNotNull())

#df3.show(truncate=False)
