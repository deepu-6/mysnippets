import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)
from pyspark.sql.functions import col,element_at,split,array_contains,upper,trim,lower
from archwelder import *

w = Welder(config = WelderConfig(config_file="config.json"))
arch = w.ignite('arch')
print(arch.spark.sparkContext.getConf().get('spark.ui.proxyRedirectUri'))

df_base = arch.query("""
  SELECT 
    dili.ingredient as ingredient,
    dili.likelihood_score as result,
    dili.chapter_title as chapter_title,
    di.introduction,
    di.hepatotoxicity,
    di.mechanismofinjury,
    di.mechanismofliverinjury,
    di.outcomeandmanagement,
    di.background
  FROM nih_livertox.master_file dili
  LEFT OUTER JOIN nih_livertox.drug_info di on
    lower(di.drug_name) = lower(dili.ingredient)
  WHERE dili.type_of_agent_ = 'P'
  """,format='df',rows=0)

df_drugs = arch.query("""
  SELECT
    dc.abbv_uid as abbvie_drug_uid,
    dc.chembl_terms as chembl_terms,
    dc.abbv_term
  FROM academe_2_8.drug_concept_v dc
  WHERE
    dc.abbv_uid is not null and 
    dc.abbv_uid not like '%|%' and
    (dc.chembl_terms is not null or dc.abbv_term is not null)
""",format='df',rows=0)
#df_drugs.show(truncate=False)

logging.info('Normalizing '+str(df_base.count())+' rows against '+str(df_drugs.count())+' drugs')

#df_base.show(truncate=False)

df1 = df_base.join(df_drugs,((array_contains(col('chembl_terms'),upper(col('ingredient'))))|(lower(trim(col('ingredient')))==col('abbv_term'))),'leftouter')

#df1.show(truncate=False)

df2 = df1.select(['abbvie_drug_uid','ingredient','result','chapter_title','introduction','hepatotoxicity','mechanismofinjury','mechanismofliverinjury',
                  'outcomeandmanagement','background'])\
  .filter(col('abbvie_drug_uid').isNotNull())

#df2.show(truncate=False)

logging.info('Writing '+str(df2.count())+' normalized rows')


arch.saveARCHTable(df2,
                         environment='prod',
                         data_store='integrated',
                         db_name='arch_normalized_2_8',
                         set_name='nih_livertox_norm',
                         partitions=1,
                         partitionBy=None)

dfx = df1\
  .filter(col('abbvie_drug_uid').isNull())

logging.info('Writing '+str(dfx.count())+' unmatched rows')
  
arch.saveARCHTable(dfx,
                         environment='prod',
                         data_store='integrated',
                         db_name='arch_normalized_2_8',
                         set_name='nih_livertox_norm_unmatched',
                         partitions=1,
                         partitionBy=None)

  