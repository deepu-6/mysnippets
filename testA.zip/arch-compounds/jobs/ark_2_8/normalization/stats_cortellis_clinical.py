from datetime import datetime
from archwelder import *
from pyspark.sql.types import StructType,StringType,StructField,ArrayType,IntegerType,DateType
from pyspark.sql import Row,Window
from pyspark.sql.functions import *
from pprint import pprint
import os
import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)

config_path = os.getcwd()+'/config.json'
logging.info(config_path)
w = Welder(config = WelderConfig(config_file=config_path))
arch = w.ignite('arch')


df_ae_norm = arch.query("""
select count(*) count, 'ae_norm_all_rows_26' thing from arch_normalized.abcxunp1_abbvie_cortellis_clinical_trials_ae_norm
union all
SELECT count(*), 'ae_norm_matched_rows_26' FROM arch_normalized.abcxunp1_abbvie_cortellis_clinical_trials_ae_norm where abbvie_drug_uid is not null and abbvie_disease_uid is not null
union all
select count(*), 'ae_norm_matched_rows_28' from arch_normalized_2_8.abcxunp1_abbvie_cortellis_clinical_trials_ae_norm
union all
select count(*), 'ae_norm_unmatched_rows_28' from arch_normalized_2_8.abcxunp1_abbvie_cortellis_clinical_trials_ae_norm_unmatched
union all
select count(distinct drug_name), 'ae_norm_drugs_26' from arch_normalized.abcxunp1_abbvie_cortellis_clinical_trials_ae_norm
union all
SELECT count(distinct drug_name), 'ae_norm_matched_drugs_26' FROM arch_normalized.abcxunp1_abbvie_cortellis_clinical_trials_ae_norm where abbvie_drug_uid is not null and abbvie_disease_uid is not null
union all
select count(distinct drug_name), 'ae_norm_matched_drugs_28' from arch_normalized_2_8.abcxunp1_abbvie_cortellis_clinical_trials_ae_norm
union all
select count(distinct drug_name), 'ae_norm_unmatched_drugs_28' from arch_normalized_2_8.abcxunp1_abbvie_cortellis_clinical_trials_ae_norm_unmatched
union all
select count(distinct indication_name), 'ae_norm_indications_26' from arch_normalized.abcxunp1_abbvie_cortellis_clinical_trials_ae_norm
union all
SELECT count(distinct indication_name), 'ae_norm_matched_indications_26' FROM arch_normalized.abcxunp1_abbvie_cortellis_clinical_trials_ae_norm where abbvie_drug_uid is not null and abbvie_disease_uid is not null
union all
select count(distinct indication_name), 'ae_norm_matched_indications_28' from arch_normalized_2_8.abcxunp1_abbvie_cortellis_clinical_trials_ae_norm
union all
select count(distinct indication_name), 'ae_norm_umatched_indications_28' from arch_normalized_2_8.abcxunp1_abbvie_cortellis_clinical_trials_ae_norm_unmatched
union all
select count(*), 'ae_norm_drug_just_in_26' from (
SELECT distinct lower(drug_name)
FROM arch_normalized.abcxunp1_abbvie_cortellis_clinical_trials_ae_norm
where case when abbvie_drug_uid is null then 0 else 1 end = 1
and case when abbvie_disease_uid is null then 0 else 1 end = 1
minus
SELECT distinct lower(drug_name)
FROM arch_normalized_2_8.abcxunp1_abbvie_cortellis_clinical_trials_ae_norm) x
union all
select count(*), 'ae_norm_drug_just_in_28' from (
SELECT distinct lower(drug_name)
FROM arch_normalized_2_8.abcxunp1_abbvie_cortellis_clinical_trials_ae_norm
minus
SELECT distinct lower(drug_name)
FROM arch_normalized.abcxunp1_abbvie_cortellis_clinical_trials_ae_norm
where case when abbvie_drug_uid is null then 0 else 1 end = 1
and case when abbvie_disease_uid is null then 0 else 1 end = 1
) x
union all
select count(*),'ae_norm_indication_just_in_26' from (
SELECT distinct lower(indication_name)
FROM arch_normalized.abcxunp1_abbvie_cortellis_clinical_trials_ae_norm
where case when abbvie_drug_uid is null then 0 else 1 end = 1
and case when abbvie_disease_uid is null then 0 else 1 end = 1
minus
SELECT distinct lower(indication_name)
FROM arch_normalized_2_8.abcxunp1_abbvie_cortellis_clinical_trials_ae_norm) x
union all
select count(*), 'ae_norm_indication_just_in_28' from (
SELECT distinct lower(indication_name)
FROM arch_normalized_2_8.abcxunp1_abbvie_cortellis_clinical_trials_ae_norm
minus
SELECT distinct lower(indication_name)
FROM arch_normalized.abcxunp1_abbvie_cortellis_clinical_trials_ae_norm
where case when abbvie_drug_uid is null then 0 else 1 end = 1
and case when abbvie_disease_uid is null then 0 else 1 end = 1
) x
""",format='df',rows=0)

df_ae_norm.show(truncate=False, vertical=True)


df_norm = arch.query("""
select count(*) count, 'norm_all_rows_26' from arch_normalized.abcxunp1_abbvie_cortellis_clinical_trials_norm
union all
SELECT count(*), 'norm_matched_rows_26' FROM arch_normalized.abcxunp1_abbvie_cortellis_clinical_trials_norm where abbvie_drug_uid is not null and abbvie_disease_uid is not null
union all
select count(*), 'norm_matched_rows_28' from arch_normalized_2_8.abcxunp1_abbvie_cortellis_clinical_trials_norm
union all
select count(*), 'norm_unmatched_rows_28' from arch_normalized_2_8.abcxunp1_abbvie_cortellis_clinical_trials_norm_unmatched
union all
select count(distinct drug_name), 'norm_drugs_26' from arch_normalized.abcxunp1_abbvie_cortellis_clinical_trials_norm
union all
SELECT count(distinct drug_name), 'norm_matched_drugs_26' FROM arch_normalized.abcxunp1_abbvie_cortellis_clinical_trials_norm where abbvie_drug_uid is not null and abbvie_disease_uid is not null
union all
select count(distinct drug_name), 'norm_matched_drugs_28' from arch_normalized_2_8.abcxunp1_abbvie_cortellis_clinical_trials_norm
union all
select count(distinct drug_name), 'norm_unmatched_drugs_28' from arch_normalized_2_8.abcxunp1_abbvie_cortellis_clinical_trials_norm_unmatched
union all
select count(distinct indication_name), 'norm_indications_26' from arch_normalized.abcxunp1_abbvie_cortellis_clinical_trials_norm
union all
SELECT count(distinct indication_name), 'norm_matched_indications_26' FROM arch_normalized.abcxunp1_abbvie_cortellis_clinical_trials_norm where abbvie_drug_uid is not null and abbvie_disease_uid is not null
union all
select count(distinct indication_name), 'norm_matched_indications_28' from arch_normalized_2_8.abcxunp1_abbvie_cortellis_clinical_trials_norm
union all
select count(distinct indication_name), 'norm_umatched_indications_28' from arch_normalized_2_8.abcxunp1_abbvie_cortellis_clinical_trials_norm_unmatched
union all
select count(*), 'ae_norm_drug_just_in_26' from (
SELECT distinct lower(drug_name)
FROM arch_normalized.abcxunp1_abbvie_cortellis_clinical_trials_norm
where case when abbvie_drug_uid is null then 0 else 1 end = 1
and case when abbvie_disease_uid is null then 0 else 1 end = 1
minus
SELECT distinct lower(drug_name)
FROM arch_normalized_2_8.abcxunp1_abbvie_cortellis_clinical_trials_norm) x
union all
select count(*), 'ae_norm_drug_just_in_28' from (
SELECT distinct lower(drug_name)
FROM arch_normalized_2_8.abcxunp1_abbvie_cortellis_clinical_trials_norm
minus
SELECT distinct lower(drug_name)
FROM arch_normalized.abcxunp1_abbvie_cortellis_clinical_trials_norm
where case when abbvie_drug_uid is null then 0 else 1 end = 1
and case when abbvie_disease_uid is null then 0 else 1 end = 1
) x
union all
select count(*),'ae_norm_indication_just_in_26' from (
SELECT distinct lower(indication_name)
FROM arch_normalized.abcxunp1_abbvie_cortellis_clinical_trials_norm
where case when abbvie_drug_uid is null then 0 else 1 end = 1
and case when abbvie_disease_uid is null then 0 else 1 end = 1
minus
SELECT distinct lower(indication_name)
FROM arch_normalized_2_8.abcxunp1_abbvie_cortellis_clinical_trials_norm) x
union all
select count(*), 'ae_norm_indication_just_in_28' from (
SELECT distinct lower(indication_name)
FROM arch_normalized_2_8.abcxunp1_abbvie_cortellis_clinical_trials_norm
minus
SELECT distinct lower(indication_name)
FROM arch_normalized.abcxunp1_abbvie_cortellis_clinical_trials_norm
where case when abbvie_drug_uid is null then 0 else 1 end = 1
and case when abbvie_disease_uid is null then 0 else 1 end = 1
) x
""",format='df',rows=0)

df_norm.show(truncate=False, vertical=True)