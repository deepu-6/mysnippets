import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)
from pyspark.sql.functions import col,element_at,split,array_intersect,size,trim,lower
from archwelder import *

w = Welder(config = WelderConfig(config_file="config.json"))
arch = w.ignite('arch')
print(arch.spark.sparkContext.getConf().get('spark.ui.proxyRedirectUri'))

df_base = arch.query("""
  with scopiarx as (
    SELECT 
      aedb.embl_code,
      aedb.ai,
      aedb.meddra_code,
      aedb.ae ,
      aedb.score ,
      aedb.codes ,
      aedb.total_aftermarket_reports_for_drug ,
      aedb.total_reports_for_drug_and_adverse_event ,
      aedb.aftermarket_reporting_freq,
      aedb.grade_3_percent ,
      aedb.grade_4_percent ,
      aedb.grade_3or4_percent ,
      LENGTH(regexp_replace(aedb.ai,'[^;]',''))+1 as NUM_COMPONENTS,
      LENGTH(regexp_replace(aedb.ai,'[^&]',''))+1 as NUM_IDS
    FROM scopiarx.ae_main_db aedb
  )
  
  SELECT DISTINCT
    scp.embl_code ,
    scp.ai ,
    scp.meddra_code ,
    scp.ae ,
    scp.score ,
    scp.codes ,
    scp.total_aftermarket_reports_for_drug ,
    scp.total_reports_for_drug_and_adverse_event ,
    scp.aftermarket_reporting_freq,
    scp.grade_3_percent ,
    scp.grade_4_percent ,
    scp.grade_3or4_percent ,
    scp.NUM_COMPONENTS,
    scp.NUM_IDS
  FROM (
    SELECT *
    FROM scopiarx 
    LATERAL VIEW outer explode(split(ai,';')) expval AS d_name
  ) scp
""",format='df',rows=0)

df_drugs = arch.query("""
  SELECT
    dc.abbv_uid as abbvie_drug_uid,
    dc.chembl_terms
  FROM academe_2_8.drug_concept_v dc
  WHERE
    dc.abbv_uid is not null and 
    dc.chembl_terms is not null
""",format='df',rows=0)
#df_drugs.show(truncate=False)

df_hc = arch.query("""
  SELECT DISTINCT
    abbv_uid as abbvie_disease_uid,
    abbv_term
  FROM academe_2_8.health_condition_v hc
  WHERE 
    abbv_uid is not null and 
    abbv_uid not like '%|%'
""",format='df',rows=0)
#df_hc.show(truncate=False)

logging.info('Normalizing '+str(df_base.count())+' rows against '+str(df_drugs.count())+' drugs and '+str(df_hc.count())+' diseases')


#df_base.show(truncate=False)

df1 = df_base.join(df_drugs,size(array_intersect(col('chembl_terms'),split(col('ai'),';')))>0,'leftouter')

#df1.show(truncate=False)

df2 = df1.join(df_hc,trim(lower(col('abbv_term')))==trim(lower(col('ae'))),'leftouter')

#df2.show(truncate=False)
    
df3 = df2.select(['abbvie_drug_uid','abbvie_disease_uid','embl_code','ai','meddra_code','ae','score','codes','total_aftermarket_reports_for_drug','total_reports_for_drug_and_adverse_event',
                 'aftermarket_reporting_freq','grade_3_percent','grade_4_percent','grade_3or4_percent','NUM_COMPONENTS','NUM_IDS'])\
  .filter(col('abbvie_drug_uid').isNotNull())\
  .filter(col('abbvie_disease_uid').isNotNull())

#df4.show(truncate=False)

logging.info('Writing '+str(df3.count())+' normalized rows')

arch.saveARCHTable(df3,
                         environment='prod',
                         data_store='integrated',
                         db_name='arch_normalized_2_8',
                         set_name='scopiarx_ae_main_db_norm',
                         partitions=1,
                         partitionBy=None)

dfx = df2\
  .filter(col('abbvie_drug_uid').isNull() | col('abbvie_disease_uid').isNull())

logging.info('Writing '+str(dfx.count())+' unmatched rows')
  
arch.saveARCHTable(dfx,
                         environment='prod',
                         data_store='integrated',
                         db_name='arch_normalized_2_8',
                         set_name='scopiarx_ae_main_db_norm_unmatched',
                         partitions=1,
                         partitionBy=None)    

