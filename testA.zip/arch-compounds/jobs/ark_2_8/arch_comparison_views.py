from datetime import datetime
from archwelder import *
from pprint import pprint
import os
import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)

config_path = os.getcwd()+'/config.json'
logging.info(config_path)
w = Welder(config = WelderConfig(config_file=config_path))
arch = w.ignite('arch')

arch.query("""create or replace view cws_ir_raiders.v_arch_norm_comparison as
select
  'abcxunp1_abbvie_cortellis_clinical_trials_ae_norm' as table_name,
  '2.7' as version,
  count(*) as row_count,
  count(distinct abbvie_drug_uid) as drug_count,
  count(distinct abbvie_disease_uid) as disease_count,
  0 as gene_count
FROM arch_normalized.abcxunp1_abbvie_cortellis_clinical_trials_ae_norm
WHERE abbvie_drug_uid is not null and abbvie_disease_uid is not null
union
select
  'abcxunp1_abbvie_cortellis_clinical_trials_ae_norm (unmatched)' as table_name,
  '2.7' as version,
  count(*) as row_count,
  count(distinct abbvie_drug_uid) as drug_count,
  count(distinct abbvie_disease_uid) as disease_count,
  0 as gene_count
FROM arch_normalized.abcxunp1_abbvie_cortellis_clinical_trials_ae_norm
WHERE abbvie_drug_uid is null or abbvie_disease_uid is null
union
select
  'abcxunp1_abbvie_cortellis_clinical_trials_ae_norm' as table_name,
  '2.8' as version,
  count(*) as row_count,
  count(distinct abbvie_drug_uid) as drug_count,
  count(distinct abbvie_disease_uid) as disease_count,
  0 as gene_count
FROM arch_normalized_2_8.abcxunp1_abbvie_cortellis_clinical_trials_ae_norm
union
select
  'abcxunp1_abbvie_cortellis_clinical_trials_ae_norm (unmatched)' as table_name,
  '2.8' as version,
  count(*) as row_count,
  count(distinct abbvie_drug_uid) as drug_count,
  count(distinct abbvie_disease_uid) as disease_count,
  0 as gene_count
FROM arch_normalized_2_8.abcxunp1_abbvie_cortellis_clinical_trials_ae_norm_unmatched
union
select
  'abcxunp1_abbvie_cortellis_clinical_trials_norm' as table_name,
  '2.7' as version,
  count(*) as row_count,
  count(distinct abbvie_drug_uid) as drug_count,
  count(distinct abbvie_disease_uid) as disease_count,
  0 as gene_count
FROM arch_normalized.abcxunp1_abbvie_cortellis_clinical_trials_norm
WHERE abbvie_drug_uid is not null and abbvie_disease_uid is not null
union
select
  'abcxunp1_abbvie_cortellis_clinical_trials_norm (unmatched)' as table_name,
  '2.7' as version,
  count(*) as row_count,
  count(distinct abbvie_drug_uid) as drug_count,
  count(distinct abbvie_disease_uid) as disease_count,
  0 as gene_count
FROM arch_normalized.abcxunp1_abbvie_cortellis_clinical_trials_norm
WHERE abbvie_drug_uid is null or abbvie_disease_uid is null
union
select
  'abcxunp1_abbvie_cortellis_clinical_trials_norm' as table_name,
  '2.8' as version,
  count(*) as row_count,
  count(distinct abbvie_drug_uid) as drug_count,
  count(distinct abbvie_disease_uid) as disease_count,
  0 as gene_count
FROM arch_normalized_2_8.abcxunp1_abbvie_cortellis_clinical_trials_norm
union
select
  'abcxunp1_abbvie_cortellis_clinical_trials_norm (unmatched)' as table_name,
  '2.8' as version,
  count(*) as row_count,
  count(distinct abbvie_drug_uid) as drug_count,
  count(distinct abbvie_disease_uid) as disease_count,
  0 as gene_count
FROM arch_normalized_2_8.abcxunp1_abbvie_cortellis_clinical_trials_norm_unmatched
union
select
  'nih_livertox_norm' as table_name,
  '2.7' as version,
  count(*) as row_count,
  count(distinct abbvie_drug_uid) as drug_count,
  0 as disease_count,
  0 as gene_count
FROM arch_normalized.nih_livertox_norm
WHERE abbvie_drug_uid is not null
union
select
  'nih_livertox_norm (unmatched)' as table_name,
  '2.7' as version,
  count(*) as row_count,
  count(distinct abbvie_drug_uid) as drug_count,
  0 as disease_count,
  0 as gene_count
FROM arch_normalized.nih_livertox_norm
WHERE abbvie_drug_uid is null
union
select
  'nih_livertox_norm' as table_name,
  '2.8' as version,
  count(*) as row_count,
  count(distinct abbvie_drug_uid) as drug_count,
  0 as disease_count,
  0 as gene_count
FROM arch_normalized_2_8.nih_livertox_norm
union
select
  'nih_livertox_norm (unmatched)' as table_name,
  '2.8' as version,
  count(*) as row_count,
  count(distinct abbvie_drug_uid) as drug_count,
  0 as disease_count,
  0 as gene_count
FROM arch_normalized_2_8.nih_livertox_norm_unmatched
union
select
  'open_targets_drug_indications_norm' as table_name,
  '2.7' as version,
  count(*) as row_count,
  count(distinct abbvie_drug_uid) as drug_count,
  count(distinct abbvie_disease_uid) as disease_count,
  0 as gene_count
FROM arch_normalized.open_targets_drug_indications_norm
WHERE abbvie_drug_uid is not null and abbvie_disease_uid is not null
union
select
  'open_targets_drug_indications_norm (unmatched)' as table_name,
  '2.7' as version,
  count(*) as row_count,
  count(distinct abbvie_drug_uid) as drug_count,
  count(distinct abbvie_disease_uid) as disease_count,
  0 as gene_count
FROM arch_normalized.open_targets_drug_indications_norm
WHERE abbvie_drug_uid is null and abbvie_disease_uid is null
union
select
  'open_targets_drug_indications_norm' as table_name,
  '2.8' as version,
  count(*) as row_count,
  count(distinct abbvie_drug_uid) as drug_count,
  count(distinct abbvie_disease_uid) as disease_count,
  0 as gene_count
FROM arch_normalized_2_8.open_targets_drug_indications_norm
union
select
  'open_targets_drug_indications_norm (unmatched)' as table_name,
  '2.8' as version,
  count(*) as row_count,
  count(distinct abbvie_drug_uid) as drug_count,
  count(distinct abbvie_disease_uid) as disease_count,
  0 as gene_count
FROM arch_normalized_2_8.open_targets_drug_indications_norm_unmatched
union
select
  'open_targets_drug_mechanism_of_action_norm' as table_name,
  '2.7' as version,
  count(*) as row_count,
  count(distinct abbvie_drug_uid) as drug_count,
  0 as disease_count,
  count(distinct abbvie_gene_uid) as gene_count
FROM arch_normalized.open_targets_drug_mechanism_of_action_norm
WHERE abbvie_drug_uid is not null and abbvie_gene_uid is not null
union
select
  'open_targets_drug_mechanism_of_action_norm (unmatched)' as table_name,
  '2.7' as version,
  count(*) as row_count,
  count(distinct abbvie_drug_uid) as drug_count,
  0 as disease_count,
  count(distinct abbvie_gene_uid) as gene_count
FROM arch_normalized.open_targets_drug_mechanism_of_action_norm
WHERE abbvie_drug_uid is null or abbvie_gene_uid is null
union
select
  'open_targets_drug_mechanism_of_action_norm' as table_name,
  '2.8' as version,
  count(*) as row_count,
  count(distinct abbvie_drug_uid) as drug_count,
  0 as disease_count,
  count(distinct abbvie_gene_uid) as gene_count
FROM arch_normalized_2_8.open_targets_drug_mechanism_of_action_norm
union
select
  'open_targets_drug_mechanism_of_action_norm (unmatched)' as table_name,
  '2.8' as version,
  count(*) as row_count,
  count(distinct abbvie_drug_uid) as drug_count,
  0 as disease_count,
  count(distinct abbvie_gene_uid) as gene_count
FROM arch_normalized_2_8.open_targets_drug_mechanism_of_action_norm_unmatched
union
select
  'r_moa_ids_norm' as table_name,
  '2.7' as version,
  count(*) as row_count,
  count(distinct abbv_drug_uid) as drug_count,
  0 as disease_count,
  count(distinct abbv_gene_uid) as gene_count
FROM arch_normalized.r_moa_ids_norm
WHERE abbv_drug_uid is not null and abbv_gene_uid is not null
union
select
  'r_moa_ids_norm (unmatched)' as table_name,
  '2.7' as version,
  count(*) as row_count,
  count(distinct abbv_drug_uid) as drug_count,
  0 as disease_count,
  count(distinct abbv_gene_uid) as gene_count
FROM arch_normalized.r_moa_ids_norm
WHERE abbv_drug_uid is null or abbv_gene_uid is null
union
select
  'r_moa_ids_norm' as table_name,
  '2.8' as version,
  count(*) as row_count,
  count(distinct abbvie_drug_uid) as drug_count,
  0 as disease_count,
  count(distinct abbvie_gene_uid) as gene_count
FROM arch_normalized_2_8.r_moa_ids_norm
union
select
  'r_moa_ids_norm (unmatched)' as table_name,
  '2.8' as version,
  count(*) as row_count,
  count(distinct abbvie_drug_uid) as drug_count,
  0 as disease_count,
  count(distinct abbvie_gene_uid) as gene_count
FROM arch_normalized_2_8.r_moa_ids_norm_unmatched
union
select
  'r_pikm_moa_chembl_ids_norm' as table_name,
  '2.7' as version,
  count(*) as row_count,
  count(distinct abbv_drug_uid) as drug_count,
  0 as disease_count,
  count(distinct abbv_gene_uid) as gene_count
FROM arch_normalized.r_pikm_moa_chembl_ids_norm
WHERE abbv_drug_uid is not null and abbv_gene_uid is not null
union
select
  'r_pikm_moa_chembl_ids_norm (unmatched)' as table_name,
  '2.7' as version,
  count(*) as row_count,
  count(distinct abbv_drug_uid) as drug_count,
  0 as disease_count,
  count(distinct abbv_gene_uid) as gene_count
FROM arch_normalized.r_pikm_moa_chembl_ids_norm
WHERE abbv_drug_uid is null or abbv_gene_uid is null
union
select
  'r_pikm_moa_chembl_ids_norm' as table_name,
  '2.8' as version,
  count(*) as row_count,
  count(distinct abbvie_drug_uid) as drug_count,
  0 as disease_count,
  count(distinct abbvie_gene_uid) as gene_count
FROM arch_normalized_2_8.r_pikm_moa_chembl_ids_norm
union
select
  'r_pikm_moa_chembl_ids_norm (unmatched)' as table_name,
  '2.8' as version,
  count(*) as row_count,
  count(distinct abbvie_drug_uid) as drug_count,
  0 as disease_count,
  count(distinct abbvie_gene_uid) as gene_count
FROM arch_normalized_2_8.r_pikm_moa_chembl_ids_norm_unmatched
union
select
  'scopiarx_ae_main_db_norm' as table_name,
  '2.7' as version,
  count(*) as row_count,
  count(distinct abbvie_drug_uid) as drug_count,
  count(distinct abbvie_disease_uid) as disease_count,
  0 as gene_count
FROM arch_normalized.scopiarx_ae_main_db_norm
WHERE abbvie_drug_uid is not null and abbvie_disease_uid is not null
union
select
  'scopiarx_ae_main_db_norm (unmatched)' as table_name,
  '2.7' as version,
  count(*) as row_count,
  count(distinct abbvie_drug_uid) as drug_count,
  count(distinct abbvie_disease_uid) as disease_count,
  0 as gene_count
FROM arch_normalized.scopiarx_ae_main_db_norm
WHERE abbvie_drug_uid is null or abbvie_disease_uid is null
union
select
  'scopiarx_ae_main_db_norm' as table_name,
  '2.8' as version,
  count(*) as row_count,
  count(distinct abbvie_drug_uid) as drug_count,
  count(distinct abbvie_disease_uid) as disease_count,
  0 as gene_count
FROM arch_normalized_2_8.scopiarx_ae_main_db_norm
union
select
  'scopiarx_ae_main_db_norm (unmatched)' as table_name,
  '2.8' as version,
  count(*) as row_count,
  count(distinct abbvie_drug_uid) as drug_count,
  count(distinct abbvie_disease_uid) as disease_count,
  0 as gene_count
FROM arch_normalized_2_8.scopiarx_ae_main_db_norm_unmatched
union
select
  'scopiarx_di_main_db_norm (d1)' as table_name,
  '2.7' as version,
  count(*) as row_count,
  count(distinct abbvie_drug1_uid) as drug_count,
  0 as disease_count,
  0 as gene_count
FROM arch_normalized.scopiarx_di_main_db_norm
WHERE abbvie_drug1_uid is not null
union
select
  'scopiarx_di_main_db_norm (d1) (unmatched)' as table_name,
  '2.7' as version,
  count(*) as row_count,
  count(distinct abbvie_drug1_uid) as drug_count,
  0 as disease_count,
  0 as gene_count
FROM arch_normalized.scopiarx_di_main_db_norm
WHERE abbvie_drug1_uid is null
union
select
  'scopiarx_di_main_db_norm (d1)' as table_name,
  '2.8' as version,
  count(*) as row_count,
  count(distinct abbvie_drug1_uid) as drug_count,
  0 as disease_count,
  0 as gene_count
FROM arch_normalized_2_8.scopiarx_di_main_db_norm
union
select
  'scopiarx_di_main_db_norm (d1) (unmatched)' as table_name,
  '2.8' as version,
  count(*) as row_count,
  count(distinct abbvie_drug1_uid) as drug_count,
  0 as disease_count,
  0 as gene_count
FROM arch_normalized_2_8.scopiarx_di_main_db_norm_unmatched
union
select
  'scopiarx_di_main_db_norm (d2)' as table_name,
  '2.7' as version,
  count(*) as row_count,
  count(distinct abbvie_drug2_uid) as drug_count,
  0 as disease_count,
  0 as gene_count
FROM arch_normalized.scopiarx_di_main_db_norm
WHERE abbvie_drug2_uid is not null
union
select
  'scopiarx_di_main_db_norm (d2) (unmatched)' as table_name,
  '2.7' as version,
  count(*) as row_count,
  count(distinct abbvie_drug2_uid) as drug_count,
  0 as disease_count,
  0 as gene_count
FROM arch_normalized.scopiarx_di_main_db_norm
WHERE abbvie_drug2_uid is null
union
select
  'scopiarx_di_main_db_norm (d2)' as table_name,
  '2.8' as version,
  count(*) as row_count,
  count(distinct abbvie_drug2_uid) as drug_count,
  0 as disease_count,
  0 as gene_count
FROM arch_normalized_2_8.scopiarx_di_main_db_norm
union
select
  'scopiarx_di_main_db_norm (d2) (unmatched)' as table_name,
  '2.8' as version,
  count(*) as row_count,
  count(distinct abbvie_drug2_uid) as drug_count,
  0 as disease_count,
  0 as gene_count
FROM arch_normalized_2_8.scopiarx_di_main_db_norm_unmatched
""",format='df',rows=0)