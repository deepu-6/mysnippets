import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)
from pyspark.sql.functions import col,element_at,split
from pyspark.sql.types import FloatType
from archwelder import *

w = Welder(config = WelderConfig(config_file="config.json"))
arch = w.ignite('arch')
arch_neo4j = w.ignite('arch_neo4j')
print(arch.spark.sparkContext.getConf().get('spark.ui.proxyRedirectUri'))

k = KnowledgeGraphBuilder(database_ds=arch,graph_ds=arch_neo4j)


df_existing_seqs = arch_neo4j.query("MATCH (ps:ProteinSequence) RETURN DISTINCT ps.ID AS EXISTING_ID",format='df',rows=0)
df_seqs = arch.spark.table("ark.t_protein_sequence_entities").filter("LABEL IS NOT NULL").filter("ID IS NOT NULL").dropDuplicates()\
  .join(df_existing_seqs,col('ID')==col('EXISTING_ID'),"leftouter").filter(col('EXISTING_ID').isNull())

if df_seqs.count()>0:
  label_df = arch.query("SELECT DISTINCT LABEL FROM ark.t_protein_sequence_entities",format='df',rows=0).dropDuplicates()

  ent_config = {
      "labels": [str(x.LABEL) for x in label_df.collect()],
      "key_column": "ID",
      "property_columns": ','.join([c for c in df_seqs.columns if c not in ['ID', 'LABEL']])
  }

  k.write_entities(df_seqs,ent_config)

config = {
  "table_name":"",
  "rel_type_field":"",
  "rel_properties_fields":[],
  "source_key_field":"",
  "source_label":[],
  "target_key_field":"",
  "target_label":[]
}

df_seq_rels = arch.spark.table("ark.t_protein_sequence_relationships").select(
    col("ENTITY1"),
    col("ENTITY1_TYPE"),
    col("ENTITY2"),
    col("ENTITY2_TYPE"),
    col("REL_TYPE"),
    col("STRENGTH"),
    col("RESULT"),
    col("RESULT_TYPE"),
    col("CONFIDENCE").cast(FloatType()),
    col("LINEAGE.*")
).filter("ENTITY1 IS NOT NULL").filter("ENTITY2 IS NOT NULL")
rels_df = arch.spark.sql("SELECT DISTINCT ENTITY1_TYPE, REL_TYPE, ENTITY2_TYPE FROM ark.t_protein_sequence_relationships").dropDuplicates()

rels_df.printSchema()
e1_ref = {
    "labels": [str(x.ENTITY1_TYPE) for x in rels_df.select(col("ENTITY1_TYPE")).distinct().collect()],
    "key_column": "ENTITY1"
}
e2_ref = {
    "labels": [str(x.ENTITY2_TYPE) for x in rels_df.select(col("ENTITY2_TYPE")).distinct().collect()],
    "key_column": "ENTITY2"
}
rel_ref = {
    "labels": [str(x.REL_TYPE) for x in rels_df.select(col("REL_TYPE")).distinct().collect()],
    "property_columns": ','.join(
        [c for c in df_seq_rels.columns if c not in ['ENTITY1', 'ENTITY1_TYPE', 'ENTITY2', 'ENTITY2_TYPE', 'REL_TYPE']]
    )
}

k.write_relationships(df=df_seq_rels,rel_config=rel_ref,src_config=e1_ref,tgt_config=e2_ref)
