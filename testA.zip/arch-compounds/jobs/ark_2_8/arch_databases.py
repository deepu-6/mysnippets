import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)
from pyspark.sql.functions import col,element_at,split
from archwelder import *

w = Welder(config = WelderConfig(config_file="config.json"))
arch = w.ignite('arch')
print(arch.spark.sparkContext.getConf().get('spark.ui.proxyRedirectUri'))

arch_version='_2_8'

arch_databases = [
  'academe',
  'dependency',
  'arch_normalized',
  'ark'
]

for db in [d+arch_version for d in arch_databases]:
  print(db)
  arch.query("CREATE DATABASE IF NOT EXISTS "+db,format='df',rows=0)



