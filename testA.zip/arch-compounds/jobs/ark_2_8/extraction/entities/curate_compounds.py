import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)
from pyspark.sql.functions import col,element_at,split
from archwelder import *

w = Welder(config = WelderConfig(config_file="config.json"))
arch = w.ignite('arch')
print(arch.spark.sparkContext.getConf().get('spark.ui.proxyRedirectUri'))

count_df = arch.query(query="select max(batch)+1 from academe_2_8.compounds_v",format='df',rows=0)
batch_count = count_df.collect()[0][0]
logging.info('total batches in ER table: '+str(batch_count))

batch_number = 0

while batch_number<batch_count:
  logging.info('processing batch: '+str(batch_number))

  comps = arch.query("""
  select  distinct
    ':Compound' as LABEL,
    compound_uid as ID,
    chembl_id AS CHEMBL_ID,
    case
      when ABBVIE_ID like 'A-%' then ABBVIE_ID
      when ABBVIE_ID like 'PR-%' then ABBVIE_ID
      when ABBVIE_ID like 'DC-%' then ABBVIE_ID
    else NULL
    end as ABBVIE_ID,
    c.inchi_key AS INCHI_KEY,
    root_inchi_key AS ROOT_INCHI_KEY,
    molecule_type AS MOLECULE_TYPE,
    case 
      when array_contains(c.other_sources,'ABBVIE') = 1 then 'AbbVie'
      when array_contains(c.other_sources,'CHEMBL') = 1 then 'ChEMBL'
      when array_contains(c.other_sources,'GOSTAR') = 1 then 'GOSTAR'
      when array_contains(c.other_sources,'WOMBAT') = 1 then 'Wombat'
      when array_contains(c.other_sources,'SOLVAY') = 1 then 'Solvay'
      when array_contains(c.other_sources,'INTEGRITY') = 1 then 'Integrity'
      when array_contains(c.other_sources,'DRUGMATRIX') = 1 then 'DrugMatrix'
      else c.other_sources[0]
    end as PRIMARYSOURCE,
    case 
      when array_contains(c.other_sources,'ABBVIE') = 1 then c.identifier_map["ABBVIE"][0]
      when array_contains(c.other_sources,'CHEMBL') = 1 then c.identifier_map["CHEMBL"][0]
      when array_contains(c.other_sources,'GOSTAR') = 1 then c.identifier_map["GOSTAR"][0]
      when array_contains(c.other_sources,'WOMBAT') = 1 then c.identifier_map["WOMBAT"][0]
      when array_contains(c.other_sources,'SOLVAY') = 1 then c.identifier_map["SOLVAY"][0]
      when array_contains(c.other_sources,'INTEGRITY') = 1 then c.identifier_map["INTEGRITY"][0]
      when array_contains(c.other_sources,'DRUGMATRIX') = 1 then c.identifier_map["DRUGMATRIX"][0]
      else c.other_identifiers[0]
    end as PRIMARYIDENTIFIER,
    case 
      when array_contains(c.other_sources,'ABBVIE') = 1 then c.identifier_map["ABBVIE"][0]
      when array_contains(c.other_sources,'CHEMBL') = 1 then c.identifier_map["CHEMBL"][0]
      when array_contains(c.other_sources,'GOSTAR') = 1 then c.identifier_map["INCHI_KEY"][0]
      when array_contains(c.other_sources,'WOMBAT') = 1 then c.identifier_map["INCHI_KEY"][0]
      when array_contains(c.other_sources,'SOLVAY') = 1 then c.identifier_map["INCHI_KEY"][0]
      when array_contains(c.other_sources,'INTEGRITY') = 1 then c.identifier_map["INCHI_KEY"][0]
      when array_contains(c.other_sources,'DRUGMATRIX') = 1 then c.identifier_map["INCHI_KEY"][0]
      else c.inchi_key
    end as PREFERRED_NAME,
    other_sources as SOURCES,
    other_identifiers as IDENTIFIERS,
    named_struct(
        "SOURCES",array("academe3.compounds_v"),
        "FILTERS","",
        "TIMESTAMP",unix_timestamp(),
        "VERSION","1.3.0"
    ) as LINEAGE,  
    chem.concept_id as TELLIC_ID,
    c.batch as BATCH
  from 
  academe_2_8.compounds_v c
  left outer join tellic_abbvie.tellic_graph_data_node_chem_subset chem  
  on c.inchi_key=chem.inchi_key
  where c.batch={batch_number}
  """.format(batch_number=batch_number),format='df',rows=0)

  arch.saveARCHTable(comps,
                         environment='prod',
                         data_store='integrated',
                         db_name='ark_2_8',
                         set_name='t_compound_entities',
                         partitions=1,
                         partitionBy='batch')
  batch_number += 1
  