import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)
from pyspark.sql.functions import col,element_at,split
from archwelder import *

w = Welder(config = WelderConfig(config_file="config.json"))
arch = w.ignite('arch')
print(arch.spark.sparkContext.getConf().get('spark.ui.proxyRedirectUri'))

count_df = arch.query(query="select max(batch)+1 from academe_2_8.drug_concept_v",format='df',rows=0)
batch_count = count_df.collect()[0][0]
logging.info('total batches in ER table: '+str(batch_count))

batch_number = 0

while batch_number<batch_count:
  logging.info('processing batch: '+str(batch_number))
  drugs = arch.query("""
    SELECT DISTINCT
      LABEL,
      ID,
      MOLECULE_ID,
      PREFERRED_NAME,
      collect_set(CHEMBL_ID) as CHEMBL_ID,
      MAX_PHASE,
      concat_ws(',',collect_set(USAN_STEM_DEFINITION)) as USAN_STEM_DEFINITION,
      ATC_CLASS,
      collect_set(SYNONYMS) as SYNONYMS,
      collect_set(NDCS) as NDCS,
      PROPRIETARYNAME,
      NUM_COMPONENTS,
      COMPONENT_NAMES,
      collect_set(moa) as MOA,
      named_struct(
            "SOURCES",array("arch_normalized3.r_moa_ids_norm","academe3.drug_concept_v"),
            "FILTERS","",
            "TIMESTAMP",unix_timestamp(),
            "VERSION","1.3.0"
            ) as LINEAGE,
      BATCH
    FROM (
      SELECT DISTINCT
        concat(':Drug') as LABEL,
        drugs.abbv_uid as ID,
        drugs.abbv_term as MOLECULE_ID,--drugs.abbv_code as MOLECULE_ID,
        drugs.abbv_term as PREFERRED_NAME,
        drugs.chembl_id as CHEMBL_ID,
        cast(drugs.abbv_max_phase as integer) as MAX_PHASE,
        CASE
          WHEN chembl_usan_stem_definition like '' THEN null
          ELSE chembl_usan_stem_definition 
        END as USAN_STEM_DEFINITION,
        drugs.abbv_atc_class_term[0] as ATC_CLASS,
        array_distinct(concat(drugs.abbv_trade_names,drugs.abbvdrug_term,ndc_trade_names,chembl_syns,integrity_terms,cortellis_trade_names,cortellis_syns,ncit_syns)) as SYNONYMS,
        drugs.ndc_term as NDCS,
        drugs.abbv_trade_names[0] as PROPRIETARYNAME,
        cast(drugs.abbv_num_comp as int) as NUM_COMPONENTS,
        drugs.abbv_comp_names as COMPONENT_NAMES,
        moa.ensembl_hgnc_symbol as MOA,
        drugs.batch
      FROM academe_2_8.drug_concept_v drugs
      LEFT JOIN arch_normalized_2_8.r_moa_ids_norm moa ON 
        drugs.abbv_uid=moa.abbvie_drug_uid
      WHERE drugs.batch={batch_number}
    ) d
    GROUP BY LABEL,ID,MOLECULE_ID,PREFERRED_NAME,MAX_PHASE,ATC_CLASS,PROPRIETARYNAME,NUM_COMPONENTS,COMPONENT_NAMES,batch
    """.format(batch_number=batch_number),format='df',rows=0)
  
  arch.saveARCHTable(drugs,
                         environment='prod',
                         data_store='integrated',
                         db_name='ark_2_8',
                         set_name='t_drug_entities',
                         partitions=1,
                         partitionBy='batch')
  batch_number+=1