import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)
from pyspark.sql.functions import col,element_at,split
from archwelder import *

w = Welder(config = WelderConfig(config_file="config.json"))
arch = w.ignite('arch')
print(arch.spark.sparkContext.getConf().get('spark.ui.proxyRedirectUri'))

count_df = arch.query(query="select count(*) from arch_normalized_2_8.scopiarx_di_main_db_norm",format='df',rows=0)
row_count = count_df.collect()[0][0]
logging.info('total rows in ER table: '+str(row_count))

ddis = arch.query("""
  SELECT DISTINCT
    ':DDI' as LABEL,
    CASE 
        WHEN EMBL_DI > EMBL_DPS then concat(ABBVIE_DRUG2_UID, '|', ABBVIE_DRUG1_UID) 
        ELSE concat(ABBVIE_DRUG1_UID, '|', ABBVIE_DRUG2_UID)  
    END as ID,
    CASE 
        WHEN EMBL_DI > EMBL_DPS then concat(drug2_er_abbv_term, '|', drug1_er_abbv_term) 
        ELSE concat(drug1_er_abbv_term, '|', drug2_er_abbv_term)  
    END as PREFERRED_NAME,
    CASE 
        WHEN EMBL_DI > EMBL_DPS then concat(drug2_er_abbv_term, '|', drug1_er_abbv_term)
        ELSE concat(drug1_er_abbv_term, '|', drug2_er_abbv_term)  
    END as DDI,
    CASE 
        WHEN EMBL_DI > EMBL_DPS then concat(ABBVIE_DRUG2_UID, '|', ABBVIE_DRUG1_UID) 
        ELSE concat(ABBVIE_DRUG1_UID, '|', ABBVIE_DRUG2_UID)  
    END as DDI_ID,
    named_struct(
        "SOURCES",array("scopiarx.di_main_db_norm"),
        "FILTERS","",
        "TIMESTAMP",unix_timestamp(),
        "VERSION","1.5"
    ) as LINEAGE
  FROM arch_normalized_2_8.scopiarx_di_main_db_norm
  WHERE 
    ABBVIE_DRUG1_UID is NOT NULL 
    and ABBVIE_DRUG2_UID is NOT NULL
""",format='df',rows=0)

arch.saveARCHTable(ddis,
                       environment='prod',
                       data_store='integrated',
                       db_name='ark_2_8',
                       set_name='t_ddi_entities',
                       partitions=1,
                       partitionBy=None)
  