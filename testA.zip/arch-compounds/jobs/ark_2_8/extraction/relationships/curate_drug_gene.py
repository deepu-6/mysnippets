import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)
from pyspark.sql.functions import col,element_at,split
from archwelder import *

w = Welder(config = WelderConfig(config_file="config.json"))
arch = w.ignite('arch')
print(arch.spark.sparkContext.getConf().get('spark.ui.proxyRedirectUri'))

count_df = arch.query(query="select count(*) from arch_normalized_2_8.r_moa_ids_norm",format='df',rows=0)
row_count = count_df.collect()[0][0]
logging.info('total rows in source table: '+str(row_count))

rels = arch.query("""
  SELECT DISTINCT
    t1.abbvie_drug_uid as ENTITY1,
    ':Drug' as ENTITY1_TYPE,
    t1.abbvie_gene_uid as ENTITY2,
    ':Gene' as ENTITY2_TYPE,
    'HAS_MOA' as REL_TYPE,
    4 as STRENGTH,
    1 as RESULT,
    'Activity' as RESULT_TYPE,
    1.0 as CONFIDENCE,
    named_struct(
      "RULESETS",array(""),
      "SOURCES",array("arch_normalized3.r_moa_ids_norm"),
      "FILTERS",array(""),
      "TIMESTAMP",unix_timestamp(),
      "VERSION","1.3.0"
    ) as LINEAGE,
    named_struct(
      "MODALITY","Activity",
      "PARENT_ID",t1.PARENT_ID,
      "MOLECULE_ID",t1.MOLECULE_ID,
      "TARGET",t1.TARGET,
      "ACTION_TYPE",t1.ACTION_TYPE,
      "MOA",t1.MOA,
      "SOURCE",t1.SOURCE,
      "REFERENCES",t1.REFERENCES
    ) as METADATA
FROM arch_normalized_2_8.r_moa_ids_norm t1 
WHERE t1.abbvie_drug_uid is not null and t1.abbvie_gene_uid is not null
""",format='df',rows=0)

arch.saveARCHTable(rels,
                       environment='prod',
                       data_store='integrated',
                       db_name='ark_2_8',
                       set_name='t_drug_gene_relationships',
                       partitions=1,
                       partitionBy=None)
  
  