import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)
from pyspark.sql.functions import col,element_at,split
from archwelder import *

w = Welder(config = WelderConfig(config_file="config.json"))
arch = w.ignite('arch')
print(arch.spark.sparkContext.getConf().get('spark.ui.proxyRedirectUri'))

rels = arch.query("""
with normalized_view as (
SELECT *,
CASE WHEN EMBL_DI > EMBL_DPS then array(ABBVIE_DRUG2_UID, ABBVIE_DRUG1_UID) 
    ELSE array(ABBVIE_DRUG1_UID, ABBVIE_DRUG2_UID)  END as DDI,
CASE WHEN EMBL_DI > EMBL_DPS then array(EMBL_DPS, EMBL_DI) 
    ELSE array(EMBL_DI, EMBL_DPS) END as DDI_ID,
CASE WHEN INTERACTION_CODE_1 ='min' OR INTERACTION_CODE_2 = 'min' THEN 'Minor'
	WHEN INTERACTION_CODE_1 = 'mod' OR INTERACTION_CODE_2 = 'mod' THEN 'Moderate'
	WHEN INTERACTION_CODE_1 = 'sev' OR INTERACTION_CODE_2 = 'sev' THEN 'Severe'
	WHEN INTERACTION_CODE_1 = 'contra' OR INTERACTION_CODE_2 = 'contra' THEN 'Contra-indicated'
	ELSE 'Not Specified in Label' END as MAGNITUDE,
CASE WHEN INTERACTION_CODE_1 ='w' OR INTERACTION_CODE_2 = 'w' THEN 'Warning'
	WHEN INTERACTION_CODE_1 = 'bw' OR INTERACTION_CODE_2 = 'bw' THEN 'Box Warning'
	WHEN INTERACTION_CODE_1 = 'ca' OR INTERACTION_CODE_2 = 'ca' THEN 'Caution'
	WHEN INTERACTION_CODE_1 = 'contra' OR INTERACTION_CODE_2 = 'contra' THEN 'Contra-indicated'
	ELSE 'Not Specified in Label' END as SEVERITY,
CASE WHEN INTERACTION_CODE_1 ='contra' OR INTERACTION_CODE_2 = 'contra' THEN 4
	WHEN INTERACTION_CODE_1 = 'sev' OR INTERACTION_CODE_2 = 'sev' THEN 3
	WHEN INTERACTION_CODE_1 = 'mod' OR INTERACTION_CODE_2 = 'mod' THEN 2
	ELSE 1 END as STRENGTH,
CASE WHEN EXPLICIT_FLAG_1 = 't' or EXPLICIT_FLAG_2 = 't' THEN 'Yes'
	ELSE 'No' END as EXPLICIT_INTERACTION,
CASE WHEN LENGTH(SOURCE_RXCLASS_1) > 0 and LENGTH(SOURCE_RXCLASS_2) > 0 THEN concat(SOURCE_RXCLASS_1,'|',SOURCE_RXCLASS_2)
	WHEN LENGTH(SOURCE_RXCLASS_1) > 0 THEN SOURCE_RXCLASS_1
	WHEN LENGTH(SOURCE_RXCLASS_2) > 0 THEN SOURCE_RXCLASS_2
	ELSE '' END as CLASS_EFFECT,
CASE WHEN EXPLICIT_FLAG_1 = 't' and EXPLICIT_FLAG_2 = 't' THEN 1.0
	WHEN EXPLICIT_FLAG_1 = 't' and EXPLICIT_FLAG_2 = 'f' THEN 0.9
	WHEN EXPLICIT_FLAG_1 = 't' THEN 0.8
	WHEN EXPLICIT_FLAG_1 = 'f' and EXPLICIT_FLAG_2 = 't' THEN 0.9
	WHEN EXPLICIT_FLAG_1 = 'f' and EXPLICIT_FLAG_2 = 'f' THEN 0.8
	WHEN EXPLICIT_FLAG_1 = 'f' THEN 0.8
	ELSE 0.7 END as CONFIDENCE
FROM arch_normalized_2_8.scopiarx_di_main_db_norm 
where NUM_IDS1 = 1 and NUM_IDS2 = 1 and ABBVIE_DRUG1_UID is not null and ABBVIE_DRUG2_UID is not null and ABBVIE_DISEASE_UID is not null
)
,relationship_rule as (SELECT
concat_ws('|',DDI) as ENTITY1,
':DDI' as ENTITY1_TYPE,
ABBVIE_DISEASE_UID as ENTITY2,
':Patient Adverse Event' as ENTITY2_TYPE,
'HAS_MODULATED_AE' as RELATIONSHIP,
STRENGTH,
CONFIDENCE,
nvl(cast(SCORE as integer),0) as RESULT,
"ScopiaRX Score" as RESULT_TYPE,
named_struct(
	"RULESETS","",
	"SOURCES",array("arch_normalized3.scopiarx_di_main_db_norm "),
	"FILTERS",array(""),
	"TIMESTAMP",unix_timestamp(),
	"VERSION","1.5"
	) as LINEAGE,
named_struct(
	"AI_DI",AI_DI,
	"AI_DPS",AI_DPS,
	"EMBL_DI",EMBL_DI,
	"EMBL_DPS",EMBL_DPS,
	"DI_ROUTE",DI_ROUTE,
	"DPS_ROUTE",DPS_ROUTE,
	"AE",AE,
	"AE_ID",AE_ID,
	"SEVERITY", SEVERITY,
	"MAGNITUDE", MAGNITUDE,
	"EXPLICIT_INTERACTION", EXPLICIT_INTERACTION,
	"CLASS_EFFECT", CLASS_EFFECT,
	"SOURCE_RXCLASS_1", SOURCE_RXCLASS_1,
	"EXPLICIT_FLAG_1", EXPLICIT_FLAG_1,
	"SOURCE_RXCLASS_2", SOURCE_RXCLASS_2,
	"EXPLICIT_FLAG_2", EXPLICIT_FLAG_2,
	"SOURCE_LABEL_1", SOURCE_LABEL_1,
	"INTERACTION_CODE_1", INTERACTION_CODE_1,
	"SOURCE_LABEL_2", SOURCE_LABEL_2,
	"INTERACTION_CODE_2", INTERACTION_CODE_2,
	"INTERACTION_TYPE_1", INTERACTION_TYPE_1,
	"INTERACTION_TYPE_2", INTERACTION_TYPE_2,
	"SOURCE", 'ScopiaRx - DI'
	) as METADATA
from  normalized_view
)
SELECT ENTITY1, ENTITY1_TYPE, ENTITY2, ENTITY2_TYPE, RELATIONSHIP as REL_TYPE, STRENGTH, CONFIDENCE, RESULT, RESULT_TYPE, LINEAGE, METADATA from(
SELECT *,row_number() over(partition by ENTITY1,ENTITY2 order by ENTITY1) as ROWNUM 
from relationship_rule
)t where ROWNUM=1 and ENTITY2 <> 'noae'
""",format='df',rows=0)

arch.saveARCHTable(rels,
                       environment='prod',
                       data_store='integrated',
                       db_name='ark_2_8',
                       set_name='t_ddi_adverseevent_relationships',
                       partitions=1,
                       partitionBy=None)
  
  