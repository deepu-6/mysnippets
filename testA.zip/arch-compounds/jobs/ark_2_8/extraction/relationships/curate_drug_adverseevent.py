import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)
from pyspark.sql.functions import col,element_at,split
from archwelder import *

w = Welder(config = WelderConfig(config_file="config.json"))
arch = w.ignite('arch')
print(arch.spark.sparkContext.getConf().get('spark.ui.proxyRedirectUri'))

rels = arch.query("""
with cortellis_clinical_trials_ae as (
Select
    abbvie_drug_uid as c_ENTITY1,
    ':Drug' as c_ENTITY1_TYPE,
    abbvie_disease_uid as c_ENTITY2,
    ':Adverse Event' as c_ENTITY2_TYPE,
    'HAS_ADVERSE_EVENT' as c_REL_TYPE,
    case
        when Reporting_Frequency_Mean >= 10 THEN 3
        when Reporting_Frequency_Mean >= 1 THEN 2
        when Reporting_Frequency_Mean >= 0.1 THEN 1
        else 0 
    end as c_STRENGTH,
    null as c_RESULT,
    null as c_RESULT_TYPE,
    1.0  as c_CONFIDENCE,
    named_struct(
        "RULESETS",array(""),
        "SOURCES",array("arch_normalized_2_8.abcxunp1_abbvie_cortellis_clinical_trials_ae_norm"),
        "FILTERS",array(""),
        "TIMESTAMP",unix_timestamp(),
        "VERSION","1.4.0"
        ) as c_LINEAGE,
        named_struct(
        "DRUG_NAME",upper(DRUG_NAME),
        "INDICATION_NAME",upper(INDICATION_NAME),
        "REPORTING_FREQUENCY_MEAN",REPORTING_FREQUENCY_MEAN,
        "REPORTING_FREQUENCY_N",REPORTING_FREQUENCY_N,
        "REPORTING_FREQUENCY_RANGE",REPORTING_FREQUENCY_RANGE,
        "SOURCE","SOURCE"
    ) as c_METADATA
from
arch_normalized_2_8.abcxunp1_abbvie_cortellis_clinical_trials_ae_norm cae
where 1=1
and abbvie_drug_uid is not null 
and abbvie_disease_uid is not null
--and lower(DRUG_NAME) = 'veliparib'
)
,scopia_ae_main as (
select *
from dependency_2_8.v_scopia_drug_ae_relationships_knwlextract_dep
where 1=1
and entity1 is not null 
and entity2 is not null 
--and entity1 = '4a1f2946bee5d577d1cd2da7dd557a81'
)
,scopia_cortellis as (
select 
    cort.c_ENTITY1 as ENTITY1, 
    cort.c_ENTITY1_TYPE as ENTITY1_TYPE,
    cort.c_ENTITY2 as ENTITY2,
    cort.c_ENTITY2_TYPE as ENTITY2_TYPE,
    scop.entity1 as sc_entity1,
    scop.entity2 as sc_entity2,
    scop.ENTITY1_TYPE as sc_entity1_type,
    scop.ENTITY2_TYPE as sc_entity2_type,
    scop.REL_TYPE as REL_TYPE,
    scop.STRENGTH as STRENGTH,
    round(scop.RESULT,2) as RESULT,
    scop.RESULT_TYPE as RESULT_TYPE,
    scop.CONFIDENCE as CONFIDENCE,
    cort.c_metadata.INDICATION_NAME,
    cort.c_metadata.DRUG_NAME,
    scop.metadata.EMBL_CODE,
    scop.metadata.MEDDRA_CODE,
    scop.metadata.SCORE,
    scop.metadata.CODES,
    scop.metadata.ae as SCOPIA_AE,
    scop.metadata.ai as SCOPIA_AI,
    scop.METADATA.onlabel as ON_LABEL,
    scop.METADATA.FREQUENCY,
    case when scop.METADATA.severity is null then 'Not Specified'
    else scop.METADATA.severity end as SEVERITY,
    scop.METADATA.AES as REPORTS_WITH_AE,
    scop.METADATA.REPORTS as TOTAL_REPORTS,
    round(scop.RESULT,2) as REPORTED_FREQUENCY,
    round(cort.c_METADATA.REPORTING_FREQUENCY_MEAN,2) as CLINICAL_TRIAL_REPORTED_FREQUENCY,
    cort.c_METADATA.REPORTING_FREQUENCY_N as TRIALS,
    cort.c_metadata.REPORTING_FREQUENCY_RANGE as `RANGE`
from cortellis_clinical_trials_ae cort full outer join scopia_ae_main scop
on 1=1
and cort.c_entity1 = scop.entity1
and cort.c_entity2 = scop.entity2
)
,ae_from_scopia_exists as(
select
    ENTITY1,
    ENTITY1_TYPE,
    ENTITY2,
    ENTITY2_TYPE,
    REL_TYPE,
    STRENGTH,
    RESULT,
    RESULT_TYPE,
    CONFIDENCE,
    INDICATION_NAME,
    DRUG_NAME,
    SCOPIA_AE,
	SCOPIA_AI,
    MEDDRA_CODE,
	EMBL_CODE,
	SCORE,
	CODES,
    ON_LABEL,
    FREQUENCY,
    SEVERITY,
    REPORTS_WITH_AE,
    TOTAL_REPORTS,
    REPORTED_FREQUENCY,
    cast('Yes' as string) as TRIAL_SAFETY_DATA_AVAILABLE,
    CLINICAL_TRIAL_REPORTED_FREQUENCY,
    TRIALS,
    `RANGE`
from scopia_cortellis
where entity2 is not null and sc_entity2 is not null
)
,ae_from_scopia_does_not_exists as (
select
    ENTITY1,
    ENTITY1_TYPE,
    ENTITY2,
    ENTITY2_TYPE,
    'HAS_SIDE_EFFECT' as REL_TYPE,
    1 as STRENGTH,
    RESULT,
    RESULT_TYPE,
    0.5 as CONFIDENCE,
    INDICATION_NAME,
    DRUG_NAME,
    SCOPIA_AE,
	SCOPIA_AI,
    MEDDRA_CODE,
	EMBL_CODE,
	SCORE,
	CODES,
    cast('N' as string) as ON_LABEL,
    FREQUENCY,
    SEVERITY,
    REPORTS_WITH_AE,
    TOTAL_REPORTS,
    REPORTED_FREQUENCY,
    cast('Yes' as string) as TRIAL_SAFETY_DATA_AVAILABLE,
    CLINICAL_TRIAL_REPORTED_FREQUENCY,
    TRIALS,
    `RANGE`
from scopia_cortellis
where sc_entity2 is null
)
,ae_from_cortellis_does_not_exists as (
select 
    sc_entity1 as ENTITY1,
    sc_entity1_type as ENTITY1_TYPE,
    sc_entity2 as ENTITY2,
    sc_entity2_type as ENTITY2_TYPE,
    REL_TYPE,
    STRENGTH,
    RESULT,
    RESULT_TYPE,
    CONFIDENCE,
--   SCOPIA_AE AS INDICATION_NAME,
--   SCOPIA_AI AS DRUG_NAME,
	INDICATION_NAME,
	DRUG_NAME,
    SCOPIA_AE,
	SCOPIA_AI,
    MEDDRA_CODE,
	EMBL_CODE,
	SCORE,
	CODES,
    ON_LABEL,
    FREQUENCY,
    SEVERITY,
    REPORTS_WITH_AE,
    TOTAL_REPORTS,
    REPORTED_FREQUENCY,
    cast('No' as string) as TRIAL_SAFETY_DATA_AVAILABLE,
    CLINICAL_TRIAL_REPORTED_FREQUENCY,
    TRIALS,
   `RANGE`
from scopia_cortellis
where ENTITY2 is null
)
select DISTINCT
ENTITY1,
ENTITY1_TYPE,
ENTITY2,
':Patient Adverse Event' as ENTITY2_TYPE,
REL_TYPE,
STRENGTH,
RESULT,
RESULT_TYPE,
CONFIDENCE,
named_struct(
      "RULESETS",array(""),
      "SOURCES",array("arch_normalized_2_8.abcxunp1_abbvie_cortellis_clinical_trials_ae_norm","dependency_2_8.v_scopia_drug_ae_relationships_knwlextract_dep","arch_normalized_2_8.scopiarx_ae_main_db_norm","preclinical.t_adverseevent_exclusions","academe_2_8.drug_concept_v","academe.drug_synonyms_v","academe_2_8.health_condition_v"),
      "FILTERS",array(""),
      "TIMESTAMP",unix_timestamp(),
      "VERSION","1.5.0"
) as LINEAGE,
named_struct(
"SRC_CORTELLIS_INDICATION_NAME",INDICATION_NAME,
"SRC_CORTELLIS_DRUG_NAME",DRUG_NAME,
"SRC_SCOPIA_AE",SCOPIA_AE,
"SRC_SCOPIA_AI",SCOPIA_AI,
"SOURCE_ID",cast(MEDDRA_CODE as string),   --added SOURCE_ID column on John request (ARCHO-2694)
"EMBL_CODE",EMBL_CODE,
"SCORE",SCORE,
"CODES",CODES,
"ONLABEL",ON_LABEL,
"FREQUENCY",FREQUENCY,
"SEVERITY",SEVERITY,
"REPORTS_WITH_AE",REPORTS_WITH_AE,
"TOTAL_REPORTS",TOTAL_REPORTS,
"REPORTED_FREQUENCY",REPORTED_FREQUENCY,
"TRIAL_SAFETY_DATA_AVAILABLE",TRIAL_SAFETY_DATA_AVAILABLE,
"CLINICAL_TRIAL_REPORTED_FREQUENCY",CLINICAL_TRIAL_REPORTED_FREQUENCY,
"TRIALS",TRIALS,
"RANGE",`RANGE`,
"SOURCE","Scopia_Cortellis"   -- updated source as mentioned by Lynn in jira ARCHO-2941
) as METADATA  
from
(
select * from ae_from_scopia_exists
union all
select * from ae_from_scopia_does_not_exists
union all
select * from ae_from_cortellis_does_not_exists
)n   
  """,format='df',rows=0)

arch.saveARCHTable(rels,
                       environment='prod',
                       data_store='integrated',
                       db_name='ark_2_8',
                       set_name='t_drug_adverseevent_relationships',
                       partitions=1,
                       partitionBy=None)

  