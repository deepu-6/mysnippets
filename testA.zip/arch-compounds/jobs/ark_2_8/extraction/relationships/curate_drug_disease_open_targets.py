import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)
from pyspark.sql.functions import col,element_at,split
from archwelder import *

w = Welder(config = WelderConfig(config_file="config.json"))
arch = w.ignite('arch')
print(arch.spark.sparkContext.getConf().get('spark.ui.proxyRedirectUri'))



count_df = arch.query(query="select count(*) from arch_normalized_2_8.open_targets_drug_indications_norm",format='df',rows=0)
row_count = count_df.collect()[0][0]
logging.info('total rows in source table: '+str(row_count))

rels = arch.query("""
  SELECT
    t1.ENTITY1,
    t1.ENTITY1_TYPE,
    t1.ENTITY2,
    t1.ENTITY2_TYPE,
    t1.REL_TYPE,
    t1.STRENGTH,
    t1.RESULT,
    t1.RESULT_TYPE,
    t1.CONFIDENCE,
    t1.LINEAGE,
    t1.METADATA
  FROM (
    SELECT 
      abbvie_drug_uid as ENTITY1,
      ":Drug" as ENTITY1_TYPE,
      abbvie_disease_uid as ENTITY2,
      ":Disease" as ENTITY2_TYPE,
      CASE
        WHEN cast(maxPhaseForIndication as int) = 4 THEN "APPROVED_TREATMENT_FOR"
        ELSE "TESTED_IN_CLINICAL_TRIALS_FOR"
      END AS REL_TYPE,
      cast(maxPhaseForIndication as int) as STRENGTH,
      1 as RESULT,
      "Membership" as RESULT_TYPE,
      1.0 as CONFIDENCE,
      named_struct(
        "RULESETS",array(""),
        "SOURCES",array("arch_normalized3.open_targets_drug_indications_norm"),
        "FILTERS",array(""),
        "TIMESTAMP",unix_timestamp(),
        "VERSION","1.4.0"
      ) as LINEAGE,
      named_struct(
        "EFONAME",efoName,
        "MAXPHASEFORINDICATION",cast(maxPhaseForIndication as int),
        "DISEASE",disease,
        "APPROVED",concat_ws(',',approved),
        "DRUG_ID",drug_id,
        "SOURCE","OpenTargets"
      ) as METADATA, 
      row_number() over (partition by abbvie_drug_uid,abbvie_disease_uid order by cast(maxPhaseForIndication as int) desc) as rownum -- Added row_number() to remove duplicate drug indications as mentioned in jira ARCHO-3150
    FROM arch_normalized_2_8.open_targets_drug_indications_norm
  ) t1 
  WHERE rownum = 1
""",format='df',rows=0)

arch.saveARCHTable(rels,
                       environment='prod',
                       data_store='integrated',
                       db_name='ark_2_8',
                       set_name='t_drug_disease_open_targets_relationships',
                       partitions=1,
                       partitionBy=None)
  