import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)
from pyspark.sql.functions import col,element_at,split
from archwelder import *

w = Welder(config = WelderConfig(config_file="config.json"))
arch = w.ignite('arch')
print(arch.spark.sparkContext.getConf().get('spark.ui.proxyRedirectUri'))



count_df = arch.query(query="select count(*) from arch_normalized_2_8.open_targets_drug_indications_norm",format='df',rows=0)
row_count = count_df.collect()[0][0]
logging.info('total rows in source table: '+str(row_count))


rels = arch.query("""
  SELECT DISTINCT
    cc.abbvie_drug_uid as ENTITY1,
    ":Drug" as ENTITY1_TYPE,
    cc.abbvie_disease_uid as ENTITY2,
    ":Disease" as ENTITY2_TYPE,
    "WAS_STUDIED" as REL_TYPE,
    1 as STRENGTH,
    1 as RESULT,
    "Membership" as RESULT_TYPE,
    cast(1 as float) as CONFIDENCE,
    named_struct(
      "RULESETS",array(""),
      "SOURCES",array("arch_normalized3.abcxunp1_abbvie_cortellis_clinical_trials_norm"),
      "FILTERS",array(""),
      "TIMESTAMP",unix_timestamp(),
      "VERSION","1.4.0"
    ) as lineage,
    named_struct(
      "INTERVENTION_NAME",cc.INTERVENTION_NAME,
      "MAXIMUM_DOSE",cc.MAXIMUM_DOSE,
      "MINIMUM_DOSE",cc.MINIMUM_DOSE,
      "DOSE_UNITS",cc.DOSE_UNITS,
      "ROUTE",cc.ROUTE,
      "INDICATION_NAME",cc.INDICATION_NAME,
      "IDENTIFIER_VALUE",cc.IDENTIFIER_VALUE,
      "DRUG_NAME",cc.DRUG_NAME,
      "DRUG_ID",cast(cc.DRUG_ID as double),
      "XTRA_INTERVENTIONS",cc.XTRA_INTERVENTIONS,
      "INTERVENTION_TYPE",cc.INTERVENTION_TYPE,
      "REGIMEN_TYPE",cc.REGIMEN_TYPE,
      "TRIAL_ID",cc.TRIAL_ID,
      "TITLE_DISPLAY",cc.TITLE_DISPLAY,
      "OUTCOMES_AVAILABLE",cc.OUTCOMES_AVAILABLE,
      "ENDPOINTS_ACHIEVED",cc.ENDPOINTS_ACHIEVED,
      "PHASE",cc.PHASE,
      "HARMONIZED_PHASE",cast(cc.HARMONIZED_PHASE as int),
      "RECRUITMENT_STATUS_NAME",cc.RECRUITMENT_STATUS_NAME,
      "NUMBER_OF_SITES",cast(cc.NUMBER_OF_SITES as int),
      "PATIENT_COUNT_ENROLLMENT",cc.PATIENT_COUNT_ENROLLMENT,
      "DATE_START",cc.DATE_START,
      "DATE_END",cc.DATE_END,
      "PRIMARY_COMPLETION_DATE",cc.PRIMARY_COMPLETION_DATE,
      "CRITERIA_INCLUSION",cc.CRITERIA_INCLUSION,
      "CRITERIA_EXCLUSION",cc.CRITERIA_EXCLUSION,
      "ADVERSE_EVENTS",cc.ADVERSE_EVENTS,
      "OUTCOMES",cc.OUTCOMES,
      "SPONSOR",cc.SPONSOR,
      "DOSE_GROUPS",cast(cc.DOSE_GROUP as int),
      "DOSE_RANGE",cc.DOSE_RANGE,
      "REGIMEN_SUMMARY",cc.REGIMEN_SUMMARY,
      "SOURCE",cc.SOURCE
      ) as METADATA
  FROM arch_normalized_2_8.abcxunp1_abbvie_cortellis_clinical_trials_norm cc
""",format='df',rows=0)

arch.saveARCHTable(rels,
                       environment='prod',
                       data_store='integrated',
                       db_name='ark_2_8',
                       set_name='t_drug_disease_cortellis_relationships',
                       partitions=1,
                       partitionBy=None)
  