import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)
from pyspark.sql.functions import col,element_at,split
from archwelder import *

w = Welder(config = WelderConfig(config_file="config.json"))
arch = w.ignite('arch')
print(arch.spark.sparkContext.getConf().get('spark.ui.proxyRedirectUri'))


tables = [
  't_compound_compound_metabolite_relationships',
  't_compound_cv_endpoint_medmsd_relationships',
  't_compound_cv_endpoint_relationships',
  't_compound_endpoint_adme_relationships',
  't_compound_endpoint_medmsd_relationships',
  't_compound_endpoint_relationships',
  't_compound_gene_bioactivity_implied_relationships',
  't_compound_gene_bioactivity_relationships',
  't_compound_gene_form_relationship',
  't_compound_gene_relationships',
  't_compound_pkpairing_dosed_relationships',
  't_compound_pkpairing_measured_relationships',
  't_gene_adverseevent_relationships',
  't_gene_cell_line_relationships',
  't_gene_disease_relationships',
  't_gene_gene_bioprofile_relationships',
  't_gene_gene_form_relationships',
  't_gene_gene_relationships',
  't_gene_pathway_relationships',
  't_gene_phenotype_relationships',
  't_gene_tissue_relationships',
  't_gene_variant_relationships',
  't_pkpairing_endpoint_pk_relationships',
  't_variant_phenotype_relationships'
  
  
]


for t in tables:
  df = arch.spark.table('ark.'+t)

  logging.info('copying table '+t+' with '+str(df.count())+' rows')
  
  arch.saveARCHTable(df,
                         environment='prod',
                         data_store='integrated',
                         db_name='ark_2_8',
                         set_name=t,
                         partitions=1,
                         partitionBy=None)
