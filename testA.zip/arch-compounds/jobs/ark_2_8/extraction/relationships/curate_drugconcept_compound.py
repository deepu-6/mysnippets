import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)
from pyspark.sql.functions import col,element_at,split
from archwelder import *
from datetime import datetime

w = Welder(config = WelderConfig(config_file="config.json"))
arch = w.ignite('arch')
print(arch.spark.sparkContext.getConf().get('spark.ui.proxyRedirectUri'))

count_df = arch.query(query="select max(batch)+1 as cnt from dependency_2_8.drug_concept_compound_xref_v",format='df',rows=0)
batch_count = count_df.collect()[0][0]
logging.info('total batches in XREF table: '+str(batch_count))

batch_number = 0
datestr=datetime.now().strftime('%d%b%Y')

while batch_number<batch_count:
  logging.info('processing batch: '+str(batch_number))

  comps = arch.query("""
SELECT DISTINCT 
    t1.drug_concept_uid as ENTITY1,
    ":Drug" as ENTITY1_TYPE,
    t1.compound_uid as ENTITY2,
    ":Compound" as ENTITY2_TYPE,
    "CONTAINS" as REL_TYPE,
    1 as STRENGTH,
    1 as CONFIDENCE,
    1 as RESULT,
    "Membership" as RESULT_TYPE,
    named_struct(
        "RULESETS",array(""),
        "SOURCES",array("dependency_2_8.drug_concept_compound_xref_v"),
        "FILTERS",array(""),
        "TIMESTAMP",unix_timestamp(),
        "VERSION","1.0.0"
    ) as LINEAGE,
    named_struct(
        "DRUG_CONCEPT_GEN_DATE",t1.drug_concept_gen_date,
        "COMPOUND_GEN_DATE",t1.compound_gen_date,
        "COMMON_ONTOLOGIES",t1.common_ontologies
    ) as METADATA,
    t1.batch as BATCH
FROM dependency_2_8.drug_concept_compound_xref_v t1
WHERE t1.batch={batch_number}
""".format(batch_number=batch_number),format='df',rows=0)

  arch.saveARCHTable(comps,
                         environment='prod',
                         data_store='integrated',
                         db_name='ark_2_8',
                         set_name='t_drug_compound_relationships',
                         partitions=1,
                         partitionBy='batch')
  batch_number += 1
  