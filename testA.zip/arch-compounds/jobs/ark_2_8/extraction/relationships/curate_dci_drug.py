import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)
from pyspark.sql.functions import col,element_at,split
from archwelder import *

w = Welder(config = WelderConfig(config_file="config.json"))
arch = w.ignite('arch')
print(arch.spark.sparkContext.getConf().get('spark.ui.proxyRedirectUri'))

count_df = arch.query(query="select max(batch)+1 from academe.compounds_v",format='df',rows=0)
batch_count = count_df.collect()[0][0]
logging.info('total batches in ER table: '+str(batch_count))

batch_number = 0

while batch_number<batch_count:
  logging.info('processing batch: '+str(batch_number))

  comps = arch.query("""
XXXXX  
  """.format(batch_number=batch_number),format='df',rows=0)

  arch.saveARCHTable(comps,
                         environment='prod',
                         data_store='integrated',
                         db_name='ark',
                         set_name='t_compound_entities',
                         partitions=1,
                         partitionBy='batch')
  batch_number += 1
  