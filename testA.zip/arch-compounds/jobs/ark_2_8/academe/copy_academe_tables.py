import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)
from pyspark.sql.functions import col,element_at,split
from archwelder import *

w = Welder(config = WelderConfig(config_file="config.json"))
arch = w.ignite('arch')
print(arch.spark.sparkContext.getConf().get('spark.ui.proxyRedirectUri'))


tables = [
  'gte_gene_v',
  'health_condition_v'
]


for t in tables:
  df = arch.spark.table('academe3.'+t)

  logging.info('copying table '+t+' with '+str(df.count())+' rows')
  
  arch.saveARCHTable(df,
                         environment='prod',
                         data_store='integrated',
                         db_name='academe_2_8',
                         set_name=t,
                         partitions=1,
                         partitionBy=None)


