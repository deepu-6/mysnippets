from datetime import datetime
from archwelder import *
from pyspark.sql.types import StructType,StringType,StructField,ArrayType,IntegerType,DateType
from pyspark.sql import Row,Window
from pyspark.sql.functions import *

import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)

conf = {
  'environment':'prod',
  'data_store':'integrated',
  'db_name':'academe_2_8',
  'er_concept':'compounds',
  'concept_type':'Compound',
  'batch_size':100000,
  'num_partitions':1,
  'partition_key':'batch'
}

b = ERBuilder(conf=conf)

def prep_parent_keys(s):
  s.arch.query("REFRESH TABLE AIDXUNP1_ABV_FD2.FD_STRUCTURE_SOURCE")
  return s.arch.query("""
    SELECT DISTINCT 
      parent_inchi_key,
      compound_inchi_key 
    FROM AIDXUNP1_ABV_FD2.FD_STRUCTURE_SOURCE
  """,format='df',rows=0)\
    .filter(col('parent_inchi_key').isNotNull())\
    .filter(col('compound_inchi_key').isNotNull())\
    .withColumnRenamed('parent_inchi_key','root_inchi_key')\
    .withColumnRenamed('compound_inchi_key','match_inchi_key')\
    .filter(col('root_inchi_key').rlike('[a-zA-Z]{14}-[a-zA-Z]{10}-[a-zA-Z]'))
    
b.add_prep_function('parent_keys',prep_parent_keys)

def prep_drugs(s):
  s.arch.query("REFRESH TABLE academe_2_8.drug_concept_v")
  s.arch.query("REFRESH TABLE dependency_2_8.drug_concept_compound_xref_v")
  return s.arch.query("""
    SELECT 
      compound_uid,
      concat_ws('|',collect_list(abbv_term)) as abbv_term
    FROM dependency_2_8.drug_concept_compound_xref_v xref
    LEFT OUTER JOIN academe_2_8.drug_concept_v drugs ON 
      xref.drug_concept_uid=drugs.abbv_uid
    WHERE drugs.abbv_term IS NOT NULL
    GROUP BY compound_uid
  """,format='df',rows=0)\
    .withColumnRenamed('compound_uid','match_compound_uid')

b.add_prep_function('drugs',prep_drugs)

def step1(s):
  return s.recon_neo4j.query(query="""
    MATCH (c:Concept)
    WHERE c.concept_type='Compound'
    WITH c SKIP {skip_rows} LIMIT {limit_rows}
    MATCH (c)-[r]->(i:Identifier)
    WITH c,i
    ORDER BY i.PREFERRED
    WITH c.concept_id as concept_id,i.ontology as ontology,i.name as name,coalesce(i.PREFERRED,0) as sort_order
    RETURN DISTINCT concept_id,ontology,name,sort_order
  """.format(skip_rows=s.skip_rows,limit_rows=s.limit_rows),format='df',rows=0)
b.add_step_function(step1)

def step2(s):
  w = Window.partitionBy('concept_id','ontology').orderBy('sort_order')
  return s.dataframes['step1']\
    .withColumn("names",collect_list("name").over(w))\
    .groupby("concept_id","ontology")\
    .agg(max('names'))\
    .withColumnRenamed('max(names)','names')\
    .withColumn('identifiers',create_map('ontology','names'))\
    .drop('ontology')\
    .drop('names')
b.add_step_function(step2)

def step3(s):
  map_expr = 'aggregate(slice(identifier_list, 2, size(identifier_list)), identifier_list[0], (acc, element) -> map_concat(acc, element))'
  return s.dataframes['step2']\
    .groupBy('concept_id')\
    .agg(collect_list('identifiers').alias('identifier_list'))\
    .withColumn('identifier_map', expr(map_expr))\
    .drop('identifier_list')\
    .withColumnRenamed('concept_id','compound_uid')
b.add_step_function(step3)

def step4(s):
  return s.dataframes['step3'].join(s.dataframes['drugs'],col('compound_uid')==col('match_compound_uid'),"leftouter")\
  .drop('match_compound_uid')
b.add_step_function(step4)

def step5(s):
  return s.dataframes['step4']\
    .withColumn('chembl_id',expr("element_at(identifier_map,'CHEMBL')[0]"))\
    .withColumn('abbvie_id',expr("element_at(identifier_map,'ABBVIE')[0]"))\
    .withColumn('inchi_key',expr("element_at(identifier_map,'INCHI_KEY')[0]"))\
    .withColumn('canonical_smiles',expr("element_at(identifier_map,'CANONICAL_SMILES')[0]"))\
    .withColumn('molecule_type',expr("case "+
  "when abbv_term like '%tide' or abbv_term like '%tide\\|%'  then 'Peptide'"+
  "when abbv_term like '%mab' or abbv_term like '%mab\\|%' then 'Antibody'"+
  "when abbv_term like '%nib' or abbv_term like '%nib\\|%'  then 'Small molecule'"+
  "when abbv_term like '%recombinant%' then 'Protein'"+
  "when abbv_term like '%vaccine%' then 'Vaccine'"+
  "when abbv_term like '%antibody%' and abbv_term like '%conjugate%' then 'Drug Conjugate'"+
  "when abbv_term like '%antibody%' and abbv_term like '%conjugate%' then 'Antibody'"+
  "when element_at(identifier_map,'ABBVIE')[0] is not null and element_at(identifier_map,'ABBVIE')[0] like 'A-%' then 'Small molecule' "+
  "when element_at(identifier_map,'ABBVIE')[0] is not null and element_at(identifier_map,'ABBVIE')[0] like 'PR-%' then 'Protein' "+
  "when element_at(identifier_map,'ABBVIE')[0] is not null and element_at(identifier_map,'ABBVIE')[0] like 'DC-%' then 'Drug Conjugate' "+
  "when element_at(identifier_map,'ABBVIE')[0] is not null and element_at(identifier_map,'ABBVIE')[0] like 'CL-%' then 'Peptide' "+
  "when element_at(identifier_map,'INCHI_KEY')[0] is not null and element_at(identifier_map,'INCHI_KEY')[0] rlike '[a-zA-Z]{14}-[a-zA-Z]{10}-[a-zA-Z]' then 'Small molecule' "+                                     
  "else 'Unknown' END"))\
    .withColumn('other_identifiers',expr('flatten(map_values(identifier_map))'))\
    .withColumn('other_sources',expr('map_keys(identifier_map)'))
b.add_step_function(step5)

def step6(s):
  return s.dataframes['step5'].join(s.dataframes['parent_keys'],col('inchi_key')==col('match_inchi_key'),"leftouter")\
    .drop('match_inchi_key')\
    .withColumn('root_inchi_key',coalesce(col('root_inchi_key'),col('inchi_key')))\
    .withColumn('batch',lit(s.batch_number))
b.add_step_function(step6)
    

b.generate_er_table()