from datetime import datetime
from archwelder import *
from pyspark.sql.types import StructType,StringType,StructField,ArrayType,IntegerType,DateType,MapType
from pyspark.sql import Row,Window
from pyspark.sql.functions import *

import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)

conf = {
  'environment':'prod',
  'data_store':'integrated',
  'db_name':'academe_2_8',
  'er_concept':'drug_concept',
  'concept_type':'DrugConcept',
  'batch_size':100000,
  'num_partitions':1,
  'partition_key':'batch'
}

drug_test_list = [
  ('19e8cee6-4680-4cae-8c27-1150357def04','carbidopa'),
  ('3b7b56a3-f99e-47f9-b463-d97ab49df411','ravulizumab'),
  ('635da62d-b4fa-431c-86ef-0bad97f913f6','eculizumab'),
  ('6608eccf-0701-4211-b28c-343c76f3a281','ramucirumab'),
  ('67328cdd-5d60-475a-9bf6-b75fcda39b2d','canagliflozin; metformin hydrochloride'),
  ('7418637b-56d4-4c28-a943-e0f92222fdba','lenvatinib mesylate or lenvatinib'),
  ('7bce9e06-8163-4e81-bd9e-a349ae49eade','nivolumab'),
  ('87858478-5eef-455f-b60f-90afce375267','nintedanib'),
  ('8850a02a-f6e7-4deb-b820-29a33d7d9132','indeglitazar'),
  ('8ac1526d-dafa-4588-92fe-f983fcde8e83','upadacitinib'),
  ('8d0c818e-8197-4c92-9cad-98a5cfa8258f', 'bictegravir; emtricitabine; tenofovir alafenamide fumarate'),
  ('8dbc6764-bbb4-4def-9ffe-1812a138603e','ticagrelor'),
  ('90a1f4a0-d2f9-4fbb-bfc7-02194c912e7e','interferon beta-1a'),
  ('9c6c1c62-9202-4a33-8cf4-ac169ccd64d6','imiglucerase'),
  ('9d5aa552-e944-4633-a3ba-5ebcebe6194d','certolizumab pegol'),
  ('9d7d6054-57fb-4294-b59a-39a6dc444d0a','epoetin alfa'),
  ('9db1b7ae-d49b-48f6-a1c9-329a7912ab2f','leuprorelin acetate depot'),
  ('9fea71b8-77c4-4ba2-9cbf-9aa16a9313a0','vilanterol; fluticasone furoate'),
  ('a0f7115a-4817-40b1-8ef5-b89e23a54c15','amlodipine besylate'),
  ('a5a14c0a-5457-43f2-aa75-f4d79c1c4a94','ipilimumab'),
  ('a72c7e2e-d05d-4f9e-ac76-c064478a3e0f','pegfilgrastim'),
  ('a898558b-9499-457b-85fc-55dadd2bbc7d','eltrombopag'),
  ('d0dd50ca-982d-418e-8880-ef2e91e51eab','foscarbidopa; foslevodopa'),
  ('df88b315-6df2-42c8-878d-aad3dc3e23f1','abciximab'),
  ('e1ef7f42-52b9-4c41-b98e-1db5b43ce1e0','degarelix'),
  ('ea47da0e-ae7e-4566-8ea6-29a7e0af8f3e','carbidopa; levodopa'),
  ('ea58a38f-1db1-468b-9e74-1421b415ea45','liposomal factor VIII'),
  ('fab79cc1-8906-4c22-afd4-bc633006bc59','rintatolimod'),
  ('fbbfefbd-d350-4066-af7d-2b30706a881c','adalimumab')
  
]
drug_test_uids = [d[0] for d in drug_test_list ]
drug_test_uids_str = "["+','.join(["'"+d+"'" for d in drug_test_uids])+"]"

name_schema =  StructType([StructField("names",ArrayType(StringType()),True)])

b = ERBuilder(conf=conf)

def prep_chembl_metadata(s):
  s.arch.query("REFRESH TABLE symxunp1_ebi_chembl.molecule_dictionary")
  s.arch.query("REFRESH TABLE symxunp1_ebi_chembl.molecule_synonyms")
  return s.arch.query("""
    SELECT
      d.chembl_id as chembl_id,
      d.max_phase as chembl_max_phase,
      d.usan_stem_definition as chembl_usan_stem_definition,
      d.pref_name as chembl_term,
      collect_set(tn.synonyms) as chembl_trade_names,
      collect_set(ms.synonyms) as chembl_syns
    FROM symxunp1_ebi_chembl.molecule_dictionary d
    LEFT JOIN symxunp1_ebi_chembl.molecule_synonyms tn ON 
      d.molregno = tn.molregno and tn.syn_type='TRADE_NAME'
    LEFT JOIN symxunp1_ebi_chembl.molecule_synonyms ms ON 
      d.molregno = ms.molregno
    WHERE 
      d.pref_name is not null
    GROUP BY 
      d.chembl_id,
      d.max_phase,
      d.usan_stem_definition,
      d.pref_name
  """,format='df',rows=0)
b.add_prep_function('chembl_metadata_prep',prep_chembl_metadata)

def prep_atc_metadata(s):
  s.arch.query("REFRESH TABLE dependency_2_8.t_drugconcept_atc")
  return s.arch.query("""
    SELECT 
      atc_class_lookup abbv_term, 
      collect_list(atc_code) abbv_atc_class,
      collect_list(atc_class_term_cased) abbv_atc_class_term
    FROM dependency_2_8.t_drugconcept_atc
    GROUP BY atc_class_lookup
  """,format='df',rows=0)
b.add_prep_function('atc_metadata_prep',prep_atc_metadata)

def prep_ndc_metadata(s):
  s.arch.query("REFRESH TABLE dependency_2_8.v_drugconcept_ndc_dc")
  return s.arch.query("""
    SELECT DISTINCT
      d.generic_name abbv_term,
      d.proprietaryname ndc_trade_names, 
      d.generic_name ndc_term
    FROM dependency_2_8.v_drugconcept_ndc_dc d
  """,format='df',rows=0)
b.add_prep_function('ndc_metadata_prep',prep_ndc_metadata)

def prep_integrity_metadata(s):
  s.arch.query("REFRESH TABLE dependency_2_8.v_drugconcept_integrity")
  return s.arch.query("""
    SELECT
      generic_name integrity_term,
      integrity_id,
      max_phase as integrity_max_phase
    FROM dependency_2_8.v_drugconcept_integrity
  """,format='df',rows=0)
b.add_prep_function('integrity_metadata_prep',prep_integrity_metadata)


def prep_cortellis_metadata(s):
  s.arch.query("REFRESH TABLE dependency_2_8.v_drugconcept_cortellis")
  return s.arch.query("""
    SELECT
      cast(trid_id as string) as cortellis_id,
      generic_name as cortellis_term,
      syns as cortellis_syns,
      max_phase as cortellis_max_phase,
      trade_names as cortellis_trade_names
    FROM dependency_2_8.v_drugconcept_cortellis
  """,format='df',rows=0)
b.add_prep_function('cortellis_metadata_prep',prep_cortellis_metadata)

def prep_ncit_metadata(s):
  s.arch.query("REFRESH TABLE dependency_2_8.t_drugconcept_ncit_dc")
  return s.arch.query("""
    SELECT 
      code as ncit_id,
      generic_name_cased as ncit_term,
      synonyms as ncit_syns
    FROM dependency_2_8.t_drugconcept_ncit_dc
  """,format='df',rows=0)
b.add_prep_function('ncit_metadata_prep',prep_ncit_metadata)

def prep_legacy_drugs_metadata(s):
  s.arch.query("REFRESH TABLE academe.drug_concept_r_v")
  s.arch.query("REFRESH TABLE academe.drug_concept_v")
  return s.arch.query("""
    SELECT DISTINCT
      abbv_uid,
      dcr_abbv_uid 
    FROM (
      SELECT 
        'ncit' as src,
        dc.abbv_uid,
        dcr.abbv_uid as dcr_abbv_uid,
        dc.abbv_term,
        dcr.abbv_term as dcr_abbv_term
      FROM academe.drug_concept_v dc
      FULL JOIN academe.drug_concept_r_v dcr ON 
        dc.ncit_code=dcr.ncit_code[0]
      WHERE 
        dc.abbv_term_source='ncit'
      UNION
      SELECT 
        'ndc' as src,
        dc.abbv_uid,
        dcr.abbv_uid as dcr_abbv_uid,
        dc.abbv_term,
        dcr.abbv_term as dcr_abbv_term
      FROM academe.drug_concept_v dc
      FULL JOIN academe.drug_concept_r_v dcr ON 
        dc.ndc_term=dcr.ndc_term
      WHERE
        dc.abbv_term_source='ndc'
      UNION
      SELECT
        'cortellis' as src,
        dc.abbv_uid,
        dcr.abbv_uid as dcr_abbv_uid,
        dc.abbv_term,
        dcr.abbv_term as dcr_abbv_term
      FROM academe.drug_concept_v dc
      FULL JOIN academe.drug_concept_r_v dcr ON 
        dc.cortellis_code=dcr.cortellis_code[0]
      WHERE
        dc.abbv_term_source='cortellis'
      UNION
      SELECT
        'chembl' as src,
        dc.abbv_uid,
        dcr.abbv_uid as dcr_abbv_uid,
        dc.abbv_term,
        dcr.abbv_term as dcr_abbv_term
      FROM academe.drug_concept_v dc
      FULL JOIN academe.drug_concept_r_v dcr ON
        dc.chembl_code=dcr.chembl_id[0]
      WHERE
        dc.abbv_term_source='chembl'
      UNION
      SELECT
        dc.abbv_term_source as src,
        dc.abbv_uid,
        dcr.abbv_uid as dcr_abbv_uid,
        dc.abbv_term,
        dcr.abbv_term as dcr_abbv_term
      FROM academe.drug_concept_r_v dcr
      LEFT JOIN academe.drug_concept_v dc ON 
        dc.abbv_term=dcr.abbv_term
      WHERE 
        dcr.ndc_term is null and 
        dcr.chembl_id is null and 
        dcr.cortellis_code is null and 
        dcr.ncit_code is null
    ) t
  """,format='df',rows=0)\
  .withColumnRenamed('abbv_uid','legacy_abbv_uid')\
  .withColumnRenamed('dcr_abbv_uid','abbv_uid')
b.add_prep_function('legacy_drugs_metadata_prep',prep_legacy_drugs_metadata)

def step1(s):
  w = Window.partitionBy('concept_id', "ontology").orderBy(asc('date'))
  return s.recon_neo4j.query(query="""
    MATCH (c:Concept {{concept_type:"DrugConcept"}})
    WITH c SKIP {skip_rows} LIMIT {limit_rows}
    MATCH (c)-[r]->(i:Identifier)
    WITH c,i order by i.gen_date
    WITH c.concept_id as concept_id,i.ontology as ontology,i.name as name, apoc.date.parse(i.gen_date, "ms", "ddMMMyyyy_hhmmss") as date
    RETURN DISTINCT concept_id,ontology,name,date
  """.format(skip_rows=s.skip_rows,limit_rows=s.limit_rows),format='df',rows=0)\
    .withColumn("names", collect_list("name").over(w))\
    .groupby("concept_id","ontology")\
    .agg(max("names"))\
    .withColumnRenamed('max(names)','names')\
    .withColumn('identifiers',create_map('ontology','names'))\
    .drop('ontology')\
    .drop('names')
b.add_step_function(step1)
  
def step2(s):
  map_expr = 'aggregate(slice(identifier_list, 2, size(identifier_list)), identifier_list[0], (acc, element) -> map_concat(acc, element))'
  return s.dataframes['step1']\
    .groupBy('concept_id')\
    .agg(collect_list('identifiers').alias('identifier_list'))\
    .withColumn('identifier_map', expr(map_expr))\
    .drop('identifier_list')\
    .withColumnRenamed('concept_id','abbv_uid')
b.add_step_function(step2)

def step3(s):
  return s.dataframes['step2']\
    .withColumn('abbv_term',lower(trim(expr("element_at(identifier_map,'GENERIC_NAME')[0]"))))\
    .withColumn('chembl_id',expr("element_at(identifier_map,'CHEMBL')"))\
    .withColumn('integrity_code',expr("element_at(identifier_map,'INTEGRITY')"))\
    .withColumn('cortellis_code',expr("element_at(identifier_map,'CLINICAL_ID')"))\
    .withColumn('abbvdrug_term',expr("element_at(identifier_map,'ABBVDRUG')"))\
    .withColumn('abbvdrug_corp_id',expr("element_at(identifier_map,'CORP_ID')"))\
    .withColumn('ncit_code',expr("element_at(identifier_map,'NCIT')"))\
    .withColumn('abbv_comp_names',expr("split(abbv_term, '; ')"))\
    .withColumn('abbv_num_comp',expr("size(abbv_comp_names)"))\
    .withColumnRenamed('identifier_map','abbv_codes')
b.add_step_function(step3)

def chembl_metadata(s):
  return s.dataframes['step3']\
    .select("abbv_uid","abbv_codes")\
    .withColumn("chembl_id",explode(element_at(col('abbv_codes'),'CHEMBL')))\
    .drop("abbv_codes")\
    .join(s.dataframes['chembl_metadata_prep'], on='chembl_id',how="left")\
    .withColumn("chembl_trade_name",explode(col('chembl_trade_names')))\
    .withColumn("chembl_syn",explode(col('chembl_syns')))\
    .groupBy("abbv_uid")\
    .agg(
        collect_set('chembl_id').alias('chembl_ids'),
        max('chembl_max_phase').alias('chembl_max_phase'),
        first('chembl_usan_stem_definition').alias('chembl_usan_stem_definition'),
        collect_set('chembl_term').alias('chembl_terms'),
        collect_set(col('chembl_trade_name')).alias('chembl_trade_names'),
        collect_set(col('chembl_syn')).alias('chembl_syns'))
  return None
b.add_step_function(chembl_metadata)

def integrity_metadata(s):
  return s.dataframes['step3']\
    .select("abbv_uid","abbv_codes")\
    .withColumn("integrity_id",explode(element_at(col('abbv_codes'),'INTEGRITY')))\
    .drop("abbv_codes")\
    .join(s.dataframes['integrity_metadata_prep'], on='integrity_id',how="left")\
    .groupBy("abbv_uid")\
    .agg(
        collect_set('integrity_id').alias('integrity_ids'),
        max('integrity_max_phase').alias('integrity_max_phase'),
        collect_set('integrity_term').alias('integrity_terms'))
  return None
b.add_step_function(integrity_metadata)

def cortellis_metadata(s):  
  return s.dataframes['step3']\
    .select("abbv_uid","abbv_codes")\
    .withColumn("cortellis_id",explode(element_at(col('abbv_codes'),'CLINICAL_ID')))\
    .drop("abbv_codes")\
    .join(s.dataframes['cortellis_metadata_prep'], on='cortellis_id',how="left")\
    .groupBy("abbv_uid")\
    .agg(
        collect_set('cortellis_id').alias('cortellis_ids'),
        max('cortellis_max_phase').alias('cortellis_max_phase'),
        collect_set('cortellis_term').alias('cortellis_terms'),
        collect_set("cortellis_syns").alias('cortellis_syn_list'),
        collect_set("cortellis_trade_names").alias('cortellis_trade_names_list'))\
    .withColumn('cortellis_trade_names',flatten(col('cortellis_trade_names_list')))\
    .withColumn('cortellis_syns',flatten(col('cortellis_syn_list')))\
    .drop('cortellis_trade_names_list')\
    .drop('cortellis_syn_list')
  return None
b.add_step_function(cortellis_metadata)

def ncit_metadata(s):
  return s.dataframes['step3']\
    .select("abbv_uid","abbv_codes")\
    .withColumn("ncit_id",explode(element_at(col('abbv_codes'),'NCIT')))\
    .drop("abbv_codes")\
    .join(s.dataframes['ncit_metadata_prep'], on='ncit_id',how="left")\
    .groupBy("abbv_uid")\
    .agg(
        collect_set('ncit_id').alias('ncit_ids'),
        collect_set('ncit_term').alias('ncit_terms'),
        collect_set("ncit_syns").alias('ncit_syns_list'),)\
    .withColumn('ncit_syns',flatten(col('ncit_syns_list')))\
    .drop('ncit_syns_list')
  return None
b.add_step_function(ncit_metadata)

def legacy_drugs_metadata(s):  
  return s.dataframes['step3']\
    .select("abbv_uid")\
    .join(s.dataframes['legacy_drugs_metadata_prep'], on='abbv_uid',how="left")
  return None
b.add_step_function(legacy_drugs_metadata)

def step9(s):
  return s.dataframes['step3']\
    .join(s.dataframes['atc_metadata_prep'], on='abbv_term' ,how="leftouter")\
    .join(s.dataframes['chembl_metadata'], on='abbv_uid' ,how="leftouter")\
    .join(s.dataframes['integrity_metadata'], on='abbv_uid' ,how="leftouter")\
    .join(s.dataframes['cortellis_metadata'], on='abbv_uid' ,how="leftouter")\
    .join(s.dataframes['ncit_metadata'], on='abbv_uid' ,how="leftouter")\
    .join(s.dataframes['ndc_metadata_prep'], on='abbv_term' ,how="leftouter")\
    .join(s.dataframes['legacy_drugs_metadata'], on='abbv_uid', how="leftouter")\
    .withColumn('chembl_trade_names', when(col('chembl_trade_names').isNull(), array()).otherwise(col('chembl_trade_names')))\
    .withColumn('ndc_trade_names', when(col('ndc_trade_names').isNull(), array()).otherwise(col('ndc_trade_names')))\
    .withColumn('cortellis_trade_names', when(col('cortellis_trade_names').isNull(), array()).otherwise(col('cortellis_trade_names')))\
    .withColumn('abbv_trade_names', array_distinct(concat(col('chembl_trade_names'),col('ndc_trade_names'),col('cortellis_trade_names'))))\
    .withColumn('abbv_max_phase', greatest('chembl_max_phase','cortellis_max_phase','integrity_max_phase'))\
    .filter(col('abbv_num_comp') < 6)\
    .filter(col('abbv_term').isNotNull())
b.add_step_function(step9)

def step10(s):
  return s.dataframes['step9']\
    .withColumn('batch',lit(s.batch_number))\
    .select(
      "abbv_uid",
      "abbv_term",
      "abbv_codes",
      "abbv_comp_names",
      "abbv_num_comp",
      "abbv_max_phase",
      "abbv_atc_class",
      "abbv_atc_class_term",
      "abbv_trade_names",
      "abbvdrug_term",
      "abbvdrug_corp_id",
      "ndc_term",
      "ndc_trade_names",
      "chembl_terms",
      "chembl_id",
      "chembl_max_phase",
      "chembl_usan_stem_definition",
      "chembl_trade_names",
      "chembl_syns",
      "integrity_terms",
      "integrity_code",
      "integrity_max_phase",
      "cortellis_terms",
      "cortellis_code",
      "cortellis_max_phase",
      "cortellis_trade_names",
      "cortellis_syns",
      "ncit_terms",
      "ncit_ids",
      "ncit_syns",
      "legacy_abbv_uid",
      "batch"
    )
b.add_step_function(step10)

b.generate_er_table()