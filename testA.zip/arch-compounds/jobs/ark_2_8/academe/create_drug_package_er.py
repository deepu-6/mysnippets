import requests
import json
from datetime import datetime
from archwelder import *
from pyspark.sql.types import StructType,StringType,StructField,ArrayType,IntegerType,DateType
from pyspark.sql import Row
from pyspark.sql.functions import *
import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)

major_version = 1
minor_version = 0

w = Welder(config = WelderConfig(config_file="config.json"))
arch = w.ignite('arch')
recon_neo4j = w.ignite('recon_neo4j')

datestr=datetime.now().strftime('%d%b%Y')


ndc_sql = """select distinct ndcpackagecode, 
productndc, 
packagedescription, 
startmarketingdate,
endmarketingdate,
ndc_exclude_flag,
sample_package
from ndc_codes.package"""
package_df = arch.query(query=ndc_sql, format='df', rows=0)


df = recon_neo4j.query(query="""
MATCH (c:Concept {concept_type:"DrugPackage"})-[r]->(i:Identifier {ontology:"NDC_PACKAGE"})
WITH c.concept_id as drug_package_uid, i.name as ndcpackagecode
return drug_package_uid, ndcpackagecode
""",format='df',rows=0)\
.withColumn("x", expr("split(ndcpackagecode, '-')"))\
.withColumn("lx", expr("lpad(x[0], 5, '0')"))\
.withColumn("rx", expr("lpad(x[1], 4, '0')"))\
.withColumn("lp", expr("lpad(x[2], 2, '0')"))\
.withColumn("ndc11", expr("concat(lx,rx,lp)"))\
.drop('x')\
.drop('lx')\
.drop('rx')\
.drop('lp')\
.join(package_df, on='ndcpackagecode' ,how="left")\
.dropDuplicates(["drug_package_uid"])
# there were about 5 duplicates


#df.show(truncate=False)



environment='prod'
data_store='integrated'
db_name='academe'
num_partitions=1
partition_key=None
set_name='drug_package_r_v'

arch.saveARCHTable(df,
                  environment=environment,
                  data_store=data_store,
                  db_name=db_name,
                  set_name=set_name+datestr,
                  partitions=num_partitions,
                  partitionBy=partition_key)



arch.query('DROP TABLE IF EXISTS academe.drug_package_r_v_last',format='df',rows=0)
arch.query('ALTER TABLE academe.drug_package_r_v RENAME TO academe.drug_package_r_v_last',format='df',rows=0)
arch.query('ALTER TABLE academe.drug_package_r_v'+datestr+' RENAME TO academe.drug_package_r_v',format='df',rows=0)
  
  

