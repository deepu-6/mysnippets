import requests
import json
from datetime import datetime
from archwelder import *
from pyspark.sql.types import StructType,StringType,StructField,ArrayType,IntegerType,DateType
from pyspark.sql import Row
from pyspark.sql.functions import *
import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)

major_version = 1
minor_version = 0

w = Welder(config = WelderConfig(config_file="config.json"))
arch = w.ignite('arch')
recon_neo4j = w.ignite('recon_neo4j')

datestr=datetime.now().strftime('%d%b%Y')


ndc_sql = "select * from ndc_codes.product"
product_df = arch.query(query=ndc_sql, format='df', rows=0)


#df = recon_neo4j.query(query="""
#MATCH (c:Concept {concept_type:"DrugProduct"})-[r]->(i:Identifier {ontology:"GENERIC_NAME"}) 
#MATCH (c)-[r2]->(i2:Identifier {ontology:"NDC_PRODUCT"})
#MATCH (c)-[r3]->(i3:Identifier {ontology:"PROPRIETARY_NAME"})
#unwind c.concept_id as CONCEPT_ID
#unwind i.name as GENERIC_NAME
#unwind i2.name as NDC_PRODUCT
#unwind i3.name as PROPRIETARY_NAME
#return CONCEPT_ID, GENERIC_NAME, NDC_PRODUCT, PROPRIETARY_NAME
#""",format='df',rows=0)


#MATCH (c:Concept {concept_type:"DrugProduct"})-[r]->(i:Identifier {ontology:"NDC_PRODUCT"})
#with c.concept_id as conceptid, i.name as productndc
#return count(conceptid)
#--115070

df = recon_neo4j.query(query="""
MATCH (c:Concept {concept_type:"DrugProduct"})-[r]->(i:Identifier {ontology:"NDC_PRODUCT"})
with c.concept_id as conceptid, i.name as productndc
match (dpp:Concept {concept_id:conceptid, concept_type:"DrugProduct"})-[r2]->(i2:Identifier {ontology:"GENERIC_NAME"})-[r3]->(dpc:Concept {concept_type:"DrugConcept"})
with productndc, conceptid as drug_product_uid, i2.name as generic_name, dpc.concept_id as drug_concept_uid
return drug_product_uid, productndc, generic_name, drug_concept_uid
""",format='df',rows=0)

#df.show(truncate=False)

df2 = df\
.withColumn("x", expr("split(productndc, '-')"))\
.withColumn("lx", expr("lpad(x[0], 5, '0')"))\
.withColumn("rx", expr("lpad(x[1], 4, '0')"))\
.withColumn("ndc9", expr("concat(lx,rx)"))\
.drop("x")\
.drop("lx")\
.drop("rx")\
.join(product_df, on='productndc' ,how="left")\
.drop("PRODUCTID")


#df2.show(truncate=False)



environment='prod'
data_store='integrated'
db_name='academe'
num_partitions=1
partition_key=None
set_name='drug_product_r_v'

arch.saveARCHTable(df2,
                  environment=environment,
                  data_store=data_store,
                  db_name=db_name,
                  set_name=set_name+datestr,
                  partitions=num_partitions,
                  partitionBy=partition_key)



arch.query('DROP TABLE IF EXISTS academe.drug_product_r_v_last',format='df',rows=0)
arch.query('ALTER TABLE academe.drug_product_r_v RENAME TO academe.drug_product_r_v_last',format='df',rows=0)
arch.query('ALTER TABLE academe.drug_product_r_v'+datestr+' RENAME TO academe.drug_product_r_v',format='df',rows=0)
  
  

