## SETUP DATABASES
# arch_databases.py

## COPY OVER AND CREATE DEPENDENCIES
# dependency/copy_dependency_tables.py
# --> dependency.t_chembl_pikm_moa
# dependency/t_drugconcept_atc.py
# dependency/t_drugconcept_drugbank.py
# dependency/t_drugconcept_ncit_dc.py
# dependency/v_drugconcept_abbvdrug.py
# dependency/v_drugconcept_cortellis.py
# dependency/v_drugconcept_integrity.py
# dependency/v_drugconcept_ndc_dc.py
# dependency/v_drugconcept_ndc_dp.py
# dependency/v_drugconcept_ndc_dpp.py
# dependency/build_drug_concept_compound_xref_table.py
# depencency/v_cortellis_ct_full_view.py

## ACADEME BUILDS
# academe/copy_academe_tables.py
# --> academe.gte_gene_v
# --> academe.health_condition_v
# academe/build_drug_concept_er_table.py --> dependency.t_drugconcept_atc, dependency.v_drugconcept_ndc_dc, dependency.v_drugconcept_integrity, dependency.v_drugconcept_cortellis, dependency.t_drugconcept_ncit_dc
# academe/build_compounds_er_table.py --> academe.drug_concept_v, dependency.drug_concept_compound_xref_v
# TBD academe/build_drug_product_er_table.py
# TBD academe/build_drug_package_er_table.py

## NORMALIZATION
# normalization/abcxunp1_abbvie_cortellis_clinical_trials_ae_norm.py --> academe.drug_concept_v, academe.health_condition_v
# normalization/abcxunp1_abbvie_cortellis_clinical_trials_norm.py --> dependency.v_cortellis_ct_full_view, academe.drug_concept_v, academe.health_condition_v
# normalization/nih_livertox_norm.py --> academe.drug_concept_v
# normalization/open_targets_drug_indications_norm.py --> academe.drug_concept_v, academe.health_conditions_v
# normalization/open_targets_drug_mechanism_of_action_norm.py --> academe.drug_concept_v, academe.gte_gene_v
# normalization/r_moa_ids_norm.py --> arch_normalized.open_targets_drug_mechanism_of_action_norm, dependency.t_chembl_pikm_moa, academe.drug_concept_v, academe.gte_gene_v
# normalization/r_pikm_moa_chembl_ids_norm.py --> academe.drug_concept_v, academe.gte_gene_v
# normalization/scopiarx_ae_main_db_norm.py --> academe.drug_concept_v, academe.health_condition_v
# normalization/scopiarx_di_main_db_norm.py --> academe.drug_concept_v, academe.health_condition_v

## EXTRACTION
# extraction/entities/copy_entity_tables.py
# --> ark.t_adverseevent_entities
# --> ark.t_cellline_entities
# --> ark.t_clinicalcondition_entities
# --> ark.t_disease_entities
# --> ark.t_endpoint_adme_entities
# --> ark.t_endpoint_cv_entities
# --> ark.t_endpoint_entities
# --> ark.t_endpoint_pcsdw_entities
# --> ark.t_endpoint_pk_entities
# --> ark.t_gene_entities
# --> ark.t_gene_form_entities
# --> ark.t_pathway_entities
# --> ark.t_phenotype_entities
# --> ark.t_pkpairing_entities
# --> ark.t_tissue_entities
# --> ark.t_variant_entitie
# extraction/entities/curate_compounds.py --> academe.compounds_v
# extraction/entities/curate_drugconcept.py --> academe.drug_concept_v, arch_normalized.r_moa_ids_norm
# extraction/entities/curate_ddis.py --> arch_normalized3.scopiarx_di_main_db_norm

# extraction/relationships/copy_relationship_tables.py
# --> ark.t_compound_compound_metabolite_relationships
# --> ark.t_compound_cv_endpoint_medmsd_relationships
# --> ark.t_compound_cv_endpoint_relationships
# --> ark.t_compound_endpoint_adme_relationships
# --> ark.t_compound_endpoint_medmsd_relationships
# --> ark.t_compound_endpoint_relationships
# --> ark.t_compound_gene_bioactivity_implied_relationships
# --> ark.t_compound_gene_bioactivity_relationships
# --> ark.t_compound_gene_form_relationship
# --> ark.t_compound_gene_relationships
# --> ark.t_compound_pkpairing_dosed_relationships
# --> ark.t_compound_pkpairing_measured_relationships
# --> ark.t_gene_adverseevent_relationships
# --> ark.t_gene_cell_line_relationships
# --> ark.t_gene_disease_relationships
# --> ark.t_gene_gene_bioprofile_relationships
# --> ark.t_gene_gene_form_relationships
# --> ark.t_gene_gene_relationships
# --> ark.t_gene_pathway_relationships
# --> ark.t_gene_phenotype_relationships
# --> ark.t_gene_tissue_relationships
# --> ark.t_gene_variant_relationships
# --> ark.t_pkpairing_endpoint_pk_relationships
# --> ark.t_variant_phenotype_relationships
# TBD curate_compound_compound_bioprofile.py
# extraction/relationships/curate_ddi_adverseevent.py --> arch_normalized.scopiarx_di_main_db
# extraction/relationships/curate_ddi_drug.py --> arch_normalized3.scopiarx_di_main_db_norm 
# dependency/v_scopia_drug_ad_relationships_knwlextract_dep.py -->  arch_normalized.scopiarx_ae_main_db_norm
# extraction/relationships/curate_drug_adverseevent.py --> arch_normalized.abcxunp1_abbvie_cortellis_clinical_trials_ae_norm, dependency.v_scopia_drug_ae_relationships_knwlextract_dep
# extraction/relationships/curate_drug_disease_cortellis.py --> arch_normalized.abcxunp1_abbvie_cortellis_clinical_trials_norm
# extraction/relationships/curate_drug_disease_open_targets.py --> arch_normalized.open_targets_drug_indications_norm
# extraction/relationships/curate_drug_drug.py --> arch_normalized.scopiarx_di_main_db_norm
# extraction/relationships/curate_drug_gene.py --> arch_normalized3.r_moa_ids_norm
# extraction/relationships/curate_drugconcept_compound.py --> dependency.drug_concept_compound_xref_v


