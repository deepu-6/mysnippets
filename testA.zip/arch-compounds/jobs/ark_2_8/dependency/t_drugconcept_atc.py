import requests
import json
import os
import re
from pprint import pprint
import warnings
warnings.filterwarnings("ignore")
from archwelder import *

config_file = os.getcwd()+'/config.json'
config = json.load(open(config_file))["environments"]["prod"]["data_sources"]["centree"]

w = Welder(config = WelderConfig(config_file="config.json"))
arch = w.ignite('arch')



def get_centree_header():
    url = f"{config['base_url']}{config['apikey_url']}"
    creds_dict = {"username": config["user"], "password": config["password"], "rememberMe":True}
    token = requests.request("POST", url, json=creds_dict, verify=False).json()["id_token"]
    header = {"Authorization": f"Bearer {token}"}
    return header


def ontology_exists(headers, ont_id):
    ontology_endpoint = f"{config['base_url']}{config['ontology_url']}/{ont_id}"
    req = requests.get(ontology_endpoint, headers=headers, verify=False)
    res = req.json()
    try:
        if req.status_code == 200:
            v = res["ontologyMetadataJSONBean"]["version"]
            return v
        else:
            return None
    except:
        print("Failed to return response from 'ontology_exists'")
        exit()
        
        
def scroll_ontology(headers, ont_id):
    size_ = 500
    scroll_url = f"{config['base_url']}{config['scroll_url']}&size={size_}&ontology={ont_id}"
    ret = requests.get(scroll_url,  headers=headers, verify=False)
    res = ret.json()
    elements = res['elements']
    scroll_id = res['scrollId']
    
    ret = requests.get(f"{scroll_url}&scrollId={scroll_id}",  headers=headers, verify=False)
    while ret:
        res = ret.json()
        if len(res["elements"]) == 0:
            break
        elements = elements + res["elements"]
        print(len(elements))
        ret = requests.get(f"{scroll_url}&scrollId={scroll_id}",  headers=headers, verify=False)
    return(elements)
  
  
def munge_data(d, v):
    ret = []
    x = {}
    
    # set up look up for key:code value:original label
    for e in d:
        primary_label_cased = e["primaryLabel"]
        if(len(e["shortFormIDs"][0]) <= 10):
            code = e["shortFormIDs"][0]
        elif(len(e["shortFormIDs"][0]) > 10):
            code = re.sub('.*=', '', e["superClasses"][0])
        x[code] = primary_label_cased
    
    
    for e in d:
        temp = e["primaryLabel"].lower()
        primary_label = temp.replace(" and ", "; " ).replace(", ", "; " )
        primary_label_cased = e["primaryLabel"]
        if(len(e["shortFormIDs"][0]) <= 10):
            code = e["shortFormIDs"][0]
        elif(len(e["shortFormIDs"][0]) > 10):
            code = re.sub('.*=', '', e["superClasses"][0])
        x[code] = primary_label_cased
        if len(code) == 7:
            code = code[:5]
            primary_label_cased = x[code]
        ret.append({"atc_class_lookup":primary_label, "atc_code":code, "atc_class_term_cased":primary_label_cased, "version":v})
    return ret

  
  
onto = 'atc'
header = get_centree_header()

version = ontology_exists(header, onto)
if version == None:
    print(ont_id + " does not exist")
    exit()

ncit = scroll_ontology(header, onto)
data = munge_data(ncit, version)
df = arch.spark.createDataFrame(data)
#df.show()
#print(df.count())


arch.query('DROP TABLE IF EXISTS dependency_2_8.t_drugconcept_atc',format='df',rows=0) 

environment='prod'
data_store='integrated'
db_name='dependency_2_8'
num_partitions=1
partition_key=None
set_name='t_drugconcept_atc'
arch.saveARCHTable(df,
                  environment=environment,
                  data_store=data_store,
                  db_name=db_name,
                  set_name=set_name,
                  partitions=num_partitions,
                  partitionBy=partition_key)


