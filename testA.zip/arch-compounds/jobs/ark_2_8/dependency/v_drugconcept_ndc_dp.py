from datetime import datetime
from archwelder import *
from pprint import pprint
import os
import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)

config_path = os.getcwd()+'/config.json'
logging.info(config_path)
w = Welder(config = WelderConfig(config_file=config_path))
arch = w.ignite('arch')


arch.query("""CREATE OR REPLACE VIEW dependency_2_8.v_drugconcept_ndc_dp as
with ndc_dp as (
  SELECT lower(r.productndc) productndc, 
  lower(r.proprietaryname) proprietaryname, 
  lower(r.nonproprietaryname) nonproprietaryname,
  case when substancename is null then null
    else lower(concat_ws('; ', sort_array(split(r.substancename, '; ')))) end as substancename,
  case when r.substancename is not null then 
      size(sort_array(split(r.substancename, '; ')))
  when r.nonproprietaryname is not null then
      size(sort_array(split(r.nonproprietaryname, ', ')))
  else 1
  end num_comp
  FROM ndc_codes.product r)
select r.productndc, r.proprietaryname, r.nonproprietaryname,  r.substancename, coalesce(r.substancename, r.nonproprietaryname) generic_name, num_comp
from ndc_dp r
""",format='df',rows=0)