from datetime import datetime
from archwelder import *
from pprint import pprint
import os
import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)

config_path = os.getcwd()+'/config.json'
logging.info(config_path)
w = Welder(config = WelderConfig(config_file=config_path))
arch = w.ignite('arch')


arch.query("""CREATE OR REPLACE VIEW dependency_2_8.v_drugconcept_ndc_dpp as 
select r.productndc, p.ndcpackagecode
from ndc_codes.product r, ndc_codes.package p
where r.productndc = p.productndc""",format='df',rows=0)