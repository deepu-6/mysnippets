import requests
import json
import os
from pprint import pprint
import warnings
warnings.filterwarnings("ignore")
from archwelder import *

config_file = os.getcwd()+'/config.json'
config = json.load(open(config_file))["environments"]["prod"]["data_sources"]["centree"]

w = Welder(config = WelderConfig(config_file="config.json"))
arch = w.ignite('arch')



def get_centree_header():
    url = f"{config['base_url']}{config['apikey_url']}"
    creds_dict = {"username": config["user"], "password": config["password"], "rememberMe":True}
    token = requests.request("POST", url, json=creds_dict, verify=False).json()["id_token"]
    header = {"Authorization": f"Bearer {token}"}
    return header


def ontology_exists(headers, ont_id):
    ontology_endpoint = f"{config['base_url']}{config['ontology_url']}/{ont_id}"
    req = requests.get(ontology_endpoint, headers=headers, verify=False)
    res = req.json()
    try:
        if req.status_code == 200:
            v = res["ontologyMetadataJSONBean"]["version"]
            return v
        else:
            return None
    except:
        print("Failed to return response from 'ontology_exists'")
        exit()
        
        
def scroll_ontology(headers, ont_id):
    size_ = 500
    scroll_url = f"{config['base_url']}{config['scroll_url']}&size={size_}&ontology={ont_id}"
    ret = requests.get(scroll_url,  headers=headers, verify=False)
    res = ret.json()
    elements = res['elements']
    scroll_id = res['scrollId']
    
    ret = requests.get(f"{scroll_url}&scrollId={scroll_id}",  headers=headers, verify=False)
    while ret:
        res = ret.json()
        if len(res["elements"]) == 0:
            break
        elements = elements + res["elements"]
        print(len(elements))
        ret = requests.get(f"{scroll_url}&scrollId={scroll_id}",  headers=headers, verify=False)
    return(elements)
  
  
def munge_data(d, v):
    all_names = []
    ret = []
    
    # get all names
    for e in d:
        all_names.append(e["primaryLabel"].replace('"', ''))
    
    for e in d:
        name = e["primaryLabel"].replace('"', '')
        code = e["shortFormIDs"][0]
        code = code.replace("_", ":").replace('"', '')
        code = code.replace(" ","_")
        syns = e['synonyms']
        
        # for FDC, check that each name is in ncit.  Sometimes "/" is used for reasons other than FDCs
        temp_name = name.split("/")
        found_count = 0
        for t in temp_name:
            if t in all_names:
                found_count += 1
                
        if found_count == len(temp_name):
            components = name.split("/")
            components.sort()
        else: 
            components = [name]
        
        num_components = len(components)
        generic_name = '; '.join(components)
        
        ret.append({"generic_name":generic_name.lower(), "generic_name_cased":generic_name, "code":code, "num_comp":num_components, "synonyms":syns, "version":v})
        
    return ret
    


    
   
    
onto = 'ncit_drug'
header = get_centree_header()

version = ontology_exists(header, onto)
if version == None:
    print(ont_id + " does not exist")
    exit()

ncit = scroll_ontology(header, onto)
data = munge_data(ncit, version)
df = arch.spark.createDataFrame(data)
#df.show()
#print(df.count())


arch.query('DROP TABLE IF EXISTS dependency_2_8.t_drugconcept_ncit_dc',format='df',rows=0) 

environment='prod'
data_store='integrated'
db_name='dependency_2_8'
num_partitions=1
partition_key=None
set_name='t_drugconcept_ncit_dc'
arch.saveARCHTable(df,
                  environment=environment,
                  data_store=data_store,
                  db_name=db_name,
                  set_name=set_name,
                  partitions=num_partitions,
                  partitionBy=partition_key)

