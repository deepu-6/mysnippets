from datetime import datetime
from archwelder import *
from pprint import pprint
import os
import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)

config_path = os.getcwd()+'/config.json'
logging.info(config_path)
w = Welder(config = WelderConfig(config_file=config_path))
arch = w.ignite('arch')



arch.query("""CREATE OR REPLACE VIEW dependency_2_8.v_drugconcept_integrity as
WITH FDC as
(
select pc.pcg_entry_number, 'Y' as FDC
FROM symxunp1_sym_tr.pro_categories pc
join symxunp1_sym_tr.product_categories pc2 on pc.pcg_product_category_id = pc2.tpc_product_category_id
where pc2.tpc_description = 'Fixed-Dose Combinations'
)
SELECT distinct
p.pro_entry_number AS integrity_id,
p.pro_highest_phase_id,
case when fdc.fdc = 'Y' then 
    lower(concat_ws('; ', sort_array(split(pn.name, '/')))) 
else pn.name end as generic_name,
case when fdc.fdc = 'Y' then 
    size(split(pn.name, '/'))  else 1 end num_comp,
case when pp.pha_description in ('Phase 0','Discontinued', 'Clinical') then 0
     when pp.pha_description = 'Phase I' then 1
     when pp.pha_description in ('Phase I/II', 'Phase II') then 2
     when pp.pha_description in ('Phase III', 'Pre-Registered', 'IND Filed', 'Phase II/III', 'Recommended Approval') then 3
     when pp.pha_description in ('Registered' ,'Withdrawn', 'Launched') then 4
     when pp.pha_description in ('Preclinical','Biological Testing', 'Not Applicable', 'Not Determined', 'Suspended') then null
     else -999
     end as max_phase,
fdc.fdc as fixed_dose_combo,
'GN' type
FROM symxunp1_sym_tr.pro_products p
JOIN symxunp1_sym_tr.pro_phases pp ON p.pro_highest_phase_id = pp.pha_phase_id
JOIN symxunp1_sym_tr.pro_product_names pn ON p.pro_entry_number = pn.entrynumber
left join FDC on p.pro_entry_number = fdc.pcg_entry_number
WHERE pn.ppn_type='GN'
""",format='df',rows=0)
