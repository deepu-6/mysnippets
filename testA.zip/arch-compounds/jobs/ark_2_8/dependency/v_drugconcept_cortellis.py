from datetime import datetime
from archwelder import *
from pprint import pprint
import os
import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)

config_path = os.getcwd()+'/config.json'
logging.info(config_path)
w = Welder(config = WelderConfig(config_file=config_path))
arch = w.ignite('arch')



arch.query("""CREATE OR REPLACE VIEW dependency_2_8.v_drugconcept_cortellis as
with syns as (  
SELECT id.ID AS DRUG_ID, 
collect_set(distinct REGEXP_REPLACE(S.NAME, '^\\\s*', '')) syns
FROM abcxunp1_world3_writer.TRID_INVESTIGATIONAL_DRUG id ,
abcxunp1_world3_writer.TRID_SYNONYM s
where id.id = s.drug_id 
group by id.ID
),
trade_name as ( 
SELECT id.ID AS DRUG_ID,
collect_set(distinct REGEXP_REPLACE(S.NAME, '^\\\s*', '')) trade_names
FROM abcxunp1_world3_writer.TRID_INVESTIGATIONAL_DRUG id
 left join abcxunp1_world3_writer.TRID_SYNONYM s on id.id = s.drug_id and s.type = 'Trade Name'
group by id.ID
),
sort_order as (
SELECT id.id AS DRUG_ID, REGEXP_REPLACE(id.NAME, '\\\s*$', '') name, MAX(cast(ds.sort_order as integer)) sort_order
FROM abcxunp1_world3_writer.TRID_INVESTIGATIONAL_DRUG id
JOIN abcxunp1_world3_writer.TRID_DEVELOPMENT d ON d.DRUG_ID = id.ID
JOIN abcxunp1_world3_writer.TRID_DEVELOPMENT_STATUS ds ON d.STATUS = ds.id
GROUP BY id.id, id.NAME
),
sort_order_map as (
select distinct ds.id, ds.sort_order
from abcxunp1_world3_writer.TRID_DEVELOPMENT_STATUS ds
),
gn as (
select id drug_id,
name, 
lower(regexp_replace(regexp_replace(regexp_replace(trid.name, " \\\(.*\\\)",""),", ?.*$", ""), "\\\s+", " "))  generic_name
FROM abcxunp1_world3_writer.TRID_INVESTIGATIONAL_DRUG trid
)
select distinct trid.drug_id trid_id,
trid.name trid_name,
cast(xref.target_id as string) as xref_target_id,
lower(concat_ws('; ', sort_array(split(trid.generic_name, ' \\\+ ')))) generic_name,
syns.syns,
trade_name.trade_names,
sort_order.sort_order,
sort_order_map.id sort_order_code,
case
  when sort_order_map.id = 'C1' then 1
  when sort_order_map.id = 'C2' then 2
  when sort_order_map.id in ('C3','PR','R') then 3
  when sort_order_map.id = 'L' then 4
  when sort_order_map.id in ('PC', 'DR', 'NDR') then 0
  when sort_order_map.id in ('DX', 'S', 'W') then null
  else -999
end as max_phase
from GN trid
    left outer join abcxunp1_world3_writer.TRID_CROSS_REFERENCE xref 
         on cast(trid.drug_id as string) = cast(xref.source_id as string) 
         and xref.target_type = 'siDrug'
    left outer join syns on syns.drug_id = trid.drug_id
    left outer join trade_name on trade_name.drug_id = trid.drug_id
    left outer join sort_order on sort_order.drug_id = trid.drug_id
    left outer join sort_order_map on sort_order_map.sort_order = sort_order.sort_order
where trid.generic_name is not null""",format='df',rows=0)




