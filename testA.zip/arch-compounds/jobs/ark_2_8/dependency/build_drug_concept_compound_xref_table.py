from datetime import datetime
from archwelder import *
from pyspark.sql.types import StructType,StringType,StructField,ArrayType,IntegerType,DateType,MapType
from pyspark.sql import Row,Window
from pyspark.sql.functions import *

import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)

conf = {
  'environment':'prod',
  'data_store':'integrated',
  'db_name':'dependency_2_8',
  'er_concepts':['drug_concept','compound'],
  'concept_types':['DrugConcept','Compound'],
  'batch_size':10000,
  'num_partitions':1,
  'partition_key':'batch'
}


b = XREFBuilder(conf=conf)

def step1(s):
  return s.recon_neo4j.query(query="""
    MATCH (c1:Concept {{concept_type:'{concept1_type}'}})
    WITH DISTINCT c1 SKIP {skip_rows} LIMIT {limit_rows}
    MATCH (c1)-->(:Identifier)-->(c2:Concept {{concept_type:'{concept2_type}'}}) 
    WITH DISTINCT c1,c2
    MATCH (c1)-->(i:Identifier)-->(c2)
    RETURN 
      c1.concept_id as {concept1_label}_uid,
      c1.gen_date as {concept1_label}_gen_date,
      c2.concept_id as {concept2_label}_uid,
      c2.gen_date as {concept2_label}_gen_date,
      collect(DISTINCT i.ontology) as common_ontologies,
      collect({{ontology:i.ontology,name:i.name}}) as common_identifiers,
      {batch_number} as batch
    """.format(skip_rows=s.skip_rows,limit_rows=s.limit_rows,concept1_type=s.concept_types[0],concept2_type=s.concept_types[1],concept1_label=s.er_concepts[0],concept2_label=s.er_concepts[1],batch_number=s.batch_number),format='df',rows=0)
b.add_step_function(step1)

b.generate_table()