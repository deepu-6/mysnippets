from datetime import datetime
from archwelder import *
from pprint import pprint
import os
import logging
from pyspark.sql.types import StructType,StringType,StructField,ArrayType,IntegerType,DateType
from pyspark.sql import Row
from pyspark.sql import Window
from pyspark.sql.functions import *
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)

config_path = os.getcwd()+'/config.json'
logging.info(config_path)
w = Welder(config = WelderConfig(config_file=config_path))
arch = w.ignite('arch')


db_sql = """
select  lower(d.name) generic_name, d.drugbank_id, d.name, d.cas_number, collect_list(s.synonym) syns, collect_list(pc.drugbank_id) DBPC_id
from drugbank.drugs d
left join drugbank.drug_synonyms s on d.id = s.drug_id and s.language like '%english%' and s.score = 'good'
left join drugbank.product_concepts pc on pc.title = d.name
group by lower(d.name), d.drugbank_id, d.name, d.cas_number,pc.drugbank_id

UNION

select regexp_replace(lower(pc.title), ' / ','; ') generic_name, pc.drugbank_id, pc.title, null cas_number, collect_list('') syns,  collect_list('') DBPC_id
from drugbank.product_concepts pc
where pc.level = 1
and title not in (
select name from drugbank.drugs d
)
group by regexp_replace(lower(pc.title), ' / ', '; '), pc.drugbank_id, pc.title
"""
db_df = arch.query(query=fdb_sql, format='df', rows=0)

df2 = db_df.withColumn("thing", array_union(col("syns"), col("DBPC_id")))\
            .drop("syns")\
            .drop("DBPC_id")\
            .withColumnRenamed("thing","syns")\
            .withColumnRenamed("name","name_cased")
                        

#df2.show(truncate=False)



arch.query('DROP TABLE IF EXISTS dependency_2_8.t_drugconcept_drugbank',format='df',rows=0) 

environment='prod'
data_store='integrated'
db_name='dependency_2_8'
num_partitions=1
partition_key=None
set_name='t_drugconcept_drugbank'
arch.saveARCHTable(df2,
                  environment=environment,
                  data_store=data_store,
                  db_name=db_name,
                  set_name=set_name,
                  partitions=num_partitions,
                  partitionBy=partition_key)