from datetime import datetime
from archwelder import *
from pprint import pprint
import os
import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)

config_path = os.getcwd()+'/config.json'
logging.info(config_path)
w = Welder(config = WelderConfig(config_file=config_path))
arch = w.ignite('arch')

arch.query("""CREATE OR REPLACE VIEW dependency_2_8.v_drugconcept_abbvdrug AS
with thing as (
select a.abbv_number preferred_term, 
lower(coalesce(intl_non_prorietary_name, generic_name, usan)) non_prop_name_combo,
c.corporate_id,
a.usan, 
a.trade_name,
generic_name,
intl_non_prorietary_name
from ddmlcnp1_mdm_disc.abbv_identifier a,
ddmlcnp1_mdm_disc.abbv_identifier_corp_ids c
where c.abbv_identifier_id = a.id 
and lower(a.abbv_number) != 'unknown'
and lower(c.corporate_id) != 'unknown'
),
thing2 as (
select preferred_term,
case 
when non_prop_name_combo like '% and %' then
   lower(concat_ws('; ', sort_array(split(non_prop_name_combo, ' and ')))) 
when non_prop_name_combo like '% + %' then
   lower(concat_ws('; ', sort_array(split(non_prop_name_combo, ' \\\+ ')))) 
else non_prop_name_combo
end as generic_name,
corporate_id
from thing
where non_prop_name_combo is not null
)
select preferred_term abbvdrug,
generic_name,
corporate_id,
size(split(generic_name, '; ')) num_comp
from thing2
""",format='df',rows=0)