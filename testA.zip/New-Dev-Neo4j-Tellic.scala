import com.github.music.of.the.ainur.almaren.Almaren
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SQLContext
import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.neo4j.Neo4j.Neo4jImplicit
import org.apache.log4j.{Level, Logger}

Logger.getLogger("Neo4J").setLevel(Level.DEBUG)

val logger = Logger.getLogger("Neo4J")

val almaren = Almaren("Neo4j-Nodes-Relationships")

val spark = SparkSession.builder().getOrCreate()
/*
import com.modak.common.credential.Credential
import com.modak.common._
val args = sc.getConf.get("spark.driver.args").split("\\s+")
val token = args(0)
val cred_id = args(1).toInt
val cred_type = args(2).toInt
val endpoint = args(3)
val neo4j_url = args(4)

val CredentialResult = Credential.getCredentialData( CredentialPayload(s"$token", cred_id, cred_type, s"$endpoint") )

val ldap = CredentialResult.data match {
    case ldap: ldap => ldap
    case _ => throw new Exception("Currently unable avalible for other credentials Types")
  }
val user = ldap.username
val pass = ldap.password
*/ 
val neo4j_url = "bolt://10.242.33.88:7687"
val user = "neo4j"
val pass = "C#@nG3M3"	
println("NEO4J_URL: " + neo4j_url)
println("User:  " + user)


//neo4j_has_no_effect, neo4j_impact_on - MEDMSD 1,2
logger.info("Creating neo4j_has_no_effect view.")

val neo4j_has_no_effect_df=spark.sql("""SELECT  reluid as relUid,count(*) as num_of_merged, avg(strength) as avg_strength,
cast(null as Integer) as min_epoch_time,
cast(null as Integer) as max_epoch_time,
start_node as concept_1_id,
end_node as concept_2_id,
'Chemical' as entity1_type,
'Measurement' as entity2_type
from preclinical_dev.t_compound_endpoint_medmsd_solr_run3  where relationship_type =  "Has No Effect" 
GROUP BY relUid, start_node, end_node """)
neo4j_has_no_effect_df.dropDuplicates().createOrReplaceTempView("neo4j_has_no_effect")

logger.info("Creating neo4j_impact_on view.")

val neo4j_impact_on_df=spark.sql("""SELECT  reluid as relUid,count(*) as num_of_merged, avg(strength) as avg_strength,
	cast(null as Integer) as min_epoch_time,
	cast(null as Integer) as max_epoch_time,
	start_node as concept_1_id,
	end_node as concept_2_id,
	'Chemical' as entity1_type,
	'Measurement' as entity2_type
	from preclinical_dev.t_compound_endpoint_medmsd_solr_run3  where relationship_type =  "Impact On" 
GROUP BY relUid, start_node, end_node """)

neo4j_impact_on_df.dropDuplicates().createOrReplaceTempView("neo4j_impact_on")

//neo4j_has_moa -- change solr table name accordingly

logger.info("Creating neo4j_has_moa view.")

val neo4j_has_moa_df=spark.sql("""SELECT  reluid as relUid,count(*) as num_of_merged, avg(strength) as avg_strength,
	cast(null as Integer) as min_epoch_time,
	cast(null as Integer) as max_epoch_time,
	start_node as concept_1_id,
	end_node as concept_2_id,
	'Drug' as entity1_type,
	'Gene' as entity2_type
	from preclinical_dev.t_drug_gene_solr_run3  where relationship_type =  "Has MOA" 
GROUP BY relUid, start_node, end_node """)
neo4j_has_moa_df.dropDuplicates().createOrReplaceTempView("neo4j_has_moa")

//neo4j_decreases_the_effect_of

logger.info("Creating neo4j_decreases_the_effect_of view.")

val neo4j_decreases_the_effect_of_df =  spark.sql("""SELECT relUid
		,count(*) as num_of_merged
		,avg(strength) as avg_strength
		,min_epoch_time, max_epoch_time, concept_1_id, concept_2_id, entity1_type, entity2_type
		from (
			SELECT  reluid as relUid,strength,
			cast(null as Integer) as min_epoch_time,
			cast(null as Integer) as max_epoch_time,
			start_node as concept_1_id,
			end_node as concept_2_id,
			'Drug' as entity1_type,
			'Drug' as entity2_type
			from preclinical_dev.t_scopia_drug_drug_solr_run3 where relationship_type =    "Decreases The Effect Of" 
			union all
			SELECT  reluid as relUid,strength,
			cast(null as Integer) as min_epoch_time,
			cast(null as Integer) as max_epoch_time,
			start_node as concept_1_id,
			end_node as concept_2_id,
			'Drug' as entity1_type,
			'Clinical Condition' as entity2_type
			from preclinical_dev.t_scopia_drug_ci_solr_run3  where relationship_type =    "Decreases The Effect Of" 
		)x 
	GROUP BY relUid, concept_1_id, concept_2_id, entity1_type, entity2_type, min_epoch_time, max_epoch_time""")

neo4j_decreases_the_effect_of_df.dropDuplicates().createOrReplaceTempView("neo4j_decreases_the_effect_of")


//neo4j_shares_pathway
logger.info("Creating neo4j_shares_pathway view.")
val neo4j_shares_pathway_df=spark.sql("""SELECT  reluid as relUid,count(*) as num_of_merged, avg(strength) as avg_strength,
	cast(null as Integer) as min_epoch_time,
	cast(null as Integer) as max_epoch_time,
	start_node as concept_1_id,
	end_node as concept_2_id,
	'Gene' as entity1_type,
	'Gene' as entity2_type
	from preclinical_dev.t_cpdb_gene_gene_solr_run3  where relationship_type =  "Shares Pathway With" 
	GROUP BY relUid, start_node, end_node """)
neo4j_shares_pathway_df.dropDuplicates().createOrReplaceTempView("neo4j_shares_pathway")

//neo4j_has_activity_against
logger.info("Creating neo4j_has_activity_against view.")
val neo4j_has_activity_against_df =  spark.sql("""
	SELECT relUid
	,count(*) as num_of_merged
	,avg(strength) as avg_strength
	,min_epoch_time, max_epoch_time, concept_1_id, concept_2_id, entity1_type, entity2_type
	from (
		SELECT  reluid as relUid,strength,
         cast(null as Integer) as min_epoch_time,
         cast(null as Integer) as max_epoch_time,
         start_node as concept_1_id,
         end_node as concept_2_id,
         'Chemical' as entity1_type,
         'CellLine' as entity2_type
         from preclinical_dev.t_tdb_sm_cell_solr_run3  where relationship_type =   "Has Activity Against"
		 
		 union all
		 
		 SELECT  reluid as relUid,strength,
         cast(null as Integer) as min_epoch_time,
         cast(null as Integer) as max_epoch_time,
         start_node as concept_1_id,
         end_node as concept_2_id,
         'Chemical' as entity1_type,
         'Gene' as entity2_type
         from preclinical_dev.t_fdb_sm_gene_solr_run3  where relationship_type =   "Has Activity Against"
		 )x
	GROUP BY relUid, concept_1_id, concept_2_id, entity1_type, entity2_type, min_epoch_time, max_epoch_time""")

neo4j_has_activity_against_df.dropDuplicates().createOrReplaceTempView("neo4j_has_activity_against")


//neo4j_is_member_of
logger.info("Creating neo4j_is_member_of view.")
val neo4j_is_member_of_df =  spark.sql("""SELECT relUid
	,count(*) as num_of_merged
	,avg(strength) as avg_strength
	,min_epoch_time, max_epoch_time, concept_1_id, concept_2_id, entity1_type, entity2_type
	from (
		SELECT reluid as relUid
		, strength
		,cast(null as Integer) as min_epoch_time,
		cast(null as Integer) as max_epoch_time,
		start_node as concept_1_id,
		end_node as concept_2_id,
		'Clinical Condition' as entity1_type,
		'Clinical Interaction' as entity2_type
		from preclinical_dev.t_scopia_dci_ci_solr_run3  where relationship_type = "Is A Member Of"
	   
		union all
	   
		SELECT reluid as relUid
		, strength
		,cast(null as Integer) as min_epoch_time,
		cast(null as Integer) as max_epoch_time,
		start_node as concept_1_id,
		end_node as concept_2_id,
		'Drug' as entity1_type,
		'Clinical Interaction' as entity2_type
		from preclinical_dev.t_scopia_dci_ai_solr_run3  where relationship_type = "Is A Member Of"
	   
		union all
	   
		SELECT reluid as relUid
		, strength
		,cast(null as Integer) as min_epoch_time,
		cast(null as Integer) as max_epoch_time,
		start_node as concept_1_id,
		end_node as concept_2_id,
		'Drug' as entity1_type,
		'Drug Interaction' as entity2_type
		from preclinical_dev.t_scopia_ddi_di_solr_run3  where relationship_type = "Is A Member Of"
	   
		union all
	   
		SELECT  reluid as relUid, strength,
		cast(null as Integer) as min_epoch_time,
		cast(null as Integer) as max_epoch_time,
		start_node as concept_1_id,
		end_node as concept_2_id,
		'Drug' as entity1_type,
		'Drug Interaction' as entity2_type
		from preclinical_dev.t_scopia_ddi_dps_solr_run3  where relationship_type = "Is A Member Of"
		)x
	GROUP BY relUid, concept_1_id, concept_2_id, entity1_type, entity2_type, min_epoch_time, max_epoch_time""")

neo4j_is_member_of_df.dropDuplicates().createOrReplaceTempView("neo4j_is_member_of")


//neo4j_has_side_effect
logger.info("Creating neo4j_has_side_effect view.")

val neo4j_has_side_effect_df =  spark.sql("""SELECT relUid
	,count(*) as num_of_merged
	,avg(strength) as avg_strength
	,min_epoch_time, max_epoch_time, concept_1_id, concept_2_id, entity1_type, entity2_type
	from (
		SELECT  reluid as relUid,strength,
		cast(null as Integer) as min_epoch_time,
		cast(null as Integer) as max_epoch_time,
		start_node as concept_1_id,
		end_node as concept_2_id,
		'Drug' as entity1_type,
		'Adverse Event' as entity2_type
		from preclinical_dev.t_scopia_drug_ae_solr_run3  where relationship_type =   "Has Side Effect" 
		union all
		SELECT  reluid as relUid,strength,
		cast(null as Integer) as min_epoch_time,
		cast(null as Integer) as max_epoch_time,
		start_node as concept_1_id,
		end_node as concept_2_id,
		'Drug' as entity1_type,
		'Adverse Event' as entity2_type
		from preclinical_dev.t_scopia_rare_ae_solr_run3  where relationship_type =   "Has Side Effect" 
	  )x
	GROUP BY relUid, concept_1_id, concept_2_id, entity1_type, entity2_type, min_epoch_time, max_epoch_time""")

neo4j_has_side_effect_df.dropDuplicates().createOrReplaceTempView("neo4j_has_side_effect")


// HAS MODULATED SIDE EFFECT
logger.info("Creating neo4j_has_modulated_side_effect view.")

val neo4j_has_modulated_side_effect_df =  spark.sql("""SELECT relUid
		,count(*) as num_of_merged
		,avg(strength) as avg_strength
		,min_epoch_time, max_epoch_time, concept_1_id, concept_2_id, entity1_type, entity2_type
		from (
		SELECT  reluid as relUid,strength,
		cast(null as Integer) as min_epoch_time,
		cast(null as Integer) as max_epoch_time,
		start_node as concept_1_id,
		end_node as concept_2_id,
		'Drug Interaction' as entity1_type,
		'Adverse Event' as entity2_type
		from preclinical_dev.t_scopia_ddi_ae_solr_run3  where relationship_type =   "Has Modulated Side Effect" 
		union all
		SELECT  reluid as relUid, strength,
		cast(null as Integer) as min_epoch_time,
		cast(null as Integer) as max_epoch_time,
		start_node as concept_1_id,
		end_node as concept_2_id,
		'Clinical Interaction' as entity1_type,
		'Adverse Event' as entity2_type
		from preclinical_dev.t_scopia_dci_ae_solr_run3  where relationship_type =   "Has Modulated Side Effect" 
		)x
	GROUP BY relUid, concept_1_id, concept_2_id, entity1_type, entity2_type, min_epoch_time, max_epoch_time""")

neo4j_has_modulated_side_effect_df.dropDuplicates().createOrReplaceTempView("neo4j_has_modulated_side_effect")


// HAS AN INTERACTION WITH
logger.info("Creating neo4j_has_interaction_with view.")

val neo4j_has_an_interaction_with_df =  spark.sql("""SELECT relUid
		,count(*) as num_of_merged
		,avg(strength) as avg_strength
		,min_epoch_time, max_epoch_time, concept_1_id, concept_2_id, entity1_type, entity2_type
		from (
		SELECT  reluid as relUid,strength,
		cast(null as Integer) as min_epoch_time,
		cast(null as Integer) as max_epoch_time,
		start_node as concept_1_id,
		end_node as concept_2_id,
		'Drug' as entity1_type,
		'Drug' as entity2_type
		from preclinical_dev.t_scopia_drug_drug_solr_run3  where relationship_type =   "Has An Interaction With"
		union all
		 
		SELECT  reluid as relUid,strength,
		cast(null as Integer) as min_epoch_time,
		cast(null as Integer) as max_epoch_time,
		start_node as concept_1_id,
		end_node as concept_2_id,
		'Drug' as entity1_type,
		'Clinical Condition' as entity2_type
		from preclinical_dev.t_scopia_drug_ci_solr_run3  where relationship_type =   "Has An Interaction With" 
		)x 
	GROUP BY relUid, concept_1_id, concept_2_id, entity1_type, entity2_type, min_epoch_time, max_epoch_time""")

neo4j_has_an_interaction_with_df.dropDuplicates().createOrReplaceTempView("neo4j_has_an_interaction_with")


//INCREASES THE EFFECT OF
logger.info("Creating neo4j_increases_the_effect_of view.")

val neo4j_increases_the_effect_of_df =  spark.sql("""SELECT relUid
		,count(*) as num_of_merged
		,avg(strength) as avg_strength
		,min_epoch_time, max_epoch_time, concept_1_id, concept_2_id, entity1_type, entity2_type
		from (
		SELECT  reluid as relUid,strength,
		cast(null as Integer) as min_epoch_time,
		cast(null as Integer) as max_epoch_time,
		start_node as concept_1_id,
		end_node as concept_2_id,
		'Drug' as entity1_type,
		'Drug' as entity2_type
		from preclinical_dev.t_scopia_drug_drug_solr_run3 where relationship_type =   "Increases The Effect Of" 
		union all
		SELECT  reluid as relUid,strength,
		cast(null as Integer) as min_epoch_time,
		cast(null as Integer) as max_epoch_time,
		start_node as concept_1_id,
		end_node as concept_2_id,
		'Drug' as entity1_type,
		'Clinical Condition' as entity2_type
		from preclinical_dev.t_scopia_drug_ci_solr_run3  where relationship_type =   "Increases The Effect Of" 
		)x 
	GROUP BY relUid, concept_1_id, concept_2_id, entity1_type, entity2_type, min_epoch_time, max_epoch_time""")

neo4j_increases_the_effect_of_df.dropDuplicates().createOrReplaceTempView("neo4j_increases_the_effect_of")

//HAS ANTAGONISM AGAINST
logger.info("Creating neo4j_has_antagonism_against view.")

val neo4j_has_antagonism_against_df =  spark.sql("""SELECT relUid
		,count(*) as num_of_merged
		,avg(strength) as avg_strength
		,min_epoch_time, max_epoch_time, concept_1_id, concept_2_id, entity1_type, entity2_type
		from (
		SELECT  reluid as relUid,strength,
         cast(null as Integer) as min_epoch_time,
         cast(null as Integer) as max_epoch_time,
         start_node as concept_1_id,
         end_node as concept_2_id,
         'Chemical' as entity1_type,
         'CellLine' as entity2_type
         from preclinical_dev.t_tdb_sm_cell_solr_run3  where relationship_type =   "Has Antagonism Against"
		 
		 union all
		
		SELECT  reluid as relUid,strength,
		cast(null as Integer) as min_epoch_time,
		cast(null as Integer) as max_epoch_time,
		start_node as concept_1_id,
		end_node as concept_2_id,
		'Chemical' as entity1_type,
		'Gene' as entity2_type
		from preclinical_dev.t_fdb_sm_gene_solr_run3  where relationship_type =   "Has Antagonism Against"
		)x 
	GROUP BY relUid, concept_1_id, concept_2_id, entity1_type, entity2_type, min_epoch_time, max_epoch_time""")

neo4j_has_antagonism_against_df.dropDuplicates().createOrReplaceTempView("neo4j_has_antagonism_against")


//HAS MODULATION AGAINST
logger.info("Creating neo4j_has_modulation_against view.")

val neo4j_has_modulation_against_df =  spark.sql("""SELECT relUid
		,count(*) as num_of_merged
		,avg(strength) as avg_strength
		,min_epoch_time, max_epoch_time, concept_1_id, concept_2_id, entity1_type, entity2_type
		from (
		SELECT  reluid as relUid,strength,
         cast(null as Integer) as min_epoch_time,
         cast(null as Integer) as max_epoch_time,
         start_node as concept_1_id,
         end_node as concept_2_id,
         'Chemical' as entity1_type,
         'CellLine' as entity2_type
         from preclinical_dev.t_tdb_sm_cell_solr_run3  where relationship_type =   "Has Modulation Against"
		 
		 union all
		 
		SELECT  reluid as relUid,strength,
		cast(null as Integer) as min_epoch_time,
		cast(null as Integer) as max_epoch_time,
		start_node as concept_1_id,
		end_node as concept_2_id,
		'Chemical' as entity1_type,
		'Gene' as entity2_type
		from preclinical_dev.t_fdb_sm_gene_solr_run3  where relationship_type =   "Has Modulation Against" 	)x  
	GROUP BY relUid, concept_1_id, concept_2_id, entity1_type, entity2_type, min_epoch_time, max_epoch_time""")

neo4j_has_modulation_against_df.dropDuplicates().createOrReplaceTempView("neo4j_has_modulation_against")

//HAS INDUCTION/ACTIVATION AGAINST
logger.info("Creating neo4j_has_induction_or_activation_against view.")

val neo4j_has_induction_or_activation_against_df =  spark.sql("""SELECT relUid
		,count(*) as num_of_merged
		,avg(strength) as avg_strength
		,min_epoch_time, max_epoch_time, concept_1_id, concept_2_id, entity1_type, entity2_type
		from (
		 SELECT  reluid as relUid,strength,
         cast(null as Integer) as min_epoch_time,
         cast(null as Integer) as max_epoch_time,
         start_node as concept_1_id,
         end_node as concept_2_id,
         'Chemical' as entity1_type,
         'CellLine' as entity2_type
         from preclinical_dev.t_tdb_sm_cell_solr_run3  where relationship_type =   "Has Induction/Activation Against"
		 
		 union all
		SELECT  reluid as relUid,strength,
		cast(null as Integer) as min_epoch_time,
		cast(null as Integer) as max_epoch_time,
		start_node as concept_1_id,
		end_node as concept_2_id,
		'Chemical' as entity1_type,
		'Gene' as entity2_type
		from preclinical_dev.t_fdb_sm_gene_solr_run3  where relationship_type =   "Has Induction/Activation Against" 
		)x 
	GROUP BY relUid, concept_1_id, concept_2_id, entity1_type, entity2_type, min_epoch_time, max_epoch_time""")

neo4j_has_induction_or_activation_against_df.dropDuplicates().createOrReplaceTempView("neo4j_has_induction_or_activation_against")

//neo4j_does_not_significantly_affect_df
logger.info("Creating neo4j_does_not_significantly_affect view.")

val neo4j_does_not_significantly_affect_df =spark.sql("""
		SELECT reluid as relUid,count(*) as num_of_merged, avg(strength) as avg_strength,
		cast(null as Integer) as min_epoch_time,
		cast(null as Integer) as max_epoch_time,
		start_node as concept_1_id,
		end_node as concept_2_id,
		'Chemical' as entity1_type,
		'Measurement' as entity2_type
		from preclinical_dev.t_pcsdw_solr_run3 where relationship_type =  "Does Not Significantly Affect" 
		GROUP BY  relUid, start_node, end_node """)
neo4j_does_not_significantly_affect_df.dropDuplicates().createOrReplaceTempView("neo4j_does_not_significantly_affect")

//neo4j_increases
logger.info("Creating neo4j_increases view.")

val neo4j_increases_df =spark.sql("""
		SELECT reluid as relUid,count(*) as num_of_merged, avg(strength) as avg_strength,
		cast(null as Integer) as min_epoch_time,
		cast(null as Integer) as max_epoch_time,
		start_node as concept_1_id,
		end_node as concept_2_id,
		'Chemical' as entity1_type,
		'Measurement' as entity2_type
		from preclinical_dev.t_pcsdw_solr_run3 where relationship_type = "Increases" 
		GROUP BY  relUid, start_node, end_node """)

neo4j_increases_df.dropDuplicates().createOrReplaceTempView("neo4j_increases")

//neo4j_decreases
logger.info("Creating neo4j_decreases view.")

val neo4j_decreases_df = spark.sql("""
		SELECT reluid as relUid,count(*) as num_of_merged, avg(strength) as avg_strength,
		cast(null as Integer) as min_epoch_time,
		cast(null as Integer) as max_epoch_time,
		start_node as concept_1_id,
		end_node as concept_2_id,
		'Chemical' as entity1_type,
		'Measurement' as entity2_type
		from preclinical_dev.t_pcsdw_solr_run3 where relationship_type =   "Decreases" 
		GROUP BY  relUid, start_node, end_node """)
neo4j_decreases_df.dropDuplicates().createOrReplaceTempView("neo4j_decreases")



//neo4j_is_chemically_similar_to
logger.info("Creating neo4j_is_chemically_similar_to view.")

val neo4j_is_chemically_similar_to_df=spark.sql("""SELECT  reluid as relUid,count(*) as num_of_merged, avg(strength) as avg_strength,
cast(null as Integer) as min_epoch_time,
cast(null as Integer) as max_epoch_time,
start_node as concept_1_id,
end_node as concept_2_id,
'Chemical' as entity1_type,
'Chemical' as entity2_type
from preclinical_dev.t_fdb_comp_sim_solr_run3  where relationship_type =   "Is Chemically Similar To" 
GROUP BY relUid, start_node, end_node """)
neo4j_is_chemically_similar_to_df.dropDuplicates().createOrReplaceTempView("neo4j_is_chemically_similar_to")



//neo4j_contains
logger.info("Creating neo4j_contains view.")

val neo4j_contains_df=spark.sql("""SELECT  reluid as relUid,count(*) as num_of_merged, avg(strength) as avg_strength,
cast(null as Integer) as min_epoch_time,
cast(null as Integer) as max_epoch_time,
start_node as concept_1_id,
end_node as concept_2_id,
'Drug' as entity1_type,
'Chemical' as entity2_type
from preclinical_dev.t_fdb_drug_comp_solr_run3  where relationship_type =   "Contains" 
GROUP BY relUid, start_node, end_node """)
neo4j_contains_df.dropDuplicates().createOrReplaceTempView("neo4j_contains")

//neo4j_has_agonism_against
logger.info("Creating neo4j_has_agonism_against view.")

val neo4j_has_agonism_against_df=spark.sql("""SELECT  reluid as relUid,count(*) as num_of_merged, avg(strength) as avg_strength,
cast(null as Integer) as min_epoch_time,
cast(null as Integer) as max_epoch_time,
start_node as concept_1_id,
end_node as concept_2_id,
'Chemical' as entity1_type,
'Gene' as entity2_type
from preclinical_dev.t_fdb_sm_gene_solr_run3  where relationship_type = "Has Agonism Against" 
GROUP BY relUid, start_node, end_node """)
neo4j_has_agonism_against_df.dropDuplicates().createOrReplaceTempView ("neo4j_has_agonism_against")

//---------------------------------------NEO4J-LABELS-----------------------------------------------------
var adverseEvent = "Adverse Event"
var cellType  = "CellType"
var cellLine = "CellLine"
var chemical = "Chemical"
var clinicalCondition = "Clinical Condition"
var clinicalInteraction = "Clinical Interaction"
var disease = "Disease"
var drug = "Drug"
var drugProduct = "Drug Product"
var drugInteraction = "Drug Interaction"
var gene = "Gene"
var measurement = "Measurement"
var phenotype = "Phenotype"
var variant = "Variant"


//-----------------------------------NEO4J preclinical_dev NODES---------------------------

logger.info("Loading Drug nodes into Neo4j.")

val node_preclinical_dev_drug = almaren.builder
.sourceSql("select * from preclinical_dev.tellic_node_drug_run3 where concept_id is not NULL")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("labels" -> drug,
		"batch.size" -> "20000",
		"node.keys" -> "concept_id",
		"node.properties" -> "entity_type ,ontology ,entity_name ,class ,label ,molecule_type ,max_phase ,therapeutic_flag ,first_approval ,rxcui ,pharmacological_action_classes ,moa_classes ,atc_classes ,targets ,synonyms ,run_date ",
		"script" -> "CREATE CONSTRAINT ON ( clinicalinteraction:`Clinical Interaction` ) ASSERT clinicalinteraction.concept_id IS UNIQUE; CREATE CONSTRAINT ON ( druginteraction:`Drug Interaction` ) ASSERT druginteraction.concept_id IS UNIQUE; CREATE CONSTRAINT ON ( drugproduct:`Drug Product` ) ASSERT drugproduct.concept_id IS UNIQUE; CREATE CONSTRAINT ON ( celltype:CellType ) ASSERT celltype.concept_id IS UNIQUE; CREATE CONSTRAINT ON ( clinicalcondition:`Clinical Condition` ) ASSERT clinicalcondition.concept_id IS UNIQUE; CREATE CONSTRAINT ON ( adverseevent:`Adverse Event` ) ASSERT adverseevent.concept_id IS UNIQUE; CREATE CONSTRAINT ON ( chemical:Chemical ) ASSERT chemical.concept_id IS UNIQUE; CREATE CONSTRAINT ON ( drug:Drug ) ASSERT drug.concept_id IS UNIQUE; CREATE CONSTRAINT ON ( measurement:Measurement ) ASSERT measurement.concept_id IS UNIQUE; CREATE CONSTRAINT ON ( gene:Gene ) ASSERT gene.concept_id IS UNIQUE; CREATE CONSTRAINT ON ( phenotype:Phenotype ) ASSERT phenotype.concept_id IS UNIQUE; CREATE CONSTRAINT ON ( variant:Variant ) ASSERT variant.concept_id IS UNIQUE;  CREATE CONSTRAINT ON ( disease:Disease ) ASSERT disease.concept_id IS UNIQUE; CREATE CONSTRAINT ON ( cellline:CellLine ) ASSERT cellline.concept_id IS UNIQUE; "),
	SaveMode.Overwrite
	)
.batch

logger.info("Loading Measurement nodes into Neo4j.")

val node_preclinical_dev_measurement = almaren.builder
.sourceSql("select * from preclinical_dev.tellic_node_measurement_run3 where concept_id is not NULL")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("labels" -> measurement,
		"batch.size" -> "20000",
		"node.keys" -> "concept_id",
		"node.properties" -> "entity_type ,ontology ,entity_name ,label"),
	SaveMode.Overwrite
	)
.batch	

logger.info("Loading Gene nodes into Neo4j.")

val node_preclinical_dev_gene = almaren.builder
.sourceSql("select * from preclinical_dev.tellic_node_gene_run3 where concept_id is not NULL")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("labels" -> gene,
		"batch.size" -> "20000",
		"node.keys" -> "concept_id",
		"node.properties" -> "entity_type ,ontology ,entity_name ,class ,label ,approved_name ,gene_type ,entrez_id ,uniprot_ids ,ensembl_id ,opentargets_link ,mgd_ids ,reactome_ids ,synonyms ,run_date"),
	SaveMode.Overwrite
	)
.batch	

logger.info("Loading Adverse Event nodes into Neo4j.")

val node_preclinical_dev_adverse_event = almaren.builder
.sourceSql("select * from preclinical_dev.tellic_node_ae_run3 where concept_id is not NULL")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("labels" -> adverseEvent,
		"batch.size" -> "20000",
		"node.keys" -> "concept_id",
		"node.properties" -> "entity_type ,ontology ,entity_name ,class ,label ,synonyms ,term_class ,system_organ_classes ,run_date"),
	SaveMode.Overwrite
	)
.batch	

logger.info("Loading Chemical nodes into Neo4j.")

val node_preclinical_dev_chem_subset = almaren.builder
.sourceSql("select * from preclinical_dev.tellic_node_chem_subset_run3 where concept_id is not NULL")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("labels" -> chemical,
		"batch.size" -> "20000",
		"node.keys" -> "concept_id",
		"node.properties" -> "entity_type ,ontology ,entity_name ,class ,label ,synonyms ,pubchem_ids ,chebi_ids ,rxnorm_ids ,inchi_key ,smiles ,iupac_name"),
	SaveMode.Overwrite
	)
.batch	


//New Node tables


//node_preclinical_dev_cellline
logger.info("Loading CellLine nodes into Neo4j.")

val node_preclinical_dev_cellline = almaren.builder
.sourceSql("select * from preclinical_dev.tellic_node_cellline_run3 where concept_id is not NULL")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("labels" -> cellLine,
		"batch.size" -> "20000",
		"node.keys" -> "concept_id",
		"node.properties" -> "entity_name, entity_type, ontology, label"),
	SaveMode.Overwrite
	)
.batch

//node_preclinical_dev_dci
logger.info("Loading Clinical Interaction nodes into Neo4j.")

val node_preclinical_dev_dci = almaren.builder
.sourceSql("select * from preclinical_dev.tellic_node_dci_run3 where concept_id is not NULL")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("labels" -> clinicalInteraction,
		"batch.size" -> "20000",
		"node.keys" -> "concept_id",
		"node.properties" -> "entity_name, entity_type, ontology, label"),
	SaveMode.Overwrite
	)
.batch

//node_preclinical_dev_ddi
logger.info("Loading Drug Interaction nodes into Neo4j.")

val node_preclinical_dev_ddi = almaren.builder
.sourceSql("select * from preclinical_dev.tellic_node_ddi_run3 where concept_id is not NULL")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("labels" -> drugInteraction,
		"batch.size" -> "20000",
		"node.keys" -> "concept_id",
		"node.properties" -> "entity_name, entity_type, ontology, label"),
	SaveMode.Overwrite
	)
.batch	

//node_preclinical_dev_clinicalcondition
logger.info("Loading Clinical Condition nodes into Neo4j.")

val node_preclinical_dev_clinicalcondition = almaren.builder
.sourceSql("select * from preclinical_dev.tellic_node_clinicalcondition_run3 where concept_id is not NULL")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("labels" -> clinicalCondition,
		"batch.size" -> "20000",
		"node.keys" -> "concept_id",
		"node.properties" -> "entity_name, entity_type, ontology, label"),
	SaveMode.Overwrite
	)
.batch	

//-----------------------------------NEO4J-TELLIC-NODES--------------------------------------------------------------
logger.info("Loading Drug Product nodes into Neo4j.")

val node_drug_product_df = almaren.builder
.sourceSql("select * from tellic_abbvie.t_tellic_abbvie_tellic_graph_data_node_drug_product where concept_id is not NULL")  
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("labels" -> ":Drug Product",
		"batch.size" -> "20000",
		"node.keys" -> "concept_id",
		"node.properties" -> "label, entity_type, class, entity_name, ontology, generic, ndc_list, labeler_list, quantity, strength, prescribable, schedule, general_cardinality, synonyms, run_date"),
		SaveMode.Overwrite
	)
.batch
    

logger.info("Loading Phenotype nodes into Neo4j.")

val node_pheno_df = almaren.builder
.sourceSql("select * from tellic_abbvie.t_tellic_abbvie_tellic_graph_data_node_pheno where concept_id is not NULL")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("labels" -> phenotype,
		"batch.size" -> "20000",
		"node.keys" -> "concept_id",
		"node.properties" -> "entity_type ,ontology ,entity_name ,class ,label ,definition ,synonyms ,run_date"),
	SaveMode.Overwrite
	)
.batch

logger.info("Loading Variant nodes into Neo4j.")

val node_variant_df = almaren.builder
.sourceSql("select * from tellic_abbvie.t_tellic_abbvie_tellic_graph_data_node_variant where concept_id is not NULL")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("labels" -> variant,
		"batch.size" -> "20000",
		"node.keys" -> "concept_id",
		"node.properties" -> "entity_type ,ontology ,entity_name ,label ,chromosome ,position ,synonyms ,run_date"),
		SaveMode.Overwrite
	)
.batch

logger.info("Loading Disease nodes into Neo4j.")

val node_diso_df = almaren.builder
.sourceSql("select * from tellic_abbvie.t_tellic_abbvie_tellic_graph_data_node_diso where concept_id is not NULL")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("labels" -> disease,
		"batch.size" -> "20000",
		"node.keys" -> "concept_id",
		"node.properties" -> "entity_type ,ontology ,entity_name ,class ,label ,therapeutic_areas ,synonyms ,run_date"),
	SaveMode.Overwrite
	)
.batch

logger.info("Loading CellType nodes into Neo4j.")

val node_celltype_df = almaren.builder
.sourceSql("select * from tellic_abbvie.t_tellic_abbvie_tellic_graph_data_node_celltype where concept_id is not NULL")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("labels" -> cellType,
		"batch.size" -> "20000",
		"node.keys" -> "concept_id",
		"node.properties" -> "definition ,entity_name ,synonyms ,xrefs ,ontology ,entity_type ,label"),
	SaveMode.Overwrite
	)
.batch

//---------------------------------END-NEO4J-TELLIC-NODES--------------------------------------------------------------
	

//-----------------------------------NEO4J-TELLIC-RELATIONSHIPS--------------------------------------------------------
logger.info("Loading HAS_ADVERSE_EVENT relationships into Neo4j.")

val neo4j_adverse_event_df = almaren.builder
.sourceSql("select * from tellic_abbvie.t_tellic_abbvie_tellic_graph_data_processed_relationships_adverse_event where concept_1_id is not null and concept_2_id is not null")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("relationship" -> "HAS_ADVERSE_EVENT",
		"relationship.source.labels" -> drug,
		"relationship.source.node.keys" -> "concept_1_id:concept_id",
		"relationship.source.save.mode" -> "Overwrite",
		"relationship.target.labels" -> adverseEvent,
		"relationship.target.node.keys" -> "concept_2_id:concept_id",
		"relationship.target.save.mode" -> "Overwrite",
		"relationship.save.strategy" -> "keys",
		"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
		"batch.size" -> "50000",
		"transaction.retries" -> "5"),
	SaveMode.Overwrite
	)
.batch

logger.info("Loading HAS_INGREDIENT relationships into Neo4j.")

val neo4j_has_ingredient_df = almaren.builder
.sourceSql("select * from tellic_abbvie.t_tellic_abbvie_tellic_graph_data_processed_relationships_has_ingredient where concept_1_id is not null and concept_2_id is not null")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("relationship" -> "HAS_INGREDIENT",
		"relationship.source.labels" -> drugProduct,
		"relationship.source.node.keys" -> "concept_1_id:concept_id",
		"relationship.source.save.mode" -> "Overwrite",
		"relationship.target.labels" -> drug,
		"relationship.target.node.keys" -> "concept_2_id:concept_id",
		"relationship.target.save.mode" -> "Overwrite",
		"relationship.save.strategy" -> "keys",
		"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
		"batch.size" -> "50000",
		"transaction.retries" -> "5"),
	SaveMode.Overwrite
	)
.batch

logger.info("Loading HAS_ISOMER relationships into Neo4j.")

val neo4j_has_isomer_df = almaren.builder
.sourceSql("select * from tellic_abbvie.t_tellic_abbvie_tellic_graph_data_processed_relationships_has_isomer where concept_1_id is not null and concept_2_id is not null")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("relationship" -> "HAS_ISOMER",
		"relationship.source.labels" -> chemical,
		"relationship.source.node.keys" -> "concept_1_id:concept_id",
		"relationship.source.save.mode" -> "Overwrite",
		"relationship.target.labels" -> chemical,
		"relationship.target.node.keys" -> "concept_2_id:concept_id",
		"relationship.target.save.mode" -> "Overwrite",
		"relationship.save.strategy" -> "keys",
		"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
		"batch.size" -> "50000",
		"transaction.retries" -> "5"),
	SaveMode.Overwrite
	)
.batch
	
logger.info("Loading HAS_PARENT relationships into Neo4j.")

val neo4j_has_parent_df = almaren.builder
.sourceSql("select * from tellic_abbvie.t_tellic_abbvie_tellic_graph_data_processed_relationships_has_parent where concept_1_id is not null and concept_2_id is not null")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("relationship" -> "HAS_PARENT",   
		"relationship.source.labels" -> chemical,
		"relationship.source.node.keys" -> "concept_1_id:concept_id",
		"relationship.source.save.mode" -> "Overwrite",
		"relationship.target.labels" -> chemical,
		"relationship.target.node.keys" -> "concept_2_id:concept_id",
		"relationship.target.save.mode" -> "Overwrite",
		"relationship.save.strategy" -> "keys",
		"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
		"batch.size" -> "50000",
		"transaction.retries" -> "5"),
	SaveMode.Overwrite
	)
.batch

logger.info("Loading HAS_PRECISE_INGREDIENT relationships into Neo4j.")

val neo4j_has_precise_ingredient_df = almaren.builder
.sourceSql("select * from tellic_abbvie.t_tellic_abbvie_tellic_graph_data_processed_relationships_has_precise_ingredient where concept_1_id is not null and concept_2_id is not null")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("relationship" -> "HAS_PRECISE_INGREDIENT",
		"relationship.source.labels" -> drugProduct,
		"relationship.source.node.keys" -> "concept_1_id:concept_id",
		"relationship.source.save.mode" -> "Overwrite",
		"relationship.target.labels" -> drug,
		"relationship.target.node.keys" -> "concept_2_id:concept_id",
		"relationship.target.save.mode" -> "Overwrite",
		"relationship.save.strategy" -> "keys",
		"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
		"batch.size" -> "50000",
		"transaction.retries" -> "5"),
	SaveMode.Overwrite
	)
.batch

logger.info("Loading IS_EQUAL_TO relationships into Neo4j.")

val neo4j_is_equal_to_df = almaren.builder
.sourceSql("select * from tellic_abbvie.t_tellic_abbvie_tellic_graph_data_processed_relationships_is_equal_to where concept_1_id is not null and concept_2_id is not null")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("relationship" -> "IS_EQUAL_TO",    
		"relationship.source.labels" -> chemical,
		"relationship.source.node.keys" -> "concept_1_id:concept_id",
		"relationship.source.save.mode" -> "Overwrite",
		"relationship.target.labels" -> drug,
		"relationship.target.node.keys" -> "concept_2_id:concept_id",
		"relationship.target.save.mode" -> "Overwrite",
		"relationship.save.strategy" -> "keys",
		"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
		"batch.size" -> "50000",
		"transaction.retries" -> "5"),
	SaveMode.Overwrite
	)
.batch
	

val with_ID_1 = List("CL", "CHEMBL", "EFO", "HGNC", "MESH");
val with_ID_2 = List("tellicVO", "HGNC", "MESH", "EFO", "CHEMBL" );

def label(x: String): String = x match {
  case "CHEMBL" => "Drug"
  case "HGNC" => "Gene"
  case "CL" => "CellType"
  case "EFO" => "Phenotype"
  case "MESH" => "Disease"
  case "tellicVO" => "Variant"
}

logger.info("Loading RELATED_TO relationships into Neo4j.")

for( a <- with_ID_1 ){
	for( b <- with_ID_2 ){
		var label_1 = label(a) 
		var label_2 = label(b)
		print("concept_1_id: " + a + " -> " + "concept_2_id: " + b)
		spark.sql("select count(*) from tellic_abbvie.t_tellic_abbvie_tellic_graph_data_processed_relationships_with_strength where concept_1_id is not null and concept_2_id is not null and "+"concept_1_id like '" + a + "%' and concept_2_id like '" + b + "%'").show(false)
		
		val neo4j_with_strength_df = almaren.builder
		.sourceSql("select * from tellic_abbvie.t_tellic_abbvie_tellic_graph_data_processed_relationships_with_strength where concept_1_id is not null and concept_2_id is not null and "+"concept_1_id like '" + a + "%' and concept_2_id like '" + b + "%'")
		.repartition(1)
		.targetNeo4j(
			s"$neo4j_url", 
			Some(s"$user"),
			Some(s"$pass"),
			Map("relationship" -> "RELATED_TO",    
				"relationship.source.labels" -> s"$label_1",
				"relationship.source.node.keys" -> "concept_1_id:concept_id",
				"relationship.source.save.mode" -> "Overwrite",
				"relationship.target.labels" -> s"$label_2",
				"relationship.target.node.keys" -> "concept_2_id:concept_id",
				"relationship.target.save.mode" -> "Overwrite",
				"relationship.save.strategy" -> "keys",
				"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
				"batch.size" -> "50000",
				"transaction.retries" -> "5"),
			SaveMode.Overwrite
			)
		.batch
	}
}

val without_ID_1 = List("CHEMBL", "HGNC", "MESH", "CL", "EFO");
val without_ID_2 = List("HGNC", "tellicVO", "MESH", "EFO", "CHEMBL");

logger.info("Loading RELATED_TO relationships into Neo4j.")

for( a <- without_ID_1 ){
	for( b <- without_ID_2 ){
		var label_1 = label(a)
		var label_2 = label(b)
		print("concept_1_id: " + a + " -> " + "concept_2_id: " + b)
		spark.sql("select count(*) from tellic_abbvie.t_tellic_abbvie_tellic_graph_data_processed_relationships_without_strength where concept_1_id is not null and concept_2_id is not null and "+"concept_1_id like '" + a + "%' and concept_2_id like '" + b + "%'").show(false)
		
		val neo4j_without_strength_df = almaren.builder
		.sourceSql("select * from tellic_abbvie.t_tellic_abbvie_tellic_graph_data_processed_relationships_without_strength where concept_1_id is not null and concept_2_id is not null and "+"concept_1_id like '" + a + "%' and concept_2_id like '" + b + "%'")
		.repartition(1)
		.targetNeo4j(
			s"$neo4j_url",
			Some(s"$user"),
			Some(s"$pass"),
			Map("relationship" -> "RELATED_TO",   
				"relationship.source.labels" -> s"$label_1",
				"relationship.source.node.keys" -> "concept_1_id:concept_id",
				"relationship.source.save.mode" -> "Overwrite",
				"relationship.target.labels" -> s"$label_2",
				"relationship.target.node.keys" -> "concept_2_id:concept_id",
				"relationship.target.save.mode" -> "Overwrite",
				"relationship.save.strategy" -> "keys",
				"relationship.properties" -> "relUid,num_of_merged,min_epoch_time,max_epoch_time",
				"batch.size" -> "50000",
				"transaction.retries" -> "5"),
			SaveMode.Overwrite
			)
		.batch
	}
}

	
//--------------------------------------------NEO4J-preclinical_dev-RELATIONSHIPS----------------------------------------------
logger.info("Loading CONTAINS relationships into Neo4j.")

val neo4j_contains_rel_df = almaren.builder
.sourceSql("select * from neo4j_contains where concept_1_id is not null and concept_2_id is not null")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("relationship" -> "CONTAINS",
		"relationship.source.labels" -> drug,
		"relationship.source.node.keys" -> "concept_1_id:concept_id",
		"relationship.source.save.mode" -> "Overwrite",
		"relationship.target.labels" -> chemical,
		"relationship.target.node.keys" -> "concept_2_id:concept_id",
		"relationship.target.save.mode" -> "Overwrite",
		"relationship.save.strategy" -> "keys",
		"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
		"batch.size" -> "50000",
		"transaction.retries" -> "5"),
	SaveMode.Overwrite
	)
.batch		

logger.info("Loading HAS_ACTIVITY_AGAINST relationships into Neo4j.")

val neo4j_has_activity_against_rel_df1 = almaren.builder
.sourceSql("select * from neo4j_has_activity_against where entity2_type = 'CellLine' and concept_1_id is not null and concept_2_id is not null")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("relationship" -> "HAS_ACTIVITY_AGAINST",
		"relationship.source.labels" -> chemical,
		"relationship.source.node.keys" -> "concept_1_id:concept_id",
		"relationship.source.save.mode" -> "Overwrite",
		"relationship.target.labels" -> cellLine,
		"relationship.target.node.keys" -> "concept_2_id:concept_id",
		"relationship.target.save.mode" -> "Overwrite",
		"relationship.save.strategy" -> "keys",
		"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
		"batch.size" -> "50000",
		"transaction.retries" -> "5"),
	SaveMode.Overwrite
	)
.batch	


val neo4j_has_activity_against_rel_df2 = almaren.builder
.sourceSql("select * from neo4j_has_activity_against where entity2_type = 'Gene' and concept_1_id is not null and concept_2_id is not null")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("relationship" -> "HAS_ACTIVITY_AGAINST",
		"relationship.source.labels" -> chemical,
		"relationship.source.node.keys" -> "concept_1_id:concept_id",
		"relationship.source.save.mode" -> "Overwrite",
		"relationship.target.labels" -> gene,
		"relationship.target.node.keys" -> "concept_2_id:concept_id",
		"relationship.target.save.mode" -> "Overwrite",
		"relationship.save.strategy" -> "keys",
		"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
		"batch.size" -> "50000",
		"transaction.retries" -> "5"),
	SaveMode.Overwrite
	)
.batch

logger.info("Loading HAS_AGONISM_AGAINST relationships into Neo4j.")

val neo4j_has_agonism_against_rel_df = almaren.builder
.sourceSql("select * from neo4j_has_agonism_against where concept_1_id is not null and concept_2_id is not null")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("relationship" -> "HAS_AGONISM_AGAINST",
		"relationship.source.labels" -> chemical,
		"relationship.source.node.keys" -> "concept_1_id:concept_id",
		"relationship.source.save.mode" -> "Overwrite",
		"relationship.target.labels" -> gene,
		"relationship.target.node.keys" -> "concept_2_id:concept_id",
		"relationship.target.save.mode" -> "Overwrite",
		"relationship.save.strategy" -> "keys",
		"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
		"batch.size" -> "50000",
		"transaction.retries" -> "5"),
	SaveMode.Overwrite
	)
.batch

logger.info("Loading HAS_ANTAGONISM_AGAINST relationships into Neo4j.")

val neo4j_has_antagonism_against_rel_df1 = almaren.builder
.sourceSql("select * from neo4j_has_antagonism_against where entity2_type = 'Gene' and concept_1_id is not null and concept_2_id is not null")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("relationship" -> "HAS_ANTAGONISM_AGAINST",
		"relationship.source.labels" -> chemical,
		"relationship.source.node.keys" -> "concept_1_id:concept_id",
		"relationship.source.save.mode" -> "Overwrite",
		"relationship.target.labels" -> gene,
		"relationship.target.node.keys" -> "concept_2_id:concept_id",
		"relationship.target.save.mode" -> "Overwrite",
		"relationship.save.strategy" -> "keys",
		"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
		"batch.size" -> "50000",
		"transaction.retries" -> "5"),
	SaveMode.Overwrite
	)
.batch

val neo4j_has_antagonism_against_rel_df2 = almaren.builder
.sourceSql("select * from neo4j_has_antagonism_against where entity2_type = 'CellLine' and concept_1_id is not null and concept_2_id is not null")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("relationship" -> "HAS_ANTAGONISM_AGAINST",
		"relationship.source.labels" -> chemical,
		"relationship.source.node.keys" -> "concept_1_id:concept_id",
		"relationship.source.save.mode" -> "Overwrite",
		"relationship.target.labels" -> cellLine,
		"relationship.target.node.keys" -> "concept_2_id:concept_id",
		"relationship.target.save.mode" -> "Overwrite",
		"relationship.save.strategy" -> "keys",
		"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
		"batch.size" -> "50000",
		"transaction.retries" -> "5"),
	SaveMode.Overwrite
	)
.batch

logger.info("Loading HAS_INDUCTION_OR_ACTIVATION_AGAINST relationships into Neo4j.")

val neo4j_has_induction_or_activation_against_rel_df1 = almaren.builder
.sourceSql("select * from neo4j_has_induction_or_activation_against where entity2_type = 'Gene' and concept_1_id is not null and concept_2_id is not null")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("relationship" -> "HAS_INDUCTION_OR_ACTIVATION_AGAINST",
		"relationship.source.labels" -> chemical,
		"relationship.source.node.keys" -> "concept_1_id:concept_id",
		"relationship.source.save.mode" -> "Overwrite",
		"relationship.target.labels" -> gene,
		"relationship.target.node.keys" -> "concept_2_id:concept_id",
		"relationship.target.save.mode" -> "Overwrite",
		"relationship.save.strategy" -> "keys",
		"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
		"batch.size" -> "50000",
		"transaction.retries" -> "5"),
	SaveMode.Overwrite
	)
.batch


val neo4j_has_induction_or_activation_against_rel_df2 = almaren.builder
.sourceSql("select * from neo4j_has_induction_or_activation_against where entity2_type = 'CellLine' and concept_1_id is not null and concept_2_id is not null")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("relationship" -> "HAS_INDUCTION_OR_ACTIVATION_AGAINST",
		"relationship.source.labels" -> chemical,
		"relationship.source.node.keys" -> "concept_1_id:concept_id",
		"relationship.source.save.mode" -> "Overwrite",
		"relationship.target.labels" -> cellLine,
		"relationship.target.node.keys" -> "concept_2_id:concept_id",
		"relationship.target.save.mode" -> "Overwrite",
		"relationship.save.strategy"-> "keys",
		"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
		"batch.size" -> "50000",
		"transaction.retries" -> "5"),
	SaveMode.Overwrite
	)
.batch

logger.info("Loading HAS_INTERACTION_WITH relationships into Neo4j.")

val neo4j_has_an_interaction_with_rel_df1 = almaren.builder
.sourceSql("select * from neo4j_has_an_interaction_with where entity2_type = 'Drug' and concept_1_id is not null and concept_2_id is not null")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("relationship" -> "HAS_AN_INTERACTION_WITH",
		"relationship.source.labels" -> drug,
		"relationship.source.node.keys" -> "concept_1_id:concept_id",
		"relationship.source.save.mode" -> "Overwrite",
		"relationship.target.labels" -> drug,
		"relationship.target.node.keys" -> "concept_2_id:concept_id",
		"relationship.target.save.mode" -> "Overwrite",
		"relationship.save.strategy" -> "keys",
		"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
		"batch.size" -> "50000",
		"transaction.retries" -> "5"),
	SaveMode.Overwrite
	)
.batch

val neo4j_has_interaction_with_rel_df2 = almaren.builder
.sourceSql("select * from neo4j_has_an_interaction_with where entity2_type = 'Clinical Condition' and concept_1_id is not null and concept_2_id is not null")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("relationship" -> "HAS_AN_INTERACTION_WITH",
		"relationship.source.labels" -> drug,
		"relationship.source.node.keys" -> "concept_1_id:concept_id",
		"relationship.source.save.mode" -> "Overwrite",
		"relationship.target.labels" -> clinicalCondition,
		"relationship.target.node.keys" -> "concept_2_id:concept_id",
		"relationship.target.save.mode" -> "Overwrite",
		"relationship.save.strategy" -> "keys",
		"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
		"batch.size" -> "50000",
		"transaction.retries" -> "5"),
	SaveMode.Overwrite
	)
.batch

//spark.sql("select count(*) from neo4j_has_modulated_side_effect where entity1_type = 'Clinical Interaction' and concept_1_id is not null and concept_2_id is not null").show(false)
logger.info("Loading HAS_MODULATED_SIDE_EFFECT relationships into Neo4j.")

val neo4j_has_modulated_side_effect_rel_df1 = almaren.builder
.sourceSql("select * from neo4j_has_modulated_side_effect where entity1_type = 'Clinical Interaction' and concept_1_id is not null and concept_2_id is not null")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("relationship" -> "HAS_MODULATED_SIDE_EFFECT",
		"relationship.source.labels" -> clinicalInteraction,
		"relationship.source.node.keys" -> "concept_1_id:concept_id",
		"relationship.source.save.mode" -> "Overwrite",
		"relationship.target.labels" -> adverseEvent,
		"relationship.target.node.keys" -> "concept_2_id:concept_id",
		"relationship.target.save.mode" -> "Overwrite",
		"relationship.save.strategy" -> "keys",
		"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
		"batch.size" -> "50000",
		"transaction.retries" -> "5"),
	SaveMode.Overwrite
	)
.batch

//spark.sql("select count(*) from neo4j_has_modulated_side_effect where entity1_type = 'Drug Interaction' and concept_1_id is not null and concept_2_id is not null").show(false)

val neo4j_has_modulated_side_effect_rel_df2 = almaren.builder
.sourceSql("select * from neo4j_has_modulated_side_effect where entity1_type = 'Drug Interaction' and concept_1_id is not null and concept_2_id is not null")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("relationship" -> "HAS_MODULATED_SIDE_EFFECT",
		"relationship.source.labels" -> drugInteraction,
		"relationship.source.node.keys" -> "concept_1_id:concept_id",
		"relationship.source.save.mode" -> "Overwrite",
		"relationship.target.labels" -> adverseEvent,
		"relationship.target.node.keys" -> "concept_2_id:concept_id",
		"relationship.target.save.mode" -> "Overwrite",
		"relationship.save.strategy" -> "keys",
		"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
		"batch.size" -> "50000",
		"transaction.retries" -> "5"),
	SaveMode.Overwrite
	)
.batch


logger.info("Loading HAS_MODULATION_AGAINST relationships into Neo4j.")

val neo4j_has_modulation_against_rel_df1 = almaren.builder
.sourceSql("select * from neo4j_has_modulation_against where entity2_type = 'Gene' and concept_1_id is not null and concept_2_id is not null")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("relationship" -> "HAS_MODULATION_AGAINST",
		"relationship.source.labels" -> chemical,
		"relationship.source.node.keys" -> "concept_1_id:concept_id",
		"relationship.source.save.mode" -> "Overwrite",
		"relationship.target.labels" -> gene,
		"relationship.target.node.keys" -> "concept_2_id:concept_id",
		"relationship.target.save.mode" -> "Overwrite",
		"relationship.save.strategy" -> "keys",
		"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
		"batch.size" -> "50000",
		"transaction.retries" -> "5"),
	SaveMode.Overwrite
	)
.batch

val neo4j_has_modulation_against_rel_df2 = almaren.builder
.sourceSql("select * from neo4j_has_modulation_against where entity2_type = 'CellLine' and concept_1_id is not null and concept_2_id is not null")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("relationship" -> "HAS_MODULATION_AGAINST",
		"relationship.source.labels" -> chemical,
		"relationship.source.node.keys" -> "concept_1_id:concept_id",
		"relationship.source.save.mode" -> "Overwrite",
		"relationship.target.labels" -> cellLine,
		"relationship.target.node.keys" -> "concept_2_id:concept_id",
		"relationship.target.save.mode" -> "Overwrite",
		"relationship.save.strategy" -> "keys",
		"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
		"batch.size" -> "50000",
		"transaction.retries" -> "5"),
	SaveMode.Overwrite
	)
.batch


//spark.sql("select count(*) from neo4j_has_side_effect where concept_1_id is not null and concept_2_id is not null").show(false)
logger.info("Loading HAS_SIDE_EFFECT relationships into Neo4j.")

val neo4j_has_side_effect_rel_df = almaren.builder
.sourceSql("select * from neo4j_has_side_effect where concept_1_id is not null and concept_2_id is not null")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("relationship" -> "HAS_SIDE_EFFECT",
		"relationship.source.labels" -> drug,
		"relationship.source.node.keys" -> "concept_1_id:concept_id",
		"relationship.source.save.mode" -> "Overwrite",
		"relationship.target.labels" -> adverseEvent,
		"relationship.target.node.keys" -> "concept_2_id:concept_id",
		"relationship.target.save.mode" -> "Overwrite",
		"relationship.save.strategy" -> "keys",
		"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
		"batch.size" -> "50000",
		"transaction.retries" -> "5"),
	SaveMode.Overwrite
	)
.batch

logger.info("Loading INCREASES_THE_EFFECT_OF relationships into Neo4j.")

val neo4j_increases_the_effect_of_rel_df1 = almaren.builder
.sourceSql("select * from neo4j_increases_the_effect_of where entity2_type = 'Clinical Condition' and concept_1_id is not null and concept_2_id is not null")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("relationship" -> "INCREASES_THE_EFFECT_OF",
		"relationship.source.labels" -> drug,
		"relationship.source.node.keys" -> "concept_1_id:concept_id",
		"relationship.source.save.mode" -> "Overwrite",
		"relationship.target.labels" -> clinicalCondition,
		"relationship.target.node.keys" -> "concept_2_id:concept_id",
		"relationship.target.save.mode" -> "Overwrite",
		"relationship.save.strategy" -> "keys",
		"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
		"batch.size" -> "50000",
		"transaction.retries" -> "5"),
	SaveMode.Overwrite
	)
.batch

val neo4j_increases_the_effect_of_rel_df2 = almaren.builder
.sourceSql("select * from neo4j_increases_the_effect_of where entity2_type = 'Drug' and concept_1_id is not null and concept_2_id is not null")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("relationship" -> "INCREASES_THE_EFFECT_OF",
		"relationship.source.labels" -> drug,
		"relationship.source.node.keys" -> "concept_1_id:concept_id",
		"relationship.source.save.mode" -> "Overwrite",
		"relationship.target.labels" -> drug,
		"relationship.target.node.keys" -> "concept_2_id:concept_id",
		"relationship.target.save.mode" -> "Overwrite",
		"relationship.save.strategy" -> "keys",
		"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
		"batch.size" -> "50000",
		"transaction.retries" -> "5"),
	SaveMode.Overwrite
	)
.batch


//spark.sql("select count(*) from neo4j_is_member_of where entity2_type = 'Clinical Interaction' and concept_1_id is not null and concept_2_id is not null").show(false)
logger.info("Loading IS_A_MEMBER_OF relationships into Neo4j.")

val neo4j_is_member_of_rel_df1 = almaren.builder
.sourceSql("select * from neo4j_is_member_of where entity1_type = 'Drug' and entity2_type = 'Clinical Interaction' and concept_1_id is not null and concept_2_id is not null")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("relationship" -> "IS_A_MEMBER_OF",
		"relationship.source.labels" -> drug,
		"relationship.source.node.keys" -> "concept_1_id:concept_id",
		"relationship.source.save.mode" -> "Overwrite",
		"relationship.target.labels" -> clinicalInteraction,
		"relationship.target.node.keys" -> "concept_2_id:concept_id",
		"relationship.target.save.mode" -> "Overwrite",
		"relationship.save.strategy" -> "keys",
		"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
		"batch.size" -> "50000",
		"transaction.retries" -> "5"),
	SaveMode.Overwrite
	)
.batch

//spark.sql("select count(*) from neo4j_is_member_of where entity2_type = 'Drug Interaction' and concept_1_id is not null and concept_2_id is not null").show(false)

val neo4j_is_member_of_rel_df2 = almaren.builder
.sourceSql("select * from neo4j_is_member_of where entity1_type = 'Drug' and entity2_type = 'Drug Interaction' and concept_1_id is not null and concept_2_id is not null")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("relationship" -> "IS_A_MEMBER_OF",
		"relationship.source.labels" -> drug,
		"relationship.source.node.keys" -> "concept_1_id:concept_id",
		"relationship.source.save.mode" -> "Overwrite",
		"relationship.target.labels" -> drugInteraction,
		"relationship.target.node.keys" -> "concept_2_id:concept_id",
		"relationship.target.save.mode" -> "Overwrite",
		"relationship.save.strategy" -> "keys",
		"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
		"batch.size" -> "50000",
		"transaction.retries" -> "5"),
	SaveMode.Overwrite
	)
.batch

val neo4j_is_member_of_rel_df3 = almaren.builder
.sourceSql("select * from neo4j_is_member_of where entity1_type = 'Clinical Condition' and entity2_type = 'Clinical Interaction' and concept_1_id is not null and concept_2_id is not null")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("relationship" -> "IS_A_MEMBER_OF",
		"relationship.source.labels" -> clinicalCondition,
		"relationship.source.node.keys" -> "concept_1_id:concept_id",
		"relationship.source.save.mode" -> "Overwrite",
		"relationship.target.labels" -> clinicalInteraction,
		"relationship.target.node.keys" -> "concept_2_id:concept_id",
		"relationship.target.save.mode" -> "Overwrite",
		"relationship.save.strategy" -> "keys",
		"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
		"batch.size" -> "50000",
		"transaction.retries" -> "5"),
	SaveMode.Overwrite
	)
.batch

logger.info("Loading IS_CHEMICALLY_SIMILAR_TO relationships into Neo4j.")

val neo4j_is_chemically_similar_to_rel_df = almaren.builder
.sourceSql("select * from neo4j_is_chemically_similar_to where concept_1_id is not null and concept_2_id is not null")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("relationship" -> "IS_CHEMICALLY_SIMILAR_TO",
		"relationship.source.labels" -> chemical,
		"relationship.source.node.keys" -> "concept_1_id:concept_id",
		"relationship.source.save.mode" -> "Overwrite",
		"relationship.target.labels" -> chemical,
		"relationship.target.node.keys" -> "concept_2_id:concept_id",
		"relationship.target.save.mode" -> "Overwrite",
		"relationship.save.strategy" -> "keys",
		"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
		"batch.size" -> "50000",
		"transaction.retries" -> "5"),
	SaveMode.Overwrite
	)
.batch


 

//val entities2_list = spark.sql("""SELECT DISTINCT entity2_type from neo4j_does_not_significantly_affect""").collect().map(_(0)).toList

logger.info("Loading DOES_NOT_SIGNIFICANTLY_AFFECT relationships into Neo4j.")

val neo4j_does_not_significantly_affect_rel_df = almaren.builder
.sourceSql("select  * from neo4j_does_not_significantly_affect where concept_1_id is not null and concept_2_id is not null")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("relationship" -> "DOES_NOT_SIGNIFICANTLY_AFFECT",
		"relationship.source.labels" -> chemical,
		"relationship.source.node.keys" -> "concept_1_id:concept_id",
		"relationship.source.save.mode" -> "Overwrite",
		"relationship.target.labels" -> measurement,
		"relationship.target.node.keys" -> "concept_2_id:concept_id",
		"relationship.target.save.mode" -> "Overwrite",
		"relationship.save.strategy" -> "keys",
		"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
		"batch.size" -> "50000",
		"transaction.retries" -> "5"),
	SaveMode.Overwrite
	)
.batch



//val dec_entities2_list = spark.sql("""SELECT DISTINCT entity2_type from neo4j_decreases""").collect().map(_(0)).toList
logger.info("Loading DECREASES relationships into Neo4j.")

val neo4j_decreases_rel_df = almaren.builder
.sourceSql("select  * from neo4j_decreases where concept_1_id is not null and concept_2_id is not null ")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("relationship" -> "DECREASES",
		"relationship.source.labels" -> chemical,
		"relationship.source.node.keys" -> "concept_1_id:concept_id",
		"relationship.source.save.mode" -> "Overwrite",
		"relationship.target.labels" -> measurement,
		"relationship.target.node.keys" -> "concept_2_id:concept_id",
		"relationship.target.save.mode" -> "Overwrite",
		"relationship.save.strategy" -> "keys",
		"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
		"batch.size" -> "50000",
		"transaction.retries" -> "5"),
	SaveMode.Overwrite
	)
.batch


//val inc_entities2_list = spark.sql("""SELECT DISTINCT entity2_type from neo4j_increases""").collect().map(_(0)).toList

logger.info("Loading INCREASES relationships into Neo4j.")

val neo4j_increases_rel_df = almaren.builder
.sourceSql("select  * from neo4j_increases where concept_1_id is not null and concept_2_id is not null")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("relationship" -> "INCREASES",
		"relationship.source.labels" -> chemical,
		"relationship.source.node.keys" -> "concept_1_id:concept_id",
		"relationship.source.save.mode" -> "Overwrite",
		"relationship.target.labels" -> measurement,
		"relationship.target.node.keys" -> "concept_2_id:concept_id",
		"relationship.target.save.mode" -> "Overwrite",
		"relationship.save.strategy" -> "keys",
		"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
		"batch.size" -> "50000",
		"transaction.retries" -> "5"),
	SaveMode.Overwrite
	)
.batch


logger.info("Loading SHARES_PATHWAY_WITH relationships into Neo4j.")

val neo4j_shares_pathway_rel_df = almaren.builder
.sourceSql("select * from neo4j_shares_pathway where concept_1_id is not null and concept_2_id is not null")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("relationship" -> "SHARES_PATHWAY_WITH",
		"relationship.source.labels" -> gene,
		"relationship.source.node.keys" -> "concept_1_id:concept_id",
		"relationship.source.save.mode" -> "Overwrite",
		"relationship.target.labels" -> gene,
		"relationship.target.node.keys" -> "concept_2_id:concept_id",
		"relationship.target.save.mode" -> "Overwrite",
		"relationship.save.strategy" -> "keys",
		"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
		"batch.size" -> "50000",
		"transaction.retries" -> "5"),
	SaveMode.Overwrite
	)
.batch


logger.info("Loading HAS_MOA relationships into Neo4j.")

val neo4j_has_moa_rel_df = almaren.builder
.sourceSql("select * from neo4j_has_moa where concept_1_id is not null and concept_2_id is not null")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("relationship" -> "HAS_MOA",
		"relationship.source.labels" -> drug,
		"relationship.source.node.keys" -> "concept_1_id:concept_id",
		"relationship.source.save.mode" -> "Overwrite",
		"relationship.target.labels" -> gene,
		"relationship.target.node.keys" -> "concept_2_id:concept_id",
		"relationship.target.save.mode" -> "Overwrite",
		"relationship.save.strategy" -> "keys",
		"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
		"batch.size" -> "50000",
		"transaction.retries" -> "5"),
	SaveMode.Overwrite
	)
.batch


logger.info("Loading HAS_NO_EFFECT relationships into Neo4j.")
val neo4j_has_no_effect_rel_df = almaren.builder
.sourceSql("select * from neo4j_has_no_effect where concept_1_id is not null and concept_2_id is not null")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("relationship" -> "HAS_NO_EFFECT",
		"relationship.source.labels" -> chemical,
		"relationship.source.node.keys" -> "concept_1_id:concept_id",
		"relationship.source.save.mode" -> "Overwrite",
		"relationship.target.labels" -> measurement,
		"relationship.target.node.keys" -> "concept_2_id:concept_id",
		"relationship.target.save.mode" -> "Overwrite",
		"relationship.save.strategy" -> "keys",
		"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
		"batch.size" -> "50000",
		"transaction.retries" -> "5"),
	SaveMode.Overwrite
	)
.batch


logger.info("Loading HAS_IMPACT_ON relationships into Neo4j.")
val neo4j_impact_on_rel_df = almaren.builder
.sourceSql("select * from neo4j_impact_on where concept_1_id is not null and concept_2_id is not null")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("relationship" -> "HAS_IMPACT_ON",
		"relationship.source.labels" -> chemical,
		"relationship.source.node.keys" -> "concept_1_id:concept_id",
		"relationship.source.save.mode" -> "Overwrite",
		"relationship.target.labels" -> measurement,
		"relationship.target.node.keys" -> "concept_2_id:concept_id",
		"relationship.target.save.mode" -> "Overwrite",
		"relationship.save.strategy" -> "keys",
		"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
		"batch.size" -> "50000",
		"transaction.retries" -> "5"),
	SaveMode.Overwrite
	)
.batch


logger.info("Loading DECREASES_THE_EFFECT_OF relationships into Neo4j.")
val neo4j_decreases_the_effect_of_rel_df1 = almaren.builder
.sourceSql("select * from neo4j_decreases_the_effect_of where entity2_type = 'Clinical Condition' and concept_1_id is not null and concept_2_id is not null")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("relationship" -> "DECREASES_THE_EFFECT_OF",
		"relationship.source.labels" -> drug,
		"relationship.source.node.keys" -> "concept_1_id:concept_id",
		"relationship.source.save.mode" -> "Overwrite",
		"relationship.target.labels" -> clinicalCondition,
		"relationship.target.node.keys" -> "concept_2_id:concept_id",
		"relationship.target.save.mode" -> "Overwrite",
		"relationship.save.strategy" -> "keys",
		"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
		"batch.size" -> "50000",
		"transaction.retries" -> "5"),
	SaveMode.Overwrite
	)
.batch

val neo4j_decreases_the_effect_of_rel_df2 = almaren.builder
.sourceSql("select * from neo4j_decreases_the_effect_of where entity2_type = 'Drug' and concept_1_id is not null and concept_2_id is not null")
.repartition(1)
.targetNeo4j(
	s"$neo4j_url",
	Some(s"$user"),
	Some(s"$pass"),
	Map("relationship" -> "DECREASES_THE_EFFECT_OF",
		"relationship.source.labels" -> drug,
		"relationship.source.node.keys" -> "concept_1_id:concept_id",
		"relationship.source.save.mode" -> "Overwrite",
		"relationship.target.labels" -> drug,
		"relationship.target.node.keys" -> "concept_2_id:concept_id",
		"relationship.target.save.mode" -> "Overwrite",
		"relationship.save.strategy" -> "keys",
		"relationship.properties" -> "relUid,num_of_merged,avg_strength,min_epoch_time,max_epoch_time",
		"batch.size" -> "50000",
		"transaction.retries" -> "5"),
	SaveMode.Overwrite
	)
.batch

//--------------------------------END OF LOADING preclinical_dev RELATIONSHIPS INTO NEO4J---------------------------------------

