import argparse
import logging
import os
import boto3
import ruamel.yaml
from botocore.exceptions import ClientError

parser = argparse.ArgumentParser()

parser.add_argument("cypher_file", help="cypher template file for building the automation yml file")
parser.add_argument("yml_file",
                    help="name of the automation yml file that is built from the s3 data and the cypher template file")
parser.add_argument("-a", "--archive_input", default="N", help="input data archive indicator")
parser.add_argument("-f", "--field_separator", default=",", help="input data field separator")
parser.add_argument("-c", "--chunk_size", type=int, default=1000, help="chunk size for ingestion")

args = parser.parse_args()

# connect to S3 using boto3 client
try:
    s3 = boto3.Session(aws_access_key_id=os.environ['MWU_S3Bucket_Accesskey'],
                       aws_secret_access_key=os.environ['MWU_S3Bucket_secretkey']).resource('s3')
except ClientError as e:
    logging.error(e)
bucket = s3.Bucket(os.environ['MWU_s3Bucket_Name'])
yaml_dict = {'admin_pass': os.environ['NEO4J_PASSWORD'], 'admin_user': os.environ['NEO4J_USER'], 'database': os.environ['NEO4J_DATABASE_NAME'],
             'server_uri': os.environ['NEO4J_BOLT_ENDPOINT'], 'archive_input': args.archive_input}
ingestionFiles = []


def read_yaml():
    yaml = ruamel.yaml.YAML()
    with open(args.cypher_file) as cf:
        yml = yaml.load(cf)
        yml['cql'] = yml['cql'].replace("\\{", "{").replace("\\}", "}")
    return yml


def write_yaml(data):
    yaml = ruamel.yaml.YAML()
    with open(args.yml_file, 'w') as fl:
        yaml.dump(data, fl)


if __name__ == "__main__":

    # get the file names from s3 and construct yml for each
    for s3_bucket_object in bucket.objects.filter(Prefix=os.environ['S3_SAP_DATA_PREFIX']):
        # read the cypher from the yaml file
        cypher = read_yaml()
        cypher['url'] = "s3://" + os.environ['MWU_s3Bucket_Name'] + "/" + s3_bucket_object.key
        cypher['field_separator'] = args.field_separator
        cypher['chunk_size'] = args.chunk_size
        ingestionFiles.append(cypher)

    # add the files yml to the dict
    yaml_dict['files'] = ingestionFiles
    # generate yml for ingestion
    write_yaml(yaml_dict)

