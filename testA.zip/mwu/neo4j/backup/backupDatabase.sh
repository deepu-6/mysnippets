#!/bin/bash

##########################################################################
#    Name         : backupDatabase.sh
#
#    Copyright (c)  2002-2021 "Neo4j,"
#                   Neo4j Sweden AB [http://neo4j.com]
#                   This file is a commercial add-on to Neo4j Enterprise Edition.
#
#    Description  : This program uses "neo4j-admin backup" to backup an EE database while running.
#
#    Input(s)     : The backup destination directory's full path.
#
#    Notes        :
##########################################################################

##########################################################################
#
# Function_name: usage_error
# Inputs:        None
# Purpose:       Will be invoked whenever script encounters
#                an invalid parameter or unhandled error
#
#############################R#############################################

function usage_error
{
   echo ""
   echo "usage: $0 -b <>" 
   echo "     -l log file name to save logs to (Mandatory)"
   echo "     -b Backup destination directory to save files to (Mandatory)" 
   echo "     -f Set From Host Port: Default localhost:6362 (Optional)" 
   echo "     -d Database to Backup: Default neo4j (Optional)" 
   echo "     -c Run Consistency Check [true] : Default false (Optional)" 
   echo "     -m Set HEAP_SIZE : Default 2G (Optional)" 
   echo "     -p Set pache cache : Default 4G (Optional)" 
   echo "     -h  Print help message" 
   echo
   exit 1
}




###########################################################
# Script starts here
###########################################################

# First process all the command line options.
#
while getopts ":l:b:f:d:c:m:p:h"  nextarg
do
        case $nextarg in
                l ) logFile=$OPTARG;;
                b ) backupFileDir=$OPTARG;;
                f ) fromHostPort=$OPTARG;;
                d ) databaseName=$OPTARG;;
                c ) ccheck=$OPTARG;;
                m ) heapSize=$OPTARG;;
                p ) pageCache=$OPTARG;;
                h | \? ) usage_error;;
       esac
done
source /home/cdsw/neo4j/backup/variables.conf
NEO4J_ADMIN_PATH=/home/cdsw/neo4j-enterprise-4.4.8/bin/neo4j-admin
# Check if the log directory can be written to
#
logDir=`dirname ${logFile}`
if [ ! -w ${logDir} ]; then
        echo "The log file ${logFile} cannot be created" 
        echo "Check if the path exists and also the permissions on the directory" 
        exit 2
else
        echo "The log file ${logFile} is created and can be written to" 
fi


if [ ! "$backupFileDir" ] ; then
  echo "argument -b Backup destination directory must be provided" 
fi
shift $(($OPTIND -1 ))

#Printing variables passed from variables.conf

echo "Variables passed from variables.conf"

echo "NEO4J_HOME: $NEO4J_HOME"
echo "NEO4J_CONFDIR: $NEO4J_CONFDIR"
echo "NEO4J_USER: $NEO4J_USER"
echo "fromHostPort: $fromHostPort"
echo "backupFileDir: $backupFileDir"

echo

# Check if the Destination directory has been specified (it is mandatory)
#
echo "Checking if the Destination directory has been specified?"
if [ "${backupFileDir}" = "" ]; then
        echo -e "The backup destination directory has not been specified\n" 
        usage_error;
        exit 3
else
	echo -e "The backup destination directory ${backupFileDir} has been specified \n" 
fi

# Check if the Destination directory exists
#

echo "Checking if the Destination directory ${backupFileDir} exists?" 
if [ ! -d "${backupFileDir}" ]; then
        echo -e "The backup destination directory specified does not exist\n" 
        usage_error;
        exit 4
else
	echo -e "The backup destination directory ${backupFileDir} exist\n" 
fi

# Check if the Destination directory can be written to
#
echo "Checking if the Destination directory can be writable" 

if [ ! -w "${backupFileDir}" ]; then
        echo "The backup destination directory is not accessible" 
        echo -e "Check if the path exists and also the permissions on the directory\n" 
        exit 5
else
	echo -e "The backup destination directory is accessible and can be writable to\n" 
fi



# Check size of source directory (in KB)
#
echo "Checking size of source directory" 

if [ "${dbDataDir}" = "" ]; then
   if [ -d ${NEO4J_HOME}/data ]; then
      sSize=`du -ks ${NEO4J_HOME}/data | cut -f1 | sed -e 's/^[ \t]*//'`
   elif [ -d ${NEO4J_LIB_PATH}/data ]; then
      sSize=`du -ks ${NEO4J_LIB_PATH}/data | cut -f1 | sed -e 's/^[ \t]*//'`
   fi
else
   if [ ! -d "${dbDataDir}" ]; then
      echo -e "Data directory ${dbDataDir} does not exist, backup Failed at `date`\n" 
      if [ ! -z "$SENDMAIL" ]; then
                        (echo -e "$EMAIL_HDR\n$SUBJ_F" ; cat $logFile ; ) | ${SENDMAIL} -f"${BACKUP_FROM}" "${DBA_PAGER}";
      fi
      exit 7
   else
      sSize=`du -ks ${dbDataDir} | cut -f1 | sed -e 's/^[ \t]*//'`
   fi
fi

echo -e "Size of source directory (in KB) is ${sSize} \n" 

# Check size of backup directory (in KB)
#

echo "Checking Available size in backup directory" 

bSize=`df -hk --output=avail ${backupFileDir} | sed 1d | sed -e 's/^[ \t]*//'`

echo -e "Available size in backup directory (in KB) is ${bSize}\n " 

# Check if backup location has sufficient space to hold the backup
#
echo "Checking if backup location has sufficient space to hold the backup " 

if [ "${sSize}" -gt "${bSize}" ]; then
   echo -e "Not enough space in ${backupFileDir} to perform backup, backup Failed at `date`\n" 
   if [ ! -z "$SENDMAIL" ]; then
                (echo -e "$EMAIL_HDR\n$SUBJ_F" ; cat $logFile ; ) | ${SENDMAIL} -f"${BACKUP_FROM}" "${DBA_PAGER}";
   fi
   exit 8
else
	echo -e "The backup location has the sufficient space to hold the backup\n" 
fi

echo "Starting backup of database ${databaseName} to ${backupFileDir} at `date`" 
echo "The log of the backup process can be found at ${logFile}" 
echo 

# Explicitly set HEAP_SIZE
#
echo -e "Setting the HEAP_SIZE to ${heapSize}\n" 

export HEAP_SIZE=${heapSize}
echo $NEO4J_ADMIN_PATH
echo $backupFileDir
echo $fromHostPort
echo $databaseName
echo $pageCache

# Backup the database
#
"${NEO4J_ADMIN_PATH}" backup --backup-dir="${backupFileDir}" --from="${fromHostPort}" --database="${databaseName}" --fallback-to-full=true --pagecache=${pageCache} --check-consistency=false 2>&1 
#/home/cdsw/neo4j-enterprise-4.4.8/bin/neo4j-admin backup --from="uq01568dk.abbvienet.com:6362" --backup-dir="/home/cdsw/neo4j/backup/artifacts" --database=automation --fallback-to-full=true --check-consistency=false
RET=$?
echo $RET
# Check backup log for errors
#


grep -v "WARNING: Max 1024 open files allowed" ${logFile} | grep -e "ERROR" -e "error" -e "WARN" -e "failed"
if [ $? -ne 0 -a $RET -eq 0 ]; then
    echo 
    echo "Backup Succeeded at `date`" 
    if [ ! -z "$SENDMAIL" ]; then
        (echo -e "$EMAIL_HDR\n$SUBJ_S" ; cat $logFile ; ) | ${SENDMAIL} -f"${BACKUP_FROM}" "${DBA_EMAIL}";
    fi

    ####
    #### Insert copy to external storage here...
    ####

   if [ "${ccheck}" = "true" ]; then
        # If backup is successful and ccheck wasnt run, then run a consistency check on the backup
        #
        echo 
        echo "Performing backup consistency check at `date`" 
        "${NEO4J_ADMIN_PATH}" check-consistency --backup="${backupFileDir}/${databaseName}" --verbose 2>&1 
        #Check for errors
        #
        # grep -e "ERROR" -e "WARN" -e "failed" -e "Inconsistencies" ${logFile}
        grep -e "ERROR" -e "failed" -e "Inconsistencies" ${logFile}
        if [ $? -eq 0 -o $RET -ne 0 ]; then
           echo "Consistency check Failed at `date`" 
        else
           echo 
           echo "Consistency check Succeeded at `date`" 

           ####
           #### Insert copy to external storage here...
           ####

           if [ ! -z "$SENDMAIL" ]; then
                                (echo -e "$EMAIL_HDR\n$SUBJ_[[[[[S" ; cat $logFile ; ) | ${SENDMAIL} -f"${BACKUP_FROM}" "${DBA_EMAIL}";
           fi
         fi
   fi

elif [ $RET -eq 1 ]; then
        echo "Backup Failed at `date`" 
        if [ ! -z "$SENDMAIL" ]; then
                        (echo -e "$EMAIL_HDR\n$SUBJ_F" ; cat $logFile ; ) | ${SENDMAIL} -f"${BACKUP_FROM}" "${DBA_PAGER}";
        fi
elif [ $RET -eq 2 ]; then
        echo "Backup Succeeded, but consistency check failed at `date`" 
        if [ ! -z "$SENDMAIL" ]; then
                        (echo -e "$EMAIL_HDR\n$SUBJ_W" ; cat $logFile ; ) | ${SENDMAIL} -f"${BACKUP_FROM}" "${DBA_EMAIL}";
        fi
elif [ $RET -eq 3 ]; then
        echo "Backup Succeeded, but consistency check found inconsistencies at `date`" 
        if [ ! -z "$SENDMAIL" ]; then
                        (echo -e "$EMAIL_HDR\n$SUBJ_W" ; cat $logFile ; ) | ${SENDMAIL} -f"${BACKUP_FROM}" "${DBA_EMAIL}";
        fi
else
        echo "Backup Failed at `date`" 
        if [ ! -z "$SENDMAIL" ]; then
                        (echo -e "$EMAIL_HDR\n$SUBJ_F" ; cat $logFile ; ) | ${SENDMAIL} -f"${BACKUP_FROM}" "${DBA_PAGER}";
        fi
fi

echo 
echo "End backup of database ${databaseName} to ${backupFileDir} at `date`" 

echo "After the backup, checking avaialble size in backup directory" 

bSize=`df -hk --output=avail ${backupFileDir} | sed 1d | sed -e 's/^[ \t]*//'`

echo -e "After the backup, avaialble size in backup directory (in KB) is ${bSize}\n" 
exit 0
