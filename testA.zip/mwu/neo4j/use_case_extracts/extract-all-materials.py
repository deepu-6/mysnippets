import argparse
import logging
import sys
import pandas as pd
from neo4j import GraphDatabase
import boto3
from botocore.exceptions import ClientError
import os

parser = argparse.ArgumentParser()

parser.add_argument("output_file", help="output file with the extract data")

args = parser.parse_args()


class App:

    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password))

    def close(self):
        # Don't forget to close the driver connection when you are finished with it
        self.driver.close()

    @staticmethod
    def enable_log(level, output_stream):
        handler = logging.StreamHandler(output_stream)
        handler.setLevel(level)
        logging.getLogger("neo4j").addHandler(handler)
        logging.getLogger("neo4j").setLevel(level)

    def build_extract(self, db, output_file):
        with self.driver.session(database=db) as session:
            result = session.read_transaction(self.query_db)
            df = pd.DataFrame.from_dict(result)
            # df = DataFrame(result)
            df = df.replace(r'\n', ' ', regex=True)
            df.to_csv(output_file, index=False, header=True)

    def upload_file(self, file_name, bucket, object_name=None):
        # If S3 object_name was not specified, use file_name
        if object_name is None:
            object_name = os.path.basename(file_name)

        # Upload the file
        s3_client = boto3.Session(aws_access_key_id=os.environ['MWU_S3Bucket_Accesskey'],
                                  aws_secret_access_key=os.environ['MWU_S3Bucket_secretkey']).client('s3')
        try:
            response = s3_client.upload_file(file_name, bucket, object_name)
        except ClientError as e:
            logging.error(e)
            return False
        return True

    @staticmethod
    def query_db(tx):
        query = (
            "CALL { "
            "match (matDoc:MatDocNumber)-[:USES_MATERIAL]->(mt) "
            "WITH DISTINCT matDoc, mt "
            "OPTIONAL MATCH (matDoc)-[:HAS_ORDER]->(pur:PurchaseOrder) "
            "OPTIONAL MATCH (matDoc)-[:HAS_ORDER]->(pro:ProcessOrder) "
            "OPTIONAL MATCH (matDoc)-[:ASSOCIATED_WITH]->(plant) "
            "OPTIONAL MATCH (matDoc)-[:HAS_SUPPLIER]->(supplier) "
            "OPTIONAL MATCH (matDoc)-[:HAS_MANUFACTURER]->(manufacturer) "
            "OPTIONAL MATCH (matDoc)-[:HAS_DISTRIBUTOR]->(distributor) "
            "OPTIONAL MATCH (mt)-[:HAS_MANUMATLID]->(mmi) "
            "RETURN DISTINCT pur, pro, mt as material, plant, supplier, manufacturer, distributor, mmi "
            "UNION "
            "match (mt:Material) WHERE NOT EXISTS ((:MatDocNumber)-[:USES_MATERIAL]->(mt)) "
            "OPTIONAL MATCH (mt)-[:FROM_ORDER]->(pur:PurchaseOrder) "
            "OPTIONAL MATCH (mt)-[:FROM_ORDER]->(pro:ProcessOrder) "
            "OPTIONAL MATCH (mt)-[:ASSOCIATED_WITH]->(plant) "
            "OPTIONAL MATCH (mt)<-[:SUPPLIES]-(supplier) "
            "OPTIONAL MATCH (mt)<-[:MANUFACTURES]-(manufacturer) "
            "OPTIONAL MATCH (mt)<-[:DISTRIBUTES]-(distributor) "
            "OPTIONAL MATCH (mt)-[:HAS_MANUMATLID]->(mmi) "
            "RETURN DISTINCT pur, pro, mt as material, plant, supplier, manufacturer, distributor, mmi "
            "} "
            "WITH DISTINCT pur, pro, material, plant, supplier, manufacturer, distributor, mmi "
            "OPTIONAL MATCH (supplier)-[smr:SUPPLIES]->(material) "
            "OPTIONAL MATCH (supplier)-[:AT_ADDRESS]->(supaddress)-[:IN_CITY]-(supcity) "
            "WITH pur, pro, material, plant, supplier, manufacturer, distributor, mmi, smr, supaddress, supcity "
            "OPTIONAL MATCH (manufacturer)-[:MANUFACTURES]->(material) "
            "OPTIONAL MATCH (manufacturer)-[:AT_ADDRESS]->(manaddress)-[:IN_CITY]-(mancity) "
            "WITH pur, pro, material, plant, supplier, manufacturer, distributor, mmi, smr, supaddress, supcity, manaddress, mancity "
            "OPTIONAL MATCH (distributor)-[:DISTRIBUTES]->(material) "
            "OPTIONAL MATCH (distributor)-[:AT_ADDRESS]->(disaddress)-[:IN_CITY]-(discity) "
            "WITH pur, pro, material, plant, supplier, manufacturer, distributor, mmi, smr, supaddress, supcity, manaddress, mancity, disaddress, discity "
            "OPTIONAL MATCH (supplier)-[:HAS_AGREEMENT]->(agreement) "
            "WITH pur, pro, material, plant, supplier, manufacturer, distributor, mmi, smr, supaddress, supcity, manaddress, "
            "mancity, disaddress, discity, collect(agreement.id) as agreementIds "
            "OPTIONAL MATCH (supplier)-[:HAS_SERVICE_TYPE]->(servicetype) "
            "OPTIONAL MATCH (plant)-[:HAS_COMPANY]->(company) "
            "OPTIONAL MATCH (plant)-[:IN_DOMAIN]->(domain) "
            "OPTIONAL MATCH (plant)-[:IN_SCM]->(scm) "
            "OPTIONAL MATCH (plant)-[:HAS_SITE_IDENTITY]->(siteidentity) "
            "WITH pur.id as purchaseOrderId, pro.id as processOrderId, pur.date as purchaseDate, material.id as materialId, material.description as materialName, "
            "CASE "
            "WHEN material.type = 'ZROH' THEN 'Raw materials' "
            "WHEN material.type = 'ZFRT' THEN 'ABT - Finished Product' "
            "WHEN material.type = 'ZHBE' THEN 'Operating Supplies' "
            "WHEN material.type = 'ZHLB' THEN 'Semifinished Product' "
            "WHEN material.type = 'ZHRS' THEN 'Manufacturer Part'"
            "WHEN material.type = 'ZNLG' THEN 'Non-stock materials' "
            "WHEN material.type = 'ZUNW' THEN 'Non Valuated Materials' "
            "WHEN material.type = 'ZVRP' THEN 'ABT - Packaging' "
            "WHEN material.type = 'ZDEN' THEN 'ABT - Service' "
            "ELSE material.type END as materialType, "
            "material.oldNum as oldmaterialNumber, supplier.id as supplierId, "
            "smr.materialId as supplierMaterialId, supplier.name as supplierName, "
            "coalesce(supaddress.name + '|', '') + coalesce(supaddress.zip + '|', '') + coalesce(supaddress.site, '') as sapsupplieraddress, "
            "supcity.name as supplierCity, supcity.country as supplierCountry, supplier.risk as riskClassification, supplier.soltraqId as soltraqId, "
            "supplier.soltraqName as soltraqName, supplier.soltraqStatus as soltraqStatus, supplier.soltraqAddress as soltraqsupplierAddress, agreementIds, "
            "servicetype.name as supplierServiceType, manufacturer.name as manufacturerName, distributor.name as distributorName, "
            "manaddress.name as manufacturerAddress, mancity.name as manufacturerCity, disaddress.name as distributorAddress, discity.name as distributorCity, "
            "mmi.id as manufacturerMaterialId, plant.id as plantId, plant.name as plantName, "
            "plant.region as Region, scm.name as scmFunctionalArea, siteidentity.name as siteIdentity, company.name as plantCompany, "
            "domain.name as domain, plant.address as plantAddress, plant.zip as plantZipcode, plant.state as plantState, plant.city as plantCity, "
            "plant.country as plantCountry return *"
        )
        result = tx.run(query)
        values = []
        for record in result:
            values.append(dict(record))
        return values


if __name__ == "__main__":
    bolt_url = os.environ['NEO4J_BOLT_ENDPOINT']
    user = os.environ['NEO4J_USER']
    password = os.environ['NEO4J_PASSWORD']
    App.enable_log(logging.INFO, sys.stdout)
    app = App(bolt_url, user, password)
    app.build_extract(os.environ['NEO4J_DATABASE_NAME'], args.output_file)
    filename = os.getcwd() + '/' + args.output_file
    objectname = os.environ['S3_NEO4J_DATA_EXTRACTS_FOLDER'] + args.output_file
    app.upload_file(filename, os.environ['MWU_s3Bucket_Name'], objectname)
    app.close()
