import argparse
import logging
import sys
import pandas as pd
from neo4j import GraphDatabase
import boto3
from botocore.exceptions import ClientError
import os
import datetime

parser = argparse.ArgumentParser()

parser.add_argument("output_file", help="output file with the extract data")

args = parser.parse_args()


class App:

    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password))

    def close(self):
        # Don't forget to close the driver connection when you are finished with it
        self.driver.close()

    @staticmethod
    def enable_log(level, output_stream):
        handler = logging.StreamHandler(output_stream)
        handler.setLevel(level)
        logging.getLogger("neo4j").addHandler(handler)
        logging.getLogger("neo4j").setLevel(level)

    def build_extract(self, db, output_file):
        with self.driver.session(database=db) as session:
            result = session.read_transaction(self.query_db)
            df = pd.DataFrame.from_dict(result)
            df = df.replace(r'\n', ' ', regex=True)
            df.to_csv(output_file, index=False, header=True)

    def upload_file(self, file_name, bucket, object_name=None):
        # If S3 object_name was not specified, use file_name
        if object_name is None:
            object_name = os.path.basename(file_name)

        # Upload the file
        s3_client = boto3.Session(aws_access_key_id=os.environ['MWU_S3Bucket_Accesskey'],
                                  aws_secret_access_key=os.environ['MWU_S3Bucket_secretkey']).client('s3')
        try:
            response = s3_client.upload_file(file_name, bucket, object_name)
        except ClientError as e:
            logging.error(e)
            return False
        return True

    @staticmethod
    def query_db(tx):
        query = (
            "MATCH (t:Trial)-[:HAS_TRIAL_MATERIAL]->(m) WITH t,m CALL apoc.path.expandConfig(m,{ relationshipFilter: 'USES>', minLevel: 1, maxLevel: 100, uniqueness: 'NODE_GLOBAL' }) "
            "yield path WITH t, path WITH t, nodes(path) as nodes UNWIND nodes as material WITH DISTINCT t, material OPTIONAL MATCH (material)<-[:SUPPLIES]-(supplier) "
            "WITH t.id as trialId, t.name as trialName, t.program as programName, material.id as materialId, material.description as materialDesc RETURN *"
        )
        result = tx.run(query)
        values = []
        for record in result:
            values.append(dict(record))
        return values


if __name__ == "__main__":
    bolt_url = os.environ['NEO4J_BOLT_ENDPOINT']
    user = os.environ['NEO4J_USER']
    password = os.environ['NEO4J_PASSWORD']
    App.enable_log(logging.INFO, sys.stdout)
    app = App(bolt_url, user, password)
    daily_output_file = str(datetime.date.today()) + "-" + args.output_file
    app.build_extract(os.environ['NEO4J_DATABASE_NAME'], daily_output_file)
    file_location = os.getcwd() + '/' + daily_output_file
    objectname = os.environ['S3_NEO4J_DATA_EXTRACTS_FOLDER'] + daily_output_file
    app.upload_file(file_location, os.environ['MWU_s3Bucket_Name'], objectname)
    app.close()
