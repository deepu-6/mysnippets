#!/bin/bash



curl --negotiate -u : -X POST -H 'Content-type:application/json' --data-binary '{"add-field": {"name":"therapy_end_dt", "type":"string", "indexed":true, "stored":true, "multiValued":false}}' "https://ir-arch-dev-discovery-worker0.ir-arch.u55l-xcud.cloudera.site:8985/solr/comp_sim_test3/schema"

curl --negotiate -u : -X POST -H 'Content-type:application/json' --data-binary '{"add-field": {"name":"therapy_start_dt", "type":"string", "indexed":true, "stored":true, "multiValued":false}}' "https://ir-arch-dev-discovery-worker0.ir-arch.u55l-xcud.cloudera.site:8985/solr/comp_sim_test3/schema"

curl --negotiate -u : -X POST -H 'Content-type:application/json' --data-binary '{"add-field": {"name":"init_fda_dt", "type":"string", "indexed":true, "stored":true, "multiValued":false}}' "https://ir-arch-dev-discovery-worker0.ir-arch.u55l-xcud.cloudera.site:8985/solr/comp_sim_test3/schema"

curl --negotiate -u : -X POST -H 'Content-type:application/json' --data-binary '{"add-field": {"name":"latest_revision_dt", "type":"string", "indexed":true, "stored":true, "multiValued":false}}' "https://ir-arch-dev-discovery-worker0.ir-arch.u55l-xcud.cloudera.site:8985/solr/comp_sim_test3/schema"

curl --negotiate -u : -X POST -H 'Content-type:application/json' --data-binary '{"add-field": {"name":"event_dt", "type":"string", "indexed":true, "stored":true, "multiValued":false}}' "https://ir-arch-dev-discovery-worker0.ir-arch.u55l-xcud.cloudera.site:8985/solr/comp_sim_test3/schema"

curl --negotiate -u : -X POST -H 'Content-type:application/json' --data-binary '{"add-field": {"name":"mfr_dt", "type":"string", "indexed":true, "stored":true, "multiValued":false}}' "https://ir-arch-dev-discovery-worker0.ir-arch.u55l-xcud.cloudera.site:8985/solr/comp_sim_test3/schema"

curl --negotiate -u : -X POST -H 'Content-type:application/json' --data-binary '{"add-field": {"name":"rept_dt", "type":"string", "indexed":true, "stored":true, "multiValued":false}}' "https://ir-arch-dev-discovery-worker0.ir-arch.u55l-xcud.cloudera.site:8985/solr/comp_sim_test3/schema"

curl --negotiate -u : -X POST -H 'Content-type:application/json' --data-binary '{"add-field": {"name":"run_date", "type":"string", "indexed":true, "stored":true, "multiValued":false}}' "https://ir-arch-dev-discovery-worker0.ir-arch.u55l-xcud.cloudera.site:8985/solr/comp_sim_test3/schema"