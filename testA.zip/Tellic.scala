import org.apache.spark.sql.{SaveMode, SparkSession, SQLContext, DataFrame}
import org.apache.log4j.{Level, Logger}
import com.github.music.of.the.ainur.almaren.builder.Core.Implicit
import com.github.music.of.the.ainur.almaren.neo4j.Neo4j.Neo4jImplicit
import com.github.music.of.the.ainur.almaren.Almaren
import com.github.music.of.the.ainur.almaren.Tree
//import com.modak.common.credential.Credential
//import com.modak.common._
import org.neo4j.driver._
import scala.util.control._

val almaren = Almaren("Loading Tellic Neo4j Pipeline")
val spark = SparkSession.builder().getOrCreate()
val logger = Logger.getLogger("Neo4J")

class Tellic(neo4j_url:String, user:String, pass:String) {
	var adverseEvent = "Adverse Event"
	var cellType  = "CellType"
	var cellLine = "CellLine"
	var chemical = "Chemical"
	var clinicalCondition = "Clinical Condition"
	var clinicalInteraction = "Clinical Interaction"
	var disease = "Disease"
	var drug = "Drug"
	var drugProduct = "Drug Product"
	var drugInteraction = "Drug Interaction"
	var gene = "Gene"
	var measurement = "Measurement"
	var phenotype = "Phenotype"
	var variant = "Variant"
	var drugparent = "Drug Parent"
	var healthcondition = "Health Condition"

	def create_constriants(node_tables: List[List[String]]) {
		val driver = GraphDatabase.driver(neo4j_url, AuthTokens.basic(user, pass))
		val session = driver.session				
		for(node <-  node_tables) {
			var constraint_label = node.apply(1)
			var alias = constraint_label.replace(' ', '_').toLowerCase()
			var script = "CREATE CONSTRAINT ON ( " + alias + ":`" + constraint_label + "` ) ASSERT " + alias +".concept_id IS UNIQUE; "
			println(script)	
			val result = session.run(script)
		}		
		logger.info("Created Constraints Successfully.")
	}

	def getRelationshipDetails(relationship_table: String): List[String]={
		val all_rel_tables : List[List[String]]  = List(
				List("preclinical_dev.neo4j_contains_check2", "CONTAINS"),
				List("preclinical_dev.neo4j_has_agonism_against_check2", "HAS_AGONISM_AGAINST"),
				List("preclinical_dev.neo4j_has_side_effect_check2", "HAS_SIDE_EFFECT"),
				List("preclinical_dev.neo4j_is_chemically_similar_to_check2", "IS_CHEMICALLY_SIMILAR_TO"),
				List("preclinical_dev.neo4j_is_member_of_check2", "IS_A_MEMBER_OF"),
				List("preclinical_dev.neo4j_increases_the_effect_of_check2", "INCREASES_THE_EFFECT_OF"),
				List("preclinical_dev.neo4j_decreases_the_effect_of_check2", "DECREASES_THE_EFFECT_OF"),
				List("preclinical_dev.neo4j_has_activity_against_check2", "HAS_ACTIVITY_AGAINST"),
				List("preclinical_dev.neo4j_has_antagonism_against_check2", "HAS_ANTAGONISM_AGAINST"),
				List("preclinical_dev.neo4j_has_induction_or_activation_against_check2", "HAS_INDUCTION_OR_ACTIVATION_AGAINST"),
				List("preclinical_dev.neo4j_has_an_interaction_with_check2", "HAS_AN_INTERACTION_WITH"),
				List("preclinical_dev.neo4j_has_modulated_side_effect_check2", "HAS_MODULATED_SIDE_EFFECT"),
				List("preclinical_dev.neo4j_has_modulation_against_check2", "HAS_MODULATION_AGAINST"),
				List("preclinical_dev.neo4j_shares_pathway_check2", "SHARES_PATHWAY_WITH"),
				List("preclinical_dev.neo4j_does_not_significantly_affect_check2", "DOES_NOT_SIGNIFICANTLY_AFFECT"),
				List("preclinical_dev.neo4j_decreases_check2", "DECREASES"),
				List("preclinical_dev.neo4j_increases_check2", "INCREASES"),
				List("preclinical_dev.neo4j_has_no_effect_check2", "HAS_NO_EFFECT"),
				List("preclinical_dev.neo4j_has_moa_check2", "HAS_MOA"),
				List("preclinical_dev.neo4j_impact_on_check2", "IMPACT_ON"),
				List("tellic_abbvie.tellic_graph_data_processed_relationships_has_ingredient", "HAS_INGREDIENT", drugProduct, drug),
				List("tellic_abbvie.tellic_graph_data_processed_relationships_has_isomer", "HAS_ISOMER", chemical, chemical),
				List("tellic_abbvie.tellic_graph_data_processed_relationships_has_parent", "HAS_PARENT", chemical, chemical),
				List("tellic_abbvie.tellic_graph_data_processed_relationships_has_precise_ingredient", "HAS_PRECISE_INGREDIENT", drugProduct, drug),
				List("tellic_abbvie.tellic_graph_data_processed_relationships_is_equal_to", "IS_EQUAL_TO", chemical, drug),
				List("tellic_abbvie.tellic_graph_data_processed_relationships_shares_family", "SHARES_FAMILY", gene, gene),				
				List("tellic_abbvie.tellic_graph_data_processed_relationships_associated_with", "ASSOCIATED_WITH", variant, disease),	
				List("tellic_abbvie.tellic_graph_data_processed_relationships_has_interaction", "HAS_INTERACTION", gene, gene),	
				List("tellic_abbvie.tellic_graph_data_processed_relationships_has_variant", "HAS_VARIANT", gene, variant)		
		)
		var rel_details_list = List[String]()		
		for(rel_details <- all_rel_tables)  {
			if(relationship_table == rel_details(0)) {
				rel_details_list = rel_details
			}
		}	
		rel_details_list
	}
	
	def getNodeDetails(node_tables: String*): List[List[String]] = {
		val all_node_tables :List[List[String]] = List(
			List("preclinical_dev.tellic_node_measurement_check2", measurement),
			List("preclinical_dev.tellic_node_gene_check2", gene),
			List("preclinical_dev.tellic_node_ae_check2", adverseEvent),
			List("preclinical_dev.tellic_node_chem_subset_check2", chemical),
			List("preclinical_dev.tellic_node_drug_check2", drug),
			List("preclinical_dev.tellic_node_ddi_check2", drugInteraction),
			List("preclinical_dev.tellic_node_dci_check2", clinicalInteraction),
			List("preclinical_dev.tellic_node_cellline_check2", cellLine),
			List("preclinical_dev.tellic_node_clinicalcondition_check2", clinicalCondition),
			List("tellic_abbvie.tellic_graph_data_node_pheno", phenotype),
			List("tellic_abbvie.tellic_graph_data_node_variant", variant),
			List("tellic_abbvie.tellic_graph_data_node_diso", disease),
			List("tellic_abbvie.tellic_graph_data_node_celltype", cellType),
			List("tellic_abbvie.tellic_graph_data_node_health_event", healthcondition),
			List("tellic_abbvie.tellic_graph_data_node_drug_product", drugProduct),
			List("tellic_abbvie.tellic_graph_data_node_drug_parent", drugparent)
			)
		var node_details_list = List[List[String]]()
		for(node_table_name <- node_tables) {
			for(node_details <- all_node_tables)  {
				if(node_table_name == node_details(0)) {
					node_details_list :+= node_details
				}
			}
		}
		node_details_list
	}
	
	def delete_relationships(table_details:List[String]) {	
		val driver = GraphDatabase.driver(neo4j_url, AuthTokens.basic(user, pass))
        val session = driver.session
		val loop = new Breaks;
		for (rel_type <- table_details(1)) {                
			logger.info("Deleting relationship type: " + rel_type)
			flag = True
			retry_attempt = 0
			loop.breakable {
				while(True) {
					var rel_delete_cql = "CALL apoc.periodic.iterate(\"MATCH ()-[n:`" + rel_type + "`]-() RETURN n\", \"DELETE n\", {batchSize:1000, parallel:false})"
					print("Relationship delete CQL: " + rel_delete_cql)
					var delete_result = session.run(rel_delete_cql)
					var count_cql = "MATCH ()-[r:`" + rel_type +"`]->() RETURN count(r) as count"
					print(count_cql)
					var count_result = session.run(count_cql)
					var rem_count = count_result.peek()['count']
					if rem_count == 0:
					   loop.break
					retry_attempt += 1
					logger.info("Retry attempt " + retry_attempt)
				logger.info("Deleted " + rel_type + " relationships.")			
			}
		}
	}
	
	
	def load_tellic_relationships(table_name:String, rel_type:String, e1_label:String, e2_label:String) {
		var tellic_df = spark.sql("select * from " + table_name + " where concept_1_id is not null and concept_2_id is not null ")
		write_relationships(tellic_df, rel_type, e1_label, e2_label)
				
	}

	def load_abbvie_relationships(table_name:String, rel_type:String) {
		//var rels = abbvie_table
		val df = spark.table(table_name)
		val entity1 =  df.select("entity1_type").distinct.collect().map(_(0)).toList
		val entity2 =  df.select("entity2_type").distinct.collect().map(_(0)).toList
		for(e1_label <- entity1) {
			for(e2_label <- entity2) {
				logger.info("Loading " + rel_type + " relationships between " + s"$e1_label" + " and " + s"$e2_label" + ".")
				var abbvie_df = spark.sql("select * from " + table_name + " where entity1_type = '" + e1_label + "' and entity2_type =  '" + e2_label + "'  and concept_1_id is not null and concept_2_id is not null")
				write_relationships(abbvie_df, rel_type, e1_label.toString, e2_label.toString)
			}
		}
	}
	
	def write_nodes(node_tables: List[List[String]]) {
		if(node_tables.length > 1) {
			for(node_table <- node_tables) {
				var table_name = node_table.apply(0)
				var label = node_table.apply(1)
				var properties = spark.table(table_name).columns.filter(! _.contains("concept_id")).mkString(", ")
				println(properties)
				val node_df = almaren.builder
					.sourceSql("select * from " + table_name + " where concept_id is not NULL ")
					.repartition(1)
					.targetNeo4j(
						neo4j_url,
						Some(user),
						Some(pass),
						Map("labels" -> label,
							"batch.size" -> "20000",
							"node.keys" -> "concept_id",
							"node.properties" -> properties),
						SaveMode.Overwrite
					)
					.batch
			}
		}			
	}
	def write_relationships(table_df:DataFrame, rel_type:String, e1_label:String, e2_label:String) {
		println("Writing " + table_df.count() +" "+ rel_type + " relationships between  " + e1_label + " -> " + e2_label)
		table_df.createOrReplaceTempView("table_view")
		var properties = table_df.columns.filter(! _.contains("concept_1_id")).filter(! _.contains("concept_2_id")).mkString(", ")
		val rel_df = almaren.builder.sourceSql("select * from table_view").repartition(1)
				.targetNeo4j(
				neo4j_url,
				Some(user),
				Some(pass),
				Map("relationship" -> rel_type,
					"relationship.source.labels" -> e1_label,
					"relationship.source.node.keys" -> "concept_1_id:concept_id",
					"relationship.source.save.mode" -> "Overwrite",
					"relationship.target.labels" -> e2_label,
					"relationship.target.node.keys" -> "concept_2_id:concept_id",
					"relationship.target.save.mode" -> "Overwrite",
					"relationship.save.strategy" -> "keys",
					"relationship.properties" -> properties,
					"batch.size" -> "50000",
					"transaction.retries" -> "5"),
				SaveMode.Overwrite
				)
			.batch
	}

	def id_to_label(x: String): String = x match {
		case "CHEMBL" => "Drug"
		case "HGNC" => "Gene"
		case "CL" => "CellType"
		case "EFO" => "Phenotype"
		case "MESH" => "Disease"
		case "tellicVO" => "Variant"
		case "DP" => "Drug Parent"
		case "RXCUI" => "Drug Product"
		case "HE" => "Health Condition"
		case "MEDDRA" => "Adverse Event"
		case "T000" => "Chemical"
	}
	def isMultiLabelRelationship(table_name:String): Boolean = {
		val multi_label_rel_tables = List(
			"tellic_abbvie.tellic_graph_data_processed_relationships_targets",
			"tellic_abbvie.tellic_graph_data_processed_relationships_is_member",
			"tellic_abbvie.tellic_graph_data_processed_relationships_with_strength",
			"tellic_abbvie.tellic_graph_data_processed_relationships_without_strength",
			"tellic_abbvie.tellic_graph_data_processed_relationships_adverse_event")
		multi_label_rel_tables.contains(table_name)
	}
	def load_multi_label_relationships(table_name:String) {
		if(table_name == "tellic_abbvie.tellic_graph_data_processed_relationships_with_strength" || table_name == "tellic_abbvie.tellic_graph_data_processed_relationships_without_strength") {
			val ID = List("CL", "CHEMBL", "EFO", "HGNC", "MESH", "tellicVO" );	
			var rel_type = "RELATED_TO"
			load_multi_label_relationship(table_name,rel_type, ID)
			
		}
		if(table_name == "tellic_abbvie.tellic_graph_data_processed_relationships_targets") {
			val ID = List("DP", "CHEMBL", "HGNC");	
			var rel_type = "TARGETS"
			load_multi_label_relationship(table_name,rel_type,ID)
			
		}
		if(table_name == "tellic_abbvie.tellic_graph_data_processed_relationships_is_member") {
			val ID = List("T000","RXCUI", "CHEMBL", "MEDDRA", "HGNC", "EFO", "MESH", "DP", "HE");
			var rel_type = "IS_MEMBER"
			load_multi_label_relationship(table_name,rel_type,ID)	
		}
		if(table_name == "tellic_abbvie.tellic_graph_data_processed_relationships_adverse_event") {
			val ID = List("DP", "CHEMBL", "MEDDRA", "HEA");
			var rel_type = "HAS_ADVERSE_EVENT"
			load_multi_label_relationship(table_name,rel_type,ID)	
		}		
	}
	def load_multi_label_relationship(table_name: String, rel_type:String, ID:List[String]) {
		for( e1 <- ID ){
			for( e2 <- ID ){
				var e1_label = id_to_label(e1) 
				var e2_label = id_to_label(e2)
				var multi_label_df = spark.sql("select * from " + table_name + " where concept_1_id is not null and concept_2_id is not null and "+"concept_1_id like '" + e1 + "%' and concept_2_id like '" + e2 + "%'")
				var cnt = multi_label_df.count()	
				if (cnt > 0) {
					write_relationships(multi_label_df, rel_type, e1_label, e2_label)
				}
			}
		}	
	}
}
object Main {
	def main(args:Array[String]) {
		val node_tables_list = List[String]()
		/*val node_tables_list = List(
			"preclinical_dev.tellic_node_measurement_check2", 
			"preclinical_dev.tellic_node_gene_check2",
			"preclinical_dev.tellic_node_ae_check2", 
			"preclinical_dev.tellic_node_chem_subset_check2", 
			"preclinical_dev.tellic_node_drug_check2",
			"preclinical_dev.tellic_node_ddi_check2",
			"preclinical_dev.tellic_node_dci_check2", 
			"preclinical_dev.tellic_node_cellline_check2", 
			"preclinical_dev.tellic_node_clinicalcondition_check2", 
			"tellic_abbvie.tellic_graph_data_node_pheno", 
			"tellic_abbvie.tellic_graph_data_node_variant", 
			"tellic_abbvie.tellic_graph_data_node_diso",
			"tellic_abbvie.tellic_graph_data_node_celltype", 
			"tellic_abbvie.tellic_graph_data_node_health_event", 
			"tellic_abbvie.tellic_graph_data_node_drug_product", 
			"tellic_abbvie.tellic_graph_data_node_drug_parent"
			)
		
		val rel_tables = List(
			"tellic_abbvie.tellic_graph_data_processed_relationships_targets",
			"preclinical_dev.neo4j_contains_check2",
			"tellic_abbvie.tellic_graph_data_processed_relationships_adverse_event", 
			"tellic_abbvie.tellic_graph_data_processed_relationships_is_member",
			"tellic_abbvie.tellic_graph_data_processed_relationships_with_strength",
			"tellic_abbvie.tellic_graph_data_processed_relationships_without_strength",
			"preclinical_dev.neo4j_has_agonism_against_check2", 
			"preclinical_dev.neo4j_has_side_effect_check2", 
			"preclinical_dev.neo4j_is_chemically_similar_to_check2",
			"preclinical_dev.neo4j_is_member_of_check2",
			"preclinical_dev.neo4j_increases_the_effect_of_check2", 
			"preclinical_dev.neo4j_decreases_the_effect_of_check2",
			"preclinical_dev.neo4j_has_activity_against_check2", 
			"preclinical_dev.neo4j_has_antagonism_against_check2",
			"preclinical_dev.neo4j_has_induction_or_activation_against_check2", 
			"preclinical_dev.neo4j_has_an_interaction_with_check2",
			"preclinical_dev.neo4j_has_modulated_side_effect_check2", 
			"preclinical_dev.neo4j_has_modulation_against_check2",
			"preclinical_dev.neo4j_shares_pathway_check2", 
			"preclinical_dev.neo4j_does_not_significantly_affect_check2",
			"preclinical_dev.neo4j_decreases_check2",
			"preclinical_dev.neo4j_increases_check2", 
			"preclinical_dev.neo4j_has_no_effect_check2", 
			"preclinical_dev.neo4j_has_moa_check2",  
			"preclinical_dev.neo4j_impact_on_check2",  
			"tellic_abbvie.tellic_graph_data_processed_relationships_has_ingredient",  
			"tellic_abbvie.tellic_graph_data_processed_relationships_has_isomer",  
			"tellic_abbvie.tellic_graph_data_processed_relationships_has_parent",  
			"tellic_abbvie.tellic_graph_data_processed_relationships_has_precise_ingredient",  
			"tellic_abbvie.tellic_graph_data_processed_relationships_is_equal_to", 
			"tellic_abbvie.tellic_graph_data_processed_relationships_shares_family",  			
			"tellic_abbvie.tellic_graph_data_processed_relationships_associated_with", 	
			"tellic_abbvie.tellic_graph_data_processed_relationships_has_interaction", 	
			"tellic_abbvie.tellic_graph_data_processed_relationships_has_variant" 	
		)*/
		/*
		val args = sc.getConf.get("spark.driver.args").split("\\s+")
		val token = args(0)
		val cred_id = args(1).toInt
		val cred_type = args(2).toInt
		val endpoint = args(3)
		val neo4j_url = args(4)
		val arch_tellic_tables = args(5)
		

		val CredentialResult = Credential.getCredentialData( CredentialPayload(s"$token", cred_id,cred_type, s"$endpoint") )
		val ldap = CredentialResult.data match {
			case ldap: ldap => ldap
			case _ => throw new Exception("Currently unable avalible for other credentials Types")
		  }	
		val user = ldap.username
		val pass = ldap.password 
		
		val arch_tellic_tables_arr = arch_tellic_tables.split(',')
		
				val arch_tellic_tables_list = toList(arch_tellic_tables_arr)
				val rel_tables = arch_tellic_tables_list
				val node_tables = arch_tellic_tables_list
				def toList[String](array: Array[String]): List[String] = {
					if (array == null || array.length == 0) 
					else if (array.length == 1) List(array(0))
					else array(0) :: toList(array.slice(1, array.length))
				}
		*/

		val neo4j_url = "bolt://10.242.33.88:7687"
		val user = "neo4j"
		val pass = "C#@nG3M3"
		logger.info("Neo4J URI: " + neo4j_url)
		var tellic = new Tellic(neo4j_url, user, pass)

		for(rel_table_name <- rel_tables) {
			println("Table Name: " + rel_table_name)
			var rel_tables_details = tellic.getRelationshipDetails(rel_table_name)
			tellic.delete_relationships(rel_tables_details)
		}
			
		val node_tables = tellic.getNodeDetails(node_tables_list: _*)	
		tellic.create_constriants(node_tables)		
		tellic.write_nodes(node_tables)

		for(rel_table_name <- rel_tables) {
			println("Table Name: " + rel_table_name)
			var rel_tables_details = tellic.getRelationshipDetails(rel_table_name)
			if(rel_tables_details.length == 0 && tellic.isMultiLabelRelationship(rel_table_name)){
				tellic.load_multi_label_relationships(rel_table_name)
			}
			if(rel_tables_details.length > 0) {
				var tabel_name = rel_tables_details(0)
				var rel_type = rel_tables_details(1)
				if(rel_tables_details.length == 2) {
					tellic.load_abbvie_relationships(tabel_name, rel_type)
				}
				if(rel_tables_details.length == 4) {	
					var e1_label = rel_tables_details(2)
					var e2_label = rel_tables_details(3)
					tellic.load_tellic_relationships(tabel_name, rel_type, e1_label, e2_label)
				}
			}			
		}
	}
}

