from neo4j import GraphDatabase
class app:
    uri = "bolt://10.242.33.83:7687"
    driver = GraphDatabase.driver(uri, auth=("neo4j", "C#@nG3M3"))

    def constraints_of(tx):
    
        tx.run("CREATE CONSTRAINT ON ( t:Testing ) ASSERT t.concept_id IS UNIQUE;")
        print("Created Constraints").replace('\\xa0', '')

    def wc():
        with driver.session() as session:
                        session.write_transaction(constraints_of)

if __name__ == "__main__":
    wc()
    
driver.close()

