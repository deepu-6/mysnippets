from kgb import KnowledgeGraphBuilder
from neo4j import GraphDatabase
from neo4j.exceptions import ServiceUnavailable
from pyspark.sql import HiveContext,SparkSession
from pyspark.sql.functions import col
from pyspark.context import SparkContext
from logging import getLogger, StreamHandler, DEBUG
import logging
import requests
import re
import sys
import time
import threading
#import argparse
#import  hotfixes

logging.basicConfig(level = logging.INFO)

handler = StreamHandler()
handler.setLevel(DEBUG)
logging.getLogger("neo4j").addHandler(handler)

spark = (SparkSession
 .builder
 .appName('ABBVIE NEO4J 4.3v PIPELINE')
 .enableHiveSupport()
 .getOrCreate())


class Arch:
    def __init__(self, spark_session,uri,user,password,database_name):
        self.neo4j_config={
            'uri':uri,
            'user':user,
            'pwd':password,
            'db': database_name
        }
        self.kgb = KnowledgeGraphBuilder(neo4j_config=self.neo4j_config, spark_session=spark_session)

    def load_graph(self, arch_entities, arch_tables):
        self.load_entities(arch_entities)
        self.load_relationships(arch_tables)

    def load_entities(self, arch_entities):
        self.kgb.load_entities_from_tables(arch_entities) #table_name in list

    def load_relationships(self, arch_tables): 
        self.kgb.load_relationships_from_tables(arch_tables)		

class Arch_constraints:

    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password)) 
        self.__spark = spark

    def create_constraints(self, database_name, arch_entities):
        labels = []
        for table_name in arch_entities:
            self.__spark.sql("REFRESH TABLE " + table_name)
            label_df = self.__spark.sql("SELECT DISTINCT LABEL FROM " + table_name).dropDuplicates()
            labels.extend([str(x.LABEL) for x in label_df.collect()])	
        labels = list(set(''.join(labels).split(':')))	
        with self.driver.session(database= database_name) as session:
            for label in labels:
                if label :
                    alias = re.sub('[^a-zA-Z0-9]', '', label).lower()
                    constraint_cql = "CREATE CONSTRAINT {0} IF NOT EXISTS ON ({0}:`{1}`) ASSERT {0}.ID  IS UNIQUE;".format(alias, label)
                    print(constraint_cql)
                    session.run(constraint_cql)
                    logging.info("Created unique constraint on {0}.".format(label))
        logging.info("[+] Created Constraints [+]")
        
    def close(self):
        self.driver.close()

class Arch_indexes:

    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password))

    def create_indexes(self, database_name):
        with self.driver.session(database= database_name) as session:
            session.run("CREATE INDEX inchi_key IF NOT EXISTS for (c:Compound) ON (c.INCHI_KEY);")
            session.run("CREATE INDEX chembl_id IF NOT EXISTS for (c:Compound) ON (c.CHEMBL_ID);")
            session.run("CREATE INDEX abbvie_id IF NOT EXISTS for (c:Compound) ON (c.ABBVIE_ID);")
            session.run("CREATE INDEX primaryidentifier IF NOT EXISTS for (c:Compound) ON (c.PRIMARYIDENTIFIER);")
            session.run("CREATE INDEX primarysource IF NOT EXISTS for (c:Compound) ON (c.PRIMARYSOURCE);")
            session.run("CREATE INDEX hgnc IF NOT EXISTS for (g:Gene) ON (g.HGNC);")
        print("Created Indexes")
        
    def close(self):
        self.driver.close()

class Arch_delete:
    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password), max_connection_lifetime=3600) 
        self.__spark = spark
        
    def remove_relationships(self, e1_label, rel_label, e2_label):
        retry_attempt = 0
        rel_delete_cql = "" 
        logging.info("Deleting `{0}`-`{1}`->`{2}` relationships. Thread - {3}".format(e1_label[1:], rel_label, e2_label[1:], threading.get_ident()))
        with self.driver.session(database = database_name) as session:
            while retry_attempt < 5:
                config = "{batchSize:100, parallel:false, retries:5}" #concurrency:5 - 4.3v
                rel_delete_cql = "CALL apoc.periodic.iterate(\"MATCH (n:`{0}`)-[r:`{1}`]->(m:`{2}`) RETURN id(r) as relId\", \"MATCH (n:`{0}`)-[r:`{1}`]->(m:`{2}`) WHERE id(r)=relId DELETE r\", {3})".format(e1_label[1:], rel_label, e2_label[1:], config)
                print("Relationship delete CQL: " + rel_delete_cql)
                delete_result = session.run(rel_delete_cql)
                delete_ops_result = delete_result.peek()['operations']
                print("Deleted relationships total count: " + str(delete_ops_result["total"]))
                print("Deleted relationships committed count: " + str(delete_ops_result["committed"]))
                print("Deleted relationships failed count: " + str(delete_ops_result["failed"]))
                print("Deleted relationships errors: " + str(delete_ops_result["errors"]))
                #
                #Verify, is total relationships and deleted relationships are matching or not.
                #
                if delete_ops_result["total"] == delete_ops_result["committed"]:
                    break
                #
                #Count the number of remaining relationships.
                #
                count_cql = "MATCH (n:`{0}`)-[r:`{1}`]->(m:`{2}`) RETURN count(r) as count".format(e1_label[1:], rel_label, e2_label[1:])
                print(count_cql)
                count_result = session.run(count_cql)
                rem_count = count_result.peek()['count']
                if rem_count == 0:
                    break
                #
                #if remaining relationships not equal to zero sleep for 3s
                #
                logging.info("Sleep for 3 seconds")
                time.sleep(3)
                retry_attempt += 1
                if retry_attempt == 5:
                    logging.error("Delete {0} relationships retry limit reached.".format(rel_label))
                    sys.exit(1)
                logging.info("Retry attempt {0}".format(retry_attempt))
            logging.info("Deleted (n:`{0}`)-[r:`{1}`]->(m:`{2}`) relationships. Thread - {3}".format(e1_label[1:], rel_label, e2_label[1:], threading.get_ident() ))
       
    def delete_relationships(self, database_name, arch_tables):
        rel_delete_cql = ""
        for table_name in arch_tables:
            self.__spark.sql("REFRESH TABLE " + table_name)
            
            rels_df = self.__spark.sql("SELECT DISTINCT ENTITY1_TYPE, REL_TYPE, ENTITY2_TYPE FROM " + table_name).dropDuplicates()
        
            e1_ref = {
                "labels": [str(x.ENTITY1_TYPE) for x in rels_df.select(col("ENTITY1_TYPE")).distinct().collect()],
            }
            e2_ref = {
                "labels": [str(x.ENTITY2_TYPE) for x in rels_df.select(col("ENTITY2_TYPE")).distinct().collect()],
            }
            rel_ref = {
                "labels": [str(x.REL_TYPE) for x in rels_df.select(col("REL_TYPE")).distinct().collect()],
            }
            threads = []
            try:
                for rel_label in rel_ref["labels"]:
                    for e1_label in e1_ref["labels"]:
                        for e2_label in e2_ref["labels"]:
                            #Trigger threads here.
                            t1 = threading.Thread(target=self.remove_relationships, args=(e1_label, rel_label, e2_label, ))
                            t1.start()
                            t1.name = "Thread (n:`{0}`)-[r:`{1}`]->(m:`{2}`)".format(e1_label[1:], rel_label, e2_label[1:])
                            threads.append(t1)
            #Capture any errors along with the query and data for traceability
            except ServiceUnavailable as exception:
                logging.error("(n:`{0}`)-[r:`{1}`]->(m:`{2}`) relationships, raised an error: \n {exception}".format(e1_label[1:], rel_label, e2_label[1:], exception=exception))
                sys.exit(1)
        #Main threads need to wait till child thread get terminated.
        logging.info("[+] Main thread is waiting for child threads to complete. [+]")
        for i in threads:
            i.join()
        logging.info("[+] Deleted relationships Successfully [+]")
   
    def delete_nodes(self, database_name, arch_entities):
        labels = []
        flag = False
        for table_name in arch_entities:
            self.__spark.sql("REFRESH TABLE " + table_name)
            label_df = self.__spark.sql("SELECT DISTINCT LABEL FROM " + table_name).dropDuplicates()
            labels.extend([str(x.LABEL) for x in label_df.collect()])	
        labels = list(set(''.join(labels).split(':')))	
        with self.driver.session(database= database_name) as session:
             neo4j_labels_result = session.run("CALL apoc.meta.stats() yield labels as entities")
             neo4j_labels = [record["entities"] for record in neo4j_labels_result]
             for label in labels:
                if label in neo4j_labels[0]:
                    logging.info("Label: {0}".format(label))
                    flag = True
                    retry_attempt = 0
                    while True:
                        node_delete_cql = "CALL apoc.periodic.iterate(\"MATCH (n:`" + label + "`) RETURN n\", \"DETACH DELETE n\", {batchSize:1000, parallel:true})"
                        print(node_delete_cql)
                        delete_result = session.run(node_delete_cql)
                        count_cql = "MATCH (n:`{0}`) RETURN count(n) AS count".format(label)
                        print(count_cql)
                        count_result = session.run(count_cql)
                        rem_count = count_result.peek()['count']
                        if rem_count == 0:
                            break
                        retry_attempt += 1
                        if retry_attempt == 5:
                            logging.exception("Delete nodes retry limit reached.")
                            sys.exit(1)
                        logging.info("Retry attempt {0}".format(retry_attempt))
                    logging.info("Deleted {0} nodes.".format(label))
        if flag:
            logging.info("[+] Deleted nodes Successfully [+]")

    def close(self):
        self.driver.close()

class vault_password:
    def get_password(self,token,cred_id,cred_type,fireshots_url):
        payload= {"credential_id": cred_id, "credential_type_id": cred_type}
        url= '{0}'.format(fireshots_url)
        r= requests.post(url, headers={"Content-Type":"application/json","Authorization" : token,"Accept": "application/json"},json= payload)
        if r.status_code == 200:
            logging.info("[+] Password obtained [+]")
            return r.json()
        else:
            logging.info(r.json())
			
class Arch_table_details:
    def getRelationshipDetails(self, arch_relationships):
        rel_tables = []
        for rel_table in arch_relationships:
            rel_tuple = (rel_table, False)
            rel_tables.append(rel_tuple)
        return rel_tables
    
if __name__ == "__main__":
    '''parser = argparse.ArgumentParser()
    parser.add_argument("token")
    parser.add_argument("cred_id")
    parser.add_argument("cred_type")
    parser.add_argument("neo4j_uri")
    parser.add_argument("database")
    parser.add_argument("fireshots_url")
    parser.add_argument("arch_tables")
    args = parser.parse_args()
    neo4j_token = args.token
    cred_id = args.cred_id
    cred_type = args.cred_type
    neo4j_uri = args.neo4j_uri
    database_name = args.database
    fireshots_uri = args.fireshots_url

    arch_tables = args.arch_tables'''
    
    args = spark.conf.get("spark.driver.args").split(" ")
    neo4j_token = args[0]
    cred_id = args[1]
    cred_type = args[2]
    neo4j_uri = args[3]
    database_name = args[4]
    fireshots_uri = args[5]

    arch_tables = args[6]
    arch_tables = list(arch_tables.split(","))
	
    arch_entities = []	
    arch_relationships = []

    for table in arch_tables:
        if "_entities" in table:
            arch_entities.append(table)
        if "_relationship" in table:
            arch_relationships.append(table)

    print(arch_entities)
    print(arch_relationships)
		
    vault_obj = vault_password()
    dict_pass = vault_obj.get_password(neo4j_token,cred_id,cred_type,fireshots_uri)

    neo4j_password = dict_pass["data"]["password"]
    neo4j_user = dict_pass["data"]["username"]    
    uri = '{0}'.format(neo4j_uri)
    user = neo4j_user
    database = '{0}'.format(database_name)

    delete_relationships = arch_relationships[:]
    delete_entities = arch_entities[:]
    if "ark.t_compound_compound_relationships" in delete_relationships:
       delete_relationships.remove("ark.t_compound_compound_relationships")
	
    if "ark.t_compound_entities" in delete_entities:
       delete_entities.remove("ark.t_compound_entities")
    delete_obj = Arch_delete(uri,user,neo4j_password)
    delete_obj.delete_relationships(database, delete_relationships)
    delete_obj.close()
    #delete_obj.delete_nodes(database, delete_entities)
	
    constraint_obj= Arch_constraints(uri,user,neo4j_password)
    constraint_obj.create_constraints(database, arch_entities)
    constraint_obj.close()

    index_obj= Arch_indexes(uri,user,neo4j_password)
    index_obj.create_indexes(database)
    index_obj.close()
	
    arch_details_obj = Arch_table_details()
    arch_tables = arch_details_obj.getRelationshipDetails(arch_relationships)

    neo4j_load= Arch(spark,uri,user,neo4j_password,database,)
    neo4j_load.load_graph(arch_entities, arch_tables)

    logging.info("[+] Completed Smoketest. [+]")

