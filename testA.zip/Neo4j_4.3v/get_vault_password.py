import logging
import requests

class vault_password:
    def get_password(self,token,cred_id,cred_type,fireshots_url):
        payload = {"credential_id": cred_id, "credential_type_id": cred_type}
        url = '{0}'.format(fireshots_url)
        r = requests.post(url, headers={"Content-Type":"application/json","Authorization" : token,"Accept": "application/json"},json = payload)
        if r.status_code == 200:
            logging.info("[+] Password obtained [+]")
            return r.json()
        else:
            logging.info(r.json())
