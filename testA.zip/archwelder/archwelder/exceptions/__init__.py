class InvalidEnvironment(Exception):
    pass

class NoSampleSourceSpecified(Exception):
    pass

