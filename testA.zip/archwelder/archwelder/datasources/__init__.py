from .HadoopDataSource import HadoopDataSource
from .PostgresDataSource import PostgresDataSource
from .OracleDataSource import OracleDataSource
from .Neo4JDataSource import Neo4JDataSource
from .JDBCDataSource import JDBCDataSource


class DataSourceFactory:
    
    def __init__(self):
        source_types = {}
        for cls in [HadoopDataSource,Neo4JDataSource,PostgresDataSource,OracleDataSource]:
            source_types[cls.source_type]= {
                'class': cls,
                'driver_file': cls.driver_file,
                'driver_class': cls.driver_class
            }
        self.source_types = source_types
            
    def create(self, type):
        return self._source_types[type]['class']

    def driver_files(self):
        return [f['driver_file'] for f in self._source_types.values() if f['driver_file'] is not None]
        
    @property
    def source_types(self):
        return self._source_types.keys()
    
    @source_types.setter
    def source_types(self, value):
        self._source_types=value