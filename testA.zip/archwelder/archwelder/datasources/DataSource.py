from .. import NoSampleSourceSpecified

import pprint
pp = pprint.PrettyPrinter(indent=4)

class DataSource:
    
    def __init__(self, source_type = '', config = None, spark = None):
        self.source_type = source_type
        self.config = config
        self.spark = spark
    
    def setJobDescription(self,desc):
        self.spark.sparkContext.setJobDescription(desc)
    
    @property
    def source_type(self):
        return self._source_type
    
    @source_type.setter
    def source_type(self, value):
        self._source_type = value

    @property
    def config(self):
        return self._config
    
    @config.setter
    def config(self, value):
        self._config = value
        
    @property
    def spark(self):
        return self._spark
    
    @spark.setter
    def spark(self, value):
        self._spark = value
        
    @property
    def driver_file(self):
        return self._driver_file
    
    @driver_file.setter
    def driver_file(self, value):
        self._driver_file = value

    @property
    def spark_reader(self):
        return self._spark_reader
    
    @spark_reader.setter
    def spark_reader(self, value):
        self._spark_reader = value        
        
    def ignite(self, config = None, spark = None):
        pass