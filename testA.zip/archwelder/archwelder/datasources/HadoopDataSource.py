from .DataSource import *

import pprint
pp = pprint.PrettyPrinter(indent=4)

class HadoopDataSource(DataSource):
    
    source_type = 'hadoop'
    driver_file = None
    driver_class = None
    
    
    def __init__(self, config, spark = None):
        super().__init__(source_type=HadoopDataSource.source_type,config=config,spark=spark)
    
    def ignite(self):
        self.spark_reader = self.spark
        return self

    def query(self, query, format = 'pandas',rows=0):
        if rows>0:
          if format=='pandas':
              return self.spark_reader.sql(query).limit(rows).toPandas()
          else:
              return self.spark_reader.sql(query).limit(rows)
        else:
          if format=='pandas':
              return self.spark_reader.sql(query).toPandas()
          else:
              return self.spark_reader.sql(query)    
        
    def saveARCHTable(self, df, environment,data_store,db_name,set_name,partitions=1,partitionBy=None):
      if partitionBy is not None:
        df.repartition(partitions)\
        .write\
        .mode("OVERWRITE")\
        .option("format", "parquet")\
        .partitionBy(partitionBy)\
        .option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name)\
        .saveAsTable(db_name+"."+set_name)
      else:
        df.repartition(partitions)\
        .write\
        .mode("OVERWRITE")\
        .option("format", "parquet")\
        .option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name)\
        .saveAsTable(db_name+"."+set_name)

    def saveARCHFile(self, df, environment,data_store,db_name,set_name,partitions=1,partitionBy=None):
      if partitionBy is not None:
        df.repartition(partitions)\
        .write\
        .mode("OVERWRITE")\
        .option("format", "parquet")\
        .partitionBy(partitionBy)\
        .option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name)\
        .save()
      else:
        df.repartition(partitions)\
        .write\
        .mode("OVERWRITE")\
        .option("format", "parquet")\
        .option("path","s3a://arch-"+environment+"-datalake/data/warehouse/"+data_store+"/"+db_name+".db/"+set_name)\
        .save()        
        
    def sample(self, table=None, rows=10, params={}, refresh=[], sql=None, format='pandas'):

        if sql is None:
            if table is None:
                raise(NoSampleSourceSpecified())
            else:
                sql = 'SELECT * FROM ' + table
                if len(params.keys()):
                    sql += ' WHERE 1=1 '
                    for k,v in params.items():
                        sql += 'AND ' + k + '=' + str(v)
                if rows>0:
                    sql += ' LIMIT ' + str(rows)

        for tab in refresh:
            spark.sql('REFRESH TABLE ' + tab)

        t = self.query(sql, format,rows)
        return(t)
