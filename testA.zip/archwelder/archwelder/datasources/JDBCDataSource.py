from .DataSource import *

import pprint
pp = pprint.PrettyPrinter(indent=4)


class JDBCDataSource(DataSource):

    source_type = 'postgres'
    driver_file = None
    driver_class = None
    
    def __init__(self, source_type, config, spark = None):
        super().__init__(source_type=source_type,config=config,spark=spark)
        self.url = config['url']
        self.user = config['user']
        self.password = config['password']
        self.read_format = 'jdbc'
        
    @property
    def url(self):
        return self._url
    
    @url.setter
    def url(self, value):
        self._url = value
        
    @property
    def user(self):
        return self._user
    
    @user.setter
    def user(self, value):
        self._user = value
        
    @property
    def password(self):
        return self._password
    
    @password.setter
    def password(self, value):
        self._password = value
    
    @property
    def driver(self):
        return self._driver
    
    @driver.setter
    def driver(self, value):
        self._driver = value
        
    def ignite(self):
        self.spark_reader = spark.read.format(self.read_format)\
            .option("url",self.url)\
            .option("user",self.user)\
            .option("password",self.password)\
            .option("driver",self.driver)
        return self
    
    def get_table(self, table_name):
        return self.spark_reader.option("dbtable", table_name).load()