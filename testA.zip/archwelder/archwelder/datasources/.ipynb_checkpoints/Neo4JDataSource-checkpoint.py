from .DataSource import *

import pprint
pp = pprint.PrettyPrinter(indent=4)

class Neo4JDataSource(DataSource):

    source_type = 'neo4j'
    driver_file = 'neo4j-connector-apache-spark_2.12-4.1.5_for_spark_3.jar'
    driver_class = None
    
    def __init__(self, config, spark = None):
        super().__init__(source_type=Neo4JDataSource.source_type,config=config,spark=spark)
        self.url = config['url']
        self.user = config['user']
        self.password = config['password']
        self.database = config['database']
        self.read_format = 'org.neo4j.spark.DataSource'
    
    @property
    def url(self):
        return self._url

    @url.setter
    def url(self, value):
        self._url = value

    @property
    def user(self):
        return self._user

    @user.setter
    def user(self, value):
        self._user = value

    @property
    def password(self):
        return self._password

    @password.setter
    def password(self, value):
        self._password = value

    @property
    def database(self):
        return self._database

    @database.setter
    def database(self, value):
        self._database = value
    
    def ignite(self):
        self.spark_reader = self.spark.read.format(self.read_format)\
            .option("url",self.url)\
            .option("authentication.type","basic")\
            .option("authentication.basic.username",self.user)\
            .option("authentication.basic.password",self.password)\
            .option("database",self.database)\
            .option("partitions", "10")\
            .option("relationship.nodes.map",True)
        #print(self.spark_reader)
        return self
    
    def labels(self, labels):
        return self.spark_reader.option("labels",labels).load()
    
    def query(self, query, format = 'pandas', rows = 10):
        if format=='pandas':
            if rows:
                return self.spark_reader.option("query",query).load().limit(rows).toPandas()
            else:
                return self.spark_reader.option("query",query).load().toPandas()
        else:
            if rows:
                return self.spark_reader.option("query",query).load().limit(rows)
            else:
                return self.spark_reader.option("query",query).load()
                

    def sample(self, labels=None, rows=10, params={}, refresh=[], cypher=None, format='pandas'):

        if cypher is None:
            if labels is None:
                raise(NoSampleSourceSpecified())
            else:
                cypher = "MATCH (e"+labels+")"
                if len(params.keys()):
                    cypher += ' WHERE 1=1 '
                    for k,v in params.items():
                        sql += 'AND ' + k + '=' + str(v)
                #if rows>0:
                #    cypher += ' LIMIT ' + str(rows)
                cypher += ' RETURN e'
        print(cypher)
        t = self.query(cypher,format,rows)
        return(t)    