from .JDBCDataSource import *

import pprint
pp = pprint.PrettyPrinter(indent=4)

class OracleDataSource(JDBCDataSource):

    
    source_type = 'oracle'
    driver_file = 'ojdbc8.jar'
    driver_class = 'oracle.jdbc.OracleDriver'
    
    def __init__(self, config, spark = None):
        super().__init__(source_type=OracleDataSource.source_type,config=config,spark=spark)
        self.driver = OracleDataSource.driver_class

    def ignite(self):
        self.spark_reader = self.spark.read.format(self.read_format)\
            .option("url",self.url)\
            .option("user",self.user)\
            .option("password",self.password)\
            .option("driver",OracleDataSource.driver_class)
        #print(self.spark_reader)
        return self
        
    def get_table(self, table_name):
        return self.spark_reader.option("dbtable", table_name).load().toPandas()

    def query(self, query, format = 'pandas'):
        if format=='pandas':
            return self.spark_reader.option("query",query).load().toPandas()
        else:
            return self.spark_reader.option("query",query).load()
    
    def sample(self, table=None, rows=10, params={}, refresh=[], sql=None, format = 'pandas'):

        if sql is None:
            if table is None:
                raise(NoSampleSourceSpecified())
            else:
                sql = 'SELECT * FROM ' + table
                if len(params.keys()):
                    sql += ' WHERE 1=1 '
                    for k,v in params.items():
                        sql += 'AND ' + k + '=' + str(v)
                if rows>0:
                    sql += ' FETCH FIRST ' + str(rows) + ' ROWS ONLY'

        t = self.query(sql, format)
        return(t)    