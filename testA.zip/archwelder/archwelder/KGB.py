from pyspark.sql.types import FloatType
from pyspark.sql.functions import col

class KnowledgeGraphBuilder:

    def __init__(self, database_ds=None, graph_ds=None):
      
      self.data=database_ds
      self.graph=graph_ds

      self.df = {}

      self.process_counts = {}
#        self.__neo4j_uri = neo4j_config['uri']
#        self.__neo4j_user = neo4j_config['user']
#        self.__neo4j_pwd = neo4j_config['pwd']
#        self.__neo4j_db = neo4j_config['db']
#        self.__spark = spark_session
#        self.__data = {}

#    def neo4j_overwrite_framewriter(self, __df, executors):
#        return __df\
#            .repartition(executors).write.format("org.neo4j.spark.DataSource").mode("Overwrite") \
#            .option("url", self.__neo4j_uri) \
#            .option("authentication.type", "basic") \
#            .option("authentication.basic.password", self.__neo4j_pwd) \
#            .option("authentication.basic.username", self.__neo4j_user) \
#            .option("database", self.__neo4j_db)
#			
#    def neo4j_errorifexists_framewriter(self, __df, executors):
#        return __df\
#            .repartition(executors).write.format("org.neo4j.spark.DataSource").mode("ErrorIfExists") \
#            .option("url", self.__neo4j_uri) \
#            .option("authentication.type", "basic") \
#            .option("authentication.basic.password", self.__neo4j_pwd) \
#            .option("authentication.basic.username", self.__neo4j_user) \
#            .option("database", self.__neo4j_db)

#    def write_ark_schema_entities(self, source_df, table_name, executors=10):
#        df = source_df.filter("LABEL IS NOT NULL").filter("ID IS NOT NULL").dropDuplicates()
#        label_df = self.arch.spark.sql("SELECT DISTINCT LABEL FROM " + table_name).dropDuplicates()
#        e_reference = {
#            "labels": [str(x.LABEL) for x in label_df.collect()],
#            "key_column": "ID",
#            "property_columns": ','.join([c for c in df.columns if c not in ['ID', 'LABEL']])
#        }
#        df.printSchema()
#        self.write_entities(df,e_reference)
    
    def write_entities(self,df,ent_config,executors=10):

        for node_label in ent_config["labels"]:
            df_l = df \
                .filter("LABEL='" + node_label + "'")
            print('Writing ' + str(df_l.count()) + ' nodes of type ' + node_label)
            self.graph.overwrite_framewriter(df_l, executors=executors) \
                .option("labels", ":" + node_label) \
                .option("node.keys", ent_config["key_column"]) \
                .option("node.properties", ent_config["property_columns"]) \
                .option("batch.size", 10000) \
                .option("transaction.retries", 5) \
                .save()

#    def write_ark_schema_relations(self, source_df, table_name, executors=1):
#        config = {
#          "table_name":"",
#          "rel_type_field":"",
#          "rel_properties_fields":[],
#          "source_key_field":"",
#          "source_label":[],
#          "target_key_field":"",
#          "target_label":[]
#        }
#        df = source_df.select(
#            col("ENTITY1"),
#            col("ENTITY1_TYPE"),
#            col("ENTITY2"),
#            col("ENTITY2_TYPE"),
#            col("REL_TYPE"),
#            col("STRENGTH"),
#            col("RESULT"),
#            col("RESULT_TYPE"),
#            col("CONFIDENCE").cast(FloatType()),
#            col("METADATA.*"),
#            col("LINEAGE.*")
#        ).filter("ENTITY1 IS NOT NULL").filter("ENTITY2 IS NOT NULL")
#        rels_df = self.arch.spark.sql("SELECT DISTINCT ENTITY1_TYPE, REL_TYPE, ENTITY2_TYPE FROM " + table_name).dropDuplicates()
#        
#        df.printSchema()
#        e1_ref = {
#            "labels": [str(x.ENTITY1_TYPE) for x in rels_df.select(col("ENTITY1_TYPE")).distinct().collect()],
#            "key_column": "ENTITY1"
#        }
#        e2_ref = {
#            "labels": [str(x.ENTITY2_TYPE) for x in rels_df.select(col("ENTITY2_TYPE")).distinct().collect()],
#            "key_column": "ENTITY2"
#        }
#        rel_ref = {
#            "labels": [str(x.REL_TYPE) for x in rels_df.select(col("REL_TYPE")).distinct().collect()],
#            "property_columns": ','.join(
#                [c for c in df.columns if c not in ['ENTITY1', 'ENTITY1_TYPE', 'ENTITY2', 'ENTITY2_TYPE', 'REL_TYPE']]
#            )
#        }
#        self.write_relationships(df,rel_ref,e1_ref,e2_ref)
        
    def write_relationships(self,df,rel_config,src_config,tgt_config,executors=1):
        
        print('Writing '+str(df.count())+' relationships')
        for rel_label in rel_config["labels"]:
            for e1_label in src_config["labels"]:
                for e2_label in tgt_config["labels"]:
                    df_r = df \
                        .filter("REL_TYPE='" + rel_label + "'") \
                        .filter("ENTITY1_TYPE='" + e1_label + "'") \
                        .filter("ENTITY2_TYPE='" + e2_label + "'")
                    print('Writing ' + str(df_r.count()) + ' relationships of type '+rel_label+' between '+e1_label+' and '+e2_label)
                    self.graph.overwrite_framewriter(df_r, executors=executors)\
                        .option("relationship", rel_label) \
                        .option("relationship.save.strategy", "keys") \
                        .option("relationship.source.labels", e1_label) \
                        .option("relationship.source.save.mode", "Overwrite") \
                        .option("relationship.source.node.keys", src_config["key_column"]+":ID") \
                        .option("relationship.target.labels", e2_label) \
                        .option("relationship.target.save.mode", "Overwrite") \
                        .option("relationship.target.node.keys", tgt_config["key_column"]+":ID") \
                        .option("relationship.properties", rel_config["property_columns"]) \
                        .option("batch.size", 10000) \
                        .option("transaction.retries", 5) \
                        .save()

#    def load_entities_from_tables(self, table_config):
#        for table_name in table_config:
#            self.arch.spark.sql("REFRESH TABLE " + table_name)
#            self.__data[table_name] = {
#                'dataframe': self.arch.spark.table(table_name).distinct()
#            }
#            self.write_entities(
#                source_df=self.__data[table_name]['dataframe'], table_name = table_name
#            )
#
#    def load_relationships_from_tables(self, table_config):
#        for table_name, bidir_rels in table_config:
#            self.arch.spark.sql("REFRESH TABLE " + table_name)
#            cols  = self.arch.spark.table(table_name).columns
#            if "TILESRC" in cols:
#                self.load_relationships_from_tables_partitions(table_name, bidir_rels)
#            else:
#                self.__data[table_name] = {
#                    'dataframe': self.__spark.table(table_name).distinct()
#                }
#                self.write_relations(
#                    source_df = self.__data[table_name]['dataframe'], table_name = table_name
#                )			
#	
#    def load_relationships_from_tables_partitions(self, table_name, bidir_rels):
#        self.arch.spark.sql("REFRESH TABLE " + table_name)
#        df = self.arch.spark.table(table_name).distinct()
#        df_tile_list = df.select(col("TILESRC")).distinct().rdd.flatMap(lambda x: x).collect()
#        for partition in df_tile_list:
#            print('Writing partition ' + partition + ', partition row count ' + str(df.filter("TILESRC='" + partition + "'").count()))
#            self.write_relations(
#                source_df = df.filter("TILESRC='" + partition + "'"), table_name = table_name
#            )
