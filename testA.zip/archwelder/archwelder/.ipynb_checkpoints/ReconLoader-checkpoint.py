from datetime import datetime
from . import Welder,WelderConfig
from pyspark.sql.functions import col,lit
import logging
import os
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)

class ReconLoader:
  
  def __init__(self,conf):
      self.tasks=conf['tasks']
      self.environment= conf['environment']
      self.data_store=conf['data_store']
      self.db_name=conf['db_name']
      self.dataset_prefix=conf['dataset_prefix']
      self.concept_type = conf['concept_type']
      self.q = {
        k:v for k,v in [(task_key,conf['q_template'].format(**self.tasks[task_key])) for task_key in self.tasks.keys()]
        }

      self.c = {
        k:v for k,v in [(task_key,conf['c_template'].format(**self.tasks[task_key])) for task_key in self.tasks.keys()]
        }
      #self.bootstrap_ontology = conf['bootstrap_ontology']
      #self.bootstrap_cols = bootstrap_cols
      #self.bootstrap_regex = conf['bootstrap_regex']
      #self.identifier_cols = identifier_cols
      self.batch_size = conf['batch_size']
      self.num_partitions=conf['num_partitions']
      self.partition_key=conf['partition_key']
      self.cache_bootstrap = conf['cache_bootstrap']
      print('cache_bootstrap='+str(self.cache_bootstrap))
      self.bootstrap_cached = False
      self.bootstrap_loaded = False
      self.write_staging = conf['write_staging']
      self.print_schema = conf['print_schema']
      print('print_schema='+str(self.print_schema))


      ## factory pattern
      config_path = os.getcwd()+'/config.json'
      logging.info(config_path)
      self.w = Welder(config = WelderConfig(config_file=config_path))
      self.arch = self.w.ignite('arch')
      self.recon_neo4j = self.w.ignite('recon_neo4j')

      self.df = {}

      self.process_counts = {}

  def get_ontologies(self):
    return set([task['ontology'] for task in self.tasks.values() if task['bootstrap']==False])

  def get_bootstraps(self):
    return set([task['ontology'] for task in self.tasks.values() if task['bootstrap']==True])

  def get_tasks(self):
    return sorted(self.tasks.keys(),key=lambda task_key:self.tasks[task_key]['sequence'])

  def load_bootstrap(self,task_key):
    task = self.tasks[task_key]

    bootstrap_key = [task_key for task_key in self.tasks.keys() if ((self.tasks[task_key]['ontology']==task['bootstrap_ontology']) & self.tasks[task_key]['bootstrap'])][0]
    bootstrap_task = self.tasks[bootstrap_key]

    logging.info('Loading bootstrap ontology')
    logging.info('Bootstrap cached: '+str(self.bootstrap_cached))
    logging.info('Cache bootstrap: '+str(self.cache_bootstrap))
    logging.info('Bootstrap loaded: '+str(self.bootstrap_loaded))

    if not self.bootstrap_loaded:
      logging.debug(self.c[bootstrap_key])
      self.recon_neo4j.setJobDescription(task_key+' load bootstrap '+bootstrap_key)
      self.df['BOOTSTRAP'] = self.recon_neo4j.query(query=self.c[bootstrap_key],format='df',rows=0)\
        .withColumnRenamed('EXISTING_CONCEPT_ID','concept_id')\
        .withColumnRenamed('EXISTING_NAME','EXISTING_CONCEPT_KEY')\
        .filter(col('EXISTING_CONCEPT_KEY').rlike(bootstrap_task['bootstrap_regex']))\
        .withColumn('concept_type',lit(bootstrap_task['concept_type'])).repartition(1)
      self.bootstrap_loaded=True
      logging.info('Preparing bootstrap dataframe')

    if self.print_schema==True:
      self.df['BOOTSTRAP'].printSchema()

    logging.info('Bootstrap contains: '+str(self.df['BOOTSTRAP'].count())+' records')

    if self.cache_bootstrap==True:
      self.df['BOOTSTRAP'].cache()
      self.bootstrap_cached=True
      logging.info('Bootstrap cached')

    logging.info('Bootstrap loaded')

  def load_task(self,task_key):
    datestr=datetime.now().strftime('%d%b%Y_%H%M%S')
    task = self.tasks[task_key]

    self.recon_neo4j.setJobDescription(task_key+' load existing identifiers')
    logging.info('Loading existing identifiers for '+task['ontology'])
    existing_identifiers = self.recon_neo4j.query(query=self.c[task_key],format='df',rows=0)
    if self.print_schema:
      existing_identifiers.printSchema()

    logging.info('Loaded '+str(existing_identifiers.count())+' existing identifiers')
    logging.info(self.q[task_key])
    
    if task['bootstrap']:
      if (self.bootstrap_cached & self.cache_bootstrap):
        self.df['BOOTSTRAP'].unpersist()
        self.bootstrap_cached=False
        self.bootstrap_loaded=False
        logging.info('Clearing cached bootstrap')

      logging.info('Bootstrapping new concepts')
      self.arch.setJobDescription(task_key+' bootstrapping')
      self.df[task_key] = self.arch.query(query=self.q[task_key],format='df',rows=0)
      self.df[task_key] = self.df[task_key]\
        .filter(col('CONCEPT_KEY').rlike(task['bootstrap_regex']))\
        .join(self.df['BOOTSTRAP'],col('CONCEPT_KEY')==col('EXISTING_CONCEPT_KEY'),"leftouter")\
        .filter(col('concept_id').isNull())\
        .drop('CONCEPT_KEY')\
        .drop('EXISTING_CONCEPT_KEY')\
        .drop('concept_id')\
        .withColumnRenamed('NEW_CONCEPT_ID','concept_id')\
        .withColumn('concept_type',lit(task['concept_type']))\
        .withColumn('testflag',lit(1))\
        .withColumn('gen_date',lit(datestr))\
        .limit(self.batch_size)
    else:
      self.arch.setJobDescription(task_key+' processing identifiers')
      logging.info('Checking for bootstrap concepts')
      self.df[task_key] = self.arch.query(query=self.q[task_key],format='df',rows=0)\
        .filter(col('CONCEPT_KEY').rlike(task['bootstrap_regex']))\
        .join(self.df['BOOTSTRAP'],col('CONCEPT_KEY')==col('EXISTING_CONCEPT_KEY'),"leftouter")\
        .filter(col('concept_id').isNotNull())\
        .drop('CONCEPT_KEY')\
        .drop('EXSTING_CONCEPT_KEY')\
        .drop('NEW_CONCEPT_ID')\
        .join(existing_identifiers,col('NAME')==col('EXISTING_NAME'),"leftouter")\
        .filter(col('EXISTING_CONCEPT_ID').isNull())\
        .drop('EXISTING_CONCEPT_ID')\
        .drop('EXISTING_NAME')\
        .withColumn('concept_type',lit(task['concept_type']))\
        .withColumn('testflag',lit(1))\
        .withColumn('gen_date',lit(datestr))\
        .limit(self.batch_size)


    self.df[task_key].cache()

    if self.print_schema:
      self.df[task_key].printSchema()
    
  def write_df(self,task_key):
    task = self.tasks[task_key]

    datestr=datetime.now().strftime('%d%b%Y_%H%M%S')
    set_name=self.dataset_prefix+'_'+task['ontology']+'_'+datestr

    if self.write_staging:
      logging.debug('Writing staging table to '+self.db_name+'.'+set_name)
      self.arch.setJobDescription(task_key+' saving table '+self.db_name+'.'+set_name)
      self.arch.saveARCHTable(self.df[task_key],
                         environment=self.environment,
                         data_store=self.data_store,
                         db_name=self.db_name,
                         set_name=set_name,
                         partitions=self.num_partitions,
                         partitionBy=self.partition_key)

    logging.debug('Writing REFERS_TO relationships')
    self.recon_neo4j.setJobDescription(task_key+' writing neo4j REFERS_TO relationships ')
    self.df[task_key].write\
      .format("org.neo4j.spark.DataSource")\
      .mode("Append")\
      .option("url",self.recon_neo4j.url)\
      .option("authentication.type","basic")\
      .option("authentication.basic.username",self.recon_neo4j.user)\
      .option("authentication.basic.password",self.recon_neo4j.password)\
      .option("database",self.recon_neo4j.database)\
      .option("batch.size",10000)\
      .option("partitions",1)\
      .option("relationship","REFERS_TO")\
      .option("relationship.save.strategy","keys")\
      .option("relationship.source.labels",":Identifier")\
      .option("relationship.source.save.mode","Overwrite")\
      .option("relationship.source.node.keys","name:name,ontology:ontology")\
      .option("relationship.source.node.properties","name:name,ontology:ontology,testflag:testflag:gen_date:gen_date")\
      .option("relationship.target.labels",":Concept")\
      .option("relationship.target.save.mode","Overwrite")\
      .option("relationship.target.node.keys","concept_id:concept_id")\
      .option("relationship.target.node.properties","concept_type:concept_type,testflag:testflag,gen_date:gen_date")\
      .save()
      
    logging.debug('Writing IDENTIFIED_BY relationships')
    self.recon_neo4j.setJobDescription(task_key+' writing neo4j IDENTIFIED_BY relationships ')
    self.df[task_key].write\
      .format("org.neo4j.spark.DataSource")\
      .mode("Append")\
      .option("url",self.recon_neo4j.url)\
      .option("authentication.type","basic")\
      .option("authentication.basic.username",self.recon_neo4j.user)\
      .option("authentication.basic.password",self.recon_neo4j.password)\
      .option("database",self.recon_neo4j.database)\
      .option("batch.size",10000)\
      .option("partitions",1)\
      .option("relationship","IDENTIFIED_BY")\
      .option("relationship.save.strategy","keys")\
      .option("relationship.target.labels",":Identifier")\
      .option("relationship.target.save.mode","Overwrite")\
      .option("relationship.target.node.keys","name:name,ontology:ontology")\
      .option("relationship.target.node.properties","name:name,ontology:ontology,testflag:testflag,gen_date:gen_date")\
      .option("relationship.source.labels",":Concept")\
      .option("relationship.source.save.mode","Overwrite")\
      .option("relationship.source.node.keys","concept_id:concept_id")\
      .option("relationship.source.node.properties","concept_type:concept_type,testflag:testflag,gen_date:gen_date")\
      .save()
    
  def process_task(self,task_key):
    task=self.tasks[task_key]
    self.load_bootstrap(task_key)
    self.load_task(task_key)
    self.process_counts[task_key]=int(self.df[task_key].count())
    logging.info('Processing '+task_key+' with '+str(self.process_counts[task_key])+' new identifiers for the '+task['ontology']+' ontology.')
    self.write_df(task_key)
    self.df[task_key].unpersist()
      
  def process_tasks(self):
    logging.info(self.get_tasks())
    for task_key in self.get_tasks():
      logging.info('Processing task '+task_key)
      cont = 1
      while cont:
        start = datetime.now()
        self.process_task(task_key)
        elapsed = datetime.now()-start
        cont = sum(list(self.process_counts.values()))
        logging.info('Processed '+str(cont)+' identifiers for task '+task_key+' in '+str(elapsed))
      
