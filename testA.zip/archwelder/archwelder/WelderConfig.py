from .exceptions import InvalidEnvironment
import json
import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)
class WelderConfig:

    def __init__(self, app_name = '', truststore = "", driver_path = "", environments = {}, default_env = None, active_env = None, spark_options={}, spark_cluster={}, config_file = None, config = None):
        
        if config_file is not None:
            config = json.load(open(config_file))
        
        if config is not None:
            app_name = config['app_name']
            truststore = config['truststore']
            driver_path = config['driver_path']
            environments = config['environments']
            default_env = config['default_env']
            spark_options = config['spark']
            spark_cluster = config['spark']['cluster']
        
        self.app_name = app_name
        self.truststore = truststore
        self.driver_path = driver_path
        self.environments = environments
        self.default_env = default_env
        logging.info(spark_options)
        self.spark_options = spark_options
        logging.info(spark_cluster)
        self.spark_cluster = spark_cluster
        if not active_env:
            self.active_env = self.default_env

    @property
    def spark_options(self):
      return self._spark_options
    
    @spark_options.setter
    def spark_options(self, value):
      self._spark_options={s:v for s,v in value.items()}
      
    @property
    def spark_cluster(self):
      return self._spark_cluster
    
    @spark_cluster.setter
    def spark_cluster(self, value):
      self._spark_cluster={s:v for s,v in value.items()}
            
            
    @property
    def environments(self):
        return self._environments
        
    @environments.setter
    def environments(self, value):
        self._environments = value
    
    @property
    def truststore(self):
        return self._truststore
    
    @truststore.setter
    def truststore(self, value):
        self._truststore = value
        
    @property
    def driver_path(self):
        return self._driver_path
    
    @driver_path.setter
    def driver_path(self, value):
        self._driver_path = value

    @property
    def default_env(self):
        return self._default_env
    
    @default_env.setter
    def default_env(self, value):
        self._default_env = value
        
    @property
    def active_env(self):
        return self._active_env
    
    @active_env.setter
    def active_env(self, value):
        self._active_env = value

    @property
    def app_name(self):
        return self._app_name
    
    @app_name.setter
    def app_name(self, value):
        self._app_name = value

    @property
    def hadoop_filesystems(self):
        return [f['s3_bucket'] for f in self._environments[self.active_env]['data_sources'].values() if f['source_type']=='hadoop']

    def create_env(self, env):
        self.environments[env]={
            'data_sources':{}
        }    
        
    @property
    def data_sources(self):
        return self.environments[self.active_env]['data_sources']
    
    def create_data_source(self, source, values={}, env = None):
        if env is None:
            env = self.active_env
        if env not in self.environments.keys():
            self.create_env(env)
        self.environments[env]['data_sources'][source] = values
    
    def get_data_source(self,source):
        #print(self.active_env)
        #print(source)
        return self.environments[self.active_env]['data_sources'][source]
    
    def set_data_source(self, source, values = {}, env = None):
        if env is None:
            env = self.active_env
        if source not in self.environments[env]['data_sources'].keys():
            self.create_data_source(source, values=values, env=env)
        else:
            self.environments[env]['data_sources'][source] = values
