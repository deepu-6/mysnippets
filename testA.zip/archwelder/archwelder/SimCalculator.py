from pyspark.sql.functions import split,col,size,array_intersect,array_union,ceil,lit,current_timestamp,to_timestamp
from pyspark.sql.types import *
import sys
from . import Welder,WelderConfig
from datetime import datetime
import time
import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)


class SimCalculator:
  
  def __init__(self,conf):
    self.w = Welder(config = WelderConfig(config_file=conf['archwelder_config']))
    self.arch = self.w.ignite('arch')

    self.environment=conf['environment']
    self.data_store=conf['data_store']
    self.db_name=conf['db_name']

  def identify_new_tiles(self):
    logging.info('identifying new tiles')
    max_shard = self.arch.query("SELECT MAX(shard) as shard FROM preclinical.t_compound_fingerprints",format='df',rows=0).first()['shard']
    tiles=[]
    for i in range(max_shard+1):
      for j in range(i+1):
        tiles.append({'tilesrc':str(j)+'x'+str(i),'shard_x':str(j),'shard_y':str(i)})

    df_alltiles = self.arch.spark.createDataFrame(tiles)

    df_staging_tiles = self.arch.query("""
    select distinct
      tilesrc as existing_tilesrc,
      sim_count
      from preclinical.t_compound_sims_tilesrc_metadata
    """,format='df',rows=0)

    df_joinedtiles = df_alltiles\
      .join(df_staging_tiles,df_alltiles.tilesrc==df_staging_tiles.existing_tilesrc,how='leftouter')\
      .drop('existing_tilesrc')

    df_missingtiles = df_joinedtiles\
      .filter("sim_count is NULL")\
      .drop('sim_count')

    missingtiles = [{'shard_x':t[0],'shard_y':t[1],'tilesrc':t[2]} for t in df_missingtiles.toPandas().T.to_dict('list').values()]
    return missingtiles
    
  def process_new_shards(self,num_tiles=15):
    logging.info('processing new shards')

    missingtiles = self.identify_new_tiles()
    logging.info(str(len(missingtiles))+" missing tiles: processing the first "+str(num_tiles))
    logging.info(missingtiles[:num_tiles])

    for tile in missingtiles[:num_tiles]:
      logging.info('processing tilesrc '+tile['tilesrc'])
      self.calculate_tile(tile)

    logging.info('finished calculating '+str(num_tiles)+' of '+str(len(missingtiles))+' new tiles')
    
  def write_tilesrc_info(self,tilesrc,sim_count,sim_staging_table,datestr):  
    df_tiles = self.arch.spark.table("preclinical.t_compound_sims_tilesrc_metadata").filter("tilesrc<>'"+tilesrc+"'")

    tiles = []
    shards = tilesrc.split('x')
    shard_x=shards[0]
    shard_y=shards[1]
    fp_tilesrc_data = {
        "tilesrc":tilesrc,
        "sim_count":sim_count,
        "shard_x":int(shard_x),
        "shard_y":int(shard_y),
        "sim_staging_table":sim_staging_table
      }
    tiles.append(fp_tilesrc_data)
    schema = StructType([
      StructField("tilesrc", StringType(), True),
      StructField("sim_count", IntegerType(), False),
      StructField("shard_x", IntegerType(), False),
      StructField("shard_y", IntegerType(), False),
      StructField("sim_staging_table", StringType(), False)
    ])
    df_newtilesrc = self.arch.spark.createDataFrame(tiles,schema=schema)

    df_tmd = df_newtilesrc.withColumn('date_generated',current_timestamp()).union(df_tiles)

    set_name='t_compound_sims_tilesrc_metadata_tmp'
    num_partitions=1
    partition_key=None

    self.arch.saveARCHTable(df_tmd,
                       environment=self.environment,
                       data_store=self.data_store,
                       db_name=self.db_name,
                       set_name=set_name,
                       partitions=num_partitions,
                       partitionBy=partition_key)

    df_new_tmd = self.arch.spark.table('preclinical.t_compound_sims_tilesrc_metadata_tmp')

    set_name='t_compound_sims_tilesrc_metadata'
    num_partitions=1
    partition_key=None

    self.arch.saveARCHTable(df_new_tmd,
                       environment=self.environment,
                       data_store=self.data_store,
                       db_name=self.db_name,
                       set_name=set_name,
                       partitions=num_partitions,
                       partitionBy=partition_key)


  def calculate_tile(self,tile):
    p1=int(tile['shard_x'])
    p2=int(tile['shard_y'])
    logging.info('calculating similars for tilesrc:'+tile['tilesrc'])
    fp_dfs={}
    self.arch.setJobDescription('Load fingerprints for shard '+str(p2))
    fp_dfs[p2] = self.arch.spark.table('preclinical.t_compound_fingerprints')\
      .filter(col('SHARD')==p2)\
      .drop('SHARD')
    self.arch.setJobDescription('Load fingerprints for shard '+str(p1))
    fp_dfs[p1] = self.arch.spark.table('preclinical.t_compound_fingerprints')\
      .filter(col('SHARD')==p1)\
      .drop('SHARD')

    self.arch.setJobDescription('Perform crossjoin on '+tile['tilesrc'])

    fp_x = fp_dfs[p1].repartition(int(fp_dfs[p1].count()/10000)+1)\
      .withColumnRenamed('compound_uid','COMPOUND_UID_A')\
      .withColumnRenamed('canonical_smiles','CANONICAL_SMILES_A')\
      .withColumnRenamed('INCHI_KEY','INCHI_KEY_A')\
      .withColumnRenamed('ECFP_6','ECFP_6_A')\
      .crossJoin(fp_dfs[p2].repartition(int(fp_dfs[p2].count()/10000)+1)\
                 .withColumnRenamed('compound_uid','COMPOUND_UID_B')\
                 .withColumnRenamed('canonical_smiles','CANONICAL_SMILES_B')\
                 .withColumnRenamed('INCHI_KEY','INCHI_KEY_B')\
                 .withColumnRenamed('ECFP_6','ECFP_6_B'))

    if p1==p2:
      fp_x = fp_x.filter(col('INCHI_KEY_A')>col('INCHI_KEY_B'))

    self.arch.setJobDescription('Calculate tanimotos '+tile['tilesrc'])
    fp_t = fp_x\
      .withColumn('TANIMOTO', size(array_intersect(col('ECFP_6_A'),col('ECFP_6_B'))) / size(array_union(col('ECFP_6_A'),col('ECFP_6_B'))))\
      .drop('ECFP_6_A')\
      .drop('ECFP_6_B')\
      .filter('TANIMOTO>0.25')
    self.arch.setJobDescription('Calculate belief scores '+tile['tilesrc'])
    fp_b = fp_t\
      .withColumn('BELIEF',  0.4 / (1 + 10 ** ((0.373 - col('TANIMOTO')) * 6.651)))\
      .filter('BELIEF>0.05')
    self.arch.setJobDescription('Calculate strengths '+tile['tilesrc'])
    fp_s = fp_b\
      .withColumn('STRENGTH', ceil(col('BELIEF')-0.25)+ceil(col('BELIEF')-0.30)+ceil(col('BELIEF')-0.37))\
      .filter('STRENGTH>0')\
      .withColumn('TILESRC',lit(tile['tilesrc']))\
      .dropDuplicates()
    self.arch.setJobDescription('Repartition and write data '+tile['tilesrc'])

    datestr=datetime.now().strftime('%d%b%Y')
    set_name='t_compound_similars_staging'
    num_partitions=1
    partition_key='TILESRC'

    self.arch.saveARCHTable(fp_s,
                       environment=self.environment,
                       data_store=self.data_store,
                       db_name=self.db_name,
                       set_name=set_name,
                       partitions=num_partitions,
                       partitionBy=partition_key)

    self.write_tilesrc_info(tile['tilesrc'],fp_s.count(),self.db_name+'.'+set_name,datestr)

  def process_range(self,min_shard,max_shard,target_shard):
    for comp_shard in range(min_shard,max_shard+1):
      tile = {
        'shard_x':comp_shard,
        'shard_y':target_shard,
        'tilesrc':str(comp_shard)+'x'+str(target_shard)
      }
      self.calculate_tile(tile)
  