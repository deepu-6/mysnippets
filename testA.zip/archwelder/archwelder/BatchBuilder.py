import requests
import json
import os
from datetime import datetime
from . import Welder,WelderConfig
from pyspark.sql.types import StructType,StringType,StructField,ArrayType,IntegerType,DateType,MapType
from pyspark.sql import Row,Window
from pyspark.sql.functions import *
import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)

class BatchBuilder:
  
  def __init__(self,conf):
    self.environment= conf['environment']
    self.data_store=conf['data_store']
    self.db_name=conf['db_name']
    self.batch_size = conf['batch_size']
    self.skip_rows=0
    self.limit_rows = self.batch_size
    self.batch_number=0
    self.datestr=datetime.now().strftime('%d%b%Y')
    self.num_partitions=conf['num_partitions']
    self.partition_key=conf['partition_key']
    
    self.concept_names=conf['concept_names']
    self.concept_labels=conf['concept_labels']
    self.prefix='_'.join(self.concept_names)
    self.table_name = self.db_name + '.' + self.prefix

    ## factory pattern
    config_path = os.getcwd()+'/config.json'
    logging.info(config_path)
    self.w = Welder(config = WelderConfig(config_file=config_path))
    self.arch = self.w.ignite('arch')
    self.recon_neo4j = self.w.ignite('recon_neo4j')

    self._prep_functions={}
    self._step_functions=[]
    self._step_frames=[]
    self.init_builder()

  def init_builder(self):
    self.dataframes=None
    self.dataframes={}
    logging.info('builder for '+self.er_concept+' initialized, processing '+str(self.concept_count)+' concepts')
  
  def cleanup_builder(self):
    for df in self.dataframes:
      df.unpersist()
    self.init_builder()
    
  def cleanup_batch(self):
    for df in [self.dataframes[s] for s in self._step_frames]:
      df.unpersist()
    
  def get_concept_count(self):
    self.recon_neo4j.setJobDescription('Get '+self.er_concept+' concept count')
    count_df = self.recon_neo4j.query(query="MATCH (c:Concept {concept_type:'"+self.concept_type+"'}) RETURN count(c) AS cnt",format='df',rows=0)
    concept_count = count_df.collect()[0][0]
    logging.info('total concepts in RECON: '+str(concept_count))
    return concept_count

  def add_prep_function(self,f_name,f):
    self._prep_functions[f_name]=f
    logging.debug('prep function '+f_name+' added')
    
  def prep_functions(self):
    for k,v in self._prep_functions.items():
      logging.debug('processing '+k)
      self.store_reference_dataframe(k,v(self))
  
  def add_step_function(self,f):
    self._step_functions.append(f)
    logging.debug('step function '+f.__name__+' added')
  
  def step_functions(self):
    for f in self._step_functions:
      logging.debug('processing '+f.__name__)
      self.store_incremental_dataframe(f.__name__,f(self))
    return self.dataframes[f.__name__]
                 
  def store_reference_dataframe(self,df_name,df):
    self.arch.setJobDescription('build reference dataframe '+df_name)
  
    df.cache()
    self.dataframes[df_name]=df
    
    logging.info('reference dataframe '+df_name+' cached with rows: '+str(df.count()))

  def store_incremental_dataframe(self,df_name,df):
    df.cache()
    self.dataframes[df_name]=df
    logging.info(df_name+' stored with rows: '+str(df.count()))
  
  def generate_table(self):
    
    self.prep_functions()
    
    while self.skip_rows<self.concept_count:
      self.recon_neo4j.setJobDescription('Process batch '+str(self.batch_number))
      self.arch.setJobDescription('Process batch '+str(self.batch_number))
      logging.info('Processing batch '+str(self.batch_number))

      result_df = self.step_functions()
      
      self.save_dated_table(result_df)
      
      self.batch_number += 1
      self.skip_rows += self.batch_size
      self.cleanup_batch()
    
    self.update_version_table()
    self.promote_dated_table()
    self.cleanup_builder()
      
  def save_dated_table(self,df):
    set_name=self.table_name+self.datestr
    self.arch.saveARCHTable(df,
                       environment=self.environment,
                       data_store=self.data_store,
                       db_name=self.db_name,
                       set_name=set_name,
                       partitions=self.num_partitions,
                       partitionBy=self.partition_key)
    
  def update_version_table(self):
    set_name='_'.join(self.concept_names)+'_version_v'

    self.arch.query("""
CREATE EXTERNAL TABLE IF NOT EXISTS {db_name}.{set_name} (
  major int,
  minor int,
  release_date string,
  notes string
) STORED AS PARQUET 
LOCATION 's3a://arch-{environment}-datalake/data/warehouse/{data_store}/{db_name}.db/{set_name}'    
""".format(db_name=self.db_name,set_name=set_name,environment=self.environment,data_store=self.data_store),format='df',rows=0)
    df_version = self.arch.query('SELECT major,minor,release_date,notes FROM '+self.db_name+'.'+set_name,format='df',rows=0)
    if df_version.count()>0:
      r = df_version.first().asDict()
      init_data = [{'major':r['major'],'minor':r['minor']+1,'release_date':self.datestr,'notes':'{"concepts":'+str(self.concept_count)+',"batches":'+str(self.batch_number)+',"table":"'+self.er_table_name+'"}'}]
    else:
      init_data = [{'major':1,'minor':0,'release_date':self.datestr,'notes':'{"concepts":'+str(self.concept_count)+',"batches":'+str(self.batch_number)+',"table":"'+self.er_table_name+'"}'}]  

    df_newversion = self.arch.spark.createDataFrame(init_data)  

    self.arch.saveARCHTable(df_newversion,
                      environment=self.environment,
                      data_store=self.data_store,
                      db_name=self.db_name,
                      set_name=set_name,
                      partitions=1,
                      partitionBy=None)

    
  def promote_dated_table(self):
    self.arch.query('DROP TABLE IF EXISTS '+self.table_name+'_last',format='df',rows=0)
    df_existing = self.arch.query("SHOW TABLES LIKE '"+self.table_name+"'",format='df',rows=0)
    if df_existing.count()>0:
      self.arch.query('ALTER TABLE '+self.table_name+' RENAME TO '+self.table_name+'_last',format='df',rows=0)
    self.arch.query('ALTER TABLE '+self.table_name+self.datestr+' RENAME TO '+self.table_name,format='df',rows=0)

    
    
    
    