from pyspark.sql.functions import split,col,size,array_intersect,array_union,ceil,lit
import requests
import sys
import json
from . import Welder,WelderConfig
from datetime import datetime
import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.INFO)


class FingerprintGenerator:
  
  def __init__(self,conf):
    self.w = Welder(config = WelderConfig(config_file=conf['archwelder_config']))
    self.arch = self.w.ignite('arch')

    self.shard_size=conf['shard_size']
    self.fp_count=self.shard_size
    self.current_shard=-1
    self.environment=conf['environment']
    self.data_store=conf['data_store']
    self.db_name=conf['db_name']
    self.fp_service_batch_size=conf['fp_service']['batch_size']
    self.fp_service_batch_url = conf['fp_service']['url']
    
    
  def process_new_compounds(self):
    logging.info('beginning to process new compounds')
    while self.fp_count>=self.shard_size:

      self.arch.setJobDescription('get maximum shard id')
      self.arch.query("REFRESH TABLE preclinical.t_compound_fingerprints")
      self.current_shard = self.arch.query("SELECT MAX(shard)+1 as shard FROM preclinical.t_compound_fingerprints",format='df',rows=0).first()['shard']

      self.arch.setJobDescription('identify compounds with no fingerprints')
      df = self.arch.query("""
      select   
        comps.compound_uid,
        comps.canonical_smiles,
        comps.inchi_key
      from academe.compounds_v comps
      left outer join preclinical.t_compound_fingerprints fps on comps.inchi_key=fps.inchi_key
      where fps.inchi_key is null and comps.inchi_key is not null and comps.inchi_key=comps.root_inchi_key 
      and comps.canonical_smiles is not null
      """,format='df',rows=0).withColumn('shard',lit(self.current_shard))

      new_compounds = df.count()
      
      logging.info('identified '+str(new_compounds)+' new compounds requiring fingerprint generation')

      if new_compounds>0:

        datestr=datetime.now().strftime('%d%b%Y')
        set_name='t_fingerprints_needed_'+datestr
        num_partitions=1
        partition_key='shard'

        self.arch.saveARCHTable(df.limit(self.shard_size),
                           environment=self.environment,
                           data_store=self.data_store,
                           db_name=self.db_name,
                           set_name=set_name,
                           partitions=num_partitions,
                           partitionBy=partition_key)

        calc_results = self.calc_fingerprints(fps_needed=self.db_name+'.'+set_name,shard=self.current_shard,num_workers=10)
        self.fp_count=calc_results['fp_count']
        logging.info('fingerprints calculated in shard: '+str(self.current_shard)+' for '+str(self.fp_count)+' of the total new compounds: '+str(new_compounds))

        self.write_shard_info(self.current_shard,self.fp_count,calc_results['fp_staging_table'],datestr)
      else:
        self.fp_count=0
    logging.info('processing of new compounds completed')

  def calc_fingerprints(self,fps_needed,shard,num_workers):
    in_df = self.arch.query("""select * from {fps_needed} where shard={shard}""".format(fps_needed=fps_needed,shard=shard),format='df',rows=0)
    comps = in_df.toPandas().T.to_dict('list')

    fps = []
    b=0
    while b<len(comps):
      # get the specific compounds in this batch
      batch = [i for i in comps.values()][b:b+self.fp_service_batch_size]
      data = self.get_fp_batch(batch)
      fps+=map(self.make_fp_array,data["generic"])
      b+=self.fp_service_batch_size

    # create a dataframe from the now returned fingerprint contents
    fp_df = self.arch.spark.createDataFrame(fps).withColumnRenamed('compound_uid','fp_compound_uid')

    # join the fingerprints to the compounds from the shard
    out_df = in_df.join(fp_df,col("compound_uid")==col("fp_compound_uid"),how='leftouter').drop('fp_compound_uid')

    write_results = self.write_fingerprints(out_df)
    
    return write_results
    
  def write_fingerprints(self,out_df):
    
    # write the shard to the fingerprints table
    datestr=datetime.now().strftime('%d%b%Y')
    set_name='t_compound_fingerprints'
    num_partitions=1
    partition_key='shard'

    self.arch.saveARCHTable(out_df,
                       environment=self.environment,
                       data_store=self.data_store,
                       db_name=self.db_name,
                       set_name=set_name,
                       partitions=num_partitions,
                       partitionBy=partition_key)

    return {'fp_staging_table':set_name,'fp_count':out_df.count()}

  def write_shard_info(self,shard,fp_count,fp_staging_table,datestr):  
    logging.debug('writing shard info for shard '+str(shard))
    set_name='t_compound_shard_metadata'
    num_partitions=1
    partition_key='shard'

    fp_shard_data = [
      {
        "shard":shard,
        "compound_count":fp_count,
        "fp_staging_table":fp_staging_table,
        "date_generated":datestr
      }
    ]
    df_newshard = self.arch.spark.createDataFrame(fp_shard_data)

    self.arch.saveARCHTable(df_newshard,
                       environment=self.environment,
                       data_store=self.data_store,
                       db_name=self.db_name,
                       set_name=set_name,
                       partitions=num_partitions,
                       partitionBy=partition_key)
    
  def get_fp_batch(self,batch):
    data = {"compounds":[]}
    for compound_uid,canonical_smiles in [(x[0],x[1]) for x in batch]:
      data["compounds"].append({
        "compound_uid": compound_uid,
        "canonical_smiles": canonical_smiles
      })

    headers = {
      "Content-Type":"application/json"
    }

    response = requests.request("POST", self.fp_service_batch_url, headers=headers, data=json.dumps(data), files=[], verify=False)

    return json.loads(response.text)
  
  @staticmethod
  def make_fp_array(o):
    o['ECFP_6']=[int(t) for t in o['ECFP_6'].split(',')]
    return o
