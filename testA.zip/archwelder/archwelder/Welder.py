from .Igniter import Igniter
from .WelderConfig import WelderConfig

import pprint
pp = pprint.PrettyPrinter(indent=4)

class Welder:
    
    def __init__(self, config = WelderConfig()):
        self.igniter = Igniter(config = config, app_name = config.app_name)
    
    def ignite(self, source):
        #print(source)
        return self.igniter.ignite(source)

    @property
    def igniter(self):
        return self._igniter
    
    @igniter.setter
    def igniter(self,value):
        self._igniter=value
