from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *
import logging
logging.basicConfig(format='%(asctime)s %(message)s',level=logging.DEBUG)

import pprint
pp = pprint.PrettyPrinter(indent=4)

from .datasources import DataSourceFactory

class Igniter:
    
    def __init__(self, config, app_name ="ARCHWelder Igniter"):
        #print(config)
        self.config = config
        self.dsfactory = DataSourceFactory()
        
        spark_builder = SparkSession\
          .builder\
          .appName(config.app_name)\
          .config('spark.yarn.historyServer.allowTracking',True)\
          .config("spark.kubernetes.local.dirs.tmpfs",True)\
          .config("spark.sql.sources.partitionOverwriteMode","dynamic")\
          .config("spark.sql.shuffle.partitions",200)\
          .config("spark.rpc.askTimeout","600s")\
          .config("spark.jars","/home/cdsw/archwelder/datasources/drivers/neo4j-connector-apache-spark_2.12-4.1.5_for_spark_3.jar,/home/cdsw/archwelder/datasources/drivers/postgresql-42.2.24.jar,/home/cdsw/archwelder/drivers/ojdbc8.jar")

        if self.config.spark_options['spark.dynamicAllocation.enabled']=="False":
          logging.info('spark dynamic allocation disabled')
          for option,value in config.spark_cluster.items():
            spark_builder = spark_builder.config(option,value)
        else:
          logging.info('spark dynamic allocation enabled')
          spark_builder = spark_builder\
            .config("spark.dynamicAllocation.enabled",True)\
            .config("spark.dynamicAllocation.shuffleTracking.enabled",True)
        
        if config.truststore is not None:
            #print(config.truststore)
            spark_builder = spark_builder.config("spark.driver.extraJavaOptions","-Djavax.net.ssl.trustStore="+config.truststore)\
              .config("spark.executor.extraJavaOptions","-Djavax.net.ssl.trustStore="+config.truststore)
        
        if len(self.dsfactory.driver_files()):
            #print(",".join([config.driver_path+f for f in self.dsfactory.driver_files()]))
            spark_builder = spark_builder.config("spark.jars",",".join([config.driver_path+f for f in self.dsfactory.driver_files()]))
        
        if len(config.hadoop_filesystems):
            #print(",".join(config.hadoop_filesystems))
            spark_builder = spark_builder.config("spark.yarn.access.hadoopFileSystems",",".join(config.hadoop_filesystems))\
              .enableHiveSupport()
        self.spark = spark_builder.getOrCreate()

    @property
    def config(self):
        return self._config
    
    @config.setter
    def config(self,value):
        self._config = value

    @property
    def spark(self):
        return self._spark
    
    @spark.setter
    def spark(self,value):
        self._spark = value
        
    def ignite(self, source):
        #print(source)
        conf = self.config
        #print(conf)
        ds_conf = conf.get_data_source(source)
        #print(ds_conf)
        ds = self.dsfactory.create(ds_conf['source_type'])(config=ds_conf, spark=self.spark)
        #print(ds)
        return ds.ignite()
