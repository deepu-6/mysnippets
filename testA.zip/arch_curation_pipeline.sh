#!/bin/bash


NABU_SPARK_BOT_HOME="/opt/nabu/nabu-almaren-jobs"
NABU_SPARK_BOT_KEYTAB_PATH="/opt/nabu/etc/keytab/nabu-spark-bots.keytab"
NABU_SPARK_BOT_PRINICIPAL="svc-arch-dev-spark@ARCH-DEV.L6RN-ZJ16.CLOUDERA.SITE"
EVIDENCE_SCHEMA="evidence_schema.json"
NABU_SPARK_BOT_JAAS_CONF="/opt/nabu/nabu-spark-bots/kerberos/conf/jaas.conf"
NEO4J_CONNECTOR="${NABU_SPARK_BOT_HOME}/jars/neo4j-connector-apache-spark_2.11-4.0.0.jar"
LIB_COMMON="${NABU_SPARK_BOT_HOME}/jars/nabu-sparkbot-lib-common_2.11-0.7.8.jar"
PIPELINE_JSON="arch_curation/src/publication/pipeline.json"
ABBVIE_NEO4J="abbvie_neo4j"
TIMELINE_SCHEMA="timeline_solr_schema.json"
SOLR_URL="arch-dev-tellic-master0.arch-dev.l6rn-zj16.cloudera.site:2181,arch-dev-tellic-leader0.arch-dev.l6rn-zj16.cloudera.site:2181,arch-dev-tellic-master1.arch-dev.l6rn-zj16.cloudera.site:2181/solr-dde"
NEO4J_URL="neo4j+ssc://arch-dev-graph-gateway0.arch-dev.awscloud.abbvienet.com:7687"
ABBVIE_NEO4J_DATABASE_NAME="safetynetdev"
DIRECTORY_PATH=${1}
GIT_URL=${2}
TELLIC_NEO4J_CREDENTIAL_ID=${3}
TELLIC_NEO4J_CREDENTIAL_TYPE_ID=${4}
ABBVIE_NEO4J_CREDENTIAL_ID=${5}
ABBVIE_NEO4J_CREDENTIAL_TYPE_ID=${6}
FIRESHOT_ENDPOINT=${7}
AUTHORIZATION_TOKEN=${8}
TELLIC_NEO4J_URL=${9}
ENV=${10}
TELLIC_ZIP_HDFS_PATH=${11}
PIPELINE_NAME=${12}
TABLE_LIST=${13}
NEO4J_URL=${14}

ssh svc-arch-dev-spark@localhost "cd /opt/nabu/nabu-almaren-jobs;python3 bin/nabu-arch-curation.py ${AUTHORIZATION_TOKEN} ${TELLIC_NEO4J_CREDENTIAL_ID} ${TELLIC_NEO4J_CREDENTIAL_TYPE_ID} ${DIRECTORY_PATH} ${GIT_URL} ${PIPELINE_JSON} ${EVIDENCE_SCHEMA} ${NABU_SPARK_BOT_KEYTAB_PATH} ${NABU_SPARK_BOT_PRINICIPAL} ${NABU_SPARK_BOT_HOME} ${ABBVIE_NEO4J} ${NEO4J_CONNECTOR} ${NABU_SPARK_BOT_JAAS_CONF} ${LIB_COMMON} ${FIRESHOT_ENDPOINT} ${ABBVIE_NEO4J_CREDENTIAL_ID} ${ABBVIE_NEO4J_CREDENTIAL_TYPE_ID} ${TIMELINE_SCHEMA} ${SOLR_URL} ${NEO4J_URL} ${ABBVIE_NEO4J_DATABASE_NAME} ${TELLIC_NEO4J_URL} ${ENV} $[TELLIC_ZIP_HDFS_PATH} ${PIPELINE_NAME} ${TABLE_LIST}"