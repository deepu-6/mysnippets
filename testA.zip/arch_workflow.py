import os.path
import subprocess
import logging
import sys
import requests
from requests_kerberos import HTTPKerberosAuth
import json
import os




logging.basicConfig(level = logging.INFO)

def exit_with_error(exit_code):
    sys.exit(exit_code)

def check_directory(path):

    # Check whether the specified path is an existing directory or not  
    is_directory = os.path.isdir(path)
    logging.info("[+]Checking if directory exists[+] : {0}".format(path))
    return is_directory

def git_operations(directory_response, git_url,path):
    if(directory_response)== True:
        os.chdir(path)

        init_cmd= "git init"
        cd_result= subprocess.Popen(init_cmd,shell=True,stdout=subprocess.PIPE)
        data, err = cd_result.communicate()
        if cd_result.returncode == 0:
            logging.info("[+] git init completed [+]")
        else:
            logging.critical('[+]init failed[+]')
            exit_with_error(1)
            

        git_pull_cmd= "git pull {0}".format(git_url)
        result= subprocess.Popen(git_pull_cmd,shell=True,stdout=subprocess.PIPE)
        data, err = result.communicate()
        if result.returncode == 0:
            logging.info("[+] git pull completed [+]")
        else:
            logging.critical('[+] git pull failed [+]')
            exit_with_error(1)
        
        os.chdir("..")
    
    else:
        git_clone_cmd= "git clone {0}".format(git_url)
        result1= subprocess.Popen(git_clone_cmd,shell=True,stdout=subprocess.PIPE)
        data, err = result1.communicate()
        if result1.returncode == 0:
            logging.info("[+] git clone completed [+]")
        else:
            logging.critical('[+] git clone failed [+]')
            exit_with_error(1)
    os.chdir(path)
       
    git_checkout_cmd="git checkout"
    result= subprocess.Popen(git_checkout_cmd,shell=True,stdout=subprocess.PIPE)
    data, err = result.communicate()
    if result.returncode == 0:
        logging.info("[+] git checkout completed [+]")
    else:
        logging.critical('[+] git checkout failed [+]')
        exit_with_error(1)


    os.chdir("..")   

def abbvie_neo4j_submit(path,git_folder_abbvie,abbvie_neo4j_script_name,token,cred_id,cred_type,keytab_path, principal,abbvie_neo4j_path,neo4j_jar_path,user_home_directory,abbvie_neo4j_uri,database_name,fireshots_url,table_list):
    os.environ["PYSPARK_PYTHON"]="python3.6"
    kinit_cmd = "kinit -kt {0} {1}".format(keytab_path,principal)
    kinit_result= subprocess.Popen(kinit_cmd, shell=True, stdout= subprocess.PIPE)
    data,err= kinit_result.communicate()
    if kinit_result.returncode==0:
        logging.info("[+] kinit command succeeded [+]")
    else:
        for line in err.splitlines():
            print(line)
            logging.info("[+] kinit failed [+]")
    
    abbvie_neo4j_abs_path= '{0}'.format(abbvie_neo4j_path)
    os.chdir(abbvie_neo4j_abs_path)
    abbvie_neo4j_cmd= "spark-submit --executor-memory 40G --driver-memory 20G --packages org.neo4j.driver:neo4j-java-driver:4.2.0,org.neo4j:neo4j-cypher-dsl:2020.1.4 --jars {0} {1} {2} {3} {4} {5} {6} {7} {8}".format(neo4j_jar_path,abbvie_neo4j_script_name,token,cred_id,cred_type,abbvie_neo4j_uri,database_name,fireshots_url,table_list)
    print(abbvie_neo4j_cmd)
    abbvie_neo4j_result= subprocess.Popen(abbvie_neo4j_cmd,shell=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    data, err = abbvie_neo4j_result.communicate()
    if abbvie_neo4j_result.returncode == 0:
        for line in data.splitlines():
            print(line)
        logging.info("[+] Abbvie neo4j script successfull [+]")
    else:
        for line in err.splitlines():
            print(line)
        logging.critical("[+] Abbvie neo4j script failed with {0} : {1} {2} [+]" .format(abbvie_neo4j_result.returncode, data, err))
        exit_with_error(abbvie_neo4j_result.returncode)
    user_home_directory_path = '{}'.format(user_home_directory)
    os.chdir(user_home_directory_path)
    print(os.getcwd())
    

def pyspark_script_submit(path,git_folder,pyspark_name,num_cores,num_executors,driver_memory,executor_memory,keytab_path,principal,pipeline_s3_path,database_name,env,hdfs_zip_path):
    kinit_cmd = "kinit -kt {0} {1}".format(keytab_path,principal)
    kinit_result= subprocess.Popen(kinit_cmd, shell=True, stdout= subprocess.PIPE)
    data,err= kinit_result.communicate()
    if kinit_result.returncode==0:
        logging.info("[+] kinit command succeeded [+]")
    else:
        for line in err.splitlines():
            print(line)
            logging.info("[+] kinit failed [+]")

    os.environ["PYSPARK_PYTHON"]="python3.6"
    
    pyspark_cmd= "spark-submit --master yarn --executor-cores {0} --num-executors {1} --executor-memory {2} --driver-memory {3} --deploy-mode cluster --conf spark.dynamicAllocation.enabled=false --py-files {4}  --conf \"spark.yarn.dist.archives={4}#deps\" --conf spark.yarn.appMasterEnv.PYSPARK_PYTHON=python3.6  --conf \'spark.yarn.appMasterEnv.PYTHONPATH=deps\' --conf \'spark.executorEnv.PYTHONPATH=deps\' {5}/{6}/{7} {8} {9} ".format(num_cores,num_executors,executor_memory,driver_memory,hdfs_zip_path,path,git_folder,pyspark_name,pipeline_s3_path,database_name)

    logging.info("[+] Running Pyspark script for generating normalized, solr and neo4j node tables in pipeline db [+]")
    logging.info("[+] Writing tables to " + env + " " + database_name + " database [+]")
    pyspark_result= subprocess.Popen(pyspark_cmd,shell=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    data, err = pyspark_result.communicate()
    if pyspark_result.returncode == 0:
        for line in data.splitlines():
            print(line)
        logging.info("[+] Pyspark script successfull [+]")
    else:
        for line in err.splitlines():
            print(line)
        logging.critical("[+] Pyspark failed with {0} : {1} {2} [+]" .format(pyspark_result.returncode, data, err))
        exit_with_error(pyspark_result.returncode)

def check_collections(solr_url, collection_name1,collection_name2):
    logging.info("[+] Listing out existing collections for a check [+]")
    params_list= {'action': 'LIST'}
    r = requests.get(url = solr_url, params = params_list,auth=HTTPKerberosAuth(), verify=False)
    list_dict= r.json()
    list_collections= list_dict['collections']
    return list_collections

def delete_collection(solr_url,collection_name, keytab_path, principal,zookeeper_host):
    logging.info("[+] Deleting collection [+]: {}".format(collection_name))
    params_delete= {'action':'DELETE','name':collection_name}
    r = requests.get(url = solr_url, params = params_delete,auth=HTTPKerberosAuth(), verify=False)
    if r.status_code == 200:
        logging.info("[+] Collection {0} deleted successfully [+]".format(collection_name))
    else:
        logging.info("[+] Collection {0} deletion failed [+]".format(collection_name))
        exit_with_error(1)
    
    logging.info("[+] Removing config set for {0} [+]".format(collection_name))

    kinit_cmd = "kinit -kt {0} {1}".format(keytab_path,principal)
    kinit_result= subprocess.Popen(kinit_cmd, shell=True, stdout= subprocess.PIPE)
    data,err= kinit_result.communicate()
    if kinit_result.returncode==0:
        logging.info("[+] kinit command succeeded for solrctl [+]")
    else:
        for line in err.splitlines():
            print(line)
            logging.info("[+] kinit failed [+]")

    solrctl_cmd="solrctl --zk {0} config --delete {1}.AUTOCREATED".format(zookeeper_host,collection_name)
    solrctl_res= os.system(solrctl_cmd)
    if solrctl_res == 0 :
        logging.info("[+] Config set Deleted [+]")
    else:
        logging.info("[+] Config set deletion failed [+]")
        exit_with_error(1)
        
def creating_solr_collection(solr_url,action_param,collection_name1,collection_name2,num_shards,replication_factor,max_shards_per_node):
    logging.info("[+] Creating the evidence and timeline collections [+]")
    params_1= {'action':action_param,'name':collection_name1,'numShards':num_shards,'replicationFactor':replication_factor,'maxShardsPerNode':max_shards_per_node}
    params_2=  {'action':action_param,'name':collection_name2,'numShards':num_shards,'replicationFactor':replication_factor,'maxShardsPerNode':max_shards_per_node}

    r = requests.get(url = solr_url, params = params_1,auth=HTTPKerberosAuth(), verify=False)
    if r.status_code == 200:
        logging.info("[+] Collection {0} created successfully [+]".format(collection_name1))
    else:
        logging.info("[+] Collection {0} creation failed [+]".format(collection_name1))
        exit_with_error(1)

    r1 = requests.get(url = solr_url, params = params_2,auth=HTTPKerberosAuth(), verify=False )
    if r1.status_code == 200:
        logging.info("[+] Collection {0} created successfully [+]".format(collection_name2))
    else:
        logging.info("[+] Collection {0} creation failed [+]".format(collection_name2))
        exit_with_error(1)

def creating_solr_schema(solr_url,solr_schema_evidence_dict,solr_schema_timeline_dict,collection_name1,collection_name2,zookeeper_host):
    solr_schema_url_evidence= solr_url + collection_name1 + '/' + 'schema'
    solr_schema_url_timeline= solr_url + collection_name2 + '/' + 'schema'
    logging.info("[+] Creating schema for all columns in {0} collection [+] ".format(collection_name1))
    for key, value in solr_schema_evidence_dict.items():
        payload= {"add-field":{"name":key,"type":value,"indexed":True,"stored":True, "multiValued":False}}
        r= requests.post(solr_schema_url_evidence, headers={"Content-Type":"application/json"},json= payload,auth=HTTPKerberosAuth(), verify=False)
        if r.status_code == 200:
            logging.info("[+] Schema created successfully for {0} [+]".format(key))
        else:
            logging.info(r.json())
            exit_with_error(1)

    logging.info("[+] Creating schema for all columns in {0} collection [+] ".format(collection_name2))
    for key, value in solr_schema_timeline_dict.items():
        payload_timeline= {"add-field":{"name":key,"type":value,"indexed":True,"stored":True, "multiValued":False}}
        r= requests.post(solr_schema_url_timeline, headers={"Content-Type":"application/json"},json= payload_timeline,auth=HTTPKerberosAuth(), verify=False)
        if r.status_code == 200:
            logging.info("[+] Schema created successfully for {0} [+]".format(key))
        else:
            logging.info(r.json())
            exit_with_error(1)
    
    payload_1 = {"set-user-property":{"query.max.booleanClauses":"102400"}}
    payload_2 = {"set-user-property":{"solr.max.booleanClauses":"102400"}}

    solr_evidence_config_url= solr_url + collection_name1 + '/' + 'config'
    solr_timeline_config_url= solr_url + collection_name2 + '/' + 'config'
    r1= requests.post(solr_evidence_config_url, headers={"Content-Type":"application/json"},json= payload_1,auth=HTTPKerberosAuth(), verify=False)
    if r1.status_code == 200:
        logging.info("[+] Query.max.booleanClauses updated successfully for {0} [+]".format(collection_name1))
    else:
        logging.info(r1.json())
        exit_with_error(1)
    
    r2= requests.post(solr_evidence_config_url, headers={"Content-Type":"application/json"},json= payload_2,auth=HTTPKerberosAuth(), verify=False)
    if r2.status_code == 200:
        logging.info("[+] solr.max.booleanClauses updated successfully for {0} [+]".format(collection_name1))
    else:
        logging.info(r2.json())
        exit_with_error(1)
    
    r3= requests.post(solr_timeline_config_url, headers={"Content-Type":"application/json"},json= payload_1,auth=HTTPKerberosAuth(), verify=False)
    if r3.status_code == 200:
        logging.info("[+] Query.max.booleanClauses updated successfully for {0} [+]".format(collection_name2))
    else:
        logging.info(r3.json())
        exit_with_error(1)
    
    r4= requests.post(solr_timeline_config_url, headers={"Content-Type":"application/json"},json= payload_2,auth=HTTPKerberosAuth(), verify=False)
    if r4.status_code == 200:
        logging.info("[+] solr.max.booleanClauses updated successfully for {0} [+]".format(collection_name2))
    else:
        logging.info(r4.json())
        exit_with_error(1)
    

    solrctl_cmd_evidence = "solrctl --zk {0} collection --reload {1}".format(zookeeper_host,collection_name1)
    solrctl_res1= os.system(solrctl_cmd_evidence)
    if solrctl_res1==0:
        logging.info("[+] Collection {0} reloaded [+]".format(collection_name1))
    else:
        logging.info("[+] Collection {0} not reloaded [+]".format(collection_name1))
        exit_with_error(1)
    
    solrctl_cmd_timeline = "solrctl --zk {0} collection --reload {1}".format(zookeeper_host,collection_name2)
    solrctl_res2= os.system(solrctl_cmd_timeline)
    if solrctl_res2==0:
        logging.info("[+] Collection {0} reloaded [+]".format(collection_name2))
    else:
        logging.info("[+] Collection {0} not reloaded [+]".format(collection_name2))
        exit_with_error(1)


    

def almaren_solr_submit(path,git_folder,solr_script_name,num_cores,num_executors,driver_memory,executor_memory,keytab_path,principal,jaas_path,zookeeper_host):
    logging.info("[+] Executing solr indexing script [+]")
    kinit_cmd = "kinit -kt {0} {1}".format(keytab_path,principal)
    kinit_result= subprocess.Popen(kinit_cmd, shell=True, stdout= subprocess.PIPE)
     
    almaren_solr_cmd= "cat {0}/{1}/{2} | spark-shell --master yarn --conf \'spark.executor.extraJavaOptions=-Djava.security.auth.login.config=jaas.conf\' --files {3},{4} --driver-java-options \'-Djava.security.auth.login.config=jaas.conf\' --packages \"com.github.music-of-the-ainur:almaren-framework_2.11:0.5.0-2.4,com.github.music-of-the-ainur:solr-almaren_2.11:0.2.6-2-4\" --repositories http://maven.restlet.org --executor-cores {5} --num-executors {6} --executor-memory {7} --driver-memory {8} --conf spark.dynamicAllocation.maxExecutors=25 --conf spark.task.maxFailures=20 --conf spark.network.timeout=300s --conf spark.driver.args=\"{9}\"".format(path,git_folder,solr_script_name,keytab_path,jaas_path,num_cores,num_executors,executor_memory,driver_memory,zookeeper_host) 
    solr_result= subprocess.Popen(almaren_solr_cmd,shell=True,stdout=subprocess.PIPE)
    data, err = solr_result.communicate()
    if solr_result.returncode == 0:
        for line in data.splitlines():
            print(line)
        logging.info("[+] Solr indexing script successfull [+]")
    else:
        for line in err.splitlines():
            print(line)
        logging.critical("[+] Solr indexing script failed with %d : %s %s [+]"%(solr_result.returncode, data, err))
        exit_with_error(solr_result.returncode)

def timeline_solr_submit(path,git_folder,fdb_comp_sim_solr_script,keytab_path,principal,jaas_path,zookeeper_host):
    kinit_cmd = "kinit -kt {0} {1}".format(keytab_path,principal)
    kinit_result= subprocess.Popen(kinit_cmd, shell=True, stdout= subprocess.PIPE)
    data,err= kinit_result.communicate()
    if kinit_result.returncode==0:
        logging.info("[+] kinit command succeeded [+]")
    else:
        for line in err.splitlines():
            print(line)
            logging.info("[+] kinit failed [+]")
    
    timeline_solr_cmd= "cat {0}/{1}/{2} | spark-shell --master yarn --packages \"com.github.music-of-the-ainur:almaren-framework_2.11:0.5.0-2.4,com.github.music-of-the-ainur:solr-almaren_2.11:0.2.6-2-4\" --repositories http://maven.restlet.org --conf \'spark.executor.extraJavaOptions=-Djava.security.auth.login.config=jaas.conf\' --files {3},{4} --driver-java-options \'-Djava.security.auth.login.config=jaas.conf\' --executor-cores 10 --num-executors 25 --executor-memory 50G --driver-memory 40G --conf spark.dynamicAllocation.maxExecutors=25 --conf spark.task.maxFailures=20  --conf spark.network.timeout=300s --conf spark.driver.args=\"{5}\"".format(path,git_folder,fdb_comp_sim_solr_script,keytab_path,jaas_path,zookeeper_host)
    timeline_solr_result= subprocess.Popen(timeline_solr_cmd,shell=True,stdout=subprocess.PIPE)
    data, err = timeline_solr_result.communicate()
    if timeline_solr_result.returncode == 0:
        for line in data.splitlines():
            print(line)
        logging.info("[+] Solr indexing script for fdb_comp_sim successfull [+]")
    else:
        for line in err.splitlines():
            print(line)
        logging.critical("[+] Solr indexing script failed with %d : %s %s [+]"%(timeline_solr_result.returncode, data, err))
        exit_with_error(timeline_solr_result.returncode)

def almaren_neo4j_submit(path,git_folder,neo4j_script_name,num_cores,num_executors,driver_memory,executor_memory,token,cred_id,cred_type,fireshots_url,vault_jar_path,tellic_neo4j_url):
    logging.info("[+] Executing neo4j data insertion script [+]")
    almaren_neo4j_cmd= "cat {0}/{1}/{2} | spark-shell --master yarn --jars {11} --packages \"com.github.music-of-the-ainur:almaren-framework_2.11:0.5.0-2.4,com.github.music-of-the-ainur:neo4j-almaren_2.11:0.1.0-2.4,org.scalaj:scalaj-http_2.11:2.4.2,io.circe:circe-core_2.11:0.12.0-M3,io.circe:circe-generic_2.11:0.12.0-M3,io.circe:circe-parser_2.11:0.12.0-M3\" --executor-cores {3} --num-executors {4} --executor-memory {5} --driver-memory {6}  --conf spark.driver.args=\"{7} {8} {9} {10} {12}\"".format(path,git_folder,neo4j_script_name,num_cores,num_executors,executor_memory,driver_memory,token,cred_id,cred_type,fireshots_url,vault_jar_path,tellic_neo4j_url)
    print(almaren_neo4j_cmd)
    neo4j_result= subprocess.Popen(almaren_neo4j_cmd,shell=True,stdout=subprocess.PIPE)
    data, err = neo4j_result.communicate()
    if neo4j_result.returncode == 0:
        for line in data.splitlines():
            print(line)
        logging.info("[+] Neo4j script successfull [+]")
    else:
        for line in err.splitlines():
            print(line)
        logging.critical("[+] Neo4j script failed with %d : %s %s [+]"%(neo4j_result.returncode, data,err))
        exit_with_error(neo4j_result.returncode)

def remove_dir_path(path):
    rm_cmd= "rm -rf {0}".format(path)
    rm_result= subprocess.Popen(rm_cmd,shell=True,stdout=subprocess.PIPE)
    data, err = rm_result.communicate()
    if rm_result.returncode == 0:
        logging.info("[+] Directory removed successfully: {0} [+]".format(path))
    else:
        logging.critical("[+] Directory removal failed: {0} [+]".format(path))
        exit_with_error(1)


if __name__ == "__main__":
    token= sys.argv[1]
    cred_id_tellic_neo4j= sys.argv[2]
    cred_type_tellic_neo4j= sys.argv[3]
    path1= sys.argv[4] 
    directory_response= check_directory(path1)
    git_url1= sys.argv[5] 
    git_operations(directory_response,git_url1,path1)

    path_json= sys.argv[6] 
    with open(path_json,encoding='utf-8') as json_data:
        data = json.load(json_data)
    path=data["path"]
    git_folder=data["git_folder"]
    pyspark_script_name= data["pyspark_script_name"]
    solr_almaren_script=data["solr_almaren_script"]
    neo4j_almaren_script=data["neo4j_almaren_script"]
    git_url=data["git_url"]
    num_cores_pyspark=data["num_cores_pyspark"]
    num_executors_pyspark=data["num_executors_pyspark"]
    executor_memory_pyspark=data["executor_memory_pyspark"]
    driver_memory_pyspark=data["driver_memory_pyspark"]
    num_cores_solr=data["num_cores_solr"]
    num_executors_solr=data["num_executors_solr"]
    executor_memory_solr=data["executor_memory_solr"]
    driver_memory_solr=data["driver_memory_solr"]
    num_cores_neo4j=data["num_cores_neo4j"]
    num_executors_neo4j=data["num_executors_neo4j"]
    executor_memory_neo4j=data["executor_memory_neo4j"]
    driver_memory_neo4j=data["driver_memory_neo4j"]
    solr_url_collection=data["solr_url_collection"]
    action=data["action"]
    collection_name1=data["collection_name1"]
    collection_name2=data["collection_name2"]
    numShards=data["numShards"]
    replicationFactor=data["replicationFactor"]
    maxShardsPerNode=data["maxShardsPerNode"]
    solr_url= data["solr_url"]
    git_folder_abbvie= data["abbvie_neo4j_git_folder"]
    abbvie_neo4j_script_name= data["abbvie_neo4j_script"]
    timeline_solr_script= data["timeline_indexing_script"]
    pipeline_s3_path= data["pipeline_s3_path"]
    database_name= data["database_name"]

    path_schema_evidence_json= path + '/' + git_folder + '/' + sys.argv[7]
    with open(path_schema_evidence_json,encoding='utf-8') as json_schema:
        solr_schema_evidence_dict = json.load(json_schema)
    keytab_path = sys.argv[8] 
    principal = sys.argv[9]
    user_home_directory = sys.argv[10]
    abbvie_neo4j_path = user_home_directory + '/' + path + '/' + sys.argv[11]
    neo4j_jar_path = sys.argv[12]
    jaas_conf_path = sys.argv[13]
    vault_jar_path= sys.argv[14]
    fireshots_url=sys.argv[15]
    cred_id_abbvie_neo4j= sys.argv[16]
    cred_type_abbvie_neo4j= sys.argv[17]

    path_schema_timeline_json= path + '/' + git_folder + '/' + sys.argv[18]
    with open(path_schema_timeline_json,encoding='utf-8') as json_schema_timeline:
        solr_schema_timeline_dict = json.load(json_schema_timeline)
    
    zookeeper_host= sys.argv[19]
    abbvie_neo4j_uri= sys.argv[20]
    abbvie_neo4j_database_name= sys.argv[21]
    tellic_neo4j_url= sys.argv[22]
    env= sys.argv[23]
    hdfs_zip_path= sys.argv[24]
    pipeline_name= sys.argv[25]
    table_list= sys.argv[26]



	
    pipeline_s3_path= pipeline_s3_path.replace("ENV", env)

    if pipeline_name=="tellic_pipeline":
        pyspark_script_submit(path,git_folder,pyspark_script_name,num_cores_pyspark,num_executors_pyspark,driver_memory_pyspark,executor_memory_pyspark,keytab_path,principal,pipeline_s3_path,database_name,env,hdfs_zip_path)
        collections_list= check_collections(solr_url_collection,collection_name1,collection_name2)
        if collection_name1 in collections_list:
            delete_collection(solr_url_collection, collection_name1,keytab_path,principal,zookeeper_host)
        
        if(collection_name2 in collections_list):
            delete_collection(solr_url_collection,collection_name2,keytab_path,principal,zookeeper_host)
        
        creating_solr_collection(solr_url_collection,action,collection_name1,collection_name2,numShards,replicationFactor,maxShardsPerNode)
        
        creating_solr_schema(solr_url,solr_schema_evidence_dict,solr_schema_timeline_dict,collection_name1,collection_name2,zookeeper_host)
        
        almaren_solr_submit(path,git_folder,solr_almaren_script,num_cores_solr,num_executors_solr,driver_memory_solr,executor_memory_solr,keytab_path,principal,jaas_conf_path,zookeeper_host)
        
        timeline_solr_submit(path,git_folder,timeline_solr_script,keytab_path,principal,jaas_conf_path,zookeeper_host)

        almaren_neo4j_submit(path,git_folder,neo4j_almaren_script,num_cores_neo4j,num_executors_neo4j,driver_memory_neo4j,executor_memory_neo4j,token,cred_id_tellic_neo4j,cred_type_tellic_neo4j,fireshots_url,vault_jar_path,tellic_neo4j_url)

        
    elif pipeline_name=="abbvie_neo4j_pipeline":
            abbvie_neo4j_submit(path,git_folder_abbvie,abbvie_neo4j_script_name,token,cred_id_abbvie_neo4j,cred_type_abbvie_neo4j,keytab_path,principal,abbvie_neo4j_path,neo4j_jar_path,user_home_directory,abbvie_neo4j_uri,abbvie_neo4j_database_name,fireshots_url,table_list)

    else :
        pass

    remove_dir_path(path) 

