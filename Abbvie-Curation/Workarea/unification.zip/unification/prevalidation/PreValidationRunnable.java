/*
 * Copyright 2021 GlaxoSmithKline LLC
 */

package com.gsk.rd.unification.prevalidation;

import com.gsk.rd.unification.builders.ProcessParam;
import com.gsk.rd.utils.Commons;
import com.gsk.rd.utils.Helper;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.commons.collections.map.MultiKeyMap;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.stringtemplate.v4.STGroup;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class PreValidationRunnable implements Runnable {

    private static final Logger LOGGER = LogManager.getLogger(PreValidationRunnable.class.getSimpleName());
    private final String tableName;
    private final List<HashMap<String, Object>> tableMetadata;
    private final List<Map<String, Object>> finalMetadata;
    private final ProcessParam processParam;
    private final Helper helper = Helper.getInstance();
    private final STGroup templateGroup;
    private final HikariDataSource postgresDataSource;


    /**
     * @param tableName source table name
     * @param tableMetadata source table metadata
     * @param finalMetadata syncronized list to capture prevalidation result of source tables validated parallely
     * @param processParam object with data that can be used throught out the unification
     */
    public PreValidationRunnable(String tableName, List<HashMap<String, Object>> tableMetadata, List<Map<String, Object>> finalMetadata, ProcessParam processParam) {

        this.tableName = tableName;
        this.tableMetadata = tableMetadata;
        this.finalMetadata = finalMetadata;
        this.processParam = processParam;
        this.templateGroup = processParam.getTemplateGroup();
        this.postgresDataSource = processParam.getPostgresDataSource();
    }


    @Override
    public void run() {
        try {
            this.prevalidationRun();
        }
        catch (Exception e) {
            LOGGER.error(tableName, e);
            Exception e1 = new Exception(e.getMessage() + " - " + tableName);
            e1.setStackTrace(e.getStackTrace());
            StringWriter tmp = new StringWriter();
            e1.printStackTrace(new PrintWriter(tmp));
            String exception = tmp.toString();
            helper.jobException(exception, templateGroup, postgresDataSource);
        }
        finally {
            LOGGER.info("prevalidation complete for {}", tableName);
        }
    }

    /**
     * prevalidation run method
     */
    public void prevalidationRun() {
        LOGGER.info("prevalidation started for {}", tableName);
        addMappedDatasetInfo();
        boolean noErrorsFound = checkAndReportFoundErrors();
        if (noErrorsFound) {
            addConfigurationInfo();
            noErrorsFound = checkAndReportFoundErrors();
            if (noErrorsFound) {
                compareDataTypes();
                noErrorsFound = checkAndReportFoundErrors();
                if (noErrorsFound) {
                    finalMetadata.addAll(tableMetadata);
                }
            }
        }
    }

    /**
     * @return returns boolean true/false based on error check among all columns
     */
    private boolean checkAndReportFoundErrors() {
        boolean noErrorsFound = tableMetadata.stream()
                .noneMatch(map -> map.get(Commons.MESSAGE_LEVEL).toString().equalsIgnoreCase(Commons.ERROR));
        if (!noErrorsFound) {
            List<HashMap<String, Object>> metadataToReport = tableMetadata.stream()
                    .filter(map -> map.get(Commons.MESSAGE_LEVEL).toString().equalsIgnoreCase(Commons.ERROR))
                    .collect(Collectors.toList());
            LOGGER.debug("errors found: {}", metadataToReport.size());
            try {
                helper.insertChecksReport(templateGroup, metadataToReport, postgresDataSource);
            }
            catch (Exception e) {
                LOGGER.error("failed inserting errors for {}", tableName, e);
                helper.jobException(e, templateGroup, postgresDataSource);
            }
        }
        return noErrorsFound;
    }

    /**
     * adds mapped dataset information to source table metadata
     */
    private void addMappedDatasetInfo() {
        Map<String, Object> firstRow = tableMetadata.get(0);
        String datasetName = firstRow.get("dataset_name").toString().toLowerCase();
        String mappedDatasetName = getMappedDatasetName(firstRow);
        if (mappedDatasetName != null) {
            tableMetadata.forEach(map -> {
                        map.put(Commons.MAPPED_DATASET, mappedDatasetName);
                        map.put(Commons.MESSAGE_LEVEL, Commons.INFO);
                        map.put(Commons.MESSAGE, null);
                        map.put(Commons.COMMENTS, null);
                    }
            );
        }
        else {
            LOGGER.info("{} - mapping does not exist !!", tableName);
            tableMetadata.forEach(map -> {
                        map.put(Commons.MAPPED_DATASET, null);
                        map.put(Commons.MESSAGE_LEVEL, Commons.ERROR);
                        map.put(Commons.MESSAGE, datasetName + " is not available in mappings");
                        map.put(Commons.COMMENTS, "NA - target dataset mappings; dataset not unified");
                    }
            );
        }
    }

    /**
     * Looks up mappings for the source dataset and returns mapped dataset name
     *
     * @param firstRow first(optional pick) row  of the source table metadata
     * @return returns mapped dataset name
     */
    private String getMappedDatasetName(Map<String, Object> firstRow) {
        String datasetName = firstRow.get("dataset_name").toString().toLowerCase();
        String datasetType = firstRow.get("dataset_type").toString().toLowerCase();
        String studyId = firstRow.get("studyid").toString().toLowerCase();
        MultiKeyMap mappedDatasetMap = processParam.getMappedDatasetMap();
        String mappedDataset = null;
        if (mappedDatasetMap.get(datasetName, datasetType, "default") != null) {
            mappedDataset = mappedDatasetMap.get(datasetName, datasetType, "default").toString();
        }
        if (mappedDatasetMap.get(datasetName, datasetType, studyId) != null) {
            mappedDataset = mappedDatasetMap.get(datasetName, datasetType, studyId).toString();
        }
        return mappedDataset;
    }

    /**
     * adds configuration (based on dataset_type) to source table metadata
     */
    private void addConfigurationInfo() {
        String mappedDatasetName = tableMetadata.get(0).get(Commons.MAPPED_DATASET).toString();
        String datasetType = tableMetadata.get(0).get("dataset_type").toString();
        HashMap<String, List<String>> configurationMap = getDatasetConfiguration(mappedDatasetName, datasetType);
        if (configurationMap != null) {
            for (Map<String, Object> map : tableMetadata) {
                String varName = map.get("var_name").toString();
                if (configurationMap.containsKey(varName)) {
                    List<String> varNameConfig = configurationMap.get(varName);
                    String varDtype = varNameConfig.get(0);
                    String varOrder = varNameConfig.get(1);
                    map.put(Commons.MAPPED_DATASET, mappedDatasetName);
                    map.put(Commons.VAR_DTYPE, varDtype);
                    map.put(Commons.VAR_ORDER, varOrder);
                    map.put(Commons.MESSAGE_LEVEL, "INFO");
                    map.put(Commons.MESSAGE, null);
                    map.put(Commons.COMMENTS, null);
                }
                else {
                    map.put(Commons.MAPPED_DATASET, mappedDatasetName);
                    map.put(Commons.VAR_DTYPE, null);
                    map.put(Commons.VAR_ORDER, null);
                    map.put(Commons.MESSAGE_LEVEL, Commons.ERROR);
                    map.put(Commons.MESSAGE, varName + " is not available in configuration");
                    map.put(Commons.COMMENTS, "NA - target column; dataset not unified");
                }
            }
        }
        else {
            LOGGER.info("config not found for {} of {}", mappedDatasetName, datasetType);
            tableMetadata.forEach(map -> {
                map.put(Commons.MAPPED_DATASET, mappedDatasetName);
                map.put(Commons.VAR_DTYPE, null);
                map.put(Commons.VAR_ORDER, null);
                map.put(Commons.MESSAGE_LEVEL, Commons.ERROR);
                map.put(Commons.MESSAGE, mappedDatasetName + " dataset is not available in configuration");
                map.put(Commons.COMMENTS, "NA - target dataset; dataset not unified");
            });
        }
    }

    /**
     * @param mappedDatasetName mapped/unified dataset name
     * @param datasetType dataset type
     * @return returns configuration based on dataset type and mapped dataset name
     */
    private HashMap<String, List<String>> getDatasetConfiguration(String mappedDatasetName, String datasetType) {
        HashMap<String, List<String>> configurationMap = null;
        if (datasetType.equalsIgnoreCase("SDTM")) {
            if (mappedDatasetName.toLowerCase().startsWith("supp") ||
                    mappedDatasetName.toLowerCase().startsWith("sc_supp")) {
                configurationMap = processParam.getSdtmConfigByDataset().get("supp");
            }
            else {
                configurationMap = processParam.getSdtmConfigByDataset().get(mappedDatasetName);
            }
        }
        else if (datasetType.equalsIgnoreCase("SI") ||
                datasetType.equalsIgnoreCase("AR")) {
            configurationMap = processParam.getSiArConfigByDataset().get(mappedDatasetName);
        }
        else {
            LOGGER.info("dataset type not found: {}", datasetType);
        }
        return configurationMap;
    }

    /**
     * compare datatypes of all columns of a source table
     */
    private void compareDataTypes() {
        HashMap<String, Integer> priorityMap = new HashMap<>();
        priorityMap.put(Commons.STRING, 5);
        priorityMap.put(Commons.DOUBLE, 4);
        priorityMap.put(Commons.DECIMAL, 3);
        priorityMap.put(Commons.BIGINT, 2);
        priorityMap.put("INT", 1);
        priorityMap.put("SMALLINT", 1);
        priorityMap.put("null", 0);
        for (Map<String, Object> map : tableMetadata) {
            String hiveDtype = map.get("hive_dtype").toString();
            String configDtype = map.get(Commons.VAR_DTYPE).toString();
            String profileDtype = String.valueOf(map.get("profile_dtype"));
            if (!configDtype.equalsIgnoreCase(hiveDtype)) {
                if (configDtype.equalsIgnoreCase(Commons.STRING)) {
                    addWarning(map);
                }
                else if (map.get("is_null").toString().equalsIgnoreCase("true")) {
                    addWarning(map);
                }
                else if (hiveDtype.equalsIgnoreCase(Commons.STRING)) {
                    comparePriorities(configDtype, profileDtype, priorityMap, map);
                }
                else if (configDtype.contains(Commons.DECIMAL) || configDtype.equalsIgnoreCase(Commons.DOUBLE)) {
                    addWarning(map);
                }
                else if (hiveDtype.equalsIgnoreCase(Commons.DOUBLE) || hiveDtype.equalsIgnoreCase(Commons.BIGINT)) {
                    comparePriorities(configDtype, profileDtype, priorityMap, map);
                }
                else if (configDtype.equalsIgnoreCase(Commons.BIGINT)) {
                    addWarning(map);
                }
            }
            else {
                map.put(Commons.MESSAGE_LEVEL, "INFO");
                map.put(Commons.MESSAGE, null);
                map.put(Commons.COMMENTS, null);
            }
        }
    }

    /**
     * compare datatypes by priroties
     *
     * @param configDtype Datatype defined in Configuration
     * @param profileDtype Datatype derived by profiling
     * @param priorityMap Map of datatype priorities
     * @param map A row in a source table metadata
     */
    private void comparePriorities(String configDtype, String profileDtype, HashMap<String, Integer> priorityMap, Map<String, Object> map) {
        int profileDtypePriority = priorityMap.get(profileDtype);
        int varDtypePriority = getVarDtypePriority(configDtype, priorityMap);

        if (varDtypePriority >= profileDtypePriority) {
            addWarning(map);
        }
        else {
            addError(map);
        }
    }

    /**
     * Looks for the priority of the datatype and returns
     *
     * @param configDtype Datatype defined in Configuration
     * @param priorityMap Map of datatype priorities
     * @return returns priority of the datatype
     */
    private int getVarDtypePriority(String configDtype, HashMap<String, Integer> priorityMap) {
        int varDtypePriority;
        if (configDtype.startsWith(Commons.DECIMAL)) {
            varDtypePriority = priorityMap.get(Commons.DECIMAL);
        }
        else {
            varDtypePriority = priorityMap.get(configDtype);
        }
        return varDtypePriority;
    }

    /**
     * Method is called when a column information status has to be updated with warn status
     *
     * @param map row in a source table metadata
     */
    public void addWarning(Map<String, Object> map) {
        String configDtype = map.get(Commons.VAR_DTYPE).toString();
        map.put(Commons.MESSAGE_LEVEL, Commons.WARNING);
        map.put(Commons.MESSAGE, "All values handle by target datatype " + configDtype);
        map.put(Commons.COMMENTS, null);
    }

    /**
     * Method is called when a column information status has to be updated with error status
     *
     * @param map row in a source table metadata
     */
    public void addError(Map<String, Object> map) {
        String varName = map.get("var_name").toString();
        String hiveDtype = map.get("hive_dtype").toString();
        String configDtype = map.get(Commons.VAR_DTYPE).toString();
        String message = String.format(
                "For column %s source data type %s not handled by target datatype %s",
                varName,
                hiveDtype,
                configDtype);
        String comments = String.format(
                "Values exist that are not %s; dataset not unified",
                configDtype);
        map.put(Commons.MESSAGE_LEVEL, Commons.ERROR);
        map.put(Commons.MESSAGE, message);
        map.put(Commons.COMMENTS, comments);
    }

}
