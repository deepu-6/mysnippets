/*
 * Copyright 2021 GlaxoSmithKline LLC
 */

package com.gsk.rd.unification.prevalidation;

import com.gsk.rd.unification.builders.ProcessParam;
import com.gsk.rd.utils.Helper;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.stringtemplate.v4.STGroup;

import java.io.StringWriter;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

public class PreValidation {
    private static final Logger LOGGER = LogManager.getLogger(PreValidation.class.getSimpleName());
    private final ProcessParam processParam;
    private final Helper helper;

    public PreValidation(ProcessParam processParam) {
        this.processParam = processParam;
        this.helper = Helper.getInstance();
    }

    /**
     * main method of prevalidation
     *
     * @return prevalidation output
     */
    public List<Map<String, Object>> run() {
        LOGGER.info("unify pre validation started");
        long startTime = System.currentTimeMillis();
        int threadCount = processParam.getThreadCount();
        HikariDataSource postgresDataSource = processParam.getPostgresDataSource();
        STGroup templateGroup = processParam.getTemplateGroup();
        ExecutorService executorService = Executors.newFixedThreadPool(threadCount);
        List<Map<String, Object>> finalMetadata = Collections.synchronizedList(new ArrayList<>());
        try {
            List<HashMap<String, Object>> tablesMetadata = processParam.getTablesMetadata();
            Map<String, List<HashMap<String, Object>>> metadataByTable = tablesMetadata.stream()
                    .collect(Collectors.groupingBy(m -> m.get("table_name").toString()));
            for (Map.Entry<String, List<HashMap<String, Object>>> entry : metadataByTable.entrySet()) {
                String tableName = entry.getKey();
                List<HashMap<String, Object>> tableMetadata = entry.getValue();
                executorService.submit(
                        new PreValidationRunnable(tableName,
                                tableMetadata,
                                finalMetadata,
                                processParam)
                );
            }
        }
        catch (Exception e) {
            LOGGER.error("", e);
            helper.jobException(e, templateGroup, postgresDataSource);
        }
        finally {
            try {
                executorService.shutdown();
                boolean b = executorService.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
                LOGGER.debug("all Threads are complete: {}", b);
            }
            catch (Exception e) {
                String exceptionMessage = "Unable to shutdown executor service";
                Exception e1 = new Exception(e.getMessage() + " - " + exceptionMessage);
                e1.setStackTrace(e.getStackTrace());
                StringWriter tmp = new StringWriter();
                LOGGER.error("", e1);
                String exception = tmp.toString();
                helper.jobException(exception, templateGroup, postgresDataSource);
            }
        }
        long endTime = System.currentTimeMillis();
        String duration = getDuration(startTime, endTime);
        LOGGER.info("pre validation took: {}", duration);
        return finalMetadata;
    }

    /**
     * Converts time in ms to duration in hours
     *
     * @param startTime pre validation start time in ms
     * @param endTime   pre validation end time in ms
     * @return returns duration in hours:minutes:seconds format
     */
    public String getDuration(long startTime, long endTime) {
        long ms = endTime - startTime;
        long seconds = (ms / 1000) % 60;
        long minutes = ((ms / 1000) / 60) % 60;
        long hours = ((ms / 1000) / 60) / 60;
        String duration;
        duration = String.format("%02dh : %02dm : %02ds", hours, minutes, seconds);
        return duration;
    }
}
