/*
 * Copyright 2021 GlaxoSmithKline LLC
 */

package com.gsk.rd.unification.postvalidation;

import com.gsk.rd.unification.builders.ProcessParam;
import com.gsk.rd.utils.Commons;
import com.gsk.rd.utils.Helper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.stringtemplate.v4.STGroup;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PostValidation {
    private static final Logger LOGGER = LogManager.getLogger(PostValidation.class.getSimpleName());
    private final ProcessParam processParam;
    private final HashMap<String, String> unifyOutput;
    private final HashMap<String, String> rowCountMap;
    private final Helper helper = Helper.getInstance();
    private final String mappedDatasetName;
    private final STGroup templateGroup;
    private final List<Map<String, Object>> mismatchList = new ArrayList<>();

    /**
     * @param processParam ProcessParam object
     * @param unifyOutput  Mapped dataset unification output map
     * @param rowCountMap  map of row counts of source datasets
     */
    public PostValidation(ProcessParam processParam,
                          HashMap<String, String> unifyOutput,
                          HashMap<String, String> rowCountMap) {

        this.processParam = processParam;
        this.mappedDatasetName = unifyOutput.get(Commons.MAPPED_DATASET);
        this.unifyOutput = unifyOutput;
        this.rowCountMap = rowCountMap;
        this.templateGroup = processParam.getTemplateGroup();
    }

    /**
     * Main method for postvalidation of mapped dataset
     *
     * @return validation status "pass" or "fail"
     */
    public String run() {
        String unifiedTableName;
        String validation = "fail";
        try {
            unifiedTableName = unifyOutput.get("unified_tablename");
            String rowCountByFileIdQuery = templateGroup.getInstanceOf("row_count_by_fileid")
                    .add(Commons.TABLE_NAME, unifiedTableName)
                    .add("file_ids", rowCountMap.keySet())
                    .render();
            LOGGER.debug(rowCountByFileIdQuery);
            LOGGER.debug("row count from metadata: {}", rowCountMap);
            List<HashMap<String, Object>> rowCountByFileIdResult = helper.executeQuery(processParam.getHiveDataSource(),
                    rowCountByFileIdQuery);
            for (HashMap<String, Object> fileIdMap : rowCountByFileIdResult) {
                compareRowCount(fileIdMap);
            }
            if (!mismatchList.isEmpty()) {
                LOGGER.error("{} row count mismatch list: {}", unifiedTableName, mismatchList);
            }
            else {
                LOGGER.info("{} validation complete. No issues found", unifiedTableName);
                validation = "pass";
            }
            LOGGER.debug(Commons.LOG_SEPARATOR);
            if (mappedDatasetName.equalsIgnoreCase("dm")) {
                String usubjidCheckQuery = templateGroup.getInstanceOf("usubjid_check")
                        .add("unified_table_name", unifiedTableName)
                        .add(Commons.MAPPED_DATASET, mappedDatasetName)
                        .render();
                LOGGER.debug(usubjidCheckQuery);
                List<HashMap<String, Object>> result = helper.executeQuery(processParam.getHiveDataSource(),
                        usubjidCheckQuery);
                helper.insertChecksReport(templateGroup, result, processParam.getPostgresDataSource());
            }
            if (mappedDatasetName.equalsIgnoreCase("demo")) {
                String subjidCheckQuery = templateGroup.getInstanceOf("subjid_check")
                        .add("unified_table_name", unifiedTableName)
                        .add(Commons.MAPPED_DATASET, mappedDatasetName)
                        .render();
                LOGGER.debug(subjidCheckQuery);
                List<HashMap<String, Object>> result = helper.executeQuery(processParam.getHiveDataSource(),
                        subjidCheckQuery);
                helper.insertChecksReport(templateGroup, result, processParam.getPostgresDataSource());
            }
        }
        catch (Exception e) {
            LOGGER.error("", e);
            helper.jobException(e, templateGroup, processParam.getPostgresDataSource());
        }
        return validation;
    }

    /**
     * compares the row count in unified table for a clinical_trl_fileid against row count from metadata
     *
     * @param fileIdMap row count of a single clinical_trl_fileid in unified table
     */
    public void compareRowCount(HashMap<String, Object> fileIdMap) {
        String clinicalTrlFileId = fileIdMap.get("clinical_trl_fileid").toString();
        try {
            int rowCountInUnified = Integer.parseInt(fileIdMap.get(Commons.ROW_COUNT).toString());
            int rowCountInSource = Integer.parseInt(rowCountMap.get(clinicalTrlFileId));
            if (rowCountInUnified != rowCountInSource) {
                HashMap<String, Object> mismatchCountMap = new HashMap<>();
                mismatchCountMap.put("clinical_trl_fileid", clinicalTrlFileId);
                mismatchCountMap.put("source_row_count", rowCountInSource);
                mismatchCountMap.put("unified_row_count", rowCountInUnified);
                mismatchList.add(mismatchCountMap);
            }
        }
        catch (Exception e) {
            LOGGER.error("Failed for {}", clinicalTrlFileId, e);
            helper.jobException(e, templateGroup, processParam.getPostgresDataSource());
        }
    }
}
