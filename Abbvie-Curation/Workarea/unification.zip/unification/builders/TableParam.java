/*
 * Copyright 2021 GlaxoSmithKline LLC
 */

package com.gsk.rd.unification.builders;

import com.gsk.rd.utils.Commons;
import org.stringtemplate.v4.STGroup;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class TableParam {
    private final String tableName;
    private final int rowCount;
    private final String studyId;
    private final String datasetName;
    private final Object spectreDataset;
    private final Object nsRdipReleaseDate;
    private final Object nsConversionSource;
    private final Object nsDcoeClinicalVersion;
    private final Object nsDataStandardVersion;
    private final Object nsConvertDate;
    private final Object nsSourceDset;
    private final Object nsClinicalTrlFileId;
    private final String hdfsFilePath;
    private final String flatFilePath;
    private final String tablenameWithoutDb;
    private final List<String> sourceColumnsList;
    private final Map<String, String> sourceTableDDLMap;
    private final String seqColumn;
    private final String seqColumnDtype;
    private final List<Map<String, Object>> tableMetadata;


    private TableParam(TableParamBuilder tableParamBuilder) {
        this.studyId = tableParamBuilder.studyId;
        this.tableMetadata = tableParamBuilder.tableMetadata;
        this.tablenameWithoutDb = tableParamBuilder.tablenameWithoutDb;
        this.datasetName = tableParamBuilder.datasetName;
        this.spectreDataset = tableParamBuilder.spectreDataset;
        this.hdfsFilePath = tableParamBuilder.hdfsFilePath;
        this.flatFilePath = tableParamBuilder.flatFilePath;
        this.tableName = tableParamBuilder.tableName;
        this.nsClinicalTrlFileId = tableParamBuilder.nsClinicalTrlFileId;
        this.nsConversionSource = tableParamBuilder.nsConversionSource;
        this.nsConvertDate = tableParamBuilder.nsConvertDate;
        this.nsDataStandardVersion = tableParamBuilder.nsDataStandardVersion;
        this.nsSourceDset = tableParamBuilder.nsSourceDset;
        this.nsDcoeClinicalVersion = tableParamBuilder.nsDcoeClinicalVersion;
        this.nsRdipReleaseDate = tableParamBuilder.nsRdipReleaseDate;
        this.sourceColumnsList = tableParamBuilder.sourceColumnsList;
        this.rowCount = tableParamBuilder.rowCount;
        this.sourceTableDDLMap = tableParamBuilder.sourceTableDDLMap;
        this.seqColumn = tableParamBuilder.seqColumn;
        this.seqColumnDtype = tableParamBuilder.seqColumnDtype;
    }

    public String getTableName() {
        return tableName;
    }

    public int getRowCount() {
        return rowCount;
    }

    public String getTablenameWithoutDb() {
        return tablenameWithoutDb;
    }

    public String getStudyId() {
        return studyId;
    }

    public String getDatasetName() {
        return datasetName;
    }

    public Object getSpectreDataset() {
         return  spectreDataset;
    }

    public Object getNsRdipReleaseDate() {
        return nsRdipReleaseDate;
    }

    public Object getNsConversionSource() {
        return nsConversionSource;
    }

    public Object getNsDcoeClinicalVersion() {
        return nsDcoeClinicalVersion;
    }

    public Object getNsDataStandardVersion() {
        return nsDataStandardVersion;
    }

    public Object getNsConvertDate() {
        return nsConvertDate;
    }

    public Object getNsSourceDset() {
        return nsSourceDset;
    }

    public Object getNsClinicalTrlFileId() {
        return nsClinicalTrlFileId;
    }

    public String getHdfsFilePath() {
        return hdfsFilePath;
    }

    public String getFlatFilePath() {
        return flatFilePath;
    }

    public List<String> getSourceColumnsList() {
        return sourceColumnsList;
    }

    public Map<String, String> getSourceTableDDLMap() {
        return sourceTableDDLMap;
    }

    public String getSeqColumn() {
        return seqColumn;
    }

    public String getSeqColumnDtype() {
        return seqColumnDtype;
    }

    public List<Map<String, Object>> getTableMetadata() {
        return tableMetadata;
    }

    public static class TableParamBuilder {
        private final String tableName;
        private final List<Map<String, Object>> tableMetadata;
        private final DatasetParam datasetParam;
        private final ProcessParam processParam;
        private final STGroup templateGroup;
        private int rowCount;
        private String tablenameWithoutDb;
        private String studyId;
        private String datasetName;
        private Object spectreDataset;
        private Object nsRdipReleaseDate;
        private Object nsConversionSource;
        private Object nsDcoeClinicalVersion;
        private Object nsDataStandardVersion;
        private Object nsConvertDate;
        private Object nsSourceDset;
        private Object nsClinicalTrlFileId;
        private String hdfsFilePath;
        private String flatFilePath;
        private List<String> sourceColumnsList;
        private Map<String, String> sourceTableDDLMap;
        private String seqColumn;
        private String seqColumnDtype;

        public TableParamBuilder(String tableName,
                                 List<Map<String, Object>> tableMetadata,
                                 DatasetParam datasetParam,
                                 ProcessParam processParam,
                                 STGroup templateGroup) {

            this.tableName = tableName;
            this.tableMetadata = tableMetadata;
            this.datasetParam = datasetParam;
            this.processParam = processParam;
            this.templateGroup = templateGroup;
        }

        public TableParam build() {
            return new TableParam(this);
        }

        public TableParamBuilder setRowCount() {
            this.rowCount = Integer.parseInt(this.tableMetadata.get(0)
                    .get(Commons.ROW_COUNT)
                    .toString()
            );
            return this;
        }

        public TableParamBuilder setStudyid() {
            this.studyId = tableMetadata.get(0).get(Commons.STUDYID).toString().toLowerCase();
            return this;
        }

        public TableParamBuilder setDataset() {
            this.datasetName = tableMetadata.get(0).get(Commons.DATASET_NAME).toString().toLowerCase();
            return this;
        }

        public TableParamBuilder setSpectreDataset() {
            String s = tableMetadata.get(0).get(Commons.STUDYID).toString().toLowerCase();
            String d = tableMetadata.get(0).get(Commons.DATASET_NAME).toString().toLowerCase();
            this.spectreDataset = processParam.getSpectreMappingsMap().get(s, d);
            return this;
        }

        public TableParamBuilder setNsRdipReleaseDate() {
            this.nsRdipReleaseDate = processParam.getConfig().get(Commons.NS_RDIP_RELEASE_DATE);
            return this;
        }

        public TableParamBuilder setNsConversionSource() {
            this.nsConversionSource = processParam.getConfig().get(Commons.NS_CONVERSION_SOURCE);
            return this;
        }

        public TableParamBuilder setNsDcoeClinicalVersion() {
            this.nsDcoeClinicalVersion = processParam.getConfig().get(Commons.NS_DCOE_CLINICAL_VERSION);
            return this;
        }

        public TableParamBuilder setNsDataStandardVersion() {
            this.nsDataStandardVersion = processParam.getConfig().get(Commons.NS_DATA_STANDARD_VERSION);
            return this;
        }

        public TableParamBuilder setNsConvertDate() {
            this.nsConvertDate = processParam.getConfig().get(Commons.NS_CONVERT_DATE);
            return this;
        }

        public TableParamBuilder setNsSourceDset() {
            this.nsSourceDset = tableMetadata.get(0).get(Commons.DATASET_RENAME);
            return this;
        }

        public TableParamBuilder setNsClinicalTrlFileId() {
            this.nsClinicalTrlFileId = tableMetadata.get(0).get(Commons.CLINICAL_TRL_FILEID);
            return this;
        }

        public TableParamBuilder setHdfsFilePath() {
            String hdfsPathParent = processParam.getConfig().get("hdfs_path").toString();
            this.hdfsFilePath = templateGroup.getInstanceOf("get_hdfs_file_path")
                    .add("hdfs_path", hdfsPathParent)
                    .add("staging_tablename_without_db", datasetParam.getStagingTableNameWithoutDB())
                    .add("staging_table_db", datasetParam.getStagingTableDB())
                    .add("source_table_name_without_db", tablenameWithoutDb)
                    .render();
            return this;
        }

        public TableParamBuilder setTableNameWithoutDB() {
            this.tablenameWithoutDb = tableName.split("\\.")[1];
            return this;
        }

        public TableParamBuilder setFlatFilePath() {
            String csvDirectory = processParam.getConfig().get("csv_path").toString();
            this.flatFilePath = templateGroup.getInstanceOf("get_csv_file_path")
                    .add("csv_directory", csvDirectory)
                    .add("staging_tablename_without_db", datasetParam.getStagingTableNameWithoutDB())
                    .add("staging_table_db", datasetParam.getStagingTableDB())
                    .add("source_table_name_without_db", tablenameWithoutDb)
                    .render();
            return this;
        }

        public TableParamBuilder setSourceTableColumns() {
            this.sourceColumnsList = tableMetadata.stream()
                    .map(m -> m.get(Commons.VAR_NAME))
                    .map(String::valueOf).collect(Collectors.toList());
            return this;
        }

        public TableParamBuilder setSourceTableDDLMap() {
            this.sourceTableDDLMap = tableMetadata.stream()
                    .collect(Collectors.toMap(
                            m -> m.get(Commons.VAR_NAME).toString(),
                            m -> m.get(Commons.HIVE_DTYPE).toString().toLowerCase()
                    ));
            return this;
        }

        public TableParamBuilder checkAndSetSeqColumn() {
            String tmp = datasetParam.getMappedDatasetName() + "seq";
            this.seqColumn = null;
            this.seqColumnDtype = null;
            if (sourceColumnsList.contains(tmp)) {
                this.seqColumn = tmp;
                this.seqColumnDtype = tableMetadata.stream()
                        .filter(m -> m.get(Commons.VAR_NAME).toString().equalsIgnoreCase(tmp))
                        .map(m -> m.get(Commons.PROFILE_DTYPE).toString())
                        .collect(Collectors.toList()).get(0);
            }
            return this;
        }
    }
}
