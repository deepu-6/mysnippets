/*
 * Copyright 2021 GlaxoSmithKline LLC
 */

package com.gsk.rd.unification.builders;

import java.util.*;
import java.util.stream.Collectors;

public class DatasetParam {

    private final String mappedDatasetName;
    private final String datasetType;
    private final Map<String, String> unifiedDDLMap;
    private final List<Map<String, Object>> nsMetadata;
    private final String stagingTableName;
    private final String unifiedTableName;
    private final String prevUnifiedTableName;
    private final String stagingTableDB;
    private final String stagingTableNameWithoutDB;
    private final Map<String, Integer> nsRowIdStartingIndexMap;

    private DatasetParam(DatasetParamBuilder builder) {
        this.mappedDatasetName = builder.mappedDatasetName;
        this.datasetType = builder.datasetType;
        this.unifiedDDLMap = builder.unifiedDDLMap;
        this.nsMetadata = builder.nsMetadata;
        this.stagingTableName = builder.stagingTableName;
        this.unifiedTableName = builder.unifiedTableName;
        this.prevUnifiedTableName = builder.prevUnifiedTableName;
        this.nsRowIdStartingIndexMap = builder.nsRowIdStartingIndexMap;
        this.stagingTableDB = builder.stagingTableDB;
        this.stagingTableNameWithoutDB = builder.stagingTableNameWithoutDB;
    }

    public List<String> getUnifiedColumnsList(Map<String, String> unifiedDDLMap){
        if(unifiedDDLMap == null || unifiedDDLMap.isEmpty()){
            throw new IllegalStateException("unified DDL Map must not be null or empty");
        }
        return new ArrayList<>(unifiedDDLMap.keySet());
    }

    public String getDatasetType() {
        return datasetType;
    }

    public String getMappedDatasetName() {
        return mappedDatasetName;
    }

    public Map<String, String> getUnifiedDDLMap() {
        return unifiedDDLMap;
    }

    public List<Map<String, Object>> getNsMetadata() {
        return nsMetadata;
    }

    public String getStagingTableName() {
        return stagingTableName;
    }

    public String getStagingTableDB() {
        return stagingTableDB;
    }

    public String getStagingTableNameWithoutDB(){ return stagingTableNameWithoutDB;}

    public String getUnifiedTableName() {
        return unifiedTableName;
    }

    public String getPrevUnifiedTableName() {
        return prevUnifiedTableName;
    }

    public int getNsRowIdStartingIndexMap(String tableName) {
        if(nsRowIdStartingIndexMap.get(tableName) == null){
            throw new NullPointerException("Table not found in nsRowIdIndexMap: " + tableName);
        }
        return nsRowIdStartingIndexMap.get(tableName);

    }

    public static class DatasetParamBuilder {
        private final String mappedDatasetName;
        private final String datasetType;
        private final List<Map<String, Object>> mappedDatasetMetadata;
        private final ProcessParam processParam;
        private HashMap<String, String> unifiedDDLMap;
        private List<Map<String, Object>> nsMetadata = new ArrayList<>();
        private String stagingTableName;
        private String unifiedTableName;
        private String prevUnifiedTableName;
        private Map<String, Integer> nsRowIdStartingIndexMap;
        private String stagingTableDB;
        private String stagingTableNameWithoutDB;

        public DatasetParam build() {
            return new DatasetParam(this);
        }

        public DatasetParamBuilder(String mappedDatasetName,
                                   String datasetType, List<Map<String, Object>> mappedDatasetMetadata,
                                   ProcessParam processParam) {

            this.mappedDatasetName = mappedDatasetName;
            this.datasetType = datasetType;
            this.mappedDatasetMetadata = mappedDatasetMetadata;
            this.processParam = processParam;
        }

        public DatasetParamBuilder setNSMetadata() {
            if (datasetType.equalsIgnoreCase("SDTM")) {
                if (mappedDatasetName.toLowerCase().startsWith("supp") ||
                        mappedDatasetName.toLowerCase().startsWith("sc_supp")) {
                    this.nsMetadata = processParam.getNSMetadata(processParam.getSdtmConfigByDsetOrig("supp"));
                }
                else {
                    this.nsMetadata = processParam.getNSMetadata(processParam.getSdtmConfigByDsetOrig(mappedDatasetName));
                }
            }
            else {
                this.nsMetadata = processParam.getNSMetadata(processParam.getSiArConfigByDsetOrig(mappedDatasetName));
            }
            if (this.nsMetadata.isEmpty()) {
                throw new IllegalStateException("No NS Metadata or conditions failed for " + mappedDatasetName);
            }
            return this;
        }

        public DatasetParamBuilder addUnifiedDDLMap() {
            if (this.nsMetadata != null && !this.nsMetadata.isEmpty()) {
                List<Map<String, Object>> tempList = new ArrayList<>(mappedDatasetMetadata);
                tempList.addAll(nsMetadata);
                this.unifiedDDLMap = tempList.stream()
                        .sorted(Comparator.comparing(map -> Integer.parseInt(map.get("var_order").toString())))
                        .collect(Collectors.toMap(
                                map -> map.get("var_name").toString().toLowerCase(),
                                map -> map.get("var_dtype").toString().toLowerCase(),
                                (v, v1) -> v1,
                                LinkedHashMap::new));
            }
            else {
                setNSMetadata();
                addUnifiedDDLMap();
            }
            return this;
        }

        public DatasetParamBuilder addStagingTableName(String stagingTableName) {
            if(stagingTableName == null || stagingTableName.equals("")){
                throw new NullPointerException("staging tablename must not be null or empty");
            }
            this.stagingTableName = stagingTableName;
            String[] stagingTableNameArray = stagingTableName.split("\\.");
            this.stagingTableDB = stagingTableNameArray[0];
            this.stagingTableNameWithoutDB = stagingTableNameArray[1];
            return this;
        }

        public DatasetParamBuilder addUnifiedTableName(String unifiedTableName) {
            if(unifiedTableName == null || unifiedTableName.equals("")){
                throw new NullPointerException("unified tablename must not be null or empty");
            }
            this.unifiedTableName = unifiedTableName;
            return this;
        }

        public DatasetParamBuilder addPrevUnifiedTableName(String prevUnifiedTableName) {
            if(prevUnifiedTableName == null || prevUnifiedTableName.equals("")){
                throw new NullPointerException("previous unified tablename must not be null or empty");
            }
            this.prevUnifiedTableName = prevUnifiedTableName;
            return this;
        }

        public DatasetParamBuilder addNsRowIdIndexMap(Map<String, Integer> nsRowIdStartingIndexMap) {
            if(nsRowIdStartingIndexMap == null){
                throw new NullPointerException("nsRowIdStartingIndexMap must not be null");
            }
            if(nsRowIdStartingIndexMap.isEmpty()){
                throw new IllegalStateException("nsRowIdStartingIndexMap must not be empty");
            }
            this.nsRowIdStartingIndexMap = nsRowIdStartingIndexMap;
            return this;
        }
    }
}
