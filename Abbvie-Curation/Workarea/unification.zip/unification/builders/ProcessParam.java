/*
 * Copyright 2021 GlaxoSmithKline LLC
 */

package com.gsk.rd.unification.builders;

import com.gsk.rd.utils.Commons;
import com.gsk.rd.utils.Helper;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.commons.collections.map.MultiKeyMap;
import org.stringtemplate.v4.STGroup;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ProcessParam {

    private final String batchId;
    private final STGroup templateGroup;
    private final MultiKeyMap mappedDatasetMap;
    private final MultiKeyMap spectreMappingsMap;
    private final HashMap<String, Object> config;
    private final HikariDataSource hiveDataSource;
    private final HashMap<String, Object> hdfsConfig;
    private final HikariDataSource postgresDataSource;
    private final List<HashMap<String, Object>> tablesMetadata;
    private final Map<String, List<Map<String, Object>>> sdtmConfigByDsetOrig;
    private final Map<String, List<Map<String, Object>>> siArConfigByDsetOrig;
    private final HashMap<String, HashMap<String, List<String>>> sdtmConfigByDataset;
    private final HashMap<String, HashMap<String, List<String>>> siArConfigByDataset;

    private ProcessParam(ProcessParamBuilder builder) {
        this.batchId = builder.batchId;
        this.config = builder.config;
        this.hdfsConfig = builder.hdfsConfig;
        this.hiveDataSource = builder.hiveDataSource;
        this.mappedDatasetMap = builder.mappedDatasetMap;
        this.postgresDataSource = builder.postgresDataSource;
        this.sdtmConfigByDataset = builder.sdtmConfigByDataset;
        this.sdtmConfigByDsetOrig = builder.sdtmConfigByDsetOrig;
        this.siArConfigByDataset = builder.siArConfigByDataset;
        this.siArConfigByDsetOrig = builder.siArConfigByDsetOrig;
        this.spectreMappingsMap = builder.spectreMappingsMap;
        this.tablesMetadata = builder.tablesMetadata;
        this.templateGroup = builder.templateGroup;
    }

    public List<HashMap<String, Object>> getTablesMetadata() {
        return tablesMetadata;
    }

    public HashMap<String, Object> getConfig() {
        return config;
    }

    public HashMap<String, Object> getHdfsConfig() {
        return hdfsConfig;
    }

    public HikariDataSource getHiveDataSource() {
        return hiveDataSource;
    }

    public HikariDataSource getPostgresDataSource() {
        return postgresDataSource;
    }

    public MultiKeyMap getSpectreMappingsMap() {
        return spectreMappingsMap;
    }

    public MultiKeyMap getMappedDatasetMap() {
        return mappedDatasetMap;
    }

    public Map<String, List<Map<String, Object>>> getSdtmConfigByDsetOrig() {
        return sdtmConfigByDsetOrig;
    }

    public HashMap<String, HashMap<String, List<String>>> getSdtmConfigByDataset() {
        return sdtmConfigByDataset;
    }

    public Map<String, List<Map<String, Object>>> getSiArConfigByDsetOrig() {
        return siArConfigByDsetOrig;
    }

    public HashMap<String, HashMap<String, List<String>>> getSiArConfigByDataset() {
        return siArConfigByDataset;
    }

    public List<Map<String, Object>> getSdtmConfigByDsetOrig(String datasetName) {
        return sdtmConfigByDsetOrig.get(datasetName);
    }

    public List<Map<String, Object>> getSiArConfigByDsetOrig(String datasetName) {
        return siArConfigByDsetOrig.get(datasetName);
    }

    public HashMap<String, List<String>> getSdtmConfigByDataset(String mappedDatasetName) {
        return sdtmConfigByDataset.get(mappedDatasetName);
    }

    public HashMap<String, List<String>> getSiArConfigByDataset(String mappedDatasetName) {
        return siArConfigByDataset.get(mappedDatasetName);
    }

    public int getThreadCount() {
        return Integer.parseInt(config.getOrDefault(Commons.THREAD_COUNT, "1").toString());
    }

    public STGroup getTemplateGroup() {
        return templateGroup;
    }

    public String getBatchId() {
        return batchId;
    }

    /**
     * Filters the configuration for NS metadata
     *
     * @param configuration si ar / sdtm configuration
     * @return returns the configuration defined for non standard metadata
     */
    public List<Map<String, Object>> getNSMetadata(List<Map<String, Object>> configuration) {
        List<Map<String, Object>> nsMetadataConfiguration;
        nsMetadataConfiguration = configuration.stream()
                .filter(map -> map.get(Commons.NS_CONFIG_VAR_TYPE) != null)
                .filter(map -> map.get(Commons.NS_CONFIG_VAR_TYPE).toString()
                        .equalsIgnoreCase("NS Metadata"))
                .collect(Collectors.toList());
        return nsMetadataConfiguration;
    }

    public static class ProcessParamBuilder {

        private String batchId;
        private STGroup templateGroup;
        private MultiKeyMap mappedDatasetMap;
        private MultiKeyMap spectreMappingsMap;
        private HashMap<String, Object> hdfsConfig;
        private final HashMap<String, Object> config;
        private final HikariDataSource hiveDataSource;
        private final HikariDataSource postgresDataSource;
        private final List<HashMap<String, Object>> tablesMetadata;
        private Map<String, List<Map<String, Object>>> sdtmConfigByDsetOrig;
        private Map<String, List<Map<String, Object>>> siArConfigByDsetOrig;
        private HashMap<String, HashMap<String, List<String>>> sdtmConfigByDataset;
        private HashMap<String, HashMap<String, List<String>>> siArConfigByDataset;


        public ProcessParamBuilder(HashMap<String, Object> config,
                                   List<HashMap<String, Object>> tablesMetadata,
                                   HikariDataSource hiveDataSource,
                                   HikariDataSource postgresDataSource) {
            this.config = config;
            this.hiveDataSource = hiveDataSource;
            this.postgresDataSource = postgresDataSource;
            this.tablesMetadata = tablesMetadata;
        }

        public ProcessParam build() {
            return new ProcessParam(this);
        }

        public ProcessParamBuilder addSpectreMappings(MultiKeyMap spectreMappingsMap) {
            if(spectreMappingsMap.isEmpty()){
                throw new IllegalArgumentException("spectre mappings map must not be empty");
            }
            this.spectreMappingsMap = spectreMappingsMap;
            return this;
        }

        public ProcessParamBuilder addTemplateGroup(STGroup templateGroup) {
            if(templateGroup == null){
                throw new NullPointerException("template group must not be empty");
            }
            this.templateGroup = templateGroup;
            return this;
        }


        public ProcessParamBuilder addMappedDatasetMappings(MultiKeyMap mappedDatasetMap) {
            if(mappedDatasetMap.isEmpty()){
                throw new IllegalArgumentException("mapped datasets map must not be empty");
            }
            this.mappedDatasetMap = mappedDatasetMap;
            return this;
        }

        public ProcessParamBuilder addSdtmConfiguration(Map<String, List<Map<String, Object>>> sdtmConfigByDsetOrig) {
            if(sdtmConfigByDsetOrig.isEmpty()){
                throw new IllegalArgumentException("SI/AR config must not be empty");
            }
            this.sdtmConfigByDsetOrig = sdtmConfigByDsetOrig;
            return this;
        }

        public ProcessParamBuilder addSiArConfiguration(Map<String, List<Map<String, Object>>> siArConfigByDsetOrig) {
            if(siArConfigByDsetOrig.isEmpty()){
                throw new IllegalArgumentException("SI/AR config must not be empty");
            }
            this.siArConfigByDsetOrig = siArConfigByDsetOrig;
            return this;
        }

        public ProcessParamBuilder addSdtmConfigByDataset(HashMap<String, HashMap<String, List<String>>> sdtmConfigByDataset) {
            this.sdtmConfigByDataset = sdtmConfigByDataset;
            return this;
        }

        public ProcessParamBuilder addSiArConfigByDataset(HashMap<String, HashMap<String, List<String>>> siArConfigByDataset) {
            this.siArConfigByDataset = siArConfigByDataset;
            return this;
        }

        public ProcessParamBuilder addHDFSConfig() {
            Helper helper = Helper.getInstance();
            if(!config.containsKey(Commons.HDFS_CONFIG)){
                throw new NullPointerException(Commons.HDFS_CONFIG + " key must be present in input configuration");
            }
            this.hdfsConfig = helper.readConfig(Commons.HDFS_CONFIG, config);
            return this;
        }

        public ProcessParamBuilder addBatchId() {
            if (!tablesMetadata.get(0).containsKey("batch_id")) {
                throw new NullPointerException("column batch_id must be present in table metadata");
            }
            this.batchId = this.tablesMetadata.get(0).get("batch_id").toString();
            return this;
        }
    }

}
