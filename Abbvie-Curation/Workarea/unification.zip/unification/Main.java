/*
 * Copyright 2021 GlaxoSmithKline LLC
 */

package com.gsk.rd.unification;

import com.gsk.rd.utils.Helper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.HashMap;

public class Main {
    private static final Logger LOGGER = LogManager.getLogger(Main.class.getSimpleName());

    public static void main(String[] args) {
        String configFilePath = null;
        if (args.length == 1) {
            configFilePath = args[0];
        }
        else {
            LOGGER.fatal("INVALID INPUTS");
            System.exit(0);
        }
        Helper helper = Helper.getInstance();
        HashMap<String, Object> processConfig = helper.readJsonToHashMap(configFilePath);
        App app = new App(processConfig);
        try {
            app.init();
            app.process();
        }
        catch (Exception e) {
            LOGGER.error("", e);
        }
        finally {
            app.close();
        }
    }
}
