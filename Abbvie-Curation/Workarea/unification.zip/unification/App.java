/*
 * Copyright 2021 GlaxoSmithKline LLC
 */

package com.gsk.rd.unification;

import com.gsk.rd.unification.builders.ProcessParam;
import com.gsk.rd.unification.prevalidation.PreValidation;
import com.gsk.rd.unification.unify.Unification;
import com.gsk.rd.utils.Commons;
import com.gsk.rd.utils.Helper;
import com.modak.hive.HiveKerberosConnectionManager;
import com.modak.utils.JDBCConnectionManager;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.commons.collections.map.MultiKeyMap;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.stringtemplate.v4.STGroup;
import org.stringtemplate.v4.STGroupFile;

import java.io.File;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Unification App that converts the raw datasets into unified datasets supporting incremental load process.
 */
public class App {
    private static final Logger LOGGER = LogManager.getLogger(App.class.getSimpleName());
    private final Helper helper = Helper.getInstance();
    private final HashMap<String, Object> processConfig;
    private JDBCConnectionManager postgresConnectionManager;
    private HikariDataSource postgresDataSource;
    private HiveKerberosConnectionManager hiveKerberosConnectionManager;
    private HikariDataSource hiveDataSource;
    private STGroup templateGroup;

    public App(HashMap<String, Object> processConfig) {
        this.processConfig = processConfig;
    }

    /**
     * creates Postgres, Hive connection pool
     *
     * @throws Exception connection pool fails
     */
    public void init() throws Exception {
        File postgresFile = new File(processConfig.get(Commons.POSTGRES_CONFIG).toString());
        File hiveFile = new File(processConfig.get(Commons.HIVE_CONFIG).toString());
        postgresConnectionManager = new JDBCConnectionManager();
        postgresConnectionManager.configureHikariDataSource(postgresFile);
        postgresDataSource = postgresConnectionManager.getHikariDataSource();
        LOGGER.debug("POSTGRES DB POOL CONFIGURED");
        hiveKerberosConnectionManager = new HiveKerberosConnectionManager();
        hiveKerberosConnectionManager.configureHikariDataSource(hiveFile);
        hiveDataSource = hiveKerberosConnectionManager.getHikariDataSource();
        LOGGER.debug("HIVE DB POOL CONFIGURED");
        String templateFile = processConfig.get(Commons.TEMPLATE_FILE).toString();
        LOGGER.debug("Initializing template: {}", templateFile);
        templateGroup = new STGroupFile(templateFile, '$', '$');
    }

    /**
     * main method for unification process
     */
    public void process() {
        boolean started = helper.updateJobTracker(Commons.STARTED, templateGroup, postgresDataSource);
        LOGGER.debug("job tracker updated with status started: {}", started);
        List<HashMap<String, Object>> tablesMetadata = readTablesMetadata();
        long totalTablesCount = tablesMetadata.stream()
                .map(m -> m.get("clinical_trl_fileid"))
                .distinct()
                .count();
        LOGGER.info("Total tables: {}", totalTablesCount);
        if (!tablesMetadata.isEmpty()) {
            ProcessParam processParam = prepareParams(tablesMetadata);
            PreValidation preValidation = new PreValidation(processParam);
            List<Map<String, Object>> preValidationOutput = preValidation.run();
            String runOnlyPrevalidation = processConfig.get("run_only_prevalidation").toString();
            if (runOnlyPrevalidation.equalsIgnoreCase("N")) {
                if (!preValidationOutput.isEmpty()) {
                    LOGGER.info("unify process started");
                    Unification unification = new Unification(preValidationOutput, processParam);
                    unification.run();
                }
                else {
                    LOGGER.info("no output from prevalidation");
                }
            }
        }
        boolean completed = helper.updateJobTracker(Commons.COMPLETED, templateGroup, postgresDataSource);
        LOGGER.debug("job tracker updated with status: {}", completed);
    }

    /**
     * reads table and column metadata for the input tables list
     *
     * @return returns table metadata combined with column metadata query result for the given input tables
     */
    public List<HashMap<String, Object>> readTablesMetadata() {
        String metadataQuery;
        List<HashMap<String, Object>> metadata = new ArrayList<>();
        try (Stream<String> fileStream = Files.lines(Paths.get(processConfig.get(Commons.INPUT_FILE).toString()))) {
            List<String> tablesList = fileStream.map(String::valueOf)
                    .filter(s -> !s.isEmpty())
                    .map(String::trim)
                    .collect(Collectors.toList());
            metadataQuery = templateGroup.getInstanceOf("get_metadata")
                    .add("tables_list", tablesList)
                    .add(Commons.BATCH_ID, processConfig.get(Commons.BATCH_ID))
                    .render();
            LOGGER.debug("Input query: \n {}", metadataQuery);
            metadata = helper.executeQuery(postgresDataSource, metadataQuery);
        }
        catch (NullPointerException e) {
            LOGGER.error("", e);
            helper.jobException(e, templateGroup, postgresDataSource);
        }
        catch (Exception e) {
            LOGGER.error("failed reading table metadata", e);
            helper.jobException(e, templateGroup, postgresDataSource);
        }
        return metadata;
    }

    /**
     * creates a ProcessParam object with data that can be used through out the unification
     *
     * @param tablesMetadata postgres metadata read for tables to be unified
     * @return ProcessParam object
     */
    private ProcessParam prepareParams(List<HashMap<String, Object>> tablesMetadata) {
        ProcessParam processParam = null;
        try {
            String mappingsQuery = templateGroup.getInstanceOf("get_mappings")
                    .render();
            LOGGER.debug(Commons.LOG_SEPARATOR);
            LOGGER.debug("mappings query: \n{}", mappingsQuery);
            MultiKeyMap mappedDatasetMap = new MultiKeyMap();
            List<HashMap<String, Object>> mappedDatasetsResult = helper.executeQuery(hiveDataSource, mappingsQuery);
            LOGGER.info("lookup: Key[dataset_name,studyid,dataset_type] = Value[mapped_dataset]");
            for (Map<String, Object> map : mappedDatasetsResult) {
                String datasetName = map.get(Commons.DATASET_NAME).toString();
                String studyId = map.get("studyid").toString();
                String datasetType = map.get("dataset_type").toString();
                String mappedDataset = map.get("mapped_dataset").toString();
                mappedDatasetMap.put(datasetName, datasetType, studyId, mappedDataset);
            }

            LOGGER.debug(Commons.LOG_SEPARATOR);
            MultiKeyMap spectreMappingsMap = new MultiKeyMap();
            String spectreMappingsQuery = templateGroup.getInstanceOf("get_spectre_mappings")
                    .render();
            LOGGER.debug("spectre mappings query: \n{}", spectreMappingsQuery);
            List<HashMap<String, Object>> spectreMappings = helper.executeQuery(hiveDataSource, spectreMappingsQuery);
            LOGGER.info("creating spectre mappings lookup");
            for (Map<String, Object> map : spectreMappings) {
                String datasetName = map.get(Commons.DATASET_NAME).toString().toLowerCase();
                String studyId = map.get("studyid").toString().toLowerCase();
                String spectreDatasetName = map.get("spectre_dataset_name").toString();
                spectreMappingsMap.put(studyId, datasetName, spectreDatasetName);
            }

            LOGGER.debug(Commons.LOG_SEPARATOR);
            String configSiArQuery = templateGroup.getInstanceOf("get_si_ar_configuration")
                    .render();
            LOGGER.debug("si ar configuration query: \n{}", configSiArQuery);
            List<HashMap<String, Object>> configurationSiArResult = helper.executeQuery(hiveDataSource, configSiArQuery);
            LOGGER.info("converting si/ar config table result as lookup");
            Map<String, List<Map<String, Object>>> siArConfigByDsetOrig = configurationSiArResult.stream()
                    .collect(Collectors.groupingBy(m -> m.get("dataset_name").toString().toLowerCase()));
            HashMap<String, HashMap<String, List<String>>> siArConfigByDataset = convertConfigToMap(siArConfigByDsetOrig);
            LOGGER.debug(Commons.LOG_SEPARATOR);

            String configurationSdtmQuery = templateGroup.getInstanceOf("get_sdtm_configuration")
                    .render();
            LOGGER.debug("sdtm configuration query: \n{}", configurationSdtmQuery);
            List<HashMap<String, Object>> configurationSdtmResult = helper.executeQuery(hiveDataSource, configurationSdtmQuery);
            LOGGER.info("converting sdtm config table result as lookup");
            Map<String, List<Map<String, Object>>> sdtmConfigByDsetOrig = configurationSdtmResult.stream()
                    .collect(Collectors.groupingBy(m -> m.get("dataset_name").toString().toLowerCase()));
            HashMap<String, HashMap<String, List<String>>> sdtmConfigByDataset = convertConfigToMap(sdtmConfigByDsetOrig);
            LOGGER.debug(Commons.LOG_SEPARATOR);

            processParam = new ProcessParam.ProcessParamBuilder(processConfig,
                    tablesMetadata,
                    hiveDataSource,
                    postgresDataSource)
                    .addTemplateGroup(templateGroup)
                    .addHDFSConfig()
                    .addBatchId()
                    .addSpectreMappings(spectreMappingsMap)
                    .addMappedDatasetMappings(mappedDatasetMap)
                    .addSdtmConfiguration(sdtmConfigByDsetOrig)
                    .addSiArConfiguration(siArConfigByDsetOrig)
                    .addSdtmConfigByDataset(sdtmConfigByDataset)
                    .addSiArConfigByDataset(siArConfigByDataset)
                    .build();
            LOGGER.info("process params build success");
        }
        catch (Exception e) {
            LOGGER.error("Error preparing params", e);
            System.exit(1);
        }
        return processParam;
    }

    /**
     * reads and groups the configuration resultant by dataset/domain
     *
     * @param configurationByDatasetName si ar/ sdtm configuration
     * @return A map with dataset/domain name as key and its configuration as value
     */
    public HashMap<String, HashMap<String, List<String>>> convertConfigToMap(
            Map<String, List<Map<String, Object>>> configurationByDatasetName) {

        LOGGER.debug("lookup: Key[dataset_name] = Value[Key[var_name] = Value[List[var_dtype,var_order]]]");
        HashMap<String, HashMap<String, List<String>>> configMap = new HashMap<>();
        for (Map.Entry<String, List<Map<String, Object>>> entry : configurationByDatasetName.entrySet()) {
            String datasetName = entry.getKey();
            try {
                List<Map<String, Object>> datasetConfiguration = configurationByDatasetName.get(datasetName);
                HashMap<String, List<String>> varTypeMap = new HashMap<>();
                for (Map<String, Object> map : datasetConfiguration) {
                    String variableName = map.get("var_name").toString();
                    String variableType = map.get("var_dtype").toString();
                    String varOrder = map.get("var_order").toString();
                    varTypeMap.put(variableName, Arrays.asList(variableType, varOrder));
                }
                configMap.put(datasetName, varTypeMap);
            }
            catch (Exception e) {
                String exceptionMessage = "Failed converting to config map for " + datasetName;
                Exception e1 = new Exception(e.getMessage() + " - " + exceptionMessage);
                e1.setStackTrace(e.getStackTrace());
                LOGGER.error(exceptionMessage, e1);
                StringWriter tmp = new StringWriter();
                String exception = tmp.toString();
                helper.jobException(exception, templateGroup, postgresDataSource);
            }
        }
        return configMap;
    }

    /**
     * close postgres, hive connection pool
     */
    public void close() {
        try {
            if (hiveDataSource != null && !(hiveDataSource.isClosed())) {
                hiveDataSource.close();
                hiveKerberosConnectionManager.shutdownHikariDatasource();
                LOGGER.debug("hive db pool closed");
            }
        }
        catch (Exception e) {
            LOGGER.error("", e);
        }
        try {
            if (postgresDataSource != null && !(postgresDataSource.isClosed())) {
                postgresDataSource.close();
                postgresConnectionManager.shutdownHikariDatasource();
                LOGGER.debug("postgres db pool closed");
            }
        }
        catch (Exception e) {
            LOGGER.error("", e);
        }
    }

}
