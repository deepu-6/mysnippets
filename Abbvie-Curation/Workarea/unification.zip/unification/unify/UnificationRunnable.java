/*
 * Copyright 2021 GlaxoSmithKline LLC
 */

package com.gsk.rd.unification.unify;

import com.gsk.rd.unification.builders.DatasetParam;
import com.gsk.rd.unification.builders.ProcessParam;
import com.gsk.rd.unification.builders.TableParam;
import com.gsk.rd.utils.Commons;
import com.gsk.rd.utils.Helper;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.stringtemplate.v4.STGroup;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.management.ManagementFactory;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class UnificationRunnable implements Runnable {
    private static final Logger LOGGER = LogManager.getLogger(UnificationRunnable.class.getSimpleName());
    private final DatasetParam datasetParam;
    private final ProcessParam processParam;
    private final Helper helper = Helper.getInstance();
    private final STGroup templateGroup;
    private final String sourceTableName;
    private final HikariDataSource postgresDataSource;
    private final TableParam tableParam;

    public UnificationRunnable(TableParam tableParam,
                               DatasetParam datasetParam, ProcessParam processParam) {
        this.tableParam = tableParam;
        this.datasetParam = datasetParam;
        this.processParam = processParam;
        this.sourceTableName = tableParam.getTableName();
        this.templateGroup = processParam.getTemplateGroup();
        this.postgresDataSource = processParam.getPostgresDataSource();
    }

    @Override
    public void run() {
        boolean copied = false;
        int rowCount = tableParam.getRowCount();
        LOGGER.debug("processing {}", sourceTableName);
        try {
            if (rowCount != 0) {
                appendNsMetadata(datasetParam, tableParam);
                String tableName = sourceTableName;
                String flatFilePath = tableParam.getFlatFilePath();
                String hdfsFilePath = tableParam.getHdfsFilePath();
                String selectQuery = processParam.getTemplateGroup()
                        .getInstanceOf("select_query")
                        .add(Commons.TABLE_NAME, tableName)
                        .add("source_columns", tableParam.getSourceColumnsList())
                        .add("column_dtype_map", tableParam.getSourceTableDDLMap())
                        .render();
                boolean created = helper.cleanUp(tableParam.getFlatFilePath());
                if (created) {
                    boolean written = writeData(selectQuery);
                    LOGGER.debug("flat file created {}", sourceTableName);
                    if (written) {
                        copied = copyFileToHdfs(flatFilePath, hdfsFilePath, tableName);
                        LOGGER.debug("flat file copied to hdfs: {}", copied);
                        if (!copied) {
                            // tableName,csvFileName,outputDB,csvFilePath
                            String hdfsCommand = templateGroup.getInstanceOf("copy_file_to_hdfs")
                                    .add("csv_filepath", flatFilePath)
                                    .add("hdfs_filepath", hdfsFilePath)
                                    .render();
                            LOGGER.error("try copying file using: {}", hdfsCommand);
                        }
                        else {
                            boolean delete = Files.deleteIfExists(Paths.get(flatFilePath));
                            LOGGER.info("flat file is deleted as cleanup: {}", delete);
                        }
                    }
                }

            }
        }
        catch (Exception e) {
            LOGGER.error("", e);
            Exception e1 = new Exception(e.getMessage() + " - " + sourceTableName);
            e1.setStackTrace(e.getStackTrace());
            StringWriter tmp = new StringWriter();
            e1.printStackTrace(new PrintWriter(tmp));
            String exception = tmp.toString();
            helper.jobException(exception, templateGroup, postgresDataSource);
        }
        insertTableOutput(copied, rowCount);
    }

    /**
     * inserts the source datasets unified status into postgres unified status tracker table
     *
     * @param unifiedStatus status true/false based on source dataset is unified
     * @param rowCount      row count of the source dataset
     */
    private void insertTableOutput(boolean unifiedStatus, int rowCount) {
        try {
            String vmName = ManagementFactory.getRuntimeMXBean().getName();
            int p = vmName.indexOf("@");
            String pid = vmName.substring(0, p);
            String outputQuery = templateGroup.getInstanceOf("source_table_output")
                    .add(Commons.PID, pid)
                    .add("source_table_name", sourceTableName)
                    .add("mapped_dataset_name", datasetParam.getMappedDatasetName())
                    .add(Commons.TARGET_TABLE_NAME, datasetParam.getUnifiedTableName())
                    .add("unified_status", String.valueOf(unifiedStatus))
                    .add("row_count", rowCount)
                    .add("column_count", tableParam.getSourceColumnsList().size())
                    .render();
            helper.executeUpdateQuery(postgresDataSource, outputQuery);
        }
        catch (Exception e) {
            LOGGER.error("", e);
            helper.jobException(e, templateGroup, postgresDataSource);
        }
    }

    /**
     * copies the unified flat file created for source table into unified staging table folder in Hadoop
     *
     * @param flatFilePath local file path for source dataset flat file
     * @param hdfsFilePath hdfs file path for source dataset flat file
     * @param tableName    source dataset table name
     * @return returns boolean true if file is copied to HDFS else false
     */
    public boolean copyFileToHdfs(String flatFilePath, String hdfsFilePath, String tableName) {
        Path destHdfsFilePath = new Path(hdfsFilePath);
        Path srcCsvFilePath = new Path(flatFilePath);
        int retryCounter = 1;
        int retryLimit = 3;
        boolean copied = false;
        while (!copied) {
            FileSystem fileSystem = null;
            try {
                fileSystem = helper.getHadoopFileSystem(processParam.getHdfsConfig());
                fileSystem.copyFromLocalFile(false, true, srcCsvFilePath, destHdfsFilePath);
                copied = true;
                LOGGER.info("copied file to hdfs: {}", tableName);
            }
            catch (Exception e) {
                LOGGER.error("Attempt {}", retryCounter, e);
            }
            finally {
                if (fileSystem != null) {
                    try {
                        fileSystem.close();
                    }
                    catch (IOException e) {
                        LOGGER.error("", e);
                    }
                }
            }
            if (++retryCounter > retryLimit) {
                LOGGER.error("Failed copying CSV file: {}", tableName);
                break;
            }
        }
        return copied;
    }

    /**
     * Main method where source dataset data is written to a file. Retries for 3 times if failed.
     *
     * @param selectQuery source dataset select query
     * @return returns boolean true/false based on source dataset data is written to a file
     * @throws SQLException         throws SQLException when query execution fails
     * @throws NullPointerException throws NullPointerException when Datasource/connection/query is null
     */
    private boolean writeData(String selectQuery) throws SQLException, NullPointerException {
        HikariDataSource hiveDataSource = processParam.getHiveDataSource();
        String flatFilePath = tableParam.getFlatFilePath();
        String tableName = sourceTableName;
        boolean flatFileCreated = false;
        helper.nullDataSourceCheck(hiveDataSource);
        Connection conn = hiveDataSource.getConnection();
        helper.nullConnAndSqlCheck(conn, selectQuery);
        int retryCounter = 1;
        int retryLimit = 3;
        while (!flatFileCreated) {
            if (retryCounter > 1) {
                LOGGER.info("Retrying to select and create flat file again {}", retryCounter);
            }
            flatFileCreated = writeData(selectQuery, conn, tableName, flatFilePath);
            if (++retryCounter > retryLimit) {
                LOGGER.error("Failed creating flat file: {}", tableName);
                break;
            }
        }
        return flatFileCreated;
    }

    /**
     * source dataset Hive tables is read and writes to a file
     *
     * @param selectQuery     source dataset select query
     * @param conn            Hive connection object
     * @param sourceTableName source dataset Hive tablename
     * @param flatFilePath    file path
     * @return returns boolean true/false based on source dataset data is written to a file
     */
    private boolean writeData(String selectQuery, Connection conn, String sourceTableName, String flatFilePath) {
        boolean flatFileCreated = false;
        ResultSet rs = null;
        Statement stmt = null;
        FileWriter fileWriter = null;
        try {
            (new FileWriter(flatFilePath)).close();
            fileWriter = new FileWriter(flatFilePath, true);
            stmt = conn.createStatement();
            rs = stmt.executeQuery(selectQuery);
            int rowId = 0;
            if (rs != null) {
                int columnCount = rs.getMetaData().getColumnCount();
                int counter = 0;
                while (true) {
                    if (!rs.next()) {
                        helper.close(rs);
                        helper.close(stmt);
                        helper.close(conn);
                        break;
                    }
                    HashMap<String, Object> row = new HashMap<>();
                    for (int i = 0; i < columnCount; ++i) {
                        row.put(rs.getMetaData().getColumnLabel(i + 1).toLowerCase(), rs.getObject(i + 1));
                    }
                    if (++counter == 10000000) {
                        LOGGER.debug(" {}: read ten million rows", sourceTableName);
                        counter = 0;
                    }
                    appendRowToFile(row, rowId, fileWriter);
                    rowId++;
                }
                flatFileCreated = true;
            }
        }
        catch (Exception e) {
            LOGGER.error("", e);
        }
        finally {
            helper.close(rs);
            helper.close(stmt);
            helper.close(conn);
            helper.close(fileWriter);
        }
        return flatFileCreated;
    }

    /**
     * appends the given row to the file
     *
     * @param row row in a source dataset Hive table
     * @param rowId rowId of the row
     * @param fileWriter fileWriter object of the file
     * @throws IOException throws IOException if unable to write to file
     */
    private void appendRowToFile(HashMap<String, Object> row, int rowId, FileWriter fileWriter) throws IOException {
        List<String> unifiedColumns = datasetParam.getUnifiedColumnsList(datasetParam.getUnifiedDDLMap());
        int columnCount = unifiedColumns.size();
        StringBuilder builder = new StringBuilder();
        for (int idx = 0; idx < columnCount; idx++) {
            String column = unifiedColumns.get(idx);
            switch (column) {
                case Commons.NS_CLINICAL_TRL_FILEID:
                    addClinicalTrlFileid(builder);
                    break;
                case Commons.NS_SOURCE_DSET_ROW_ID:
                    addNsSourceDsetRowId(builder, row, rowId);
                    break;
                case Commons.NS_SOURCE_DSET_SEQ:
                    addNsSourceDsetSeq(builder, row);
                    break;
                case Commons.NS_ROW_ID:
                    addNsRowId(builder, row, rowId);
                    break;
                case Commons.NS_TAMR_PK:
                    addNsTamrPk(builder, row, rowId);
                    break;
                case Commons.NS_SOURCE_DSET:
                    addNsSourceDset(builder);
                    break;
                case Commons.NS_SOURCE_DSET_STUDYID:
                    addNsSourceDsetStudyid(builder);
                    break;
                case Commons.NS_SOURCE_SPECTRE_DSET:
                    addNsSourceSpectreDset(builder);
                    break;
                case Commons.NS_SOURCE_DSET_COLUMNS:
                    addNsSourceDsetColumns(builder);
                    break;
                case Commons.NS_CONVERT_DATE:
                    addNsConvertDate(builder);
                    break;
                case Commons.NS_DATA_STANDARD_VERSION:
                    addNsDataStandardVersion(builder);
                    break;
                case Commons.NS_DCOE_CLINICAL_VERSION:
                    addNsDcoeClinicalVersion(builder);
                    break;
                case Commons.NS_CONVERSION_SOURCE:
                    addNsConversionSource(builder);
                    break;
                case Commons.NS_RDIP_RELEASE_DATE:
                    addNsRdipReleaseDate(builder);
                    break;
                case Commons.NS_UNIFIED_TABLE:
                    addNsUnifiedTable(builder);
                    break;
                default:
                    addDefaultValue(builder, row, column);
            }
            if (idx == columnCount - 1) {
                builder.append(Commons.NEW_LINE);
            }
            else {
                builder.append(Commons.CTRL_A_CHAR);
            }
        }
        fileWriter.write(builder.toString());
        fileWriter.flush();
    }

    /**
     * appends ns_unified_tabel value
     *
     * @param builder string builder object for a row
     */
    private void addNsUnifiedTable(StringBuilder builder) {
        builder.append(datasetParam.getMappedDatasetName().toUpperCase());
    }

    /**
     * appends ns_rdip_release_date value
     *
     * @param builder string builder object for a row
     */
    private void addNsRdipReleaseDate(StringBuilder builder) {
        Object nsRdipReleaseDate = tableParam.getNsRdipReleaseDate();
        if (nsRdipReleaseDate != null) {
            builder.append(nsRdipReleaseDate);
        }
        else {
            builder.append(Commons.CTRL_B_CHAR);
        }
    }

    /**
     * appends ns_conversion_source value
     *
     * @param builder string builder object for a row
     */
    private void addNsConversionSource(StringBuilder builder) {
        Object nsConversionSource = tableParam.getNsConversionSource();
        if (nsConversionSource != null) {
            builder.append(nsConversionSource);
        }
        else {
            builder.append(Commons.CTRL_B_CHAR);
        }
    }

    /**
     * appends ns_dcoe_clinical_version
     *
     * @param builder string builder object for a row
     */
    private void addNsDcoeClinicalVersion(StringBuilder builder) {
        Object nsDcoeClinicalVersion = tableParam.getNsDcoeClinicalVersion();
        if (nsDcoeClinicalVersion != null) {
            builder.append(nsDcoeClinicalVersion);
        }
        else {
            builder.append(Commons.CTRL_B_CHAR);
        }
    }

    /**
     * appends ns_data_standard_version value
     *
     * @param builder string builder object for a row
     */
    private void addNsDataStandardVersion(StringBuilder builder) {
        Object nsDataStandardVersion = tableParam.getNsDataStandardVersion();
        if (nsDataStandardVersion != null) {
            builder.append(nsDataStandardVersion);
        }
        else {
            builder.append(Commons.CTRL_B_CHAR);
        }
    }

    /**
     * appends ns_convert_date value
     *
     * @param builder string builder object for a row
     */
    private void addNsConvertDate(StringBuilder builder) {
        Object nsConvertDate = tableParam.getNsConvertDate();
        if (nsConvertDate != null) {
            builder.append(nsConvertDate);
        }
        else {
            builder.append(Commons.CTRL_B_CHAR);
        }
    }

    /**
     * appends ns_source_dataset_columns
     *
     * @param builder string builder object for a row
     */
    private void addNsSourceDsetColumns(StringBuilder builder) {
        String nsSourceDsetColumns = String.join(",", tableParam.getSourceColumnsList());
        builder.append(nsSourceDsetColumns);
    }

    /**
     * appends ns_source_spectre_dset value
     *
     * @param builder string builder object for a row
     */
    private void addNsSourceSpectreDset(StringBuilder builder) {
        Object spectreDataset = tableParam.getSpectreDataset();
        if (spectreDataset != null) {
            builder.append(spectreDataset);
        }
        else {
            builder.append(Commons.CTRL_B_CHAR);
        }
    }

    /**
     * appends ns_source_dset_studyid value
     *
     * @param builder string builder object for a row
     */
    private void addNsSourceDsetStudyid(StringBuilder builder) {
        String studyID = tableParam.getStudyId().toUpperCase();
        builder.append(studyID);
    }

    /**
     * appends source value as is if not null. If null, appends CTRl B character
     *
     * @param builder string builder object for a row
     * @param row row
     * @param column column name
     */
    private void addDefaultValue(StringBuilder builder, HashMap<String, Object> row, String column) {
        Object val = row.get(column);
        if (val == null) {
            builder.append(Commons.CTRL_B_CHAR);
        }
        else {
            builder.append(val);
        }
    }

    /**
     * appends ns_source_dset value
     *
     * @param builder string builder object for a row
     */
    private void addNsSourceDset(StringBuilder builder) {
        String datasetRename = tableParam.getNsSourceDset().toString();
        builder.append(datasetRename);
    }

    /**
     * Generates and appends ns_tamr_pk value
     *
     * @param builder string builder object for a row
     * @param row row
     * @param rowId rowid of the row
     */
    private void addNsTamrPk(StringBuilder builder, HashMap<String, Object> row, int rowId) {
        String nsClinicalTrlFileid = null;
        String nsSourceDsetRowId;
        if (row.containsKey(Commons.NS_CLINICAL_TRL_FILEID)) {
            Object o = row.get(Commons.NS_CLINICAL_TRL_FILEID);
            if (o == null) {
                LOGGER.error("Table Name: {}", sourceTableName);
                LOGGER.error("Null ns_clinical_trl_fileid. Row: {}", row);
            }
            else {
                nsClinicalTrlFileid = o.toString();
            }
        }
        else {
            nsClinicalTrlFileid = tableParam.getNsClinicalTrlFileId().toString();
        }
        if (row.containsKey(Commons.NS_ROW_ID)) {
            nsSourceDsetRowId = row.get(Commons.NS_ROW_ID).toString();
        }
        else {
            nsSourceDsetRowId = String.valueOf(rowId + 1);
        }
        String tmp = nsClinicalTrlFileid + "-" + nsSourceDsetRowId;
        builder.append(tmp);
    }

    /**
     * appends ns_row_id if exists in source data, if not generates ns_row_id and appends
     *
     * @param builder string builder object for a row
     * @param row row
     * @param rowId rowId
     */
    private void addNsRowId(StringBuilder builder, HashMap<String, Object> row, int rowId) {
        Object val = row.get(Commons.NS_ROW_ID);
        if (val == null) {
            String nsSourceDsetRowId;
            if (row.containsKey(Commons.NS_ROW_ID)) {
                nsSourceDsetRowId = row.get(Commons.NS_ROW_ID).toString();
            }
            else {
                nsSourceDsetRowId = String.valueOf(rowId + 1);
            }
            String tmp = String.valueOf(datasetParam.getNsRowIdStartingIndexMap(sourceTableName) +
                    Integer.parseInt(nsSourceDsetRowId));
            builder.append(tmp);
        }
        else {
            String nsSourceDsetRowId = row.get(Commons.NS_ROW_ID).toString();
            String nsRowId = String.valueOf(datasetParam.getNsRowIdStartingIndexMap(sourceTableName) +
                    Integer.parseInt(nsSourceDsetRowId));
            builder.append(nsRowId);
        }
    }


    /**
     * if source data has any seq column then appends it as ns_source_dset_seq
     *
     * @param builder string builder object for a row
     * @param row row
     */
    private void addNsSourceDsetSeq(StringBuilder builder, HashMap<String, Object> row) {
        // key ns_source_dset_seq will have name of the seq column in the dataset
        String finalValue;
        Object seqColumnName = tableParam.getSeqColumn();
        if (seqColumnName != null) {
            finalValue = row.get(seqColumnName.toString()).toString();
            Object profileDtype = tableParam.getSeqColumnDtype();
            if (profileDtype != null && profileDtype.toString().equalsIgnoreCase("INT")) {
                finalValue = String.valueOf(Math.round(Double.parseDouble(finalValue)));
            }
            builder.append(finalValue);
        }
        else {
            builder.append(Commons.CTRL_B_CHAR);
        }
    }

    /**
     * appends ns_clinical_trl_fileid value
     *
     * @param builder string builder object for a row
     */
    public void addClinicalTrlFileid(StringBuilder builder) {
        String nsClinicalTrlFileid = tableParam.getNsClinicalTrlFileId().toString();
        builder.append(nsClinicalTrlFileid);
    }

    /**
     * If ns_row_id exists in source table then appends it as ns_source_dset_rowid
     * else generates and appends
     *
     * @param builder string builder object for a row
     * @param row row
     * @param rowId rowId
     */
    private void addNsSourceDsetRowId(StringBuilder builder, HashMap<String, Object> row, int rowId) {
        String nsSourceDsetRowId;
        if (row.containsKey(Commons.NS_ROW_ID)) {
            if (row.get(Commons.NS_ROW_ID) == null) {
                builder.append(Commons.CTRL_B_CHAR);
            }
            else {
                nsSourceDsetRowId = row.get(Commons.NS_ROW_ID).toString();
                builder.append(nsSourceDsetRowId);
            }
        }
        else {
            nsSourceDsetRowId = String.valueOf(rowId + 1);
            builder.append(nsSourceDsetRowId);
        }
    }


    /**
     * Adds the non standard metadata to table metadata
     *
     * @param datasetParam unified params
     * @param tableParam   source table params
     */
    public void appendNsMetadata(DatasetParam datasetParam, TableParam tableParam) {
        List<Map<String, Object>> datasetNsColumnConfig = datasetParam.getNsMetadata();
        List<Map<String, Object>> tableMetadata = tableParam.getTableMetadata();
        List<String> sourceColumnsList = tableParam.getSourceColumnsList();
        Map<String, List<Map<String, Object>>> nsColumnsGroupByVarName = datasetNsColumnConfig.stream()
                .collect(Collectors.groupingBy(m -> m.get(Commons.VAR_NAME).toString()));
        for (Map<String, Object> map : tableMetadata) {
            String varName = map.get(Commons.VAR_NAME).toString();
            if (nsColumnsGroupByVarName.containsKey(varName)) {
                map.putAll(nsColumnsGroupByVarName.get(varName).get(0));
            }
        }
        Map<String, Object> firstRow = tableMetadata.get(0);
        for (Map<String, Object> map : datasetNsColumnConfig) {
            String varName = map.get(Commons.VAR_NAME).toString();
            if (!sourceColumnsList.contains(varName)) {
                HashMap<String, Object> temp = new HashMap<>();
                temp.putAll(firstRow);
                temp.putAll(map);
                tableMetadata.add(temp);
            }
        }
    }
}
