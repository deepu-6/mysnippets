/*
 * Copyright 2021 GlaxoSmithKline LLC
 */

package com.gsk.rd.unification.unify;

import com.gsk.rd.unification.builders.DatasetParam;
import com.gsk.rd.unification.builders.ProcessParam;
import com.gsk.rd.unification.builders.TableParam;
import com.gsk.rd.unification.postvalidation.PostValidation;
import com.gsk.rd.utils.Commons;
import com.gsk.rd.utils.Helper;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.stringtemplate.v4.STGroup;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.management.ManagementFactory;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

public class Unification {

    private static final Logger LOGGER = LogManager.getLogger(Unification.class.getSimpleName());
    private final List<Map<String, Object>> preValidationOutput;
    private final ProcessParam processParam;
    private final Helper helper = Helper.getInstance();
    private final STGroup templateGroup;
    private final HikariDataSource postgresDataSource;
    private final HikariDataSource hiveDataSource;

    public Unification(List<Map<String, Object>> preValidationOutput, ProcessParam processParam) {

        this.preValidationOutput = preValidationOutput;
        this.processParam = processParam;
        this.templateGroup = processParam.getTemplateGroup();
        this.postgresDataSource = processParam.getPostgresDataSource();
        this.hiveDataSource = processParam.getHiveDataSource();
    }

    public void run() {
        Map<String, List<Map<String, Object>>> metadataByDatasetType = preValidationOutput.stream()
                .collect(Collectors.groupingBy(map -> map.get(Commons.DATASET_TYPE).toString()));
        Set<String> datasetTypes = metadataByDatasetType.keySet();
        for (String datasetType : datasetTypes) {
            Map<String, Long> mappedDatasetByTableCount = getMappedDatasetsByTableCount(datasetType,
                    metadataByDatasetType);
            for (String mappedDatasetName : mappedDatasetByTableCount.keySet()) {
                List<Map<String, Object>> mappedDatasetMetadata = metadataByDatasetType
                        .get(datasetType)
                        .stream()
                        .filter(m -> m.get(Commons.MAPPED_DATASET).toString().equalsIgnoreCase(mappedDatasetName))
                        .collect(Collectors.toList());
                HashMap<String, String> rowCountMap = mappedDatasetMetadata.stream()
                        .map(this::getTableIdRowCount)
                        .distinct()
                        .filter(m -> !m.get(Commons.ROW_COUNT).toString().equals("0"))
                        .collect(Collectors.toMap(
                                m -> m.get(Commons.CLINICAL_TRL_FILEID).toString(),
                                m -> m.get(Commons.ROW_COUNT).toString(),
                                (v1, v2) -> v1, HashMap::new));
                HashMap<String, String> unifyOutput = unifyMappedDataset(datasetType, mappedDatasetName, mappedDatasetMetadata);
                if (!unifyOutput.isEmpty()) {
                    PostValidation postValidation = new PostValidation(processParam, unifyOutput, rowCountMap);
                    String validationStatus = postValidation.run();
                    insertUnifyOutput(unifyOutput, validationStatus);
                }
            }
        }
    }

    /**
     * inserts unification output
     *
     * @param processOutput    core process output map
     * @param validationOutput validation check flag
     */
    private void insertUnifyOutput(HashMap<String, String> processOutput, String validationOutput) {
        try {
            String vmName = ManagementFactory.getRuntimeMXBean().getName();
            int p = vmName.indexOf("@");
            String pid = vmName.substring(0, p);
            String userName = System.getProperty(Commons.SYSTEM_USER_NAME);
            String startTime = processOutput.get(Commons.START_TS);
            String endTime = processOutput.get(Commons.END_TS);
            String unifiedTableName = processOutput.get(Commons.UNIFIED_TABLENAME);
            String mappedDatasetName = processOutput.get(Commons.MAPPED_DATASET);
            String tableVersion = processParam.getConfig().get("unified_tablename_suffix").toString();
            String baseUnifiedTableName = unifiedTableName.replace(tableVersion, "");
            String outputQuery = templateGroup.getInstanceOf("unified_table_output")
                    .add(Commons.PID, pid)
                    .add(Commons.START_TS, startTime)
                    .add(Commons.END_TS, endTime)
                    .add(Commons.JOB_USER, userName)
                    .add("validation", validationOutput)
                    .add(Commons.TARGET_TABLE_NAME, unifiedTableName).render();
            helper.executeUpdateQuery(postgresDataSource, outputQuery);
            if (validationOutput.equalsIgnoreCase("pass")) {
                String updateValidityOfDataset = templateGroup.getInstanceOf("batch_unified_update")
                        .add(Commons.BATCH_ID, processParam.getBatchId())
                        .add(Commons.BASE_UNIFIED_TABLE_NAME, baseUnifiedTableName).render();
                LOGGER.debug(updateValidityOfDataset);
                helper.executeUpdateQuery(postgresDataSource, updateValidityOfDataset);
                String batchUnifiedInsert = templateGroup.getInstanceOf("batch_unified_insert")
                        .add(Commons.BATCH_ID, processParam.getBatchId())
                        .add("base_dataset_name", mappedDatasetName)
                        .add("table_version", tableVersion.replaceFirst("_", ""))
                        .add(Commons.BASE_UNIFIED_TABLE_NAME, baseUnifiedTableName)
                        .add("full_unified_table_name", unifiedTableName).render();
                LOGGER.debug(batchUnifiedInsert);
                helper.executeUpdateQuery(postgresDataSource, batchUnifiedInsert);
            }
        }
        catch (Exception e) {
            LOGGER.error("", e);

        }
    }

    /**
     * Main method for unification of a mapped dataset
     *
     * @param datasetType           dataset type (si/ar/sdtm)
     * @param mappedDatasetName     mapped dataset name for the source datasets
     * @param mappedDatasetMetadata prevalidation output for a mapped dataset
     * @return returns map with output details of unification that can be used for postvalidation
     */
    private HashMap<String, String> unifyMappedDataset(String datasetType,
                                                       String mappedDatasetName,
                                                       List<Map<String, Object>> mappedDatasetMetadata) {
        ExecutorService executorService = null;
        DatasetParam datasetParam = null;
        boolean stagingTableCreated = false;
        String startTime = new Timestamp(System.currentTimeMillis()).toString();
        try {
            LOGGER.info("UNIFICATION STARTED FOR : {}", mappedDatasetName);
            int threadCount = processParam.getThreadCount();
            executorService = Executors.newFixedThreadPool(threadCount);
            String tmp = mappedDatasetName;
            if (datasetType.equalsIgnoreCase("ar") && mappedDatasetName.startsWith("ar_")) {
                tmp = mappedDatasetName.replaceFirst("ar_", "");
            }

            String stagingTableName = templateGroup.getInstanceOf("get_staging_tablename")
                    .add(Commons.MAPPED_DATASET, tmp)
                    .add(Commons.DATASET_TYPE, datasetType)
                    .add(Commons.PROCESS_CONFIG, processParam.getConfig()).render();
            LOGGER.debug(stagingTableName);

            String unifiedTableName = templateGroup.getInstanceOf("get_unified_tablename")
                    .add(Commons.MAPPED_DATASET, tmp)
                    .add(Commons.DATASET_TYPE, datasetType)
                    .add(Commons.PROCESS_CONFIG, processParam.getConfig()).render();
            LOGGER.debug(unifiedTableName);

            String prevUnifiedTableName = templateGroup.getInstanceOf("get_prev_unified_tablename")
                    .add(Commons.MAPPED_DATASET, tmp)
                    .add(Commons.DATASET_TYPE, datasetType)
                    .add(Commons.PROCESS_CONFIG, processParam.getConfig()).render();
            LOGGER.debug(prevUnifiedTableName);

            Map<String, List<Map<String, Object>>> metadataByTable = mappedDatasetMetadata.stream()
                    .collect(Collectors.groupingBy(m -> m.get(Commons.TABLE_NAME).toString()));
            Map<String, Integer> nsRowIdStartingIndexMap = getNsRowIdIndexMap(metadataByTable.keySet());

            datasetParam = new DatasetParam.DatasetParamBuilder(mappedDatasetName,
                    datasetType,
                    mappedDatasetMetadata,
                    processParam)
                    .addNsRowIdIndexMap(nsRowIdStartingIndexMap)
                    .setNSMetadata()
                    .addUnifiedDDLMap()
                    .addStagingTableName(stagingTableName)
                    .addUnifiedTableName(unifiedTableName)
                    .addPrevUnifiedTableName(prevUnifiedTableName)
                    .build();

            createStagingTable(datasetParam);
            stagingTableCreated = true;
            LOGGER.info("STAGING TABLE CREATED: {}", stagingTableName);
            for (Map.Entry<String, List<Map<String, Object>>> entry : metadataByTable.entrySet()) {
                String sourceTableName = entry.getKey();
                List<Map<String, Object>> tableMetadata = entry.getValue();
                TableParam tableParam = new TableParam.TableParamBuilder(sourceTableName,
                        tableMetadata,
                        datasetParam,
                        processParam, templateGroup)
                        .setRowCount()
                        .setDataset()
                        .setStudyid()
                        .setSpectreDataset()
                        .setSourceTableColumns()
                        .setTableNameWithoutDB()
                        .setSourceTableColumns()
                        .setSourceTableDDLMap()
                        .setFlatFilePath()
                        .setHdfsFilePath()
                        .setNsRdipReleaseDate()
                        .setNsConversionSource()
                        .setNsDcoeClinicalVersion()
                        .setNsDataStandardVersion()
                        .setNsConvertDate()
                        .setNsSourceDset()
                        .setNsClinicalTrlFileId()
                        .checkAndSetSeqColumn()
                        .build();
                executorService.submit(new UnificationRunnable(tableParam, datasetParam, processParam));
            }
        }
        catch (Exception e) {
            LOGGER.error("{} : failed mapped dataset unify", mappedDatasetName, e);
            helper.jobException(e, templateGroup, postgresDataSource);
        }
        finally {
            if (executorService != null) {
                try {
                    executorService.shutdown();
                    boolean b = executorService.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
                    LOGGER.debug("All Threads are complete: {}", b);
                }
                catch (Exception e) {
                    String exceptionMessage = "Unable to shutdown executor service";
                    LOGGER.error(exceptionMessage, e);
                    Exception e1 = new Exception(e.getMessage() + " - " + exceptionMessage);
                    e1.setStackTrace(e.getStackTrace());
                    StringWriter tmp = new StringWriter();
                    e1.printStackTrace(new PrintWriter(tmp));
                    String exception = tmp.toString();
                    helper.jobException(exception, templateGroup, postgresDataSource);
                }
            }
        }
        HashMap<String, String> unifiedOutput = new HashMap<>();
        if (stagingTableCreated) {
            boolean unifiedCreated = createUnifiedTable(datasetParam);
            LOGGER.info("Unified table created: {}", unifiedCreated);
            if (unifiedCreated) {
                String endTime = new Timestamp(System.currentTimeMillis()).toString();
                unifiedOutput.put(Commons.UNIFIED_TABLENAME, datasetParam.getUnifiedTableName());
                unifiedOutput.put(Commons.MAPPED_DATASET, mappedDatasetName);
                unifiedOutput.put(Commons.START_TS, startTime);
                unifiedOutput.put(Commons.END_TS, endTime);
            }
        }
        return unifiedOutput;
    }

    /**
     * creates unified table in Hive. It looks for previous unified tablename and
     * if exists creates the unified table adding columns which are not there in the current batch
     * but exists in previous unified
     *
     * @param datasetParam DatasetParam object created for a mapped/unified dataset
     * @return returns boolean true/false based on table creation status
     */
    private boolean createUnifiedTable(DatasetParam datasetParam) {
        boolean unifiedCreated = false;
        try {
            Map<String, String> stagingTableDDLMap = datasetParam.getUnifiedDDLMap();
            List<String> stagingTableColumns = datasetParam.getUnifiedColumnsList(stagingTableDDLMap);
            String showTablesQuery = templateGroup.getInstanceOf("show_tables_query")
                    .add("db", datasetParam.getPrevUnifiedTableName().split("\\.")[0])
                    .add("tb", datasetParam.getPrevUnifiedTableName().split("\\.")[1]).render();


            LOGGER.debug(showTablesQuery);
            List<HashMap<String, Object>> showTablesResult = helper.executeQuery(hiveDataSource, showTablesQuery);
            boolean prevUnifiedExists = false;

            Map<String, String> finalUnifiedDDLMap;
            List<String> finalUnifiedColumnsList = new ArrayList<>(stagingTableColumns);
            HashMap<String, String> prevUnifiedDDLMap = new HashMap<>();

            if (!showTablesResult.isEmpty()) {
                prevUnifiedExists = true;
                String describePrevUnifiedQuery = templateGroup.getInstanceOf("describe_query")
                        .add(Commons.TABLE_NAME, datasetParam.getPrevUnifiedTableName()).render();
                LOGGER.debug(describePrevUnifiedQuery);
                List<HashMap<String, Object>> describeResult = helper.executeQuery(hiveDataSource, describePrevUnifiedQuery);
                for (HashMap<String, Object> map : describeResult) {
                    String varName = map.get(Commons.COL_NAME).toString().toLowerCase();
                    String varDtype = map.get(Commons.DATA_TYPE).toString().toLowerCase();
                    if (!finalUnifiedColumnsList.contains(varName)) {
                        finalUnifiedColumnsList.add(varName);
                    }
                    prevUnifiedDDLMap.put(varName, varDtype);
                }
                List<Map<String, Object>> config = getConfig(datasetParam);
                // creates a map final DDL map with only variables that are in config
                finalUnifiedDDLMap = config.stream()
                        .sorted(Comparator.comparing(map -> Integer.parseInt(map.get(Commons.VAR_ORDER).toString())))
                        .filter(m -> finalUnifiedColumnsList.contains(m.get(Commons.VAR_NAME).toString()))
                        .collect(Collectors.toMap(
                                map -> map.get(Commons.VAR_NAME).toString().toLowerCase(),
                                map -> map.get(Commons.VAR_DTYPE).toString().toLowerCase(),
                                (v, v1) -> v,
                                LinkedHashMap::new));
            }
            else {
                finalUnifiedDDLMap = datasetParam.getUnifiedDDLMap();
            }

            String dropQuery = templateGroup.getInstanceOf("drop_table")
                    .add(Commons.TABLE_NAME, datasetParam.getUnifiedTableName()).render();
            String createQuery = templateGroup.getInstanceOf("create_unified_table")
                    .add("cols_types", finalUnifiedDDLMap)
                    .add(Commons.TABLE_NAME, datasetParam.getUnifiedTableName()).render();

            LOGGER.debug(Commons.LOG_SEPARATOR);
            LOGGER.debug(dropQuery);
            helper.executeUpdateQuery(hiveDataSource, dropQuery);
            LOGGER.debug(createQuery);
            helper.executeUpdateQuery(hiveDataSource, createQuery);
            LOGGER.info("unified table dropped and created");
            LOGGER.debug(Commons.LOG_SEPARATOR);

            String prevUnifiedInsertQuery = templateGroup.getInstanceOf("insert_prev_unified")
                    .add("staging_table_name", datasetParam.getStagingTableName())
                    .add("unified_table_name", datasetParam.getUnifiedTableName())
                    .add("prev_unified_table_name", datasetParam.getPrevUnifiedTableName())
                    .add("total_columns_list", finalUnifiedDDLMap.keySet())
                    .add("prev_unified_ddl_map", prevUnifiedDDLMap)
                    .render();
            String stagingInsertQuery = templateGroup.getInstanceOf("insert_staging_unified")
                    .add("staging_table_name", datasetParam.getStagingTableName())
                    .add("unified_table_name", datasetParam.getUnifiedTableName())
                    .add("total_columns_list", finalUnifiedDDLMap.keySet())
                    .add("staging_unified_ddl_map", stagingTableDDLMap)
                    .render();

            LOGGER.debug(stagingInsertQuery);
            helper.executeUpdateQuery(hiveDataSource, stagingInsertQuery);
            LOGGER.info("staging unified data is inserted");
            LOGGER.debug(Commons.LOG_SEPARATOR);

            if (prevUnifiedExists) {
                LOGGER.debug(prevUnifiedInsertQuery);
                helper.executeUpdateQuery(hiveDataSource, prevUnifiedInsertQuery);
                LOGGER.info("Previous unified data is inserted");
                LOGGER.debug(Commons.LOG_SEPARATOR);
            }
            unifiedCreated = true;
        }
        catch (Exception e) {
            LOGGER.error("", e);
            helper.jobException(e, templateGroup, postgresDataSource);
        }
        return unifiedCreated;
    }

    /**
     * reads configuration of the mapped dataset based on dataset type
     *
     * @param datasetParam DatasetParam object created for a mapped/unified dataset
     * @return returns configuration of the mapped dataset
     */
    public List<Map<String, Object>> getConfig(DatasetParam datasetParam) {
        List<Map<String, Object>> config;
        String datasetType = datasetParam.getDatasetType();
        String mappedDatasetName = datasetParam.getMappedDatasetName();
        if (datasetType.equalsIgnoreCase("SDTM")) {
            if (mappedDatasetName.toLowerCase().startsWith("supp") ||
                    mappedDatasetName.toLowerCase().startsWith("sc_supp")) {
                mappedDatasetName = "supp";
            }
            config = processParam.getSdtmConfigByDsetOrig(mappedDatasetName);
        }
        else {
            config = processParam.getSiArConfigByDsetOrig(mappedDatasetName);
        }
        return config;
    }

    /**
     * Drop creates staging table
     *
     * @param datasetParam mapped dataset params
     */
    public void createStagingTable(DatasetParam datasetParam) throws SQLException {
        String dropStagingTableQuery = templateGroup.getInstanceOf("drop_table")
                .add(Commons.TABLE_NAME, datasetParam.getStagingTableName()).render();
        String createStagingTableQuery = templateGroup.getInstanceOf("create_staging_table")
                .add("columns_types_map", datasetParam.getUnifiedDDLMap())
                .add(Commons.TABLE_NAME, datasetParam.getStagingTableName()).render();
        helper.executeUpdateQuery(hiveDataSource, dropStagingTableQuery);
        LOGGER.info("DROPPED STAGING TABLE: {}", datasetParam.getStagingTableName());
        helper.executeUpdateQuery(hiveDataSource, createStagingTableQuery);
        LOGGER.info("CREATED STAGING TABLE: {}", datasetParam.getStagingTableName());
    }

    /**
     * Generates the ns_row_id starting value
     * <p>
     * ns_row_id for multipart datasets should be linear hence the starting index is created to be used as reference
     * while generating ns_row_id for each source dataset
     *
     * @param tablesList input tables list
     * @return returns a map with tablename as key and starting index to be used for generating ns_row_id
     * @throws SQLException raises an exception when the query fails
     * @throws NullPointerException throws NullPointerExcception if any object is null
     */
    public Map<String, Integer> getNsRowIdIndexMap(Set<String> tablesList) throws SQLException, NullPointerException {
        Map<String, Integer> indexMap;
        String getIndexQuery = templateGroup.getInstanceOf("get_ns_row_id_index")
                .add("tables_list", tablesList)
                .add(Commons.BATCH_ID, processParam.getBatchId())
                .render();
        LOGGER.debug(getIndexQuery);
        List<HashMap<String, Object>> indexListMap = helper.executeQuery(postgresDataSource, getIndexQuery);
        indexMap = indexListMap.stream()
                .collect(Collectors.toMap(m -> m.get(Commons.TABLE_NAME).toString(),
                        m -> Integer.parseInt(m.get("starting_index").toString()),
                        (v1, v2) -> v1, HashMap::new));
        return indexMap;
    }

    /**
     * Sorts the input tables metadata grouped by mapped dataset and dataset type ordered by table count.
     * <p>
     * Grouping is done by a new key generated by combining dataset type and mapped dataset and then the result
     * is sorted by table count
     * also see {@link Unification#getTableNameMappedDataset(Map)} (Map)} which would filter the keys needed to do the grouping
     *
     * @param metadataByDatasetType input tables metadata grouped by dataset type
     * @param datasetType           dataset type
     * @return returns sorted mapped dataset and its table count linked hashmap
     */
    public Map<String, Long> getMappedDatasetsByTableCount(String datasetType, Map<String,
            List<Map<String, Object>>> metadataByDatasetType) {
        LOGGER.info("Dataset type: {}", datasetType);
        Map<String, Long> mappedDatasetOrderByTableCount;
        mappedDatasetOrderByTableCount = metadataByDatasetType.get(datasetType).stream()
                .map(this::getTableNameMappedDataset)
                .distinct()
                .collect(Collectors.groupingBy(m -> m.get(Commons.MAPPED_DATASET).toString(),
                        Collectors.counting()))
                .entrySet()
                .stream()
                .sorted(Map.Entry.<String, Long>comparingByValue().reversed())
                .collect(
                        Collectors.toMap(Map.Entry::getKey,
                                Map.Entry::getValue,
                                (k1, k2) -> k2,
                                LinkedHashMap::new)
                );
        return mappedDatasetOrderByTableCount;
    }

    /**
     * Filters the columns in mapped dataset metadata for grouping
     *
     * @param rowInMetadata A row in mapped dataset metadata
     * @return returns a new Map with only the desired columns
     */
    public Map<String, Object> getTableNameMappedDataset(Map<String, Object> rowInMetadata) {
        List<String> columnsToFilter = Arrays.asList(Commons.TABLE_NAME, Commons.MAPPED_DATASET);
        return rowInMetadata.entrySet()
                .stream()
                .filter(entry -> columnsToFilter.contains(entry.getKey()))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
    }

    /**
     * Filters the columns in mapped dataset metadata for grouping
     *
     * @param rowInMetadata A row in mapped dataset metadata
     * @return returns a new Map with only the desired columns
     */
    public Map<String, Object> getTableIdRowCount(Map<String, Object> rowInMetadata) {
        List<String> columnsToFilter = Arrays.asList(Commons.CLINICAL_TRL_FILEID, Commons.ROW_COUNT);
        return rowInMetadata.entrySet()
                .stream()
                .filter(entry -> columnsToFilter.contains(entry.getKey()))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
    }
}
